# ComfyUI基础镜像常见问题解答（持续更新中）

# 写在前面，如何智慧提问：

在售后技术咨询群提问时注意不要提无效问题，比如：

**以下提问没有任何可诊断问题的实际信息，服务人员无法对症下药帮你解决问题，浪费大家的时间：**

我怎么跑不了图？

我怎么爆显存了？

ComfyUI打不开了！

插件装不上去！

模型加载不了！

等等

智慧的提问应该含有**问题的描述**，**具体症状**以及后**台终端详细的日志**（获取日志方法先见后续3\.章节），以上都需要截图发送在群里，注意截图截全，最好全屏，你觉得不重要的信息极有可能却是问题关键！不要直接拷贝日志的文本发送到聊天框，文本结构的改变会导致日志分析变得更加困难！

**另外，使用镜像作者的社区镜像碰到的问题，最好联系客服进相关作者群提问，优云官方客服不可能了解所有的社区镜像的问题，有些问题可能需要作者和优云技术人员一起解决！**

# 如何上传及下载文件：

详见以下文档5\.7章节：

[优云智算镜像作者指南（Linux环境篇）](https://compshare.feishu.cn/wiki/JE9ZwssDmiQMbSkBlRec9pbSnPb?fromScene=spaceOverview)

# 如何查找ComfyUI后台日志的位置和查看：

对于官方ComfyUI基础镜像，日志位置在/root/ComfyUI/comfy\.log，双击即可打开查看，如下图：

![image\.png](图片和附件/image%2015.png)

其他ComfyUI镜像，如果上述位置没有，那么大多在/root/ComfyUI/user/下面，时间最新的既是，同样是双击打开查看，如下图：

![image\.png](图片和附件/image%201.png)

日志打开后如下图所示：

![image\.png](图片和附件/image%2012.png)

# 如何打开新版插件管理器（Manager）：

官方新版管理器改名为管理扩展功能，可以点击界面左上角ComfyUI图标然后再点击管理扩展功能打开，如下图：

![image\.png](图片和附件/image.png)

也可以点击界面上方的拼图图标打开，如下图：

![image\.png](图片和附件/image%206.png)

打开后如下图所示：

![image\.png](图片和附件/image%209.png)

# 如何把新版管理器切换到旧版：

由于好多用户还不适应ComfyUI新版管理器，官方提供了切换到旧版的方法，打开ComfyUI启动脚本，位置在/start\.d/comfyui\.sh，可双击打开，如下图：

![image\.png](图片和附件/image%203.png)

打开后删除\-\-enable\-manager这条参数，然后按ctrl\+s保存一下启动脚本，再重启ComfyUI或者实例，启动完成后刷新一下ComfyUI主页即可还原到旧版Manager，如下图：

![image\.png](图片和附件/image%205.png)

其他ComfyUI镜像请自行查找启动脚本（可能文件名不同但是位置相同），或者联系作者询问启动脚本位置！

# 如何解决新版管理器由于所谓安全限制无法安装部分插件的方法：

使用新版管理器后，安装部分插件会显示如下报错：

```Plain Text
ERROR: To use this action, security_level must be `normal or below`, and network_mode must be set to `personal_cloud`. Please contact the administrator.
Reference: https://github.com/ltdrdata/ComfyUI-Manager#security-policy

After restarting ComfyUI, please refresh the browser.
```

这是由于ComfyUI官方基于安全因素，缺省将安全级别提高，防止有非官方注册的恶意插件安装运行，但同时也导致了大量比较老的插件无法在新版管理器安装，解决方法如下：

找到config\.ini，一般是在ComfyUI根目录，如果没有，那就是在/root/ComfyUI/user/\_manager/下，如下图所示：

![image\.png](图片和附件/image%2017.png)

双击打开后，将security\_level = 后的normal改为weak，network\_mode = 后的public改为personal\_cloud，如下图所示，改完后按ctrl\+s保存，然后重启ComfyUI或者实例，重启完成后刷新ComfyUI主页面即可安装非官方注册插件了：

![image\.png](图片和附件/image%2016.png)

# （强烈推荐！）如何手动在终端窗口安装插件：

由于ComfyUI新版管理器实在是太不智能化，插件安装后，不管是不是安装成功都显示“已安装完成，请重启ComfyUI”，所以强烈建议所有插件都在终端手动git clone并且手动安装依赖：

如果新版管理器还是不能安装的插件，可以在终端窗口用命令行手动安装，方法如下：

首先打开一个新的终端窗口：

![image\.png](图片和附件/image%208.png)

然后在新建的终端窗口导航到ConfyUI插件目录：

```Plain Text
cd /root/ComfyUI/custom_nodes
```

![image\.png](图片和附件/image%204.png)

然后用git clone命令安装插件，比如我们要安装crystools插件，先找到crystools的G站项目地址，然后输入以下命令行：

```Plain Text
git clone https://github.com/crystian/ComfyUI-Crystools
```

接着导航到该插件目录，然后手动安装一下依赖：

```Plain Text
cd /root/ComfyUI/custom_nodes/ComfyUI-Crystools
pip install -r requirements.txt
```

安装完成后重启ComfyUI或者实例，待启动完毕再刷新一下ComfyUI主页面即可，注意，手动安装插件可能导致依赖冲突或者环境损坏，请事先使用保存镜像、导出重要数据等方法做好备份工作！

# （强烈推荐！）如何手动在终端窗口更新ComfyUI本体和插件：

无法在管理器更新ComfyUI本体和插件的可以在终端窗口用手动方式更新，方法如下：

```Plain Text
cd /root/ComfyUI #导航到ComfyUI安装目录，非官方基础镜像请自行查找相应的安装目录并替换绝对路径
git pull #拉取ComfyUI最新的版本
pip install -r requirements.txt #安装最新的环境依赖
```

```Plain Text
cd /root/ComfyUI/custom_nodes/需要更新的插件目录 #导航到需要更新的插件目录
git pull #拉取插件最新的版本
pip install -r requirements.txt #安装最新的环境依赖（有些插件可能不需要）
```

完成以上两种操作后需要重启ComfyUI或者实例才能生效，如果不想重启实例，并且新版管理器无法重启ComfyUI的话，可以在终端窗口用以下命令行手动终止和启动ComfyUI：

```Plain Text
pkill -f main.py #强制终止ComfyUI的Python进程
bash /stard.d/comfyui.sh #运行ComfyUI启动脚本（非官方基础镜像请自行查找启动脚本的位置和文件名）
```

# 如何解决部分老插件不适用新版ComfyUI的问题：

因为新版ComfyUI界面使用了vue\.js架构，部分老插件可能不支持该架构导致无法使用，可以暂时关闭Nodes 2\.0功能，方法是点击左上角ComfyUI图标，然后点击Nodes 2\.0测试版的开关，如下图：

![image\.png](图片和附件/image%2014.png)

但是因为ComfyUI整体架构都改了，使用此方法暂时关闭Nodes 2\.0也无法解决所有老插件的兼容问题，请等待插件作者更新或者替换成等效节点！

# 如何解决ComfyUI主界面左键长按空白处拖动画布失效的问题：

有部分用户发现原来的左键长按空白处拖动画布的功能失效的问题，解决方法如下：

点击左上角ComfyUI图标，然后点击设置，如下图：

![image\.png](图片和附件/image%2011.png)

在打开的设置菜单选择画面标签，然后点击画布导航模式，改为拖动画布即可（不用重启），如下图：

![image\.png](图片和附件/image%207.png)

# 如何解决checkpoints为jupyter保留字串而导致jupyter左方文件管理板块无法访问的问题：

最新版的ComfyUI官方基础镜像已在/root/ComfyUI/models/路径下新建了一个ckpt文件夹，并通过配置文件映射为和checkpoints等效的文件夹，以后可以直接访问ckpt文件夹上传和下载模型等文件，如下图所示：

![image\.png](图片和附件/image%2013.png)

当然你也可以用优云自带的web版文件管理器来操作，详见前文2\.章节

# 如何使用VSCode代替jupyter开发环境：

最新版的ComfyUI基础镜像已经内置微软的VSCode开发环境，并且安装了腾讯的CodeBuddy和阿里的灵码AI编程IDE插件，可以轻松使用各种AI自动化工具解决实例问题甚至自行开发独立项目，如下图所示：

![image\.png](图片和附件/image%202.png)

![image\.png](图片和附件/image%2010.png)

但是由于优云实例的外网地址都是非https协议的，而VScode强依赖https，所以无法使用插件等加强功能，所以要在本地浏览器改一下设置。具体方法如下：

1. 谷歌浏览器

地址栏输入：chrome://flags 进入谷歌浏览器实验页面，如图： 

![LX16bqpCHoAxuKxzGA1caFf2nIb\.jpg](图片和附件/LX16bqpCHoAxuKxzGA1caFf2nIb.jpg)

搜索框搜索 Insecure origins treated as secure 找到并启用该选项，并在输入框输入你code\-server地址（http://您打开实例的外网地址:7860），然后右侧下拉框选择Enabled，如下图所示（注意端口号不是图片所示的8081，而是7860）： 

![Otd2bDV0qo1s1bxdg8EcV1qTn1c\.jpg](图片和附件/Otd2bDV0qo1s1bxdg8EcV1qTn1c.jpg)

2. Edge浏览器

第一步只需要将 chrome://flags 改为 edge://flags，其他步操作均一致



**无论哪种启浏览器，设置完成后请完全关闭再打开才会生效！然后重新打开实例VSCode页面后，将地址栏开头http改为https即可！**

# 写在最后：最近ComfyUI频繁更新，并且改动很大，建议各位用户关注ComfyUI官方公众号以接收最新的教程和信息，方法为在微信公众号搜索“ComfyUI中文”并关注。

