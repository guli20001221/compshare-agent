# 优云智算使用问题FAQ

本FAQ仅包含GPU实例相关内容，CodingPlan服务请前往[优云智算模型套餐FAQ](https://compshare.feishu.cn/wiki/T9GWwVtj4iXoTJkGuj8cRrtYnog)

### GPU实例常见问题解答

## 实例相关 \-\- 卡初始化、启动失败、GPU使用等问题

#### 实例卡初始化或卡启动中

> 容器启动失败，或者容器环境在使用中被破环，会导致实例卡初始化或卡启动中，处理请加群联系群主
> 
> ![contact\_me\_qr\.png](图片和附件/contact_me_qr%202.png)
> 
> 

#### 实例常见错误码

> 错误代码8357:资源不足，当前资源售罄，可以多刷新几次或者稍后购买
> 
> 错误代码8095:配额不足，加官方群联系运营同学增加配额
> 
> 错误代码8429:云主机资源已过期，请前往订单管理中手动支付欠费清单即可恢复
> 
> 

#### 容器实例如何设置服务自启动

> 可以在/start\.d/目录下创建一个可执行的bash脚本，容器开机自动运行
> 
> ![image\.png](图片和附件/image.png)
> 
> 

#### Windows环境检测不到GPU

> 由于不同配置、卡型驱动不同，Windows环境需要用户在购买后自行安装显卡驱动，驱动下载地址：
> 
> 登录英伟达官网下载驱动程序：[下载最新版官方 GeForce 驱动程序](https://www.nvidia.cn/geforce/drivers/) 
> 
> [NVIDIA驱动安装和CUDA安装\.pdf](https://iadagxzituk.feishu.cn/wiki/Ptzhwx9oKigAcLkQp0FcKuu4nbe?from=from_copylink)
> 
> 

#### Windows镜像如何远程登录操作

> Windows镜像推荐使用本地电脑自带的远程桌面链接工具，使用方便不卡顿，教程如下：
> 
> [Windows服务器远程登录操作手册\.pdf](图片和附件/Windows服务器远程登录操作手册.pdf)
> 
> 

#### Windows镜像如何远程播放声音

> [远程windows云服务器开启声音\.pdf](图片和附件/远程windows云服务器开启声音.pdf)
> 
> 

#### Windows远程链接不上或服务器没外网，但是VNC链接可以

> 机器内网DNS没有获取到，需要通过VNC登录修改内网DNS，路径如下
> 
> ![image\.png](图片和附件/image%2011.png)
> 
> IP地址修改为自己服务器对应的内网IP
> 
> ![image\.png](图片和附件/image%206.png)
> 
> 

#### 基础镜像如何查看GPU、CPU\&内存、磁盘信息

> GPU:
> 
> 第一步：输入 nvidia\-smi 查看显卡信息，若无，需要重装驱动，参考第二步
> 
> 第二步：登录英伟达官网下载驱动程序：[下载最新版官方 GeForce 驱动程序](https://www.nvidia.cn/geforce/drivers/) 
> 
> [NVIDIA驱动安装和CUDA安装\.pdf](https://iadagxzituk.feishu.cn/wiki/Ptzhwx9oKigAcLkQp0FcKuu4nbe?from=from_copylink)
> 
> 查看CPU\&内存命令：`top`
> 
> 查看磁盘信息命令：`df -h`
> 
> 

#### ssh无法连接、xshell无法连接、vscode无法连接

> 请检查用户名、密码、端口号输入是否正确，不同类型镜像登陆信息不同
> 
> 

#### ssh、vscode经常断链

ssh需要设置心跳包，保证持续性链接，需要在本地电脑配置

> cat \~/\.ssh/config
> 
> 
> 
> GSSAPIAuthentication no
> 
> StrictHostKeyChecking no
> 
> UserKnownHostsFile /dev/null
> 
> LogLevel ERROR
> 
> ServerAliveInterval 30
> 
> ServerAliveCountMax 999
> 
> 

如果是vscode断链，删掉vscode上的\.vscode\-server文件即可，配置文件冲突



#### IP是公网IP吗？

> IP是公网、固定IP，可以当正常服务器对外提供服务使用，网络带宽为1\.5Gb共享带宽，单IP上限300Mbps
> 
> 

#### 关于“无卡启动模式”的使用和限制

> - 无卡模式：需要在实例关机后，选择无卡模式启动（无卡模式不挂载GPU，仅收取基础实例费0\.15元/小时），适用于编写/调试代码、上传下载数据到实例的场景，节省资源成本
> 
> ![image\.png](图片和附件/image%208.png)
> 
> ![image\.png](图片和附件/image%203.png)
> 
> - 注意：
> 
>     - 华北一C可用区实例仅支持1个无卡开机实例
> 
>     - 目前A800不支持无卡模式开机
> 
>     - **无卡开机不能制作镜像**
> 
> 

#### 创建的实例，在jupyterLab运行代码后，关闭jupyterLab页面，服务器还会保持运算吗？

> 会继续保持运算
> 
> 

#### Jupyter中的checkpoints文件夹无法打开

> checkpoints 是 jupyterlab 的关键字，跟 comfyui 冲突了，导致无法打开文件夹，如需下载模型，可通过如下方式
> 
> 1、直接在 jupyterlab 的 terminal里执行 cd checkpoints，然后wget 远程下载模型地址
> 
> 2、使用三方文件管理工具，见https://www\.compshare\.cn/docs/operation/gpu/uploaddata\#xftp%E4%B8%8A%E4%BC%A0
> 
> 

#### SD\-WebUI、ComfyUI服务经常断链

> 断链基本为显存、内存跑满导致服务崩溃，可以在控制台重启实例尝试
> 
> 

#### nvidia\-smi检测不到显卡

> 可能为驱动问题，控制台重启实例尝试，如重启后仍然检测不到卡，则可判断为硬件故障，加群联系技术支持处理
> 
> ![contact\_me\_qr\.png](图片和附件/contact_me_qr%201.png)
> 
> 

#### 网页Jupyter左侧文件列表不显示

Jupyter 默认工作目录在workspace下，即workspace 目录下的文件才会展示，cd 到workspace目录下，可以vim test\.sh , 然后wq 保存后，看是否左侧有展示test\.sh 文件

## 计费相关 \-\- 计费模式、扣费标准、账单、发票等问题

#### 2\.1 实例计费模式说明

> 按量：按小时计费的后付费模式，关机后CPU、GPU和内存会被释放，实例不再收费，额外扩容的系统盘和数据盘及镜像资源会保留并继续收费；
> 
> 包时：按小时计费的预付费模式，已开通自动续费，关机后实例资源不会释放，仍然计费
> 
> 包日：按天计费的预付费模式，已开通自动续费，关机后实例资源不会释放，仍然计费
> 
> 包月：按月计费的预付费模式，已开通自动续费，关机后实例资源不会释放，仍然计费
> 
> 

#### 2\.2 关于“卡初始化和启动中”的实例问题

> - 实例卡初始化超过5分钟，以及卡初始化时间过长导致的扣费问题可进群联系群主解决；
> 
> - 实例卡启动中并不会产生扣费（启动中状态说明主机还并未开机），启动中时间过长可联系群主解决；
> 
> 

#### 2\.3 关于是否支持把按量的机器直接变更为包月

> - 支持，根据客户自身需求，向客户经理/官方客户申请，通过后可非标支持；
> 
> - 变更包月的实例不支持再次变更计费方式，需要用户通过自制镜像后重新选择机器和计费重开，望悉知；
> 
> 

#### **2\.4** 关于账号存在欠费订单无法使用的情况说明

每个账号下若存在≥1条欠费订单则无法使用和创建新资源，请先前往[“财务中心”](https://console.compshare.cn/uaccount/order_list?tabs=upaid)手动支付后方可使用；

## 镜像相关 \-\- 镜像无法操作等问题

#### 镜像无定按照教程正常启动或使用

> 请加群官方群联系群主，部分镜像可对接至原项目作者使用教学群
> 
> ![contact\_me\_qr\.png](图片和附件/contact_me_qr.png)
> 
> 

#### 自制镜像容量限制

> 当前自制镜像最大容量为300GB，若大于300BG存在制作失败的情况，请注意
> 
> 

#### 自制镜像大小

> 若是容器镜像（基于基础镜像制作），镜像大小则是依据实际存储大小来决定（例如，实际使用50G，则镜像大小为50G）；
> 
> 若是虚机镜像（基于系统镜像制作），镜像大小则是依据系统盘大小来决定（例如，实际使用150G，系统盘默认200G，则镜像大小则为200G）；
> 
> 注意：一切以实际制作镜像的大小为准，上述仅为规则说明补充。
> 
> 

#### 什么类型的镜像是不支持发布到社区

> 1. 使用系统镜像部署的实例，底层为虚机类型，无法支持发布至社区；
> 
> ![image\.png](图片和附件/image%204.png)
> 
> 2. 使用社区镜像部署的实例，再次制作成镜像，无支持发布至社区；（因为社区镜像是别人的，所以不能再次发布哦！）
> 
> 

#### 3\.5  关于制作镜像时候的实例状态

> 基础镜像\-实例，需要保证开机状态下制作镜像；
> 
> 系统镜像\-实例，与实例开关机状态无关，均可制作镜像；
> 
> 

#### 3\.6  关于“私有镜像”分享功能

> 使用场景：自制镜像 一对一和一对多分享，支持分享者随时取消共享
> 操作步骤：控制台 — 镜像列表 — 选择要分享的“平台镜像” — 选择更多“共享镜像” — “共享对象” — 新建共享— 输入被分享的用户id 
> 
> 注意事项：
>  1）如何查看用户id？登录后，点击右上角头像，CompanyID则为用户id信息
>  2）镜像来源是 社区镜像 不可以被共享 
>  3）共享成功后，被共享镜像在“部署实例\-平台镜像\-共享镜像”处查看
> 
> ![image\.png](图片和附件/image%202.png)
> 
> 



## 实践相关 \-\- Docker、Dify、Ollama、VS Code、CherryStudio部署调用等问题

#### 是否可以安装Docker和Docker Compose

> 支持安装，自行安装需要使用系统镜像中的Ubuntu环境（系统镜像无Pytorch、jupyter等环境，需自行安装）
> 
> ![image\.png](图片和附件/image%207.png)
> 
> ```Plain Text
> sudo apt update
> sudo apt install docker.io
> sudo apt install docker-compose
> ```
> 
> 

> 也可以使用预装好的Docker\-Compose环境（系统镜像无Pytorch、jupyter等环境，需自行安装）
> 
> ![image\.png](图片和附件/image%2010.png)
> 
> 

#### Dify、CherryStuido等工具如何调用云端Ollama

> 在机器中使用如下命令启动Ollama服务，在Dify客户端API地址中填写 http://你的外网IP:11434
> 
> 

```Plain Text
export OLLAMA_HOST=你的外网IP:11434
ollama serve
```

#### VS Code如何链接实例使用

> 具体操作教程见该篇文档内容
> 
> 

https://www\.compshare\.cn/docs/operation/logininstance\#vscode%E8%BF%9E%E6%8E%A5

#### Dify镜像登录账号密码

账号：compshare@126\.com

密码：compshare123

#### 官方IsaaC具身智能镜像使用教程

https://www\.compshare\.cn/docs/operation/bestpractices/isaac

## 实例API相关 \-\- 调用示例

> API文档：https://www\.compshare\.cn/docs/API/createcompshareinstance
> 
> API调用示例：https://github\.com/ucloud/compshare\-developer\-examples
> 
> 文档及示例逐步完善中，API相关问题可加入用户交流群沟通
> 
> 

## 账号相关 \-\- 密码登录、开票、团队管理

#### 每次验证码登录很麻烦，建议设置登录密码：

> 如您觉得每次都需要验证码登录不方便，可以控制台\-账户管理页面进行设置
> 
> https://console\.compshare\.cn/uaccount/setting
> 
> 

![企业微信截图\_17447707755482\.png](图片和附件/企业微信截图_17447707755482.png)

#### 如何开发票？

> 点击进入“控制台” \>\> 点击“财务中心” \>\> 选择 [发票管理](https://console.compshare.cn/uaccount/invoice)
> 
> 

![image\.png](图片和附件/image%209.png)

> 如有任何开票问题，可以进入官方社群与运营同学沟通
> 
> ![contact\_me\_qr\.png](图片和附件/contact_me_qr%203.png)
> 
> 

#### 如何使用团队管理功能

> **团队管理**是优云平台推出的团队协作功能，支持团队成员管理及金额分配，主要面向培训机构、教育课堂、多成员企业管理场景。
> 
> 操作文档：https://www\.compshare\.cn/docs/uaccount/team
> 
> 团队管理功能目前面向企业、高校客户定向开通，需扫码添加官方运营同学
> 
> ![image\.png](图片和附件/image%201.png)
> 
> 

## 控制台常见报错提示

## 如何加速访问Github、Huggingface

> 外网学术加速功能已内测上线，解决外网拉取数据较慢的问题，可在控制台开通：
> 
> https://console\.compshare\.cn/light\-gpu/console/accelerator
> 
> ![image\.png](图片和附件/image%205.png)
> 
> 注意：
> 
> 开通后社区镜像默认配置加速，虚机、基础镜像需求修改DNS地址方可生效，教程见：
> 
> https://docs\.ucloud\.cn/uaaa/configuration/configuration
> 
> 

## 实例如何快速拉取或使用热门模型

> 主流模型已下载至公共模型库，直接挂载即可使用，文档见：
> 
> https://www\.compshare\.cn/docs/bestpractices/sharemodel
> 
> 

## 关于其他功能上线计划

- CPU打平，启动支持Intel、AMD切换 \- 预计3月下旬

- 按量实例变更计费方式为包月 \- 预计3月下旬

## 如有其他问题，请在下方问卷中填写

[https://f.howxm.com/xs/u/Z2GO3UBD1NF5]()



