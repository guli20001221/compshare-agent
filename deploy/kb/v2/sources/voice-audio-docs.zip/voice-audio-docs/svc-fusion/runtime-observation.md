# SVC-Fusion 镜像实际运行说明

本说明来自对当前镜像的只读检查，不包含服务器地址、登录信息、日志或模型文件。

## 已确认

- 镜像内存在 `/workspace/SVCFusion`，包含 SVC-Fusion 主程序、So-VITS-SVC、DDSP-SVC 6.0/6.1/6.3、Reflow-VAE-SVC、RVC 以及音频处理工具。
- 当前检查时只有 JupyterLab 在运行，SVC-Fusion WebUI 尚未启动。镜像主页给出的使用方式是运行 `quick_setup.ipynb` 中的启动单元，再访问 7860 端口。
- 该镜像不是 ComfyUI 镜像，没有发现 ComfyUI 的 8188 服务。

## 推荐用户流程

1. 打开 JupyterLab，运行 `quick_setup.ipynb`。
2. 根据任务选择模型：RVC、So-VITS-SVC、DDSP-SVC 或 Reflow-VAE-SVC。
3. 训练前先整理数据集、切分音频并确认采样率；推理前确认使用的底模与训练模型一致。
4. 需要伴奏、人声分离、自动混音或实时变声时，使用工具箱内对应功能。
5. 显存不足、数据集为空、`nan ddsp_loss`、尺寸不匹配等问题，优先查阅 SVC-Fusion FAQ。

## 镜像文档边界

核心收录模型选择、训练、推理、数据集、显存排查、分离、混音和实时变声；ONNX 导出作为技术参考单独保存；不收录虚拟环境、模型权重、缓存和日志。
