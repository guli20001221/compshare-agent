Title: SVC-Fusion一键部署 | 优云智算

URL Source: https://www.compshare.cn/images/compshareImage-1aly0zqh3gvc

Published Time: Wed, 16 Oct 2024 02:40:02 GMT

Markdown Content:
v2.5更新：

1、原版 MSST 分离方案已替换为 pymss，在提升处理速度的同时，进一步优化低显存环境下的资源占用表现，为低显存用户带来更加友好的使用体验。

2、添加RVC，支持RVC训练推理导入，比原版更好用，更快；

3、目前版本以预先安装各个项目的底模；

4、更新版本号至v2.3.0；

**镜像作者：[bilibili@爱过_留过](https://space.bilibili.com/399248533)****交流群：[172701496](https://qm.qq.com/q/FvdR8Z8SMU "点击加入玩家交流群")**

## 项目简介

本整合包将整合So-Vits-SVC4.1、DDSP-SVC6.3/6.1/6.0、RVC、ReFlow-VAE-SVC多种SVC模型训练及推理，让您更方便的训练和使用您的声音，让我们废话不多说，开启您奇妙的声音之旅。

### 整合包文档地址：[https://www.svcfusion.com](https://www.svcfusion.com/)

### 常见问题：[https://www.svcfusion.com/faq](https://www.svcfusion.com/faq)

### aiguoliuguo-镜像作者交流群

![Image 1: image](https://www-s.ucloud.cn/2025/07/24212d968224993159a12062d1bf4142_1751445575540.png)

* * *

### So-Vits-SVC训练视频

* * *

### DDSP6/6.1训练视频

* * *

### RVC训练视频

### WebUI启动教程

1. 先选择GPU型号，再点击“立即部署” 

2. 待实例初始化完成后，在控制台-应用中打开“JupyterLab” 

3. 进入JupyterLab后，默认会进入到“quick_setup.ipynb”这个文件中，运行“启动WebUI”代码块 ![Image 2: image](https://www-s.ucloud.cn/2025/07/c647ba97b18b4cdc7f766da90b7d9437_1752132103485.png)

4. 代码运行后，在浏览器中输入 外网ip:7860 访问WebUI界面，外网ip可以在基础网络（外）中获取 

 进入WebUI界面如下图所示 ![Image 3: image](https://www-s.ucloud.cn/2025/07/3d1dc4c5588d87b900cda904e9a2afc4_1752132285310.png)

具体训练步骤可以参考镜像作者的视频中方法
