Title: RVC一键部署 | 优云智算

URL Source: https://www.compshare.cn/images/compshareImage-18toy98a4i2a

Markdown Content:
## 镜像简介

本镜像提供RVC语音转换工具的WebUI界面，支持高质量的AI翻唱与语音变声功能。用户仅需3分钟即可快速训练个性化声音模型，实现高拟真的音色转换与歌曲翻唱。操作简单直观，适用于音乐创作、内容娱乐、语音特效及个性化音频内容制作等场景。

## 镜像使用指南

创建实例

![Image 1: image.png](https://www-s.ucloud.cn/2026/01/a68430c47cf1642ba263421de2ec20fb_1769655376140.png)

选择合适的机型，立即部署

![Image 2: image.png](https://www-s.ucloud.cn/2026/01/4f63eb9e4cc51817c877a6c99e1443e3_1769665151973.png)

待实例初始化完成后，进入JupyterLab，运行“启动WebUI”代码块 ![Image 3: image](https://www-s.ucloud.cn/2025/07/bfb588653a1cc5ef5e8661862d1fb88b_1752134889691.png)

代码运行后，在浏览器中访问 [http://0.0.0.0:7865](http://0.0.0.0:7865/) 进入WebUI界面，将0.0.0.0替换为外网ip，外网IP可以在控制台-基础网络（外）中获取。进入WebUI后界面如下图所示： ![Image 4: image](https://www-s.ucloud.cn/2025/07/e5c36075fe093e783f183863fcfbbfb8_1752135042483.png)

上传音频到 input 文件夹进行训练

上传音频到 tuili 文件夹进行推理

下载模型到本地使用：

模型文件在 root/rvc/assets/weights/ 内

特征索引在 root/rvc/assets/indices/ 内

## _**推理请使用批量推理，然后上传文件**_

**镜像作者：[bilibili@爱过_留过](https://space.bilibili.com/399248533)**

**aiguoliuguo-镜像作者交流群**

![Image 5: image](https://www-s.ucloud.cn/2025/07/24212d968224993159a12062d1bf4142_1751445575540.png)
