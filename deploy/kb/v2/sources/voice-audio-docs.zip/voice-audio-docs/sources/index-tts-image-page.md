Title: IndexTTS2 B站开源超强语音克隆一键部署 | 优云智算

URL Source: https://www.compshare.cn/images/mbu1nCYVfl9E

Markdown Content:
B站开源超强音频克隆，在情感表达和时长控制方面取得突破的自回归零样本文本合成系统

更新为vllm版本，实例启动后，需要等待5分钟加载模型！

## 使用教程

### 0. 麻烦右上角点个收藏~

![Image 1: 318e364f-9c65-489c-9391-b3fb6cd49c26.png](https://ucompshare-picture.s3-cn-wlcb.s3stor.compshare.cn/2qa0lA5BffYZnEH2%2F1757493294507.png)

### 1. 在镜像详情界面点击“使用该镜像创建实例”

![Image 2: image.png](https://ucompshare-picture.s3-cn-wlcb.s3stor.compshare.cn/2qa0lA5BffYZnEH2%2F1759223911566.png)

### 2. 选择GPU型号，再点击“立即部署”

![Image 3: image.png](https://ucompshare-picture.s3-cn-wlcb.s3stor.compshare.cn/2qa0lA5BffYZnEH2%2F1759223971912.png)

### 3. 实例启动后（此项目需要预加载模型和编译，启动时间较长，需等待5分钟），在控制台中点击“SD-WebUI”

![Image 4: image.png](https://ucompshare-picture.s3-cn-wlcb.s3stor.compshare.cn/2qa0lA5BffYZnEH2%2F1759224006921.png)

### 4.浏览器如图显示，就说明启动成功了

![Image 5: image.png](https://ucompshare-picture.s3-cn-wlcb.s3stor.compshare.cn/2qa0lA5BffYZnEH2%2F1760528343378.png)

### 5.如果页面无响应（比如此项目需要预加载模型，启动时间较长），点击“JupyterLab”，再双击log.txt可查看启动进度

![Image 6: image.png](https://ucompshare-picture.s3-cn-wlcb.s3stor.compshare.cn/2qa0lA5BffYZnEH2%2F1757493478682.png)![Image 7: image.png](https://ucompshare-picture.s3-cn-wlcb.s3stor.compshare.cn/2qa0lA5BffYZnEH2%2F1757493674519.png)

## 6.如果有报错的话，请下载log.txt发到下面的交流群中

![Image 8: image.png](https://ucompshare-picture.s3-cn-wlcb.s3stor.compshare.cn/2qa0lA5BffYZnEH2%2F1757493793482.png)

## 十字鱼-镜像作者交流群

![Image 9: image](https://www-s.ucloud.cn/2025/07/a14b92500ec0a1feff8beaf42d01d4b1_1751444644754.png)
