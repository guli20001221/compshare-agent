Title: LiveTalking一键部署 | 优云智算

URL Source: https://www.compshare.cn/images/4458094e-a43d-45fe-9b57-de79253befe4

Markdown Content:
## 注意！该镜像华北一C机器不可用，请选择华北二和上海机器！

## 镜像简介

本镜像提供名为LiveTalking的实时交互式数字人解决方案，支持ERNerf、MuseTalk、wav2lip、ultralight-digitalhuman等多种前沿技术，能够实现流畅的流式音视频对话与驱动。适用于虚拟直播、在线客服、远程互动演示及实时内容创作等场景，为用户提供免费、高效且高度拟真的实时数字人生成与交互体验。 Github: [https://github.com/lipku/LiveTalking](https://github.com/lipku/LiveTalking) 使用文档：[https://doc.livetalking.ai](https://doc.livetalking.ai/)

## 镜像使用指南

## 一、快速使用

### 1. 先选择GPU型号，再点击“立即部署”

![Image 1: image](https://www-s.ucloud.cn/2025/06/12d3bee37e0fc39686567fb7039050af_1750405772340.png)

### 2. 待实例初始化完成后，配置防火墙端口，开放udp50000-51000，具体操作可参考第三部分。然后在浏览器里打开 [http://serverip:8010/index.html](http://serverip:8010/index.html)

### serverip可以在控制台-基础网络（外）复制得到

![Image 2: image](https://www-s.ucloud.cn/2025/06/74ced3546a2db49e3eeb01d62ebe2e95_1750406237672.png)

### 进入web界面后点击开始连接，能看到数字人视频。然后输入文字并点击发送，数字人会播报输入文字

![Image 3: 123.jpg](https://compshare-files.cn-wlcb.ufileos.com/hermes/basic_ops_images/20260601/47ac10a7-0082-44a9-9b7c-251cc2847dd0-123.jpg)

## 二、使用musetalk模型

### 1. 在控制台-应用中打开“JupyterLab”

![Image 4: image](https://www-s.ucloud.cn/2025/06/99ae90e14cec0f57383a5829cfd47547_1750405876546.png)

### 2. 进入JupyterLab后，新建一个终端Terminal，在Terminal中运行如下命令

```
conda activate livetalking
cd /root/LiveTalking
python app.py --transport webrtc --model musetalk --avatar_id musetalk_avatar1
```

> 如果遇到报错提示端口已被占用，ps aux | grep python 找到自启动的livetalking两个进程kill。 也可以删除/start.d/livetalking.sh，重启后把自启动服务关闭

## 三、防火墙设置教程

### 使用该镜像时可能出现数字人无法显示的问题，此时需检查防火墙设置是否正确，防火墙端口需开放tcp 8010，udp 50000-51000

### 1. 如图所示，在控制台-操作中打开配置防火墙

![Image 5: image](https://www-s.ucloud.cn/2025/06/fe0f04cc8839ca348078ff4e2ee30c1e_1750746685842.png)

### 2. 点击“编辑防火墙规则”

![Image 6: image](https://www-s.ucloud.cn/2025/06/90a4eac01d89a18d937208e7a006ce63_1750746827100.png)

### 3. 点击“添加规则”

![Image 7: image](https://www-s.ucloud.cn/2025/06/e4d28a83788984191dd5208d0cb0993f_1750746932956.png)

### 4. 选择指定端口TCP，输入端口号8010；选择全端口UDP，输入端口号50000-51000；再点击下一步

![Image 8: image](https://www-s.ucloud.cn/2025/06/0fd6af2fa6364aac8763958ddd9332fa_1750747120684.png)

### 5. 检查端口号，点击“确认”后即添加成功，可以回到防火墙规则中确认是否添加

![Image 9: image](https://www-s.ucloud.cn/2025/06/3b2fc790eade309e88f4bbcb09f4d64d_1750747206765.png)
