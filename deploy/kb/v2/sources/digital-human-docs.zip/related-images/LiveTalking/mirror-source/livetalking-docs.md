Title: LiveTalking 文档

URL Source: https://doc.livetalking.ai/

Markdown Content:
[跳至内容](https://doc.livetalking.ai/#content)

[![Image 1: Dark Logo](https://doc.livetalking.ai/assets/logo.png)![Image 2: Dark Logo](https://doc.livetalking.ai/assets/logo.png)LiveTalking](https://livetalking.ai/)[文档](https://doc.livetalking.ai/docs)[快速开始](https://doc.livetalking.ai/docs/quickstart)

CTRL K

zh-CN

*   [zh-CN](https://doc.livetalking.ai/)
*   [en-US](https://doc.livetalking.ai/en/)

[GitHub](https://github.com/lipku/livetalking "GitHub")

CTRL K

*   [文档](https://doc.livetalking.ai/docs/) 

    *   [功能介绍](https://doc.livetalking.ai/docs/feature/) 
    *   [安装说明](https://doc.livetalking.ai/docs/install/) 
    *   [快速开始](https://doc.livetalking.ai/docs/quickstart/) 
    *   [使用说明](https://doc.livetalking.ai/docs/usage/) 
    *   [Docker](https://doc.livetalking.ai/docs/docker/) 
    *   [API 接口](https://doc.livetalking.ai/docs/api/) 
    *   [虚拟摄像头使用](https://doc.livetalking.ai/docs/virtualcam/) 
    *   [商用版](https://doc.livetalking.ai/docs/service/) 
    *   [FAQ](https://doc.livetalking.ai/docs/faq/) 
    *   [AutoDL 教程](https://doc.livetalking.ai/docs/autodl/) 
    *   [UCloud 教程](https://doc.livetalking.ai/docs/ucloud/) 
    *   [TTS](https://doc.livetalking.ai/docs/tts/) 

        *   [GPT-SoVITS](https://doc.livetalking.ai/docs/tts/gptsovits/) 
        *   [Fish Speech](https://doc.livetalking.ai/docs/tts/fishspeech/) 
        *   [CosyVoice](https://doc.livetalking.ai/docs/tts/cosyvoice/) 
        *   [OmniTTS](https://doc.livetalking.ai/docs/tts/omnitts/) 
        *   [旧版说明](https://doc.livetalking.ai/docs/tts/README-old/) 

*   [快速开始](https://doc.livetalking.ai/docs/quickstart/) 

zh-CN

*   [zh-CN](https://doc.livetalking.ai/)
*   [en-US](https://doc.livetalking.ai/en/)

*    浅色 
*    深色 
*    跟随系统 

[实时交互流式数字人](https://doc.livetalking.ai/)

# LiveTalking 文档中心

覆盖安装、快速开始、模型使用、TTS 服务、Docker 部署与商业能力说明

[开始阅读](https://doc.livetalking.ai/docs/quickstart/)[查看功能](https://doc.livetalking.ai/docs/feature/)

### [快速上手 最短路径跑通第一个 wav2lip 数字人示例。](https://doc.livetalking.ai/)### [模型覆盖 支持 wav2lip、musetalk、ernerf、Ultralight-Digital-Human。](https://doc.livetalking.ai/)### [TTS 集成 包含 GPT-SoVITS、Fish Speech、CosyVoice 等服务部署说明。](https://doc.livetalking.ai/)### [部署方案 提供 Docker、AutoDL 与 UCloud 使用教程。](https://doc.livetalking.ai/)### [接口文档 整理了 WebRTC 协商、文本驱动、录像等 API。](https://doc.livetalking.ai/)

zh-CN

*   [zh-CN](https://doc.livetalking.ai/)
*   [en-US](https://doc.livetalking.ai/en/)

浅色 深色 跟随系统

*    浅色 
*    深色 
*    跟随系统 

* * *

[由 Hextra 驱动](https://github.com/imfing/hextra "Hextra GitHub Homepage")

© 2026 Hextra Project.
