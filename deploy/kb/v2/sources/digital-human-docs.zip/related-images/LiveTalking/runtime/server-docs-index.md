# LiveTalking 服务器 Markdown 文档索引

- `/root/LiveTalking/README-EN.md` → `server-docs/README-EN.md`
- `/root/LiveTalking/README.md` → `server-docs/README.md`
- `/root/LiveTalking/assets/faq.md` → `server-docs/assets/faq.md`
- `/root/LiveTalking/avatars/musetalk/utils/face_detection/README.md` → `server-docs/avatars/musetalk/utils/face_detection/README.md`
- `/root/LiveTalking/avatars/wav2lip/face_detection/README.md` → `server-docs/avatars/wav2lip/face_detection/README.md`
- `/root/LiveTalking/docs/admin_api.md` → `server-docs/docs/admin_api.md`
- `/root/LiveTalking/docs/api.md` → `server-docs/docs/api.md`
- `/root/LiveTalking/docs/avatar_api.md` → `server-docs/docs/avatar_api.md`
