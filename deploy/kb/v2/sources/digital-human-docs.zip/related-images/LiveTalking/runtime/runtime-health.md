# LiveTalking 运行与资料状态

- 主程序：`/root/LiveTalking`
- 网页服务：8010
- ComfyUI 服务：8188 未运行
- Jupyter：8888
- 模型清单：已记录文件名和大小，未复制模型二进制
- 服务器 Markdown：已从 `/root/LiveTalking` 只读复制
- `/model/comfyui`：休眠目录，不属于当前 LiveTalking 功能

LiveTalking 是独立的实时数字人应用，不纳入 ComfyUI 核心文档。
