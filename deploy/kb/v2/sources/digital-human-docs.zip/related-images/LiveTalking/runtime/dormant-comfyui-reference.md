# LiveTalking 镜像中的休眠 ComfyUI 目录

当前实例的主服务是 `/root/LiveTalking`，8188 端口没有 ComfyUI 服务。

镜像文件系统中另有 `/model/comfyui`，检查到约 2 个自定义节点目录和 266 个模型文件。这些内容没有被当前 LiveTalking 进程加载，不能视为 LiveTalking 的实际功能，因此不纳入 ComfyUI 主文档，也不纳入该镜像的核心使用说明。
