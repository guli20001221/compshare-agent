# LiveTalking 模型文件清单

只记录模型相对路径和大小，不下载模型二进制。

- `.cache/huggingface/.gitignore` — 1 bytes
- `.cache/huggingface/CACHEDIR.TAG` — 191 bytes
- `.cache/huggingface/download/musetalk/Q1p2l2BzM1m6P5jKvr8WTq1TUio=.0ee7d5ea03ea75d8dca50ea7a76df791e90633687a135c4a69393abfc0475ffe.incomplete` — 1073029679 bytes
- `.cache/huggingface/download/musetalkV15/unet.pth.metadata` — 124 bytes
- `dwpose/.cache/huggingface/.gitignore` — 1 bytes
- `dwpose/.cache/huggingface/CACHEDIR.TAG` — 191 bytes
- `dwpose/.cache/huggingface/download/dw-ll_ucoco_384.pth.metadata` — 125 bytes
- `dwpose/dw-ll_ucoco_384.pth` — 406878486 bytes
- `face-parse-bisent/79999_iter.pth` — 53289463 bytes
- `face-parse-bisent/resnet18-5c106cde.pth` — 46827520 bytes
- `musetalkV15/musetalk.json` — 748 bytes
- `musetalkV15/unet.pth` — 3400074924 bytes
- `put models here.txt` — 0 bytes
- `sd-vae/.cache/huggingface/.gitignore` — 1 bytes
- `sd-vae/.cache/huggingface/CACHEDIR.TAG` — 191 bytes
- `sd-vae/.cache/huggingface/download/diffusion_pytorch_model.bin.metadata` — 125 bytes
- `sd-vae/config.json` — 547 bytes
- `sd-vae/diffusion_pytorch_model.bin` — 334707217 bytes
- `sd-vae/diffusion_pytorch_model.safetensors` — 334643276 bytes
- `wav2lip.pth` — 214670409 bytes
- `whisper/.cache/huggingface/.gitignore` — 1 bytes
- `whisper/.cache/huggingface/CACHEDIR.TAG` — 191 bytes
- `whisper/.cache/huggingface/download/preprocessor_config.json.metadata` — 101 bytes
- `whisper/.cache/huggingface/download/pytorch_model.bin.metadata` — 125 bytes
- `whisper/preprocessor_config.json` — 184990 bytes
- `whisper/pytorch_model.bin` — 151095027 bytes
