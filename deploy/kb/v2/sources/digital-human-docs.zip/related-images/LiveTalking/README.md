# LiveTalking 镜像相关参考

该镜像不是正在运行 ComfyUI，而是独立的实时数字人应用。SSH 实例已连接并完成只读检查：主程序位于 `/root/LiveTalking`，网页服务使用 8010 端口；镜像中虽然有 `/model/comfyui` 休眠目录，但没有运行 ComfyUI 服务。

因此本目录只保存 LiveTalking 的公开资料和运行分类信息，不把它混入 ComfyUI 主文档。休眠的 ComfyUI 目录也不作为该镜像的核心能力收录。

目录中的资料只作为相关应用参考，不计入 ComfyUI 镜像核心覆盖范围。
