# InfiniteTalk 配套 Gradio 界面清单

该文件来自镜像运行时 7860 端口的只读接口探测，未复制服务器代码。

- 组件数量：`64`
- 依赖/API 数量：`10`

## 可见组件

- `1`：<div>
    <h2 style="font-size: 35px;text-align: center;">AI数字人InfiniteTalk</h2>
</div>
<div style="display:flex;column-gap:4px;justify-content: center;">
    <a href="https://gith
- `2`：### 镜像作者：与AI同行    [Bilibili](https://space.bilibili.com/60542591)  |  [YouTube](https://www.youtube.com/@walkingwithai1996)
- `3`：AI问题咨询、远程一对一服务、AI软件/工作流定制等，欢迎加入知识星球沟通🤗🤗！    [国内](https://t.zsxq.com/uxk7B)  |  [国外](https://www.youtube.com/@walkingwithai1996/join)
- `4`：row
- `5`：column
- `6`：选择模式
- `7`：两种模式均支持单人说话和双人对话。
- `8`：音频1为必填音频，音频2为可选音频(双人对话时上传)，双人对话时，默认左侧人物对应音频1，右侧人物对应音频2。
- `9`：row
- `10`：column
- `11`：人物图片 (Person Image)
- `12`：row
- `13`：📷 镜头控制 (Camera Control)
- `14`：🧘 稳定人物动作和场景画面 (Stabilize Pose)
- `15`：form
- `16`：column
- `17`：参考视频 (Reference Video)
- `18`：column
- `19`：驱动音频 1 (必填)
- `20`：驱动音频 2 (可选 / Optional)
- `21`：row
- `22`：正面提示词 (Positive Prompts)
- `23`：负面提示词 (Negative Prompts)
- `24`：form
- `25`：🛠️ 通用参数设置
- `26`：**注意：** 视频分辨率越大，显存和内存占用越大，24G显存可生成480P/540P视频，如需生成720P，显存至少>=48G；建议生成分辨率不要超过720P分辨率。也可先生成中低分辨率视频，结合下方的高清放大使用。
- `27`：row
- `28`：视频宽度
- `29`：↔️
- `30`：视频高度
- `31`：form
- `32`：form
- `33`：row
- `34`：推理步数 (Steps)
- `35`：CPU交换块数 (Blocks to Swap)
- `36`：循环处理帧数 (Frame Window Size)
- `37`：form
- `38`：row
- `39`：Seed
- `40`：设置随机种子🎲
- `41`：视频帧率 (FPS)
- `42`：form
- `43`：form
- `44`：✨ 视频高清放大 (可选)
- `45`：row
- `46`：启用高清放大
- `47`：放大后分辨率(视频最短边)
- `48`：form
- `49`：form
- `50`：column
- `51`：系统资源占用
- `52`：队列状态
- `53`：当前任务状态 (Status)
- `54`：▶️ 点击生成
- `55`：🔄 手动刷新任务队列 
- `56`：row
- `57`：⚠️ 终止当前任务
- `58`：🗑️ 清空排队任务
- `59`：📂 打开输出文件夹
- `60`：生成结果画廊 (Results Gallery)
- `61`：实时终端日志 (Real-time Logs)
- `62`：1
- `63`：form
- `64`：form

## API/交互依赖

- API：`lambda`；输入组件：`[6]`；输出组件：`[10, 16, 54]`
- API：`lambda1`；输入组件：`[46]`；输出组件：`[47]`
- API：`add_to_queue_wrapper`；输入组件：`[6, 11, 17, 19, 20, 22, 23, 28, 30, 34, 35, 36, 39, 46, 47, 41, 13, 14]`；输出组件：`[53, 52]`
- API：`interrupt_current_task`；输入组件：`[]`；输出组件：`[53]`
- API：`clear_pending_queue`；输入组件：`[]`；输出组件：`[53]`
- API：`check_and_get_video`；输入组件：`[]`；输出组件：`[60, 53, 52, 51, 61]`
- API：`open_output_folder`；输入组件：`[]`；输出组件：`[53]`
- API：`randomize_seed`；输入组件：`[]`；输出组件：`[39]`
- API：`swap_dimensions`；输入组件：`[28, 30]`；输出组件：`[28, 30]`
- API：`check_and_get_video_1`；输入组件：`[]`；输出组件：`[60, 53, 52, 51, 61]`

## 应用接口信息

```json
{
  "error": "HTTPError"
}
```
