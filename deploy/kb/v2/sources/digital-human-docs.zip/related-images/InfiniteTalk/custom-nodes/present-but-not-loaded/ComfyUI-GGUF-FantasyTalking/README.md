<!-- source: /root/ComfyUI/custom_nodes/ComfyUI-GGUF-FantasyTalking/README.md -->

P.S. Couldn't quantize the fantasy talking model so this repo doesnt work
