<!-- source: /root/ComfyUI/custom_nodes/ComfyUI-VideoHelperSuite/tests/README.md -->

Workflows for automated testing of VHS. Most include an additional tests key to check the properties or perform comparisons on node outputs
