<!-- source: /root/ComfyUI/custom_nodes/comfyui_controlnet_aux/src/custom_manopth/CHANGES.md -->

* Chumpy is removed