# 当前镜像自定义节点清单

此文件根据当前运行实例的 `/root/ComfyUI/custom_nodes` 目录生成；只记录目录和状态，不复制代码、模型、缓存或日志。

- `AIGODLIKE-ComfyUI-Translation`：当前实例目录
- `ComfyUI-Crystools`：当前实例目录
- `ComfyUI-Custom-Scripts`：当前实例目录
- `ComfyUI-Easy-Use`：当前实例目录
- `ComfyUI-GGUF`：当前实例目录
- `ComfyUI-GGUF-FantasyTalking`：未加载参考
- `ComfyUI-KJNodes`：当前实例目录
- `ComfyUI-Manager`：当前实例目录
- `ComfyUI-MelBandRoFormer`：当前实例目录
- `ComfyUI-SoundFlow`：当前实例目录
- `ComfyUI-VideoHelperSuite`：当前实例目录
- `ComfyUI-WanVideoWrapper`：当前实例目录
- `ComfyUI_BaiduTranslate`：当前实例目录
- `ComfyUI_LayerStyle`：当前实例目录
- `ComfyUI_UltimateSDUpscale`：当前实例目录
- `ComfyUI_essentials`：当前实例目录
- `Comfyui-Memory_Cleanup`：当前实例目录
- `__pycache__`：当前实例目录
- `audio-separation-nodes-comfyui`：当前实例目录
- `comfyui-various`：当前实例目录
- `comfyui_controlnet_aux`：当前实例目录
- `comfyui_segment_anything`：当前实例目录
- `rgthree-comfy`：当前实例目录
