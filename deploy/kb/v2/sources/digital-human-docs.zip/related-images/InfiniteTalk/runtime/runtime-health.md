# 当前镜像运行状态

这是一次只读探测结果；不包含服务器地址、密码、令牌或完整运行日志。

## ComfyUI 服务

```text
/ 200
/system_stats 200
/object_info 200
```

## 版本信息

- ComfyUI：`0.3.71`
- 前端：`unknown`
- Python：`3.10.15 (main, Oct  3 2024, 07:27:34) [GCC 11.2.0]`
- PyTorch：`2.7.1+cu128`
- 节点类型数：`1558`

## 已观察到的导入问题

```text
Cannot import /root/ComfyUI/custom_nodes/ComfyUI-GGUF-FantasyTalking module for custom nodes: (unicode error) 'unicodeescape' codec can't decode bytes in position 149-150: truncated \UXXXXXXXX escape (nodes.py, line 669)
   0.0 seconds (IMPORT FAILED): /root/ComfyUI/custom_nodes/ComfyUI-GGUF-FantasyTalking
```
