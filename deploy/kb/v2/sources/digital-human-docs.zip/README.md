# 数字人应用 Markdown 文档包

这是独立于 ComfyUI 文档包的数字人应用资料包，当前包含 InfiniteTalk 和 LiveTalking。

## 应用分类

- InfiniteTalk：基于 ComfyUI 后端的数字人应用，另有 Gradio 用户界面；其 ComfyUI 节点资料只保留在本包内部。
- LiveTalking：独立实时数字人应用，不运行 ComfyUI。

## 内容

- `related-images/InfiniteTalk/`：镜像主页、Gradio 界面、节点文档、模型清单和运行状态。
- `related-images/LiveTalking/`：镜像主页、GitHub、官方文档、服务器 Markdown、模型清单和运行状态。
- `manifest.json`：来源、原始路径、应用分类、兼容性和文件哈希。

本包不包含 ComfyUI 公共教程、公共界面文档、RAG chunk 或向量；模型、图片、视频、缓存、完整日志、密码和令牌均未打包。

当前文件数：66。
