# ControlNet (Z-Image-Turbo)

- 来源类别：内置工作流蓝图
- 镜像内原始路径：`/ComfyUI/blueprints/ControlNet (Z-Image-Turbo).json`
- 节点数量：1
- 连线数量：0

## 节点类型

- `d2e76ecf-6e84-4b8c-8913-48efc09ec1c4` × 1

## 原始工作流 JSON

```json
{
  "revision": 0,
  "last_node_id": 85,
  "last_link_id": 0,
  "nodes": [
    {
      "id": 85,
      "type": "d2e76ecf-6e84-4b8c-8913-48efc09ec1c4",
      "pos": [
        440,
        1220
      ],
      "size": [
        480,
        0
      ],
      "flags": {},
      "order": 6,
      "mode": 0,
      "inputs": [
        {
          "label": "control_image",
          "localized_name": "image",
          "name": "image",
          "type": "IMAGE",
          "link": null
        },
        {
          "name": "text",
          "type": "STRING",
          "widget": {
            "name": "text"
          },
          "link": null
        },
        {
          "name": "seed",
          "type": "INT",
          "widget": {
            "name": "seed"
          },
          "link": null
        },
        {
          "name": "unet_name",
          "type": "COMBO",
          "widget": {
            "name": "unet_name"
          },
          "link": null
        },
        {
          "name": "clip_name",
          "type": "COMBO",
          "widget": {
            "name": "clip_name"
          },
          "link": null
        },
        {
          "name": "vae_name",
          "type": "COMBO",
          "widget": {
            "name": "vae_name"
          },
          "link": null
        },
        {
          "label": "patch_model",
          "name": "name",
          "type": "COMBO",
          "widget": {
            "name": "name"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "localized_name": "IMAGE",
          "name": "IMAGE",
          "type": "IMAGE",
          "links": []
        }
      ],
      "title": "ControlNet (Z-Image-Turbo)",
      "properties": {
        "proxyWidgets": [
          [
            "83",
            "text"
          ],
          [
            "79",
            "seed"
          ],
          [
            "74",
            "unet_name"
          ],
          [
            "73",
            "clip_name"
          ],
          [
            "75",
            "vae_name"
          ],
          [
            "76",
            "name"
          ],
          [
            "79",
            "control_after_generate"
          ]
        ],
        "cnr_id": "comfy-core",
        "ver": "0.18.1",
        "ue_properties": {
          "widget_ue_connectable": {},
          "version": "7.7",
          "input_ue_unconnectable": {}
        },
        "enableTabs": false,
        "tabWidth": 65,
        "tabXOffset": 10,
        "hasSecondTab": false,
        "secondTabText": "Send Back",
        "secondTabOffset": 80,
        "secondTabWidth": 65
      },
      "widgets_values": []
    }
  ],
  "links": [],
  "version": 0.4,
  "definitions": {
    "subgraphs": [
      {
        "id": "d2e76ecf-6e84-4b8c-8913-48efc09ec1c4",
        "version": 1,
        "state": {
          "lastGroupId": 9,
          "lastNodeId": 85,
          "lastLinkId": 87,
          "lastRerouteId": 0
        },
        "revision": 0,
        "config": {},
        "name": "ControlNet (Z-Image-Turbo)",
        "inputNode": {
          "id": -10,
          "bounding": [
            -500,
            620,
            120,
            180
          ]
        },
        "outputNode": {
          "id": -20,
          "bounding": [
            1390,
            1100,
            120,
            60
          ]
        },
        "inputs": [
          {
            "id": "fbbb968e-d3cf-40e4-b3ce-7abb074e5bd8",
            "name": "image",
            "type": "IMAGE",
            "linkIds": [
              65,
              80
            ],
            "localized_name": "image",
            "label": "control_image",
            "pos": [
              -400,
              640
            ]
          },
          {
            "id": "c1b19877-5417-4580-aea1-44439c70c1dd",
            "name": "text",
            "type": "STRING",
            "linkIds": [
              81
            ],
            "pos": [
              -400,
              660
            ]
          },
          {
            "id": "b5671515-bc7a-4be5-b1e7-d4f0f68907d6",
            "name": "seed",
            "type": "INT",
            "linkIds": [
              83
            ],
            "pos": [
              -400,
              680
            ]
          },
          {
            "id": "2838be23-8034-4f16-87a5-d29d790e8391",
            "name": "unet_name",
            "type": "COMBO",
            "linkIds": [
              84
            ],
            "pos": [
              -400,
              700
            ]
          },
          {
            "id": "8a6643b5-8f78-41ff-bbc6-e87b95459706",
            "name": "clip_name",
            "type": "COMBO",
            "linkIds": [
              85
            ],
            "pos": [
              -400,
              720
            ]
          },
          {
            "id": "b103dc94-8ca7-456b-a809-414d7e341a1b",
            "name": "vae_name",
            "type": "COMBO",
            "linkIds": [
              86
            ],
            "pos": [
              -400,
              740
            ]
          },
          {
            "id": "4a7d65af-f0fd-4a5c-832a-bdc0d15b1f30",
            "name": "name",
            "type": "COMBO",
            "linkIds": [
              87
            ],
            "label": "patch_model",
            "pos": [
              -400,
              760
            ]
          }
        ],
        "outputs": [
          {
            "id": "ccb7fa39-4a3d-4eb2-8fd2-91d08fad9570",
            "name": "IMAGE",
            "type": "IMAGE",
            "linkIds": [
              45
            ],
            "localized_name": "IMAGE",
            "pos": [
              1410,
              1120
            ]
          }
        ],
        "widgets": [],
        "nodes": [
          {
            "id": 73,
            "type": "CLIPLoader",
            "pos": [
              20,
              500
            ],
            "size": [
              270,
              150
            ],
            "flags": {},
            "order": 0,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "clip_name",
                "name": "clip_name",
                "type": "COMBO",
                "widget": {
                  "name": "clip_name"
                },
                "link": 85
              },
              {
                "localized_name": "type",
                "name": "type",
                "type": "COMBO",
                "widget": {
                  "name": "type"
                },
                "link": null
              },
              {
                "localized_name": "device",
                "name": "device",
                "shape": 7,
                "type": "COMBO",
                "widget": {
                  "name": "device"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "CLIP",
                "name": "CLIP",
                "type": "CLIP",
                "links": [
                  44
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.3.73",
              "ue_properties": {
                "widget_ue_connectable": {},
                "version": "7.7",
                "input_ue_unconnectable": {}
              },
              "Node name for S&R": "CLIPLoader",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65,
              "models": [
                {
                  "name": "qwen_3_4b.safetensors",
                  "url": "https://huggingface.co/Comfy-Org/z_image_turbo/resolve/main/split_files/text_encoders/qwen_3_4b.safetensors",
                  "directory": "text_encoders"
                }
              ]
            },
            "widgets_values": [
              "qwen_3_4b.safetensors",
              "lumina2",
              "default"
            ]
          },
          {
            "id": 74,
            "type": "UNETLoader",
            "pos": [
              20,
              320
            ],
            "size": [
              270,
              110
            ],
            "flags": {},
            "order": 1,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "unet_name",
                "name": "unet_name",
                "type": "COMBO",
                "widget": {
                  "name": "unet_name"
                },
                "link": 84
              },
              {
                "localized_name": "weight_dtype",
                "name": "weight_dtype",
                "type": "COMBO",
                "widget": {
                  "name": "weight_dtype"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "MODEL",
                "name": "MODEL",
                "type": "MODEL",
                "links": [
                  79
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.3.73",
              "ue_properties": {
                "widget_ue_connectable": {},
                "version": "7.7",
                "input_ue_unconnectable": {}
              },
              "Node name for S&R": "UNETLoader",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65,
              "models": [
                {
                  "name": "z_image_turbo_bf16.safetensors",
                  "url": "https://huggingface.co/Comfy-Org/z_image_turbo/resolve/main/split_files/diffusion_models/z_image_turbo_bf16.safetensors",
                  "directory": "diffusion_models"
                }
              ]
            },
            "widgets_values": [
              "z_image_turbo_bf16.safetensors",
              "default"
            ]
          },
          {
            "id": 75,
            "type": "VAELoader",
            "pos": [
              20,
              760
            ],
            "size": [
              270,
              110
            ],
            "flags": {},
            "order": 2,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "vae_name",
                "name": "vae_name",
                "type": "COMBO",
                "widget": {
                  "name": "vae_name"
                },
                "link": 86
              }
            ],
            "outputs": [
              {
                "localized_name": "VAE",
                "name": "VAE",
                "type": "VAE",
                "links": [
                  39,
                  70
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.3.73",
              "ue_properties": {
                "widget_ue_connectable": {},
                "version": "7.7",
                "input_ue_unconnectable": {}
              },
              "Node name for S&R": "VAELoader",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65,
              "models": [
                {
                  "name": "ae.safetensors",
                  "url": "https://huggingface.co/Comfy-Org/z_image_turbo/resolve/main/split_files/vae/ae.safetensors",
                  "directory": "vae"
                }
              ]
            },
            "widgets_values": [
              "ae.safetensors"
            ]
          },
          {
            "id": 76,
            "type": "ModelPatchLoader",
            "pos": [
              20,
              940
            ],
            "size": [
              270,
              110
            ],
            "flags": {},
            "order": 3,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "name",
                "name": "name",
                "type": "COMBO",
                "widget": {
                  "name": "name"
                },
                "link": 87
              }
            ],
            "outputs": [
              {
                "localized_name": "MODEL_PATCH",
                "name": "MODEL_PATCH",
                "type": "MODEL_PATCH",
                "links": [
                  74
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.3.51",
              "ue_properties": {
                "widget_ue_connectable": {},
                "version": "7.7",
                "input_ue_unconnectable": {}
              },
              "Node name for S&R": "ModelPatchLoader",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65,
              "models": [
                {
                  "name": "Z-Image-Turbo-Fun-Controlnet-Union.safetensors",
                  "url": "https://huggingface.co/alibaba-pai/Z-Image-Turbo-Fun-Controlnet-Union/resolve/main/Z-Image-Turbo-Fun-Controlnet-Union.safetensors",
                  "directory": "model_patches"
                }
              ]
            },
            "widgets_values": [
              "Z-Image-Turbo-Fun-Controlnet-Union.safetensors"
            ]
          },
          {
            "id": 77,
            "type": "VAEDecode",
            "pos": [
              940,
              1100
            ],
            "size": [
              230,
              100
            ],
            "flags": {},
            "order": 4,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "samples",
                "name": "samples",
                "type": "LATENT",
                "link": 38
              },
              {
                "localized_name": "vae",
                "name": "vae",
                "type": "VAE",
                "link": 39
              }
            ],
            "outputs": [
              {
                "localized_name": "IMAGE",
                "name": "IMAGE",
                "type": "IMAGE",
                "slot_index": 0,
                "links": [
                  45
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.3.64",
              "ue_properties": {
                "widget_ue_connectable": {},
                "version": "7.7",
                "input_ue_unconnectable": {}
              },
              "Node name for S&R": "VAEDecode",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            }
          },
          {
            "id": 78,
            "type": "ModelSamplingAuraFlow",
            "pos": [
              910,
              270
            ],
            "size": [
              290,
              110
            ],
            "flags": {},
            "order": 5,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "model",
                "name": "model",
                "type": "MODEL",
                "link": 69
              },
              {
                "localized_name": "shift",
                "name": "shift",
                "type": "FLOAT",
                "widget": {
                  "name": "shift"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "MODEL",
                "name": "MODEL",
                "type": "MODEL",
                "slot_index": 0,
                "links": [
                  40
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.3.64",
              "ue_properties": {
                "widget_ue_connectable": {},
                "version": "7.7",
                "input_ue_unconnectable": {}
              },
              "Node name for S&R": "ModelSamplingAuraFlow",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            },
            "widgets_values": [
              3
            ]
          },
          {
            "id": 79,
            "type": "KSampler",
            "pos": [
              910,
              430
            ],
            "size": [
              300,
              570
            ],
            "flags": {},
            "order": 6,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "model",
                "name": "model",
                "type": "MODEL",
                "link": 40
              },
              {
                "localized_name": "positive",
                "name": "positive",
                "type": "CONDITIONING",
                "link": 41
              },
              {
                "localized_name": "negative",
                "name": "negative",
                "type": "CONDITIONING",
                "link": 42
              },
              {
                "localized_name": "latent_image",
                "name": "latent_image",
                "type": "LATENT",
                "link": 78
              },
              {
                "localized_name": "seed",
                "name": "seed",
                "type": "INT",
                "widget": {
                  "name": "seed"
                },
                "link": 83
              },
              {
                "localized_name": "steps",
                "name": "steps",
                "type": "INT",
                "widget": {
                  "name": "steps"
                },
                "link": null
              },
              {
                "localized_name": "cfg",
                "name": "cfg",
                "type": "FLOAT",
                "widget": {
                  "name": "cfg"
                },
                "link": null
              },
              {
                "localized_name": "sampler_name",
                "name": "sampler_name",
                "type": "COMBO",
                "widget": {
                  "name": "sampler_name"
                },
                "link": null
              },
              {
                "localized_name": "scheduler",
                "name": "scheduler",
                "type": "COMBO",
                "widget": {
                  "name": "scheduler"
                },
                "link": null
              },
              {
                "localized_name": "denoise",
                "name": "denoise",
                "type": "FLOAT",
                "widget": {
                  "name": "denoise"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "LATENT",
                "name": "LATENT",
                "type": "LATENT",
                "slot_index": 0,
                "links": [
                  38
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.3.64",
              "ue_properties": {
                "widget_ue_connectable": {},
                "version": "7.7",
                "input_ue_unconnectable": {}
              },
              "Node name for S&R": "KSampler",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            },
            "widgets_values": [
              729703840979498,
              "randomize",
              8,
              1,
              "res_multistep",
              "simple",
              1
            ]
          },
          {
            "id": 80,
            "type": "ConditioningZeroOut",
            "pos": [
              610,
              830
            ],
            "size": [
              230,
              80
            ],
            "flags": {
              "collapsed": true
            },
            "order": 7,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "conditioning",
                "name": "conditioning",
                "type": "CONDITIONING",
                "link": 36
              }
            ],
            "outputs": [
              {
                "localized_name": "CONDITIONING",
                "name": "CONDITIONING",
                "type": "CONDITIONING",
                "links": [
                  42
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.3.73",
              "ue_properties": {
                "widget_ue_connectable": {},
                "version": "7.7",
                "input_ue_unconnectable": {}
              },
              "Node name for S&R": "ConditioningZeroOut",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            }
          },
          {
            "id": 81,
            "type": "QwenImageDiffsynthControlnet",
            "pos": [
              490,
              970
            ],
            "size": [
              290,
              200
            ],
            "flags": {},
            "order": 8,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "model",
                "name": "model",
                "type": "MODEL",
                "link": 79
              },
              {
                "localized_name": "model_patch",
                "name": "model_patch",
                "type": "MODEL_PATCH",
                "link": 74
              },
              {
                "localized_name": "vae",
                "name": "vae",
                "type": "VAE",
                "link": 70
              },
              {
                "localized_name": "image",
                "name": "image",
                "type": "IMAGE",
                "link": 65
              },
              {
                "localized_name": "mask",
                "name": "mask",
                "shape": 7,
                "type": "MASK",
                "link": null
              },
              {
                "localized_name": "strength",
                "name": "strength",
                "type": "FLOAT",
                "widget": {
                  "name": "strength"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "MODEL",
                "name": "MODEL",
                "type": "MODEL",
                "links": [
                  69
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.3.76",
              "ue_properties": {
                "widget_ue_connectable": {},
                "version": "7.7",
                "input_ue_unconnectable": {}
              },
              "Node name for S&R": "QwenImageDiffsynthControlnet",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            },
            "widgets_values": [
              1
            ]
          },
          {
            "id": 82,
            "type": "EmptySD3LatentImage",
            "pos": [
              40,
              1200
            ],
            "size": [
              260,
              170
            ],
            "flags": {},
            "order": 9,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "width",
                "name": "width",
                "type": "INT",
                "widget": {
                  "name": "width"
                },
                "link": 76
              },
              {
                "localized_name": "height",
                "name": "height",
                "type": "INT",
                "widget": {
                  "name": "height"
                },
                "link": 77
              },
              {
                "localized_name": "batch_size",
                "name": "batch_size",
                "type": "INT",
                "widget": {
                  "name": "batch_size"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "LATENT",
                "name": "LATENT",
                "type": "LATENT",
                "slot_index": 0,
                "links": [
                  78
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.3.64",
              "ue_properties": {
                "widget_ue_connectable": {},
                "version": "7.7",
                "input_ue_unconnectable": {}
              },
              "Node name for S&R": "EmptySD3LatentImage",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            },
            "widgets_values": [
              1024,
              1024,
              1
            ]
          },
          {
            "id": 83,
            "type": "CLIPTextEncode",
            "pos": [
              430,
              310
            ],
            "size": [
              400,
              440
            ],
            "flags": {},
            "order": 10,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "clip",
                "name": "clip",
                "type": "CLIP",
                "link": 44
              },
              {
                "localized_name": "text",
                "name": "text",
                "type": "STRING",
                "widget": {
                  "name": "text"
                },
                "link": 81
              }
            ],
            "outputs": [
              {
                "localized_name": "CONDITIONING",
                "name": "CONDITIONING",
                "type": "CONDITIONING",
                "links": [
                  36,
                  41
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.3.73",
              "ue_properties": {
                "widget_ue_connectable": {},
                "version": "7.7",
                "input_ue_unconnectable": {}
              },
              "Node name for S&R": "CLIPTextEncode",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            },
            "widgets_values": [
              ""
            ],
            "color": "#232",
            "bgcolor": "#353"
          },
          {
            "id": 84,
            "type": "GetImageSize",
            "pos": [
              50,
              1410
            ],
            "size": [
              230,
              120
            ],
            "flags": {
              "collapsed": true
            },
            "order": 11,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "image",
                "name": "image",
                "type": "IMAGE",
                "link": 80
              }
            ],
            "outputs": [
              {
                "localized_name": "width",
                "name": "width",
                "type": "INT",
                "links": [
                  76
                ]
              },
              {
                "localized_name": "height",
                "name": "height",
                "type": "INT",
                "links": [
                  77
                ]
              },
              {
                "localized_name": "batch_size",
                "name": "batch_size",
                "type": "INT",
                "links": null
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.3.76",
              "ue_properties": {
                "widget_ue_connectable": {},
                "version": "7.7",
                "input_ue_unconnectable": {}
              },
              "Node name for S&R": "GetImageSize",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            }
          }
        ],
        "groups": [
          {
            "id": 3,
            "title": "Prompt",
            "bounding": [
              410,
              230,
              440,
              630
            ],
            "color": "#3f789e",
            "font_size": 24,
            "flags": {}
          },
          {
            "id": 4,
            "title": "Model",
            "bounding": [
              -50,
              230,
              430,
              840
            ],
            "color": "#3f789e",
            "font_size": 24,
            "flags": {}
          },
          {
            "id": 8,
            "title": "Apple ControlNet",
            "bounding": [
              410,
              890,
              440,
              330
            ],
            "color": "#3f789e",
            "font_size": 24,
            "flags": {}
          },
          {
            "id": 9,
            "title": "Image Size",
            "bounding": [
              -50,
              1100,
              430,
              350
            ],
            "color": "#3f789e",
            "font_size": 24,
            "flags": {}
          }
        ],
        "links": [
          {
            "id": 38,
            "origin_id": 79,
            "origin_slot": 0,
            "target_id": 77,
            "target_slot": 0,
            "type": "LATENT"
          },
          {
            "id": 39,
            "origin_id": 75,
            "origin_slot": 0,
            "target_id": 77,
            "target_slot": 1,
            "type": "VAE"
          },
          {
            "id": 69,
            "origin_id": 81,
            "origin_slot": 0,
            "target_id": 78,
            "target_slot": 0,
            "type": "MODEL"
          },
          {
            "id": 40,
            "origin_id": 78,
            "origin_slot": 0,
            "target_id": 79,
            "target_slot": 0,
            "type": "MODEL"
          },
          {
            "id": 41,
            "origin_id": 83,
            "origin_slot": 0,
            "target_id": 79,
            "target_slot": 1,
            "type": "CONDITIONING"
          },
          {
            "id": 42,
            "origin_id": 80,
            "origin_slot": 0,
            "target_id": 79,
            "target_slot": 2,
            "type": "CONDITIONING"
          },
          {
            "id": 78,
            "origin_id": 82,
            "origin_slot": 0,
            "target_id": 79,
            "target_slot": 3,
            "type": "LATENT"
          },
          {
            "id": 36,
            "origin_id": 83,
            "origin_slot": 0,
            "target_id": 80,
            "target_slot": 0,
            "type": "CONDITIONING"
          },
          {
            "id": 79,
            "origin_id": 74,
            "origin_slot": 0,
            "target_id": 81,
            "target_slot": 0,
            "type": "MODEL"
          },
          {
            "id": 74,
            "origin_id": 76,
            "origin_slot": 0,
            "target_id": 81,
            "target_slot": 1,
            "type": "MODEL_PATCH"
          },
          {
            "id": 70,
            "origin_id": 75,
            "origin_slot": 0,
            "target_id": 81,
            "target_slot": 2,
            "type": "VAE"
          },
          {
            "id": 76,
            "origin_id": 84,
            "origin_slot": 0,
            "target_id": 82,
            "target_slot": 0,
            "type": "INT"
          },
          {
            "id": 77,
            "origin_id": 84,
            "origin_slot": 1,
            "target_id": 82,
            "target_slot": 1,
            "type": "INT"
          },
          {
            "id": 44,
            "origin_id": 73,
            "origin_slot": 0,
            "target_id": 83,
            "target_slot": 0,
            "type": "CLIP"
          },
          {
            "id": 65,
            "origin_id": -10,
            "origin_slot": 0,
            "target_id": 81,
            "target_slot": 3,
            "type": "IMAGE"
          },
          {
            "id": 80,
            "origin_id": -10,
            "origin_slot": 0,
            "target_id": 84,
            "target_slot": 0,
            "type": "IMAGE"
          },
          {
            "id": 45,
            "origin_id": 77,
            "origin_slot": 0,
            "target_id": -20,
            "target_slot": 0,
            "type": "IMAGE"
          },
          {
            "id": 81,
            "origin_id": -10,
            "origin_slot": 1,
            "target_id": 83,
            "target_slot": 1,
            "type": "STRING"
          },
          {
            "id": 83,
            "origin_id": -10,
            "origin_slot": 2,
            "target_id": 79,
            "target_slot": 4,
            "type": "INT"
          },
          {
            "id": 84,
            "origin_id": -10,
            "origin_slot": 3,
            "target_id": 74,
            "target_slot": 0,
            "type": "COMBO"
          },
          {
            "id": 85,
            "origin_id": -10,
            "origin_slot": 4,
            "target_id": 73,
            "target_slot": 0,
            "type": "COMBO"
          },
          {
            "id": 86,
            "origin_id": -10,
            "origin_slot": 5,
            "target_id": 75,
            "target_slot": 0,
            "type": "COMBO"
          },
          {
            "id": 87,
            "origin_id": -10,
            "origin_slot": 6,
            "target_id": 76,
            "target_slot": 0,
            "type": "COMBO"
          }
        ],
        "extra": {
          "workflowRendererVersion": "LG"
        },
        "category": "Image generation and editing/Conditioned",
        "description": "Generates images from a text prompt and ControlNet conditioning (e.g. depth, canny) using Z-Image-Turbo."
      }
    ]
  },
  "extra": {
    "ue_links": []
  }
}
```
