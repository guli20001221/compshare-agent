# Image Edit (LongCat Image Edit)

- 来源类别：内置工作流蓝图
- 镜像内原始路径：`/ComfyUI/blueprints/Image Edit (LongCat Image Edit).json`
- 节点数量：1
- 连线数量：0

## 节点类型

- `372a02a0-a79c-40b4-84a9-34f246fe0e9c` × 1

## 原始工作流 JSON

```json
{
  "revision": 0,
  "last_node_id": 176,
  "last_link_id": 0,
  "nodes": [
    {
      "id": 176,
      "type": "372a02a0-a79c-40b4-84a9-34f246fe0e9c",
      "pos": [
        967.0861152473078,
        4977.534165136897
      ],
      "size": [
        330,
        380
      ],
      "flags": {},
      "order": 3,
      "mode": 0,
      "inputs": [
        {
          "localized_name": "image",
          "name": "image",
          "type": "IMAGE",
          "link": null
        },
        {
          "name": "prompt",
          "type": "STRING",
          "widget": {
            "name": "prompt"
          },
          "link": null
        },
        {
          "name": "steps",
          "type": "INT",
          "widget": {
            "name": "steps"
          },
          "link": null
        },
        {
          "name": "cfg",
          "type": "FLOAT",
          "widget": {
            "name": "cfg"
          },
          "link": null
        },
        {
          "name": "seed",
          "type": "INT",
          "widget": {
            "name": "seed"
          },
          "link": null
        },
        {
          "name": "unet_name",
          "type": "COMBO",
          "widget": {
            "name": "unet_name"
          },
          "link": null
        },
        {
          "name": "clip_name",
          "type": "COMBO",
          "widget": {
            "name": "clip_name"
          },
          "link": null
        },
        {
          "name": "vae_name",
          "type": "COMBO",
          "widget": {
            "name": "vae_name"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "localized_name": "IMAGE",
          "name": "IMAGE",
          "type": "IMAGE",
          "links": []
        }
      ],
      "properties": {
        "proxyWidgets": [
          [
            "27",
            "prompt"
          ],
          [
            "33",
            "steps"
          ],
          [
            "33",
            "cfg"
          ],
          [
            "33",
            "seed"
          ],
          [
            "34",
            "unet_name"
          ],
          [
            "38",
            "clip_name"
          ],
          [
            "26",
            "vae_name"
          ]
        ],
        "cnr_id": "comfy-core",
        "ver": "0.18.1",
        "ue_properties": {
          "widget_ue_connectable": {},
          "version": "7.7",
          "input_ue_unconnectable": {}
        }
      },
      "widgets_values": [],
      "title": "Image Edit (LongCat Image Edit)"
    }
  ],
  "links": [],
  "version": 0.4,
  "definitions": {
    "subgraphs": [
      {
        "id": "372a02a0-a79c-40b4-84a9-34f246fe0e9c",
        "version": 1,
        "state": {
          "lastGroupId": 8,
          "lastNodeId": 176,
          "lastLinkId": 376,
          "lastRerouteId": 0
        },
        "revision": 0,
        "config": {},
        "name": "Image Edit (LongCat Image Edit)",
        "inputNode": {
          "id": -10,
          "bounding": [
            -750,
            380,
            120,
            200
          ]
        },
        "outputNode": {
          "id": -20,
          "bounding": [
            1680,
            340,
            120,
            60
          ]
        },
        "inputs": [
          {
            "id": "616c4f3e-8b64-4711-bee2-5ecbe1814fe4",
            "name": "image",
            "type": "IMAGE",
            "linkIds": [
              14
            ],
            "localized_name": "image",
            "pos": [
              -650,
              400
            ]
          },
          {
            "id": "d39759fc-a5a9-4b82-a88f-df9b953f1d98",
            "name": "prompt",
            "type": "STRING",
            "linkIds": [
              36
            ],
            "pos": [
              -650,
              420
            ]
          },
          {
            "id": "48627f43-cdf1-4ea9-9e11-ec13451a7323",
            "name": "steps",
            "type": "INT",
            "linkIds": [
              37
            ],
            "pos": [
              -650,
              440
            ]
          },
          {
            "id": "2213f872-d40f-4fc3-be01-b8fc73f1d92c",
            "name": "cfg",
            "type": "FLOAT",
            "linkIds": [
              42
            ],
            "pos": [
              -650,
              460
            ]
          },
          {
            "id": "2c7b3e65-e71e-4a9b-a9f8-d2e814ccb6af",
            "name": "seed",
            "type": "INT",
            "linkIds": [
              43
            ],
            "pos": [
              -650,
              480
            ]
          },
          {
            "id": "bddb2317-7210-48d5-81fd-6b2d6fac33f4",
            "name": "unet_name",
            "type": "COMBO",
            "linkIds": [
              44
            ],
            "pos": [
              -650,
              500
            ]
          },
          {
            "id": "a283167b-6d7f-4d19-ad86-1fff2335c08d",
            "name": "clip_name",
            "type": "COMBO",
            "linkIds": [
              45
            ],
            "pos": [
              -650,
              520
            ]
          },
          {
            "id": "e033047f-cc37-4043-b4a0-25d7bab661af",
            "name": "vae_name",
            "type": "COMBO",
            "linkIds": [
              46
            ],
            "pos": [
              -650,
              540
            ]
          }
        ],
        "outputs": [
          {
            "id": "0a288e93-c03f-4805-80f3-4e320a6a492e",
            "name": "IMAGE",
            "type": "IMAGE",
            "linkIds": [
              20
            ],
            "localized_name": "IMAGE",
            "pos": [
              1700,
              360
            ]
          }
        ],
        "widgets": [],
        "nodes": [
          {
            "id": 26,
            "type": "VAELoader",
            "pos": [
              -360,
              590
            ],
            "size": [
              270,
              110
            ],
            "flags": {},
            "order": 0,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "vae_name",
                "name": "vae_name",
                "type": "COMBO",
                "widget": {
                  "name": "vae_name"
                },
                "link": 46
              }
            ],
            "outputs": [
              {
                "localized_name": "VAE",
                "name": "VAE",
                "type": "VAE",
                "slot_index": 0,
                "links": [
                  4,
                  5,
                  6,
                  7
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.3.73",
              "ue_properties": {
                "widget_ue_connectable": {},
                "version": "7.7",
                "input_ue_unconnectable": {}
              },
              "Node name for S&R": "VAELoader",
              "models": [
                {
                  "name": "ae.safetensors",
                  "url": "https://huggingface.co/Comfy-Org/z_image_turbo/resolve/main/split_files/vae/ae.safetensors",
                  "directory": "vae"
                }
              ]
            },
            "widgets_values": [
              "ae.safetensors"
            ]
          },
          {
            "id": 27,
            "type": "TextEncodeQwenImageEdit",
            "pos": [
              10,
              200
            ],
            "size": [
              280,
              190
            ],
            "flags": {},
            "order": 1,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "clip",
                "name": "clip",
                "type": "CLIP",
                "link": 2
              },
              {
                "localized_name": "vae",
                "name": "vae",
                "shape": 7,
                "type": "VAE",
                "link": 4
              },
              {
                "localized_name": "image",
                "name": "image",
                "shape": 7,
                "type": "IMAGE",
                "link": 15
              },
              {
                "localized_name": "prompt",
                "name": "prompt",
                "type": "STRING",
                "widget": {
                  "name": "prompt"
                },
                "link": 36
              }
            ],
            "outputs": [
              {
                "localized_name": "CONDITIONING",
                "name": "CONDITIONING",
                "type": "CONDITIONING",
                "slot_index": 0,
                "links": [
                  8
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.3.73",
              "ue_properties": {
                "widget_ue_connectable": {},
                "version": "7.7",
                "input_ue_unconnectable": {}
              },
              "Node name for S&R": "TextEncodeQwenImageEdit"
            },
            "widgets_values": [
              ""
            ]
          },
          {
            "id": 28,
            "type": "TextEncodeQwenImageEdit",
            "pos": [
              10,
              440
            ],
            "size": [
              280,
              190
            ],
            "flags": {},
            "order": 2,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "clip",
                "name": "clip",
                "type": "CLIP",
                "link": 3
              },
              {
                "localized_name": "vae",
                "name": "vae",
                "shape": 7,
                "type": "VAE",
                "link": 5
              },
              {
                "localized_name": "image",
                "name": "image",
                "shape": 7,
                "type": "IMAGE",
                "link": 16
              },
              {
                "localized_name": "prompt",
                "name": "prompt",
                "type": "STRING",
                "widget": {
                  "name": "prompt"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "CONDITIONING",
                "name": "CONDITIONING",
                "type": "CONDITIONING",
                "slot_index": 0,
                "links": [
                  9
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.3.73",
              "ue_properties": {
                "widget_ue_connectable": {},
                "version": "7.7",
                "input_ue_unconnectable": {}
              },
              "Node name for S&R": "TextEncodeQwenImageEdit"
            },
            "widgets_values": [
              ""
            ]
          },
          {
            "id": 29,
            "type": "FluxKontextMultiReferenceLatentMethod",
            "pos": [
              660,
              200
            ],
            "size": [
              270,
              80
            ],
            "flags": {},
            "order": 3,
            "mode": 0,
            "showAdvanced": false,
            "inputs": [
              {
                "localized_name": "conditioning",
                "name": "conditioning",
                "type": "CONDITIONING",
                "link": 10
              },
              {
                "localized_name": "reference_latents_method",
                "name": "reference_latents_method",
                "type": "COMBO",
                "widget": {
                  "name": "reference_latents_method"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "CONDITIONING",
                "name": "CONDITIONING",
                "type": "CONDITIONING",
                "slot_index": 0,
                "links": [
                  12
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.3.73",
              "ue_properties": {
                "widget_ue_connectable": {},
                "version": "7.7",
                "input_ue_unconnectable": {}
              },
              "Node name for S&R": "FluxKontextMultiReferenceLatentMethod"
            },
            "widgets_values": [
              "index"
            ]
          },
          {
            "id": 30,
            "type": "FluxGuidance",
            "pos": [
              330,
              440
            ],
            "size": [
              230,
              110
            ],
            "flags": {},
            "order": 4,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "conditioning",
                "name": "conditioning",
                "type": "CONDITIONING",
                "link": 9
              },
              {
                "localized_name": "guidance",
                "name": "guidance",
                "type": "FLOAT",
                "widget": {
                  "name": "guidance"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "CONDITIONING",
                "name": "CONDITIONING",
                "type": "CONDITIONING",
                "slot_index": 0,
                "links": [
                  11
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.3.73",
              "ue_properties": {
                "widget_ue_connectable": {},
                "version": "7.7",
                "input_ue_unconnectable": {}
              },
              "Node name for S&R": "FluxGuidance"
            },
            "widgets_values": [
              4.5
            ]
          },
          {
            "id": 31,
            "type": "FluxGuidance",
            "pos": [
              330,
              200
            ],
            "size": [
              230,
              110
            ],
            "flags": {},
            "order": 5,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "conditioning",
                "name": "conditioning",
                "type": "CONDITIONING",
                "link": 8
              },
              {
                "localized_name": "guidance",
                "name": "guidance",
                "type": "FLOAT",
                "widget": {
                  "name": "guidance"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "CONDITIONING",
                "name": "CONDITIONING",
                "type": "CONDITIONING",
                "slot_index": 0,
                "links": [
                  10
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.3.73",
              "ue_properties": {
                "widget_ue_connectable": {},
                "version": "7.7",
                "input_ue_unconnectable": {}
              },
              "Node name for S&R": "FluxGuidance"
            },
            "widgets_values": [
              4.5
            ]
          },
          {
            "id": 32,
            "type": "FluxKontextMultiReferenceLatentMethod",
            "pos": [
              660,
              440
            ],
            "size": [
              270,
              80
            ],
            "flags": {},
            "order": 6,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "conditioning",
                "name": "conditioning",
                "type": "CONDITIONING",
                "link": 11
              },
              {
                "localized_name": "reference_latents_method",
                "name": "reference_latents_method",
                "type": "COMBO",
                "widget": {
                  "name": "reference_latents_method"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "CONDITIONING",
                "name": "CONDITIONING",
                "type": "CONDITIONING",
                "slot_index": 0,
                "links": [
                  13
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.3.73",
              "ue_properties": {
                "widget_ue_connectable": {},
                "version": "7.7",
                "input_ue_unconnectable": {}
              },
              "Node name for S&R": "FluxKontextMultiReferenceLatentMethod"
            },
            "widgets_values": [
              "index"
            ]
          },
          {
            "id": 33,
            "type": "KSampler",
            "pos": [
              1080,
              210
            ],
            "size": [
              270,
              460
            ],
            "flags": {},
            "order": 7,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "model",
                "name": "model",
                "type": "MODEL",
                "link": 1
              },
              {
                "localized_name": "positive",
                "name": "positive",
                "type": "CONDITIONING",
                "link": 12
              },
              {
                "localized_name": "negative",
                "name": "negative",
                "type": "CONDITIONING",
                "link": 13
              },
              {
                "localized_name": "latent_image",
                "name": "latent_image",
                "type": "LATENT",
                "link": 18
              },
              {
                "localized_name": "seed",
                "name": "seed",
                "type": "INT",
                "widget": {
                  "name": "seed"
                },
                "link": 43
              },
              {
                "localized_name": "steps",
                "name": "steps",
                "type": "INT",
                "widget": {
                  "name": "steps"
                },
                "link": 37
              },
              {
                "localized_name": "cfg",
                "name": "cfg",
                "type": "FLOAT",
                "widget": {
                  "name": "cfg"
                },
                "link": 42
              },
              {
                "localized_name": "sampler_name",
                "name": "sampler_name",
                "type": "COMBO",
                "widget": {
                  "name": "sampler_name"
                },
                "link": null
              },
              {
                "localized_name": "scheduler",
                "name": "scheduler",
                "type": "COMBO",
                "widget": {
                  "name": "scheduler"
                },
                "link": null
              },
              {
                "localized_name": "denoise",
                "name": "denoise",
                "type": "FLOAT",
                "widget": {
                  "name": "denoise"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "LATENT",
                "name": "LATENT",
                "type": "LATENT",
                "slot_index": 0,
                "links": [
                  19
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.3.73",
              "ue_properties": {
                "widget_ue_connectable": {},
                "version": "7.7",
                "input_ue_unconnectable": {}
              },
              "Node name for S&R": "KSampler"
            },
            "widgets_values": [
              43,
              "fixed",
              50,
              4.5,
              "euler",
              "simple",
              1
            ]
          },
          {
            "id": 34,
            "type": "UNETLoader",
            "pos": [
              -360,
              170
            ],
            "size": [
              270,
              110
            ],
            "flags": {},
            "order": 8,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "unet_name",
                "name": "unet_name",
                "type": "COMBO",
                "widget": {
                  "name": "unet_name"
                },
                "link": 44
              },
              {
                "localized_name": "weight_dtype",
                "name": "weight_dtype",
                "type": "COMBO",
                "widget": {
                  "name": "weight_dtype"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "MODEL",
                "name": "MODEL",
                "type": "MODEL",
                "slot_index": 0,
                "links": [
                  1
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.3.73",
              "ue_properties": {
                "widget_ue_connectable": {},
                "version": "7.7",
                "input_ue_unconnectable": {}
              },
              "Node name for S&R": "UNETLoader",
              "models": [
                {
                  "name": "longcat_image_edit_bf16.safetensors",
                  "url": "https://huggingface.co/TalmajM/LongCat-Image-Edit_ComfyUI_repackaged/resolve/main/split_files/diffusion_models/longcat_image_edit_bf16.safetensors",
                  "directory": "diffusion_models"
                }
              ]
            },
            "widgets_values": [
              "longcat_image_edit_bf16.safetensors",
              "default"
            ]
          },
          {
            "id": 35,
            "type": "VAEEncode",
            "pos": [
              710,
              790
            ],
            "size": [
              260,
              100
            ],
            "flags": {},
            "order": 9,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "pixels",
                "name": "pixels",
                "type": "IMAGE",
                "link": 17
              },
              {
                "localized_name": "vae",
                "name": "vae",
                "type": "VAE",
                "link": 6
              }
            ],
            "outputs": [
              {
                "localized_name": "LATENT",
                "name": "LATENT",
                "type": "LATENT",
                "slot_index": 0,
                "links": [
                  18
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.3.73",
              "ue_properties": {
                "widget_ue_connectable": {},
                "version": "7.7",
                "input_ue_unconnectable": {}
              },
              "Node name for S&R": "VAEEncode"
            }
          },
          {
            "id": 36,
            "type": "VAEDecode",
            "pos": [
              1100,
              800
            ],
            "size": [
              230,
              100
            ],
            "flags": {},
            "order": 10,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "samples",
                "name": "samples",
                "type": "LATENT",
                "link": 19
              },
              {
                "localized_name": "vae",
                "name": "vae",
                "type": "VAE",
                "link": 7
              }
            ],
            "outputs": [
              {
                "localized_name": "IMAGE",
                "name": "IMAGE",
                "type": "IMAGE",
                "slot_index": 0,
                "links": [
                  20
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.3.73",
              "ue_properties": {
                "widget_ue_connectable": {},
                "version": "7.7",
                "input_ue_unconnectable": {}
              },
              "Node name for S&R": "VAEDecode"
            }
          },
          {
            "id": 37,
            "type": "ImageScaleToTotalPixels",
            "pos": [
              -370,
              790
            ],
            "size": [
              270,
              140
            ],
            "flags": {},
            "order": 11,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "image",
                "name": "image",
                "type": "IMAGE",
                "link": 14
              },
              {
                "localized_name": "upscale_method",
                "name": "upscale_method",
                "type": "COMBO",
                "widget": {
                  "name": "upscale_method"
                },
                "link": null
              },
              {
                "localized_name": "megapixels",
                "name": "megapixels",
                "type": "FLOAT",
                "widget": {
                  "name": "megapixels"
                },
                "link": null
              },
              {
                "localized_name": "resolution_steps",
                "name": "resolution_steps",
                "type": "INT",
                "widget": {
                  "name": "resolution_steps"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "IMAGE",
                "name": "IMAGE",
                "type": "IMAGE",
                "slot_index": 0,
                "links": [
                  15,
                  16,
                  17
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.3.73",
              "ue_properties": {
                "widget_ue_connectable": {},
                "version": "7.7",
                "input_ue_unconnectable": {}
              },
              "Node name for S&R": "ImageScaleToTotalPixels"
            },
            "widgets_values": [
              "lanczos",
              1,
              16
            ]
          },
          {
            "id": 38,
            "type": "CLIPLoader",
            "pos": [
              -360,
              360
            ],
            "size": [
              270,
              150
            ],
            "flags": {},
            "order": 12,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "clip_name",
                "name": "clip_name",
                "type": "COMBO",
                "widget": {
                  "name": "clip_name"
                },
                "link": 45
              },
              {
                "localized_name": "type",
                "name": "type",
                "type": "COMBO",
                "widget": {
                  "name": "type"
                },
                "link": null
              },
              {
                "localized_name": "device",
                "name": "device",
                "shape": 7,
                "type": "COMBO",
                "widget": {
                  "name": "device"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "CLIP",
                "name": "CLIP",
                "type": "CLIP",
                "slot_index": 0,
                "links": [
                  2,
                  3
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.3.73",
              "ue_properties": {
                "widget_ue_connectable": {},
                "version": "7.7",
                "input_ue_unconnectable": {}
              },
              "Node name for S&R": "CLIPLoader",
              "models": [
                {
                  "name": "qwen_2.5_vl_7b_fp8_scaled.safetensors",
                  "url": "https://huggingface.co/Comfy-Org/Qwen-Image_ComfyUI/resolve/main/split_files/text_encoders/qwen_2.5_vl_7b_fp8_scaled.safetensors",
                  "directory": "text_encoders"
                }
              ]
            },
            "widgets_values": [
              "qwen_2.5_vl_7b_fp8_scaled.safetensors",
              "longcat_image",
              "default"
            ]
          }
        ],
        "groups": [
          {
            "id": 1,
            "title": "Models",
            "bounding": [
              -380,
              100,
              320,
              630
            ],
            "color": "#3f789e",
            "font_size": 24,
            "flags": {}
          },
          {
            "id": 3,
            "title": "Conditioning",
            "bounding": [
              -30,
              100,
              1030,
              630
            ],
            "color": "#3f789e",
            "font_size": 24,
            "flags": {}
          },
          {
            "id": 4,
            "title": "Sample",
            "bounding": [
              1030,
              100,
              360,
              630
            ],
            "color": "#3f789e",
            "font_size": 24,
            "flags": {}
          }
        ],
        "links": [
          {
            "id": 2,
            "origin_id": 38,
            "origin_slot": 0,
            "target_id": 27,
            "target_slot": 0,
            "type": "CLIP"
          },
          {
            "id": 4,
            "origin_id": 26,
            "origin_slot": 0,
            "target_id": 27,
            "target_slot": 1,
            "type": "VAE"
          },
          {
            "id": 15,
            "origin_id": 37,
            "origin_slot": 0,
            "target_id": 27,
            "target_slot": 2,
            "type": "IMAGE"
          },
          {
            "id": 3,
            "origin_id": 38,
            "origin_slot": 0,
            "target_id": 28,
            "target_slot": 0,
            "type": "CLIP"
          },
          {
            "id": 5,
            "origin_id": 26,
            "origin_slot": 0,
            "target_id": 28,
            "target_slot": 1,
            "type": "VAE"
          },
          {
            "id": 16,
            "origin_id": 37,
            "origin_slot": 0,
            "target_id": 28,
            "target_slot": 2,
            "type": "IMAGE"
          },
          {
            "id": 10,
            "origin_id": 31,
            "origin_slot": 0,
            "target_id": 29,
            "target_slot": 0,
            "type": "CONDITIONING"
          },
          {
            "id": 9,
            "origin_id": 28,
            "origin_slot": 0,
            "target_id": 30,
            "target_slot": 0,
            "type": "CONDITIONING"
          },
          {
            "id": 8,
            "origin_id": 27,
            "origin_slot": 0,
            "target_id": 31,
            "target_slot": 0,
            "type": "CONDITIONING"
          },
          {
            "id": 11,
            "origin_id": 30,
            "origin_slot": 0,
            "target_id": 32,
            "target_slot": 0,
            "type": "CONDITIONING"
          },
          {
            "id": 1,
            "origin_id": 34,
            "origin_slot": 0,
            "target_id": 33,
            "target_slot": 0,
            "type": "MODEL"
          },
          {
            "id": 12,
            "origin_id": 29,
            "origin_slot": 0,
            "target_id": 33,
            "target_slot": 1,
            "type": "CONDITIONING"
          },
          {
            "id": 13,
            "origin_id": 32,
            "origin_slot": 0,
            "target_id": 33,
            "target_slot": 2,
            "type": "CONDITIONING"
          },
          {
            "id": 18,
            "origin_id": 35,
            "origin_slot": 0,
            "target_id": 33,
            "target_slot": 3,
            "type": "LATENT"
          },
          {
            "id": 17,
            "origin_id": 37,
            "origin_slot": 0,
            "target_id": 35,
            "target_slot": 0,
            "type": "IMAGE"
          },
          {
            "id": 6,
            "origin_id": 26,
            "origin_slot": 0,
            "target_id": 35,
            "target_slot": 1,
            "type": "VAE"
          },
          {
            "id": 19,
            "origin_id": 33,
            "origin_slot": 0,
            "target_id": 36,
            "target_slot": 0,
            "type": "LATENT"
          },
          {
            "id": 7,
            "origin_id": 26,
            "origin_slot": 0,
            "target_id": 36,
            "target_slot": 1,
            "type": "VAE"
          },
          {
            "id": 14,
            "origin_id": -10,
            "origin_slot": 0,
            "target_id": 37,
            "target_slot": 0,
            "type": "IMAGE"
          },
          {
            "id": 20,
            "origin_id": 36,
            "origin_slot": 0,
            "target_id": -20,
            "target_slot": 0,
            "type": "IMAGE"
          },
          {
            "id": 36,
            "origin_id": -10,
            "origin_slot": 1,
            "target_id": 27,
            "target_slot": 3,
            "type": "STRING"
          },
          {
            "id": 37,
            "origin_id": -10,
            "origin_slot": 2,
            "target_id": 33,
            "target_slot": 5,
            "type": "INT"
          },
          {
            "id": 42,
            "origin_id": -10,
            "origin_slot": 3,
            "target_id": 33,
            "target_slot": 6,
            "type": "FLOAT"
          },
          {
            "id": 43,
            "origin_id": -10,
            "origin_slot": 4,
            "target_id": 33,
            "target_slot": 4,
            "type": "INT"
          },
          {
            "id": 44,
            "origin_id": -10,
            "origin_slot": 5,
            "target_id": 34,
            "target_slot": 0,
            "type": "COMBO"
          },
          {
            "id": 45,
            "origin_id": -10,
            "origin_slot": 6,
            "target_id": 38,
            "target_slot": 0,
            "type": "COMBO"
          },
          {
            "id": 46,
            "origin_id": -10,
            "origin_slot": 7,
            "target_id": 26,
            "target_slot": 0,
            "type": "COMBO"
          }
        ],
        "extra": {},
        "category": "Image generation and editing/Edit image",
        "description": "Edits images via text instructions using LongCat Image Edit, an instruction-following image editing diffusion model."
      }
    ]
  },
  "extra": {
    "ue_links": []
  }
}
```
