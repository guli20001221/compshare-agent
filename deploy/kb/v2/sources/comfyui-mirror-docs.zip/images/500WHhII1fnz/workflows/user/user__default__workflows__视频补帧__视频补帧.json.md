# 视频补帧

- 来源类别：用户工作流
- 镜像内原始路径：`/ComfyUI/user/default/workflows/视频补帧/视频补帧.json`
- 节点数量：4
- 连线数量：4

## 节点类型

- `RIFE VFI` × 1
- `VHS_LoadVideo` × 1
- `VHS_VideoCombine` × 1
- `easy cleanGpuUsed` × 1

## 工作流引用的模型或媒体文件

- `.ap-beijing.myqcloud.com//6026960d747ab2678bc6b02e27205fea/output/补帧_00001_p82_vkqvq_1777362253.mp4`
- `/ComfyUI/output/补帧_00003-audio.mp4`
- `Wanimate_00046-audio (1).mp4`
- `rife49.pth`
- `补帧_00003-audio.mp4`

## 原始工作流 JSON

```json
{
  "id": "48720452-ed20-4002-946f-b57e22b0e35f",
  "revision": 0,
  "last_node_id": 202,
  "last_link_id": 300,
  "nodes": [
    {
      "id": 199,
      "type": "easy cleanGpuUsed",
      "pos": [
        2340.426025390625,
        5573.86572265625
      ],
      "size": [
        157.38925170898438,
        26
      ],
      "flags": {},
      "order": 3,
      "mode": 0,
      "inputs": [
        {
          "label": "输入任何",
          "name": "anything",
          "type": "*",
          "link": 295
        }
      ],
      "outputs": [
        {
          "label": "output",
          "name": "output",
          "type": "*"
        }
      ],
      "properties": {
        "Node name for S&R": "easy cleanGpuUsed",
        "widget_ue_connectable": {}
      },
      "widgets_values": []
    },
    {
      "id": 198,
      "type": "VHS_VideoCombine",
      "pos": [
        2092.770263671875,
        5403.4873046875
      ],
      "size": [
        476.0711669921875,
        1158.793212890625
      ],
      "flags": {},
      "order": 2,
      "mode": 0,
      "inputs": [
        {
          "label": "图像",
          "name": "images",
          "type": "IMAGE",
          "link": 293
        },
        {
          "label": "音频",
          "name": "audio",
          "shape": 7,
          "type": "AUDIO",
          "link": 300
        },
        {
          "label": "批次管理",
          "name": "meta_batch",
          "shape": 7,
          "type": "VHS_BatchManager"
        },
        {
          "label": "vae",
          "name": "vae",
          "shape": 7,
          "type": "VAE"
        },
        {
          "label": "loop_count",
          "name": "loop_count",
          "type": "INT",
          "widget": {
            "name": "loop_count"
          }
        },
        {
          "label": "filename_prefix",
          "name": "filename_prefix",
          "type": "STRING",
          "widget": {
            "name": "filename_prefix"
          }
        },
        {
          "label": "format",
          "name": "format",
          "type": "COMBO",
          "widget": {
            "name": "format"
          }
        },
        {
          "label": "pingpong",
          "name": "pingpong",
          "type": "BOOLEAN",
          "widget": {
            "name": "pingpong"
          }
        },
        {
          "label": "save_output",
          "name": "save_output",
          "type": "BOOLEAN",
          "widget": {
            "name": "save_output"
          }
        }
      ],
      "outputs": [
        {
          "label": "文件名",
          "name": "Filenames",
          "type": "VHS_FILENAMES",
          "links": [
            295
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "VHS_VideoCombine",
        "cnr_id": "comfyui-videohelpersuite",
        "ver": "0a75c7958fe320efcb052f1d9f8451fd20c730a8",
        "widget_ue_connectable": {}
      },
      "widgets_values": {
        "frame_rate": 30,
        "loop_count": 0,
        "filename_prefix": "补帧",
        "format": "video/h264-mp4",
        "pix_fmt": "yuv420p",
        "crf": 16,
        "save_metadata": true,
        "trim_to_audio": false,
        "pingpong": false,
        "save_output": true,
        "videopreview": {
          "paused": false,
          "hidden": false,
          "params": {
            "score": "0",
            "filename": "补帧_00003-audio.mp4",
            "cos_url": "https://rh-images-1252422369.cos.ap-beijing.myqcloud.com//6026960d747ab2678bc6b02e27205fea/output/补帧_00001_p82_vkqvq_1777362253.mp4",
            "workflow": "补帧_00003.png",
            "fullpath": "/ComfyUI/output/补帧_00003-audio.mp4",
            "format": "video/h264-mp4",
            "subfolder": "",
            "label": "Normal",
            "type": "output",
            "frame_rate": 30
          }
        }
      },
      "color": "#323",
      "bgcolor": "#535"
    },
    {
      "id": 194,
      "type": "VHS_LoadVideo",
      "pos": [
        1410.9837646484375,
        5419.3837890625
      ],
      "size": [
        253.279296875,
        738.4962768554688
      ],
      "flags": {},
      "order": 0,
      "mode": 0,
      "inputs": [
        {
          "label": "批次管理",
          "name": "meta_batch",
          "shape": 7,
          "type": "VHS_BatchManager"
        },
        {
          "label": "vae",
          "name": "vae",
          "shape": 7,
          "type": "VAE"
        },
        {
          "label": "video",
          "name": "video",
          "type": "COMBO",
          "widget": {
            "name": "video"
          }
        },
        {
          "label": "force_rate",
          "name": "force_rate",
          "type": "FLOAT",
          "widget": {
            "name": "force_rate"
          }
        },
        {
          "label": "custom_width",
          "name": "custom_width",
          "type": "INT",
          "widget": {
            "name": "custom_width"
          }
        },
        {
          "label": "custom_height",
          "name": "custom_height",
          "type": "INT",
          "widget": {
            "name": "custom_height"
          }
        },
        {
          "label": "frame_load_cap",
          "name": "frame_load_cap",
          "type": "INT",
          "widget": {
            "name": "frame_load_cap"
          }
        },
        {
          "label": "skip_first_frames",
          "name": "skip_first_frames",
          "type": "INT",
          "widget": {
            "name": "skip_first_frames"
          }
        },
        {
          "label": "select_every_nth",
          "name": "select_every_nth",
          "type": "INT",
          "widget": {
            "name": "select_every_nth"
          }
        },
        {
          "label": "format",
          "name": "format",
          "shape": 7,
          "type": "COMBO",
          "widget": {
            "name": "format"
          }
        }
      ],
      "outputs": [
        {
          "label": "图像",
          "name": "IMAGE",
          "type": "IMAGE",
          "links": [
            285
          ]
        },
        {
          "label": "帧计数",
          "name": "frame_count",
          "type": "INT"
        },
        {
          "label": "音频",
          "name": "audio",
          "type": "AUDIO",
          "links": [
            300
          ]
        },
        {
          "label": "视频信息",
          "name": "video_info",
          "type": "VHS_VIDEOINFO",
          "links": []
        }
      ],
      "properties": {
        "Node name for S&R": "VHS_LoadVideo",
        "widget_ue_connectable": {}
      },
      "widgets_values": {
        "video": "Wanimate_00046-audio (1).mp4",
        "force_rate": 15,
        "custom_width": 0,
        "custom_height": 0,
        "frame_load_cap": 0,
        "skip_first_frames": 0,
        "select_every_nth": 1,
        "format": "AnimateDiff",
        "choose video to upload": "image",
        "videopreview": {
          "paused": false,
          "hidden": false,
          "params": {
            "custom_height": 0,
            "force_rate": 15,
            "filename": "Wanimate_00046-audio (1).mp4",
            "custom_width": 0,
            "select_every_nth": 1,
            "frame_load_cap": 0,
            "format": "video/mp4",
            "skip_first_frames": 0,
            "type": "input"
          }
        }
      }
    },
    {
      "id": 191,
      "type": "RIFE VFI",
      "pos": [
        1743.960205078125,
        5410.3681640625
      ],
      "size": [
        289.6578063964844,
        198
      ],
      "flags": {
        "collapsed": false
      },
      "order": 1,
      "mode": 0,
      "inputs": [
        {
          "label": "图像",
          "name": "frames",
          "type": "IMAGE",
          "link": 285
        },
        {
          "label": "插值规则(可选)",
          "name": "optional_interpolation_states",
          "shape": 7,
          "type": "INTERPOLATION_STATES"
        },
        {
          "label": "clear_cache_after_n_frames",
          "name": "clear_cache_after_n_frames",
          "type": "INT",
          "widget": {
            "name": "clear_cache_after_n_frames"
          }
        },
        {
          "label": "multiplier",
          "name": "multiplier",
          "type": "INT",
          "widget": {
            "name": "multiplier"
          }
        },
        {
          "label": "fast_mode",
          "name": "fast_mode",
          "type": "BOOLEAN",
          "widget": {
            "name": "fast_mode"
          }
        },
        {
          "label": "ensemble",
          "name": "ensemble",
          "type": "BOOLEAN",
          "widget": {
            "name": "ensemble"
          }
        },
        {
          "label": "scale_factor",
          "name": "scale_factor",
          "type": "COMBO",
          "widget": {
            "name": "scale_factor"
          }
        }
      ],
      "outputs": [
        {
          "label": "图像",
          "name": "IMAGE",
          "type": "IMAGE",
          "slot_index": 0,
          "links": [
            293
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "RIFE VFI",
        "cnr_id": "comfyui-frame-interpolation",
        "ver": "1.0.6",
        "ue_properties": {
          "widget_ue_connectable": {
            "ckpt_name": true,
            "fast_mode": true,
            "multiplier": true,
            "clear_cache_after_n_frames": true,
            "ensemble": true,
            "scale_factor": true
          },
          "version": "7.0.1"
        },
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "rife49.pth",
        8,
        2,
        true,
        true,
        1
      ],
      "color": "#323",
      "bgcolor": "#535",
      "shape": 1
    }
  ],
  "links": [
    [
      285,
      194,
      0,
      191,
      0,
      "IMAGE"
    ],
    [
      293,
      191,
      0,
      198,
      0,
      "IMAGE"
    ],
    [
      295,
      198,
      0,
      199,
      0,
      "*"
    ],
    [
      300,
      194,
      2,
      198,
      1,
      "AUDIO"
    ]
  ],
  "groups": [
    {
      "id": 41,
      "title": "补充功能：补帧",
      "bounding": [
        1367.2286376953125,
        5313.8095703125,
        1213.053466796875,
        1050.6544189453125
      ],
      "color": "#3f789e",
      "font_size": 24,
      "flags": {}
    }
  ],
  "config": {},
  "extra": {
    "ds": {
      "scale": 0.9646149645000015,
      "offset": [
        -927.5818678062828,
        -5249.32258771536
      ]
    },
    "frontendVersion": "1.23.4",
    "links_added_by_ue": [],
    "VHS_KeepIntermediate": true,
    "ue_links": [],
    "VHS_MetadataImage": true,
    "0246.VERSION": [
      0,
      0,
      4
    ],
    "VHS_latentpreviewrate": 0,
    "VHS_latentpreview": false
  },
  "version": 0.4
}
```
