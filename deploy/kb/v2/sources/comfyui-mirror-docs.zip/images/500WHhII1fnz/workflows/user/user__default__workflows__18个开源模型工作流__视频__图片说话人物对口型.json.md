# 图片说话人物对口型

- 来源类别：用户工作流
- 镜像内原始路径：`/ComfyUI/user/default/workflows/18个开源模型工作流/视频/图片说话人物对口型.json`
- 节点数量：26
- 连线数量：31

## 节点类型

- `INTConstant` × 2
- `Audio Duration` × 1
- `AudioCrop` × 1
- `AudioSeparation` × 1
- `CLIPVisionLoader` × 1
- `DownloadAndLoadWav2VecModel` × 1
- `ImageResizeKJv2` × 1
- `LoadAudio` × 1
- `LoadImage` × 1
- `LoadWanVideoT5TextEncoder` × 1
- `MultiTalkModelLoader` × 1
- `MultiTalkWav2VecEmbeds` × 1
- `SimpleMath+` × 1
- `VHS_VideoCombine` × 1
- `WanVideoBlockSwap` × 1
- `WanVideoClipVisionEncode` × 1
- `WanVideoDecode` × 1
- `WanVideoImageToVideoMultiTalk` × 1
- `WanVideoLoraSelect` × 1
- `WanVideoModelLoader` × 1
- `WanVideoSampler` × 1
- `WanVideoTextEncode` × 1
- `WanVideoTorchCompileSettings` × 1
- `WanVideoVAELoader` × 1
- `easy showAnything` × 1

## 工作流引用的模型或媒体文件

- `/ComfyUI/output/WanVideo2_1_multitalk_00004-audio.mp4`
- `004-1.mp4`
- `Wan2_1-I2V-14B-720P_fp8_e4m3fn.safetensors`
- `Wan2_1_VAE_bf16.safetensors`
- `WanVideo2_1_multitalk_00004-audio.mp4`
- `ingle.safetensors`
- `ion_h.safetensors`
- `till_rank256_bf16.safetensors`
- `umt5-xxl-enc-bf16.safetensors`

## 原始工作流 JSON

```json
{
  "id": "a7a252ea-c9b8-49ed-8b03-816d945a5727",
  "revision": 0,
  "last_node_id": 222,
  "last_link_id": 371,
  "nodes": [
    {
      "id": 134,
      "type": "WanVideoBlockSwap",
      "pos": [
        993.4380118809456,
        -2437.824406253214
      ],
      "size": [
        281.404296875,
        202
      ],
      "flags": {},
      "order": 0,
      "mode": 0,
      "inputs": [
        {
          "label": "blocks_to_swap",
          "name": "blocks_to_swap",
          "type": "INT",
          "widget": {
            "name": "blocks_to_swap"
          }
        },
        {
          "label": "offload_img_emb",
          "name": "offload_img_emb",
          "type": "BOOLEAN",
          "widget": {
            "name": "offload_img_emb"
          }
        },
        {
          "label": "offload_txt_emb",
          "name": "offload_txt_emb",
          "type": "BOOLEAN",
          "widget": {
            "name": "offload_txt_emb"
          }
        },
        {
          "label": "use_non_blocking",
          "name": "use_non_blocking",
          "shape": 7,
          "type": "BOOLEAN",
          "widget": {
            "name": "use_non_blocking"
          }
        },
        {
          "label": "vace_blocks_to_swap",
          "name": "vace_blocks_to_swap",
          "shape": 7,
          "type": "INT",
          "widget": {
            "name": "vace_blocks_to_swap"
          }
        },
        {
          "label": "prefetch_blocks",
          "name": "prefetch_blocks",
          "shape": 7,
          "type": "INT",
          "widget": {
            "name": "prefetch_blocks"
          }
        },
        {
          "label": "block_swap_debug",
          "name": "block_swap_debug",
          "shape": 7,
          "type": "BOOLEAN",
          "widget": {
            "name": "block_swap_debug"
          }
        }
      ],
      "outputs": [
        {
          "label": "block_swap_args",
          "name": "block_swap_args",
          "type": "BLOCKSWAPARGS",
          "links": [
            332
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "WanVideoBlockSwap",
        "cnr_id": "ComfyUI-WanVideoWrapper",
        "ver": "058286fc0f3b0651a2f6b68309df3f06e8332cc0",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        30,
        false,
        false,
        true,
        0,
        0,
        false
      ]
    },
    {
      "id": 177,
      "type": "WanVideoTorchCompileSettings",
      "pos": [
        1287.6744572338732,
        -2482.34145241951
      ],
      "size": [
        293.380859375,
        250
      ],
      "flags": {},
      "order": 1,
      "mode": 0,
      "inputs": [
        {
          "label": "backend",
          "name": "backend",
          "type": "COMBO",
          "widget": {
            "name": "backend"
          }
        },
        {
          "label": "fullgraph",
          "name": "fullgraph",
          "type": "BOOLEAN",
          "widget": {
            "name": "fullgraph"
          }
        },
        {
          "label": "mode",
          "name": "mode",
          "type": "COMBO",
          "widget": {
            "name": "mode"
          }
        },
        {
          "label": "dynamic",
          "name": "dynamic",
          "type": "BOOLEAN",
          "widget": {
            "name": "dynamic"
          }
        },
        {
          "label": "dynamo_cache_size_limit",
          "name": "dynamo_cache_size_limit",
          "type": "INT",
          "widget": {
            "name": "dynamo_cache_size_limit"
          }
        },
        {
          "label": "compile_transformer_blocks_only",
          "name": "compile_transformer_blocks_only",
          "type": "BOOLEAN",
          "widget": {
            "name": "compile_transformer_blocks_only"
          }
        },
        {
          "label": "dynamo_recompile_limit",
          "name": "dynamo_recompile_limit",
          "shape": 7,
          "type": "INT",
          "widget": {
            "name": "dynamo_recompile_limit"
          }
        }
      ],
      "outputs": [
        {
          "label": "torch_compile_args",
          "name": "torch_compile_args",
          "type": "WANCOMPILEARGS",
          "links": [
            299
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "WanVideoTorchCompileSettings",
        "cnr_id": "ComfyUI-WanVideoWrapper",
        "ver": "f3614e6720744247f3211d60f7b9333f43572384",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "inductor",
        false,
        "default",
        false,
        64,
        true,
        128,
        false,
        false
      ]
    },
    {
      "id": 138,
      "type": "WanVideoLoraSelect",
      "pos": [
        996.9186314904134,
        -2192.5166795854752
      ],
      "size": [
        588.8752982431374,
        152.33598432244412
      ],
      "flags": {},
      "order": 2,
      "mode": 0,
      "inputs": [
        {
          "label": "prev_lora",
          "name": "prev_lora",
          "shape": 7,
          "type": "WANVIDLORA"
        },
        {
          "label": "blocks",
          "name": "blocks",
          "shape": 7,
          "type": "SELECTEDBLOCKS"
        },
        {
          "label": "lora",
          "name": "lora",
          "type": "COMBO",
          "widget": {
            "name": "lora"
          }
        },
        {
          "label": "strength",
          "name": "strength",
          "type": "FLOAT",
          "widget": {
            "name": "strength"
          }
        },
        {
          "label": "low_mem_load",
          "name": "low_mem_load",
          "shape": 7,
          "type": "BOOLEAN",
          "widget": {
            "name": "low_mem_load"
          }
        },
        {
          "label": "merge_loras",
          "name": "merge_loras",
          "shape": 7,
          "type": "BOOLEAN",
          "widget": {
            "name": "merge_loras"
          }
        }
      ],
      "outputs": [
        {
          "label": "lora",
          "name": "lora",
          "type": "WANVIDLORA",
          "links": [
            256
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "WanVideoLoraSelect",
        "cnr_id": "ComfyUI-WanVideoWrapper",
        "ver": "058286fc0f3b0651a2f6b68309df3f06e8332cc0",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "lightx2v/lightx2v_I2V_14B_480p_cfg_step_distill_rank256_bf16.safetensors",
        0.8000000000000002,
        false,
        false
      ]
    },
    {
      "id": 120,
      "type": "MultiTalkModelLoader",
      "pos": [
        999.7993741861179,
        -1996.5903004914571
      ],
      "size": [
        584.2580219378704,
        80.02540475610272
      ],
      "flags": {},
      "order": 3,
      "mode": 0,
      "inputs": [
        {
          "label": "model",
          "name": "model",
          "type": "COMBO",
          "widget": {
            "name": "model"
          }
        }
      ],
      "outputs": [
        {
          "label": "model",
          "name": "model",
          "type": "MULTITALKMODEL",
          "links": [
            270
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "MultiTalkModelLoader",
        "cnr_id": "ComfyUI-WanVideoWrapper",
        "ver": "058286fc0f3b0651a2f6b68309df3f06e8332cc0",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "infinitetalk_single.safetensors"
      ]
    },
    {
      "id": 173,
      "type": "CLIPVisionLoader",
      "pos": [
        1003.7067755498636,
        -1870.8587082168578
      ],
      "size": [
        579.2708845554052,
        63.75609266345941
      ],
      "flags": {},
      "order": 4,
      "mode": 0,
      "inputs": [
        {
          "label": "clip_name",
          "name": "clip_name",
          "type": "COMBO",
          "widget": {
            "name": "clip_name"
          }
        }
      ],
      "outputs": [
        {
          "label": "CLIP_VISION",
          "name": "CLIP_VISION",
          "type": "CLIP_VISION",
          "links": [
            330
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.41",
        "Node name for S&R": "CLIPVisionLoader",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "clip_vision_h.safetensors"
      ]
    },
    {
      "id": 129,
      "type": "WanVideoVAELoader",
      "pos": [
        1600.2577724563891,
        -2097.4267806395237
      ],
      "size": [
        597.3727512733512,
        110.2536046422374
      ],
      "flags": {},
      "order": 5,
      "mode": 0,
      "inputs": [
        {
          "label": "compile_args",
          "name": "compile_args",
          "shape": 7,
          "type": "WANCOMPILEARGS"
        },
        {
          "label": "model_name",
          "name": "model_name",
          "type": "COMBO",
          "widget": {
            "name": "model_name"
          }
        },
        {
          "label": "precision",
          "name": "precision",
          "shape": 7,
          "type": "COMBO",
          "widget": {
            "name": "precision"
          }
        }
      ],
      "outputs": [
        {
          "label": "vae",
          "name": "vae",
          "type": "WANVAE",
          "slot_index": 0,
          "links": [
            193,
            325
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "WanVideoVAELoader",
        "cnr_id": "ComfyUI-WanVideoWrapper",
        "ver": "c3ee35f3ece76e38099dc516182d69b406e16772",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "Wan2_1_VAE_bf16.safetensors",
        "bf16",
        false
      ]
    },
    {
      "id": 122,
      "type": "WanVideoModelLoader",
      "pos": [
        1598.9209742682904,
        -2477.747789231261
      ],
      "size": [
        595.2891235351562,
        338
      ],
      "flags": {},
      "order": 11,
      "mode": 0,
      "inputs": [
        {
          "label": "compile_args",
          "name": "compile_args",
          "shape": 7,
          "type": "WANCOMPILEARGS",
          "link": 299
        },
        {
          "label": "block_swap_args",
          "name": "block_swap_args",
          "shape": 7,
          "type": "BLOCKSWAPARGS",
          "link": 332
        },
        {
          "label": "lora",
          "name": "lora",
          "shape": 7,
          "type": "WANVIDLORA",
          "link": 256
        },
        {
          "label": "vram_management_args",
          "name": "vram_management_args",
          "shape": 7,
          "type": "VRAM_MANAGEMENTARGS"
        },
        {
          "label": "extra_model",
          "name": "extra_model",
          "shape": 7,
          "type": "VACEPATH",
          "link": null
        },
        {
          "label": "fantasytalking_model",
          "name": "fantasytalking_model",
          "shape": 7,
          "type": "FANTASYTALKINGMODEL"
        },
        {
          "label": "multitalk_model",
          "name": "multitalk_model",
          "shape": 7,
          "type": "MULTITALKMODEL",
          "link": 270
        },
        {
          "label": "fantasyportrait_model",
          "name": "fantasyportrait_model",
          "shape": 7,
          "type": "FANTASYPORTRAITMODEL"
        },
        {
          "label": "model",
          "name": "model",
          "type": "COMBO",
          "widget": {
            "name": "model"
          }
        },
        {
          "label": "base_precision",
          "name": "base_precision",
          "type": "COMBO",
          "widget": {
            "name": "base_precision"
          }
        },
        {
          "label": "quantization",
          "name": "quantization",
          "type": "COMBO",
          "widget": {
            "name": "quantization"
          }
        },
        {
          "label": "load_device",
          "name": "load_device",
          "type": "COMBO",
          "widget": {
            "name": "load_device"
          }
        },
        {
          "label": "attention_mode",
          "name": "attention_mode",
          "shape": 7,
          "type": "COMBO",
          "widget": {
            "name": "attention_mode"
          }
        },
        {
          "label": "vace_model",
          "name": "vace_model",
          "shape": 7,
          "type": "VACEPATH"
        }
      ],
      "outputs": [
        {
          "label": "model",
          "name": "model",
          "type": "WANVIDEOMODEL",
          "links": [
            197
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "WanVideoModelLoader",
        "cnr_id": "ComfyUI-WanVideoWrapper",
        "ver": "058286fc0f3b0651a2f6b68309df3f06e8332cc0",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "Wan2_1-I2V-14B-720P_fp8_e4m3fn.safetensors",
        "fp16",
        "fp8_e4m3fn",
        "offload_device",
        "sageattn",
        "default"
      ]
    },
    {
      "id": 136,
      "type": "LoadWanVideoT5TextEncoder",
      "pos": [
        1600.6139374428092,
        -1946.680523213116
      ],
      "size": [
        596.0681563769522,
        130
      ],
      "flags": {},
      "order": 6,
      "mode": 0,
      "inputs": [
        {
          "label": "model_name",
          "name": "model_name",
          "type": "COMBO",
          "widget": {
            "name": "model_name"
          }
        },
        {
          "label": "precision",
          "name": "precision",
          "type": "COMBO",
          "widget": {
            "name": "precision"
          }
        },
        {
          "label": "load_device",
          "name": "load_device",
          "shape": 7,
          "type": "COMBO",
          "widget": {
            "name": "load_device"
          }
        },
        {
          "label": "quantization",
          "name": "quantization",
          "shape": 7,
          "type": "COMBO",
          "widget": {
            "name": "quantization"
          }
        }
      ],
      "outputs": [
        {
          "label": "wan_t5_model",
          "name": "wan_t5_model",
          "type": "WANTEXTENCODER",
          "links": [
            202
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "LoadWanVideoT5TextEncoder",
        "cnr_id": "ComfyUI-WanVideoWrapper",
        "ver": "058286fc0f3b0651a2f6b68309df3f06e8332cc0",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "umt5-xxl-enc-bf16.safetensors",
        "bf16",
        "offload_device",
        "disabled"
      ],
      "color": "#432",
      "bgcolor": "#653"
    },
    {
      "id": 137,
      "type": "DownloadAndLoadWav2VecModel",
      "pos": [
        1603.6213129208445,
        -1776.3641614872408
      ],
      "size": [
        593.5937043459517,
        106
      ],
      "flags": {},
      "order": 7,
      "mode": 0,
      "inputs": [
        {
          "label": "model",
          "name": "model",
          "type": "COMBO",
          "widget": {
            "name": "model"
          }
        },
        {
          "label": "base_precision",
          "name": "base_precision",
          "type": "COMBO",
          "widget": {
            "name": "base_precision"
          }
        },
        {
          "label": "load_device",
          "name": "load_device",
          "type": "COMBO",
          "widget": {
            "name": "load_device"
          }
        }
      ],
      "outputs": [
        {
          "label": "wav2vec_model",
          "name": "wav2vec_model",
          "type": "WAV2VECMODEL",
          "links": [
            334
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "DownloadAndLoadWav2VecModel",
        "cnr_id": "ComfyUI-WanVideoWrapper",
        "ver": "058286fc0f3b0651a2f6b68309df3f06e8332cc0",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "TencentGameMate/chinese-wav2vec2-base",
        "fp16",
        "main_device"
      ]
    },
    {
      "id": 192,
      "type": "WanVideoImageToVideoMultiTalk",
      "pos": [
        2209.7797896387824,
        -2467.310914415679
      ],
      "size": [
        315.2046813964844,
        290
      ],
      "flags": {},
      "order": 18,
      "mode": 0,
      "inputs": [
        {
          "label": "vae",
          "name": "vae",
          "type": "WANVAE",
          "link": 325
        },
        {
          "label": "start_image",
          "name": "start_image",
          "shape": 7,
          "type": "IMAGE",
          "link": 326
        },
        {
          "label": "clip_embeds",
          "name": "clip_embeds",
          "shape": 7,
          "type": "WANVIDIMAGE_CLIPEMBEDS",
          "link": 329
        },
        {
          "label": "width",
          "name": "width",
          "type": "INT",
          "widget": {
            "name": "width"
          },
          "link": 339
        },
        {
          "label": "height",
          "name": "height",
          "type": "INT",
          "widget": {
            "name": "height"
          },
          "link": 340
        },
        {
          "label": "frame_window_size",
          "name": "frame_window_size",
          "type": "INT",
          "widget": {
            "name": "frame_window_size"
          }
        },
        {
          "label": "motion_frame",
          "name": "motion_frame",
          "type": "INT",
          "widget": {
            "name": "motion_frame"
          }
        },
        {
          "label": "force_offload",
          "name": "force_offload",
          "type": "BOOLEAN",
          "widget": {
            "name": "force_offload"
          }
        },
        {
          "label": "colormatch",
          "name": "colormatch",
          "type": "COMBO",
          "widget": {
            "name": "colormatch"
          }
        },
        {
          "label": "tiled_vae",
          "name": "tiled_vae",
          "shape": 7,
          "type": "BOOLEAN",
          "widget": {
            "name": "tiled_vae"
          }
        },
        {
          "label": "mode",
          "name": "mode",
          "shape": 7,
          "type": "COMBO",
          "widget": {
            "name": "mode"
          }
        }
      ],
      "outputs": [
        {
          "label": "image_embeds",
          "name": "image_embeds",
          "type": "WANVIDIMAGE_EMBEDS",
          "links": [
            328
          ]
        },
        {
          "label": "output_path",
          "name": "output_path",
          "type": "STRING",
          "links": null
        }
      ],
      "properties": {
        "Node name for S&R": "WanVideoImageToVideoMultiTalk",
        "cnr_id": "ComfyUI-WanVideoWrapper",
        "ver": "49430f900bf812a1e281560bafafd04c43dfdf13",
        "widget_ue_connectable": {
          "width": true,
          "height": true
        }
      },
      "widgets_values": [
        832,
        480,
        81,
        25,
        false,
        "mkl",
        false,
        "infinitetalk",
        ""
      ]
    },
    {
      "id": 193,
      "type": "WanVideoClipVisionEncode",
      "pos": [
        2217.348282013359,
        -2121.4141126052396
      ],
      "size": [
        309.2142023293354,
        262
      ],
      "flags": {},
      "order": 15,
      "mode": 0,
      "inputs": [
        {
          "label": "clip_vision",
          "name": "clip_vision",
          "type": "CLIP_VISION",
          "link": 330
        },
        {
          "label": "image_1",
          "name": "image_1",
          "type": "IMAGE",
          "link": 331
        },
        {
          "label": "image_2",
          "name": "image_2",
          "shape": 7,
          "type": "IMAGE"
        },
        {
          "label": "negative_image",
          "name": "negative_image",
          "shape": 7,
          "type": "IMAGE"
        },
        {
          "label": "strength_1",
          "name": "strength_1",
          "type": "FLOAT",
          "widget": {
            "name": "strength_1"
          }
        },
        {
          "label": "strength_2",
          "name": "strength_2",
          "type": "FLOAT",
          "widget": {
            "name": "strength_2"
          }
        },
        {
          "label": "crop",
          "name": "crop",
          "type": "COMBO",
          "widget": {
            "name": "crop"
          }
        },
        {
          "label": "combine_embeds",
          "name": "combine_embeds",
          "type": "COMBO",
          "widget": {
            "name": "combine_embeds"
          }
        },
        {
          "label": "force_offload",
          "name": "force_offload",
          "type": "BOOLEAN",
          "widget": {
            "name": "force_offload"
          }
        },
        {
          "label": "tiles",
          "name": "tiles",
          "shape": 7,
          "type": "INT",
          "widget": {
            "name": "tiles"
          }
        },
        {
          "label": "ratio",
          "name": "ratio",
          "shape": 7,
          "type": "FLOAT",
          "widget": {
            "name": "ratio"
          }
        }
      ],
      "outputs": [
        {
          "label": "image_embeds",
          "name": "image_embeds",
          "type": "WANVIDIMAGE_CLIPEMBEDS",
          "links": [
            329
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "WanVideoClipVisionEncode",
        "cnr_id": "ComfyUI-WanVideoWrapper",
        "ver": "49430f900bf812a1e281560bafafd04c43dfdf13",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        1,
        1,
        "center",
        "average",
        true,
        0,
        0.5000000000000001
      ]
    },
    {
      "id": 194,
      "type": "MultiTalkWav2VecEmbeds",
      "pos": [
        2222.835968128463,
        -1811.9334238488807
      ],
      "size": [
        306.28676263562966,
        279.2998828612542
      ],
      "flags": {},
      "order": 22,
      "mode": 0,
      "inputs": [
        {
          "label": "wav2vec_model",
          "name": "wav2vec_model",
          "type": "WAV2VECMODEL",
          "link": 334
        },
        {
          "label": "audio_1",
          "name": "audio_1",
          "type": "AUDIO",
          "link": 335
        },
        {
          "label": "audio_2",
          "name": "audio_2",
          "shape": 7,
          "type": "AUDIO"
        },
        {
          "label": "audio_3",
          "name": "audio_3",
          "shape": 7,
          "type": "AUDIO"
        },
        {
          "label": "audio_4",
          "name": "audio_4",
          "shape": 7,
          "type": "AUDIO"
        },
        {
          "label": "ref_target_masks",
          "name": "ref_target_masks",
          "shape": 7,
          "type": "MASK"
        },
        {
          "label": "normalize_loudness",
          "name": "normalize_loudness",
          "type": "BOOLEAN",
          "widget": {
            "name": "normalize_loudness"
          }
        },
        {
          "label": "num_frames",
          "name": "num_frames",
          "type": "INT",
          "widget": {
            "name": "num_frames"
          },
          "link": 345
        },
        {
          "label": "fps",
          "name": "fps",
          "type": "FLOAT",
          "widget": {
            "name": "fps"
          }
        },
        {
          "label": "audio_scale",
          "name": "audio_scale",
          "type": "FLOAT",
          "widget": {
            "name": "audio_scale"
          }
        },
        {
          "label": "audio_cfg_scale",
          "name": "audio_cfg_scale",
          "type": "FLOAT",
          "widget": {
            "name": "audio_cfg_scale"
          }
        },
        {
          "label": "multi_audio_type",
          "name": "multi_audio_type",
          "type": "COMBO",
          "widget": {
            "name": "multi_audio_type"
          }
        }
      ],
      "outputs": [
        {
          "label": "multitalk_embeds",
          "name": "multitalk_embeds",
          "type": "MULTITALK_EMBEDS",
          "links": [
            336
          ]
        },
        {
          "label": "audio",
          "name": "audio",
          "type": "AUDIO"
        },
        {
          "label": "num_frames",
          "name": "num_frames",
          "type": "INT",
          "links": null
        }
      ],
      "properties": {
        "Node name for S&R": "MultiTalkWav2VecEmbeds",
        "cnr_id": "ComfyUI-WanVideoWrapper",
        "ver": "3d7801cee4c8e3106078dd9b9f146caee95069ba",
        "widget_ue_connectable": {
          "num_frames": true
        }
      },
      "widgets_values": [
        true,
        275,
        25,
        1,
        1,
        "para"
      ]
    },
    {
      "id": 135,
      "type": "WanVideoTextEncode",
      "pos": [
        2543.2437316439987,
        -2470.878500697884
      ],
      "size": [
        341.2131062564722,
        351.65658032336114
      ],
      "flags": {},
      "order": 12,
      "mode": 0,
      "inputs": [
        {
          "label": "t5",
          "name": "t5",
          "shape": 7,
          "type": "WANTEXTENCODER",
          "link": 202
        },
        {
          "label": "model_to_offload",
          "name": "model_to_offload",
          "shape": 7,
          "type": "WANVIDEOMODEL"
        },
        {
          "label": "positive_prompt",
          "name": "positive_prompt",
          "type": "STRING",
          "widget": {
            "name": "positive_prompt"
          }
        },
        {
          "label": "negative_prompt",
          "name": "negative_prompt",
          "type": "STRING",
          "widget": {
            "name": "negative_prompt"
          }
        },
        {
          "label": "force_offload",
          "name": "force_offload",
          "shape": 7,
          "type": "BOOLEAN",
          "widget": {
            "name": "force_offload"
          }
        },
        {
          "label": "use_disk_cache",
          "name": "use_disk_cache",
          "shape": 7,
          "type": "BOOLEAN",
          "widget": {
            "name": "use_disk_cache"
          }
        },
        {
          "label": "device",
          "name": "device",
          "shape": 7,
          "type": "COMBO",
          "widget": {
            "name": "device"
          }
        }
      ],
      "outputs": [
        {
          "label": "text_embeds",
          "name": "text_embeds",
          "type": "WANVIDEOTEXTEMBEDS",
          "links": [
            306
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "WanVideoTextEncode",
        "cnr_id": "ComfyUI-WanVideoWrapper",
        "ver": "058286fc0f3b0651a2f6b68309df3f06e8332cc0",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "一个男人拿着枪 瞄准镜头并嚣张的歪着头 看着镜头 说话 ",
        "bright tones, overexposed, static, blurred details, subtitles, style, works, paintings, images, static, overall gray, worst quality, low quality, JPEG compression residue, ugly, incomplete, extra fingers, poorly drawn hands, poorly drawn faces, deformed, disfigured, misshapen limbs, fused fingers, still picture, messy background, three legs, many people in the background, walking backwards",
        true,
        false,
        "gpu"
      ]
    },
    {
      "id": 128,
      "type": "WanVideoSampler",
      "pos": [
        2544.66194555183,
        -2071.9417201573515
      ],
      "size": [
        326.94640562786435,
        690
      ],
      "flags": {},
      "order": 23,
      "mode": 0,
      "inputs": [
        {
          "label": "model",
          "name": "model",
          "type": "WANVIDEOMODEL",
          "link": 197
        },
        {
          "label": "image_embeds",
          "name": "image_embeds",
          "type": "WANVIDIMAGE_EMBEDS",
          "link": 328
        },
        {
          "label": "text_embeds",
          "name": "text_embeds",
          "shape": 7,
          "type": "WANVIDEOTEXTEMBEDS",
          "link": 306
        },
        {
          "label": "samples",
          "name": "samples",
          "shape": 7,
          "type": "LATENT"
        },
        {
          "label": "feta_args",
          "name": "feta_args",
          "shape": 7,
          "type": "FETAARGS"
        },
        {
          "label": "context_options",
          "name": "context_options",
          "shape": 7,
          "type": "WANVIDCONTEXT"
        },
        {
          "label": "cache_args",
          "name": "cache_args",
          "shape": 7,
          "type": "CACHEARGS"
        },
        {
          "label": "flowedit_args",
          "name": "flowedit_args",
          "shape": 7,
          "type": "FLOWEDITARGS"
        },
        {
          "label": "slg_args",
          "name": "slg_args",
          "shape": 7,
          "type": "SLGARGS"
        },
        {
          "label": "loop_args",
          "name": "loop_args",
          "shape": 7,
          "type": "LOOPARGS"
        },
        {
          "label": "experimental_args",
          "name": "experimental_args",
          "shape": 7,
          "type": "EXPERIMENTALARGS"
        },
        {
          "label": "sigmas",
          "name": "sigmas",
          "shape": 7,
          "type": "SIGMAS"
        },
        {
          "label": "unianimate_poses",
          "name": "unianimate_poses",
          "shape": 7,
          "type": "UNIANIMATE_POSE"
        },
        {
          "label": "fantasytalking_embeds",
          "name": "fantasytalking_embeds",
          "shape": 7,
          "type": "FANTASYTALKING_EMBEDS"
        },
        {
          "label": "uni3c_embeds",
          "name": "uni3c_embeds",
          "shape": 7,
          "type": "UNI3C_EMBEDS"
        },
        {
          "label": "multitalk_embeds",
          "name": "multitalk_embeds",
          "shape": 7,
          "type": "MULTITALK_EMBEDS",
          "link": 336
        },
        {
          "label": "freeinit_args",
          "name": "freeinit_args",
          "shape": 7,
          "type": "FREEINITARGS"
        },
        {
          "label": "steps",
          "name": "steps",
          "type": "INT",
          "widget": {
            "name": "steps"
          }
        },
        {
          "label": "cfg",
          "name": "cfg",
          "type": "FLOAT",
          "widget": {
            "name": "cfg"
          }
        },
        {
          "label": "shift",
          "name": "shift",
          "type": "FLOAT",
          "widget": {
            "name": "shift"
          }
        },
        {
          "label": "seed",
          "name": "seed",
          "type": "INT",
          "widget": {
            "name": "seed"
          }
        },
        {
          "label": "force_offload",
          "name": "force_offload",
          "type": "BOOLEAN",
          "widget": {
            "name": "force_offload"
          }
        },
        {
          "label": "scheduler",
          "name": "scheduler",
          "type": "COMBO",
          "widget": {
            "name": "scheduler"
          }
        },
        {
          "label": "riflex_freq_index",
          "name": "riflex_freq_index",
          "type": "INT",
          "widget": {
            "name": "riflex_freq_index"
          }
        },
        {
          "label": "denoise_strength",
          "name": "denoise_strength",
          "shape": 7,
          "type": "FLOAT",
          "widget": {
            "name": "denoise_strength"
          }
        },
        {
          "label": "batched_cfg",
          "name": "batched_cfg",
          "shape": 7,
          "type": "BOOLEAN",
          "widget": {
            "name": "batched_cfg"
          }
        },
        {
          "label": "rope_function",
          "name": "rope_function",
          "shape": 7,
          "type": "COMBO",
          "widget": {
            "name": "rope_function"
          }
        },
        {
          "label": "start_step",
          "name": "start_step",
          "shape": 7,
          "type": "INT",
          "widget": {
            "name": "start_step"
          }
        },
        {
          "label": "end_step",
          "name": "end_step",
          "shape": 7,
          "type": "INT",
          "widget": {
            "name": "end_step"
          }
        },
        {
          "label": "add_noise_to_samples",
          "name": "add_noise_to_samples",
          "shape": 7,
          "type": "BOOLEAN",
          "widget": {
            "name": "add_noise_to_samples"
          }
        }
      ],
      "outputs": [
        {
          "label": "samples",
          "name": "samples",
          "type": "LATENT",
          "slot_index": 0,
          "links": [
            194
          ]
        },
        {
          "label": "denoised_samples",
          "name": "denoised_samples",
          "type": "LATENT"
        }
      ],
      "properties": {
        "Node name for S&R": "WanVideoSampler",
        "cnr_id": "ComfyUI-WanVideoWrapper",
        "ver": "c3ee35f3ece76e38099dc516182d69b406e16772",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        4,
        1.0000000000000002,
        11.000000000000002,
        1,
        "fixed",
        true,
        "flowmatch_distill",
        0,
        1,
        false,
        "comfy",
        0,
        -1,
        false
      ]
    },
    {
      "id": 171,
      "type": "ImageResizeKJv2",
      "pos": [
        1311.7909994418321,
        -1746.5908329874212
      ],
      "size": [
        270,
        336
      ],
      "flags": {},
      "order": 13,
      "mode": 0,
      "inputs": [
        {
          "label": "image",
          "name": "image",
          "type": "IMAGE",
          "link": 283
        },
        {
          "label": "mask",
          "name": "mask",
          "shape": 7,
          "type": "MASK"
        },
        {
          "label": "width",
          "name": "width",
          "type": "INT",
          "widget": {
            "name": "width"
          }
        },
        {
          "label": "height",
          "name": "height",
          "type": "INT",
          "widget": {
            "name": "height"
          }
        },
        {
          "label": "upscale_method",
          "name": "upscale_method",
          "type": "COMBO",
          "widget": {
            "name": "upscale_method"
          }
        },
        {
          "label": "keep_proportion",
          "name": "keep_proportion",
          "type": "COMBO",
          "widget": {
            "name": "keep_proportion"
          }
        },
        {
          "label": "pad_color",
          "name": "pad_color",
          "type": "STRING",
          "widget": {
            "name": "pad_color"
          }
        },
        {
          "label": "crop_position",
          "name": "crop_position",
          "type": "COMBO",
          "widget": {
            "name": "crop_position"
          }
        },
        {
          "label": "divisible_by",
          "name": "divisible_by",
          "type": "INT",
          "widget": {
            "name": "divisible_by"
          }
        },
        {
          "label": "device",
          "name": "device",
          "shape": 7,
          "type": "COMBO",
          "widget": {
            "name": "device"
          }
        }
      ],
      "outputs": [
        {
          "label": "IMAGE",
          "name": "IMAGE",
          "type": "IMAGE",
          "links": [
            326,
            331
          ]
        },
        {
          "label": "width",
          "name": "width",
          "type": "INT",
          "links": [
            339
          ]
        },
        {
          "label": "height",
          "name": "height",
          "type": "INT",
          "links": [
            340
          ]
        },
        {
          "label": "mask",
          "name": "mask",
          "type": "MASK"
        }
      ],
      "properties": {
        "Node name for S&R": "ImageResizeKJv2",
        "cnr_id": "comfyui-kjnodes",
        "ver": "f7eb33abc80a2aded1b46dff0dd14d07856a7d50",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        480,
        832,
        "lanczos",
        "crop",
        "0, 0, 0",
        "center",
        2,
        "cpu"
      ]
    },
    {
      "id": 130,
      "type": "WanVideoDecode",
      "pos": [
        1604.2220740581156,
        -1623.873997683687
      ],
      "size": [
        588.2054747856555,
        198
      ],
      "flags": {},
      "order": 24,
      "mode": 0,
      "inputs": [
        {
          "label": "vae",
          "name": "vae",
          "type": "WANVAE",
          "link": 193
        },
        {
          "label": "samples",
          "name": "samples",
          "type": "LATENT",
          "link": 194
        },
        {
          "label": "enable_vae_tiling",
          "name": "enable_vae_tiling",
          "type": "BOOLEAN",
          "widget": {
            "name": "enable_vae_tiling"
          }
        },
        {
          "label": "tile_x",
          "name": "tile_x",
          "type": "INT",
          "widget": {
            "name": "tile_x"
          }
        },
        {
          "label": "tile_y",
          "name": "tile_y",
          "type": "INT",
          "widget": {
            "name": "tile_y"
          }
        },
        {
          "label": "tile_stride_x",
          "name": "tile_stride_x",
          "type": "INT",
          "widget": {
            "name": "tile_stride_x"
          }
        },
        {
          "label": "tile_stride_y",
          "name": "tile_stride_y",
          "type": "INT",
          "widget": {
            "name": "tile_stride_y"
          }
        },
        {
          "label": "normalization",
          "name": "normalization",
          "shape": 7,
          "type": "COMBO",
          "widget": {
            "name": "normalization"
          }
        }
      ],
      "outputs": [
        {
          "label": "images",
          "name": "images",
          "type": "IMAGE",
          "slot_index": 0,
          "links": [
            196
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "WanVideoDecode",
        "cnr_id": "ComfyUI-WanVideoWrapper",
        "ver": "c3ee35f3ece76e38099dc516182d69b406e16772",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        false,
        272,
        272,
        144,
        128,
        "default"
      ]
    },
    {
      "id": 131,
      "type": "VHS_VideoCombine",
      "pos": [
        2952.451804110826,
        -2514.1774662518283
      ],
      "size": [
        850.4473266601562,
        1787.4420328776043
      ],
      "flags": {},
      "order": 25,
      "mode": 0,
      "inputs": [
        {
          "label": "images",
          "name": "images",
          "type": "IMAGE",
          "link": 196
        },
        {
          "label": "audio",
          "name": "audio",
          "shape": 7,
          "type": "AUDIO",
          "link": 296
        },
        {
          "label": "meta_batch",
          "name": "meta_batch",
          "shape": 7,
          "type": "VHS_BatchManager"
        },
        {
          "label": "vae",
          "name": "vae",
          "shape": 7,
          "type": "VAE"
        },
        {
          "label": "frame_rate",
          "name": "frame_rate",
          "type": "FLOAT",
          "widget": {
            "name": "frame_rate"
          }
        },
        {
          "label": "loop_count",
          "name": "loop_count",
          "type": "INT",
          "widget": {
            "name": "loop_count"
          }
        },
        {
          "label": "filename_prefix",
          "name": "filename_prefix",
          "type": "STRING",
          "widget": {
            "name": "filename_prefix"
          }
        },
        {
          "label": "format",
          "name": "format",
          "type": "COMBO",
          "widget": {
            "name": "format"
          }
        },
        {
          "label": "pingpong",
          "name": "pingpong",
          "type": "BOOLEAN",
          "widget": {
            "name": "pingpong"
          }
        },
        {
          "label": "save_output",
          "name": "save_output",
          "type": "BOOLEAN",
          "widget": {
            "name": "save_output"
          }
        }
      ],
      "outputs": [
        {
          "label": "Filenames",
          "name": "Filenames",
          "type": "VHS_FILENAMES"
        }
      ],
      "properties": {
        "Node name for S&R": "VHS_VideoCombine",
        "cnr_id": "comfyui-videohelpersuite",
        "ver": "0a75c7958fe320efcb052f1d9f8451fd20c730a8",
        "widget_ue_connectable": {}
      },
      "widgets_values": {
        "frame_rate": 25,
        "loop_count": 0,
        "filename_prefix": "WanVideo2_1_multitalk",
        "format": "video/h264-mp4",
        "pix_fmt": "yuv420p",
        "crf": 19,
        "save_metadata": true,
        "trim_to_audio": false,
        "pingpong": false,
        "save_output": true,
        "videopreview": {
          "paused": false,
          "hidden": false,
          "params": {
            "filename": "WanVideo2_1_multitalk_00004-audio.mp4",
            "workflow": "WanVideo2_1_multitalk_00004.png",
            "fullpath": "/ComfyUI/output/WanVideo2_1_multitalk_00004-audio.mp4",
            "format": "video/h264-mp4",
            "subfolder": "",
            "type": "output",
            "frame_rate": 25
          }
        }
      }
    },
    {
      "id": 133,
      "type": "LoadImage",
      "pos": [
        217.66842932917987,
        -2520.01556324685
      ],
      "size": [
        297.9940490722656,
        638.0676879882812
      ],
      "flags": {},
      "order": 8,
      "mode": 0,
      "inputs": [
        {
          "label": "image",
          "name": "image",
          "type": "COMBO",
          "widget": {
            "name": "image"
          }
        },
        {
          "label": "upload",
          "name": "upload",
          "type": "IMAGEUPLOAD",
          "widget": {
            "name": "upload"
          }
        }
      ],
      "outputs": [
        {
          "label": "IMAGE",
          "name": "IMAGE",
          "type": "IMAGE",
          "links": [
            283
          ]
        },
        {
          "label": "MASK",
          "name": "MASK",
          "type": "MASK"
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.41",
        "Node name for S&R": "LoadImage",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "居家黑白吊带少女CCD风写真.jpg",
        "image"
      ]
    },
    {
      "id": 125,
      "type": "LoadAudio",
      "pos": [
        551.1391407547375,
        -2504.5381381806837
      ],
      "size": [
        357.32049560546875,
        136
      ],
      "flags": {},
      "order": 9,
      "mode": 0,
      "inputs": [
        {
          "label": "audio",
          "name": "audio",
          "type": "COMBO",
          "widget": {
            "name": "audio"
          }
        },
        {
          "label": "audioUI",
          "name": "audioUI",
          "type": "AUDIO_UI",
          "widget": {
            "name": "audioUI"
          }
        },
        {
          "label": "upload",
          "name": "upload",
          "type": "AUDIOUPLOAD",
          "widget": {
            "name": "upload"
          }
        }
      ],
      "outputs": [
        {
          "label": "AUDIO",
          "name": "AUDIO",
          "type": "AUDIO",
          "links": [
            257
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.41",
        "Node name for S&R": "LoadAudio",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "004-1.mp4",
        null,
        null
      ]
    },
    {
      "id": 159,
      "type": "AudioCrop",
      "pos": [
        554.3487091883227,
        -2307.655933231752
      ],
      "size": [
        349.5041632100965,
        83.44554876810935
      ],
      "flags": {},
      "order": 14,
      "mode": 4,
      "inputs": [
        {
          "label": "audio",
          "name": "audio",
          "type": "AUDIO",
          "link": 257
        },
        {
          "label": "start_time",
          "name": "start_time",
          "type": "STRING",
          "widget": {
            "name": "start_time"
          }
        },
        {
          "label": "end_time",
          "name": "end_time",
          "type": "STRING",
          "widget": {
            "name": "end_time"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "AUDIO",
          "name": "AUDIO",
          "type": "AUDIO",
          "links": [
            296,
            301,
            355
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "AudioCrop",
        "cnr_id": "audio-separation-nodes-comfyui",
        "ver": "31a4567726e035097cc2d1f767767908a6fda2ea",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "0:00",
        "3:00"
      ]
    },
    {
      "id": 212,
      "type": "Audio Duration",
      "pos": [
        1012.3566912287612,
        -1753.9834173650165
      ],
      "size": [
        270,
        138
      ],
      "flags": {},
      "order": 17,
      "mode": 0,
      "inputs": [
        {
          "name": "audio",
          "shape": 7,
          "type": "AUDIO",
          "link": 355
        }
      ],
      "outputs": [
        {
          "name": "seconds_int",
          "type": "INT",
          "links": [
            365
          ]
        },
        {
          "name": "seconds_float",
          "type": "FLOAT",
          "links": []
        },
        {
          "name": "minutes_int",
          "type": "INT",
          "links": null
        },
        {
          "name": "minutes_float",
          "type": "FLOAT",
          "links": null
        },
        {
          "name": "temp_wav_path",
          "type": "STRING",
          "links": null
        }
      ],
      "properties": {
        "Node name for S&R": "Audio Duration"
      },
      "widgets_values": [
        ""
      ]
    },
    {
      "id": 218,
      "type": "easy showAnything",
      "pos": [
        994.9367157473264,
        -1559.7540211164503
      ],
      "size": [
        140,
        76
      ],
      "flags": {
        "collapsed": true
      },
      "order": 19,
      "mode": 0,
      "inputs": [
        {
          "name": "anything",
          "shape": 7,
          "type": "*",
          "link": 365
        }
      ],
      "outputs": [
        {
          "name": "output",
          "type": "*",
          "links": [
            370
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "easy showAnything"
      },
      "widgets_values": [
        "6"
      ]
    },
    {
      "id": 222,
      "type": "INTConstant",
      "pos": [
        1136.626958464838,
        -1558.5087937869118
      ],
      "size": [
        200,
        58
      ],
      "flags": {
        "collapsed": true
      },
      "order": 20,
      "mode": 0,
      "inputs": [
        {
          "name": "value",
          "type": "INT",
          "widget": {
            "name": "value"
          },
          "link": 370
        }
      ],
      "outputs": [
        {
          "name": "value",
          "type": "INT",
          "links": [
            371
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "INTConstant"
      },
      "widgets_values": [
        25
      ],
      "color": "#1b4669",
      "bgcolor": "#29699c"
    },
    {
      "id": 199,
      "type": "SimpleMath+",
      "pos": [
        1141.4753518184707,
        -1507.6186775022193
      ],
      "size": [
        270,
        98
      ],
      "flags": {
        "collapsed": true
      },
      "order": 21,
      "mode": 0,
      "inputs": [
        {
          "label": "a",
          "name": "a",
          "shape": 7,
          "type": "*",
          "link": 371
        },
        {
          "label": "b",
          "name": "b",
          "shape": 7,
          "type": "*",
          "link": 369
        },
        {
          "label": "c",
          "name": "c",
          "shape": 7,
          "type": "*"
        },
        {
          "label": "value",
          "name": "value",
          "type": "STRING",
          "widget": {
            "name": "value"
          }
        }
      ],
      "outputs": [
        {
          "label": "INT",
          "name": "INT",
          "type": "INT",
          "links": [
            345
          ]
        },
        {
          "label": "FLOAT",
          "name": "FLOAT",
          "type": "FLOAT"
        }
      ],
      "properties": {
        "Node name for S&R": "SimpleMath+",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "a*b+25"
      ]
    },
    {
      "id": 221,
      "type": "INTConstant",
      "pos": [
        979.4800215921297,
        -1508.9782039402178
      ],
      "size": [
        200,
        58
      ],
      "flags": {
        "collapsed": true
      },
      "order": 10,
      "mode": 0,
      "inputs": [],
      "outputs": [
        {
          "name": "value",
          "type": "INT",
          "links": [
            369
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "INTConstant"
      },
      "widgets_values": [
        25
      ],
      "color": "#1b4669",
      "bgcolor": "#29699c"
    },
    {
      "id": 170,
      "type": "AudioSeparation",
      "pos": [
        1058.876353462094,
        -1441.7191123468192
      ],
      "size": [
        270,
        166
      ],
      "flags": {
        "collapsed": true
      },
      "order": 16,
      "mode": 0,
      "inputs": [
        {
          "label": "audio",
          "name": "audio",
          "type": "AUDIO",
          "link": 301
        },
        {
          "label": "chunk_fade_shape",
          "name": "chunk_fade_shape",
          "shape": 7,
          "type": "COMBO",
          "widget": {
            "name": "chunk_fade_shape"
          }
        },
        {
          "label": "chunk_length",
          "name": "chunk_length",
          "shape": 7,
          "type": "FLOAT",
          "widget": {
            "name": "chunk_length"
          }
        },
        {
          "label": "chunk_overlap",
          "name": "chunk_overlap",
          "shape": 7,
          "type": "FLOAT",
          "widget": {
            "name": "chunk_overlap"
          }
        }
      ],
      "outputs": [
        {
          "label": "Bass",
          "name": "Bass",
          "type": "AUDIO"
        },
        {
          "label": "Drums",
          "name": "Drums",
          "type": "AUDIO"
        },
        {
          "label": "Other",
          "name": "Other",
          "type": "AUDIO"
        },
        {
          "label": "Vocals",
          "name": "Vocals",
          "type": "AUDIO",
          "links": [
            335
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "AudioSeparation",
        "cnr_id": "audio-separation-nodes-comfyui",
        "ver": "31a4567726e035097cc2d1f767767908a6fda2ea",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "linear",
        10,
        0.1
      ]
    }
  ],
  "links": [
    [
      193,
      129,
      0,
      130,
      0,
      "WANVAE"
    ],
    [
      194,
      128,
      0,
      130,
      1,
      "LATENT"
    ],
    [
      196,
      130,
      0,
      131,
      0,
      "IMAGE"
    ],
    [
      197,
      122,
      0,
      128,
      0,
      "WANVIDEOMODEL"
    ],
    [
      202,
      136,
      0,
      135,
      0,
      "WANTEXTENCODER"
    ],
    [
      256,
      138,
      0,
      122,
      2,
      "WANVIDLORA"
    ],
    [
      257,
      125,
      0,
      159,
      0,
      "AUDIO"
    ],
    [
      270,
      120,
      0,
      122,
      6,
      "MULTITALKMODEL"
    ],
    [
      283,
      133,
      0,
      171,
      0,
      "IMAGE"
    ],
    [
      296,
      159,
      0,
      131,
      1,
      "AUDIO"
    ],
    [
      299,
      177,
      0,
      122,
      0,
      "WANCOMPILEARGS"
    ],
    [
      301,
      159,
      0,
      170,
      0,
      "AUDIO"
    ],
    [
      306,
      135,
      0,
      128,
      2,
      "WANVIDEOTEXTEMBEDS"
    ],
    [
      325,
      129,
      0,
      192,
      0,
      "WANVAE"
    ],
    [
      326,
      171,
      0,
      192,
      1,
      "IMAGE"
    ],
    [
      328,
      192,
      0,
      128,
      1,
      "WANVIDIMAGE_EMBEDS"
    ],
    [
      329,
      193,
      0,
      192,
      2,
      "WANVIDIMAGE_CLIPEMBEDS"
    ],
    [
      330,
      173,
      0,
      193,
      0,
      "CLIP_VISION"
    ],
    [
      331,
      171,
      0,
      193,
      1,
      "IMAGE"
    ],
    [
      332,
      134,
      0,
      122,
      1,
      "BLOCKSWAPARGS"
    ],
    [
      334,
      137,
      0,
      194,
      0,
      "WAV2VECMODEL"
    ],
    [
      335,
      170,
      3,
      194,
      1,
      "AUDIO"
    ],
    [
      336,
      194,
      0,
      128,
      15,
      "MULTITALK_EMBEDS"
    ],
    [
      339,
      171,
      1,
      192,
      3,
      "INT"
    ],
    [
      340,
      171,
      2,
      192,
      4,
      "INT"
    ],
    [
      345,
      199,
      0,
      194,
      7,
      "INT"
    ],
    [
      355,
      159,
      0,
      212,
      0,
      "AUDIO"
    ],
    [
      365,
      212,
      0,
      218,
      0,
      "INT"
    ],
    [
      369,
      221,
      0,
      199,
      1,
      "INT"
    ],
    [
      370,
      218,
      0,
      222,
      0,
      "INT"
    ],
    [
      371,
      222,
      0,
      199,
      0,
      "INT"
    ]
  ],
  "groups": [
    {
      "id": 1,
      "title": "模型加载区",
      "bounding": [
        969.4049072265625,
        -2553.697509765625,
        1947.9510433010842,
        1190.5439974827982
      ],
      "color": "#3f789e",
      "flags": {}
    }
  ],
  "config": {},
  "extra": {
    "VHS_KeepIntermediate": true,
    "links_added_by_ue": [],
    "VHS_MetadataImage": true,
    "ue_links": [],
    "0246.VERSION": [
      0,
      0,
      4
    ],
    "VHS_latentpreviewrate": 0,
    "frontendVersion": "1.45.20",
    "VHS_latentpreview": false,
    "node_versions": {
      "ComfyUI-WanVideoWrapper": "0a11c67a0c0062b534178920a0d6dcaa75e7b5fe",
      "audio-separation-nodes-comfyui": "31a4567726e035097cc2d1f767767908a6fda2ea",
      "comfyui-videohelpersuite": "a7ce59e381934733bfae03b1be029756d6ce936d",
      "ComfyUI-KJNodes": "f7eb33abc80a2aded1b46dff0dd14d07856a7d50",
      "comfy-core": "0.3.43"
    },
    "ds": {
      "scale": 0.5445000000000029,
      "offset": [
        150.19977105197026,
        2825.631502603407
      ]
    }
  },
  "version": 0.4
}
```
