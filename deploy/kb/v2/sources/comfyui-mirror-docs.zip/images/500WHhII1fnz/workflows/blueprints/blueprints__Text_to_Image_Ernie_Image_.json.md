# Text to Image (Ernie Image)

- 来源类别：内置工作流蓝图
- 镜像内原始路径：`/ComfyUI/blueprints/Text to Image (Ernie Image).json`
- 节点数量：1
- 连线数量：0

## 节点类型

- `03921aea-a70e-44b4-bc77-f6bda10f2120` × 1

## 原始工作流 JSON

```json
{
  "revision": 0,
  "last_node_id": 88,
  "last_link_id": 0,
  "nodes": [
    {
      "id": 88,
      "type": "03921aea-a70e-44b4-bc77-f6bda10f2120",
      "pos": [
        -120,
        240
      ],
      "size": [
        400,
        540
      ],
      "flags": {},
      "order": 0,
      "mode": 0,
      "inputs": [
        {
          "label": "prompt",
          "name": "value",
          "type": "STRING",
          "widget": {
            "name": "value"
          },
          "link": null
        },
        {
          "label": "prompt_enhancement",
          "name": "value_1",
          "type": "BOOLEAN",
          "widget": {
            "name": "value_1"
          },
          "link": null
        },
        {
          "name": "width",
          "type": "INT",
          "widget": {
            "name": "width"
          },
          "link": null
        },
        {
          "name": "height",
          "type": "INT",
          "widget": {
            "name": "height"
          },
          "link": null
        },
        {
          "name": "steps",
          "type": "INT",
          "widget": {
            "name": "steps"
          },
          "link": null
        },
        {
          "name": "cfg",
          "type": "FLOAT",
          "widget": {
            "name": "cfg"
          },
          "link": null
        },
        {
          "name": "seed",
          "type": "INT",
          "widget": {
            "name": "seed"
          },
          "link": null
        },
        {
          "name": "unet_name",
          "type": "COMBO",
          "widget": {
            "name": "unet_name"
          },
          "link": null
        },
        {
          "name": "clip_name",
          "type": "COMBO",
          "widget": {
            "name": "clip_name"
          },
          "link": null
        },
        {
          "label": "prompt_enhancer",
          "name": "clip_name_1",
          "type": "COMBO",
          "widget": {
            "name": "clip_name_1"
          },
          "link": null
        },
        {
          "name": "vae_name",
          "type": "COMBO",
          "widget": {
            "name": "vae_name"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "localized_name": "IMAGE",
          "name": "IMAGE",
          "type": "IMAGE",
          "links": []
        }
      ],
      "properties": {
        "proxyWidgets": [
          [
            "78",
            "value"
          ],
          [
            "76",
            "value"
          ],
          [
            "71",
            "width"
          ],
          [
            "71",
            "height"
          ],
          [
            "70",
            "steps"
          ],
          [
            "70",
            "cfg"
          ],
          [
            "70",
            "seed"
          ],
          [
            "66",
            "unet_name"
          ],
          [
            "62",
            "clip_name"
          ],
          [
            "91",
            "clip_name"
          ],
          [
            "63",
            "vae_name"
          ]
        ],
        "cnr_id": "comfy-core",
        "ver": "0.18.1",
        "enableTabs": false,
        "tabWidth": 65,
        "tabXOffset": 10,
        "hasSecondTab": false,
        "secondTabText": "Send Back",
        "secondTabOffset": 80,
        "secondTabWidth": 65,
        "ue_properties": {
          "widget_ue_connectable": {
            "value": true,
            "value_1": true
          },
          "version": "7.7",
          "input_ue_unconnectable": {}
        }
      },
      "widgets_values": [],
      "title": "Text to Image (Ernie Image)"
    }
  ],
  "links": [],
  "version": 0.4,
  "definitions": {
    "subgraphs": [
      {
        "id": "03921aea-a70e-44b4-bc77-f6bda10f2120",
        "version": 1,
        "state": {
          "lastGroupId": 6,
          "lastNodeId": 99,
          "lastLinkId": 124,
          "lastRerouteId": 0
        },
        "revision": 0,
        "config": {},
        "name": "Text to Image (Ernie Image)",
        "inputNode": {
          "id": -10,
          "bounding": [
            -1350,
            370,
            163.50390625,
            260
          ]
        },
        "outputNode": {
          "id": -20,
          "bounding": [
            1110,
            260,
            120,
            60
          ]
        },
        "inputs": [
          {
            "id": "504de359-52a4-49aa-b6be-23c1cdb0cbde",
            "name": "value",
            "type": "STRING",
            "linkIds": [
              102
            ],
            "label": "prompt",
            "pos": [
              -1206.49609375,
              390
            ]
          },
          {
            "id": "29f699c6-9263-41f6-b37d-69b9fc3913dd",
            "name": "value_1",
            "type": "BOOLEAN",
            "linkIds": [
              103
            ],
            "label": "prompt_enhancement",
            "pos": [
              -1206.49609375,
              410
            ]
          },
          {
            "id": "968e6213-d1e9-4268-8f47-1d6b9a39a43e",
            "name": "width",
            "type": "INT",
            "linkIds": [
              104,
              113
            ],
            "pos": [
              -1206.49609375,
              430
            ]
          },
          {
            "id": "181c49ef-740d-4385-aa11-79718951ccb9",
            "name": "height",
            "type": "INT",
            "linkIds": [
              105,
              114
            ],
            "pos": [
              -1206.49609375,
              450
            ]
          },
          {
            "id": "1e85f808-66a1-41df-be52-334142b35419",
            "name": "steps",
            "type": "INT",
            "linkIds": [
              106
            ],
            "pos": [
              -1206.49609375,
              470
            ]
          },
          {
            "id": "2806addf-a252-4aa3-a5b7-397ab36dccec",
            "name": "cfg",
            "type": "FLOAT",
            "linkIds": [
              107
            ],
            "pos": [
              -1206.49609375,
              490
            ]
          },
          {
            "id": "5d036a66-5dc0-4d7c-b9a9-349e454738aa",
            "name": "seed",
            "type": "INT",
            "linkIds": [
              108
            ],
            "pos": [
              -1206.49609375,
              510
            ]
          },
          {
            "id": "360f9a40-aac5-4e9c-bc98-9d55a4a58be2",
            "name": "unet_name",
            "type": "COMBO",
            "linkIds": [
              109
            ],
            "pos": [
              -1206.49609375,
              530
            ]
          },
          {
            "id": "886301c7-6e88-4cec-96fa-8ae20e8340c5",
            "name": "clip_name",
            "type": "COMBO",
            "linkIds": [
              110
            ],
            "pos": [
              -1206.49609375,
              550
            ]
          },
          {
            "id": "1d73a545-6d01-462f-bc61-966d4b918ff2",
            "name": "clip_name_1",
            "type": "COMBO",
            "linkIds": [
              120
            ],
            "label": "prompt_enhancer",
            "pos": [
              -1206.49609375,
              570
            ]
          },
          {
            "id": "8c61dc8c-e260-4b36-b73e-d36f90a0bbe3",
            "name": "vae_name",
            "type": "COMBO",
            "linkIds": [
              121
            ],
            "pos": [
              -1206.49609375,
              590
            ]
          }
        ],
        "outputs": [
          {
            "id": "f4cb34c8-4090-4281-b428-7338a339d274",
            "name": "IMAGE",
            "type": "IMAGE",
            "linkIds": [
              84
            ],
            "localized_name": "IMAGE",
            "pos": [
              1130,
              280
            ]
          }
        ],
        "widgets": [],
        "nodes": [
          {
            "id": 71,
            "type": "EmptyFlux2LatentImage",
            "pos": [
              -460,
              1040
            ],
            "size": [
              270,
              170
            ],
            "flags": {},
            "order": 6,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "width",
                "name": "width",
                "type": "INT",
                "widget": {
                  "name": "width"
                },
                "link": 104
              },
              {
                "localized_name": "height",
                "name": "height",
                "type": "INT",
                "widget": {
                  "name": "height"
                },
                "link": 105
              },
              {
                "localized_name": "batch_size",
                "name": "batch_size",
                "type": "INT",
                "widget": {
                  "name": "batch_size"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "LATENT",
                "name": "LATENT",
                "type": "LATENT",
                "links": [
                  80
                ]
              }
            ],
            "properties": {
              "Node name for S&R": "EmptyFlux2LatentImage",
              "cnr_id": "comfy-core",
              "ver": "0.18.1",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65,
              "ue_properties": {
                "widget_ue_connectable": {},
                "version": "7.7",
                "input_ue_unconnectable": {}
              }
            },
            "widgets_values": [
              1024,
              1024,
              1
            ]
          },
          {
            "id": 66,
            "type": "UNETLoader",
            "pos": [
              -470,
              320
            ],
            "size": [
              270,
              110
            ],
            "flags": {},
            "order": 3,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "unet_name",
                "name": "unet_name",
                "type": "COMBO",
                "widget": {
                  "name": "unet_name"
                },
                "link": 109
              },
              {
                "localized_name": "weight_dtype",
                "name": "weight_dtype",
                "type": "COMBO",
                "widget": {
                  "name": "weight_dtype"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "MODEL",
                "name": "MODEL",
                "type": "MODEL",
                "links": [
                  85
                ]
              }
            ],
            "properties": {
              "Node name for S&R": "UNETLoader",
              "cnr_id": "comfy-core",
              "ver": "0.3.73",
              "models": [
                {
                  "name": "ernie-image.safetensors",
                  "url": "https://huggingface.co/Comfy-Org/ERNIE-Image/resolve/main/diffusion_models/ernie-image.safetensors",
                  "directory": "diffusion_models"
                }
              ],
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65,
              "ue_properties": {
                "widget_ue_connectable": {},
                "version": "7.7",
                "input_ue_unconnectable": {}
              }
            },
            "widgets_values": [
              "ernie-image.safetensors",
              "default"
            ]
          },
          {
            "id": 65,
            "type": "VAEDecode",
            "pos": [
              710,
              280
            ],
            "size": [
              230,
              100
            ],
            "flags": {},
            "order": 2,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "samples",
                "name": "samples",
                "type": "LATENT",
                "link": 73
              },
              {
                "localized_name": "vae",
                "name": "vae",
                "type": "VAE",
                "link": 74
              }
            ],
            "outputs": [
              {
                "localized_name": "IMAGE",
                "name": "IMAGE",
                "type": "IMAGE",
                "slot_index": 0,
                "links": [
                  84
                ]
              }
            ],
            "properties": {
              "Node name for S&R": "VAEDecode",
              "cnr_id": "comfy-core",
              "ver": "0.3.64",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65,
              "ue_properties": {
                "widget_ue_connectable": {},
                "version": "7.7",
                "input_ue_unconnectable": {}
              }
            }
          },
          {
            "id": 70,
            "type": "KSampler",
            "pos": [
              350,
              280
            ],
            "size": [
              320,
              350
            ],
            "flags": {},
            "order": 5,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "model",
                "name": "model",
                "type": "MODEL",
                "link": 85
              },
              {
                "localized_name": "positive",
                "name": "positive",
                "type": "CONDITIONING",
                "link": 76
              },
              {
                "localized_name": "negative",
                "name": "negative",
                "type": "CONDITIONING",
                "link": 83
              },
              {
                "localized_name": "latent_image",
                "name": "latent_image",
                "type": "LATENT",
                "link": 80
              },
              {
                "localized_name": "seed",
                "name": "seed",
                "type": "INT",
                "widget": {
                  "name": "seed"
                },
                "link": 108
              },
              {
                "localized_name": "steps",
                "name": "steps",
                "type": "INT",
                "widget": {
                  "name": "steps"
                },
                "link": 106
              },
              {
                "localized_name": "cfg",
                "name": "cfg",
                "type": "FLOAT",
                "widget": {
                  "name": "cfg"
                },
                "link": 107
              },
              {
                "localized_name": "sampler_name",
                "name": "sampler_name",
                "type": "COMBO",
                "widget": {
                  "name": "sampler_name"
                },
                "link": null
              },
              {
                "localized_name": "scheduler",
                "name": "scheduler",
                "type": "COMBO",
                "widget": {
                  "name": "scheduler"
                },
                "link": null
              },
              {
                "localized_name": "denoise",
                "name": "denoise",
                "type": "FLOAT",
                "widget": {
                  "name": "denoise"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "LATENT",
                "name": "LATENT",
                "type": "LATENT",
                "slot_index": 0,
                "links": [
                  73
                ]
              }
            ],
            "properties": {
              "Node name for S&R": "KSampler",
              "cnr_id": "comfy-core",
              "ver": "0.3.64",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65,
              "ue_properties": {
                "widget_ue_connectable": {},
                "version": "7.7",
                "input_ue_unconnectable": {}
              }
            },
            "widgets_values": [
              182596410725960,
              "randomize",
              20,
              4,
              "euler",
              "simple",
              1
            ]
          },
          {
            "id": 67,
            "type": "CLIPTextEncode",
            "pos": [
              -140,
              320
            ],
            "size": [
              410,
              370
            ],
            "flags": {},
            "order": 4,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "clip",
                "name": "clip",
                "type": "CLIP",
                "link": 79
              },
              {
                "localized_name": "text",
                "name": "text",
                "type": "STRING",
                "widget": {
                  "name": "text"
                },
                "link": 100
              }
            ],
            "outputs": [
              {
                "localized_name": "CONDITIONING",
                "name": "CONDITIONING",
                "type": "CONDITIONING",
                "links": [
                  76
                ]
              }
            ],
            "properties": {
              "Node name for S&R": "CLIPTextEncode",
              "cnr_id": "comfy-core",
              "ver": "0.3.73",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65,
              "ue_properties": {
                "widget_ue_connectable": {},
                "version": "7.7",
                "input_ue_unconnectable": {}
              }
            },
            "widgets_values": [
              ""
            ],
            "color": "#232",
            "bgcolor": "#353"
          },
          {
            "id": 72,
            "type": "CLIPTextEncode",
            "pos": [
              -130,
              770
            ],
            "size": [
              390,
              140
            ],
            "flags": {},
            "order": 7,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "clip",
                "name": "clip",
                "type": "CLIP",
                "link": 82
              },
              {
                "localized_name": "text",
                "name": "text",
                "type": "STRING",
                "widget": {
                  "name": "text"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "CONDITIONING",
                "name": "CONDITIONING",
                "type": "CONDITIONING",
                "links": [
                  83
                ]
              }
            ],
            "properties": {
              "Node name for S&R": "CLIPTextEncode",
              "cnr_id": "comfy-core",
              "ver": "0.3.73",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65,
              "ue_properties": {
                "widget_ue_connectable": {},
                "version": "7.7",
                "input_ue_unconnectable": {}
              }
            },
            "widgets_values": [
              ""
            ],
            "color": "#223",
            "bgcolor": "#335"
          },
          {
            "id": 83,
            "type": "StringReplace",
            "pos": [
              -500,
              -640
            ],
            "size": [
              430,
              450
            ],
            "flags": {},
            "order": 12,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "string",
                "name": "string",
                "type": "STRING",
                "widget": {
                  "name": "string"
                },
                "link": null
              },
              {
                "localized_name": "find",
                "name": "find",
                "type": "STRING",
                "widget": {
                  "name": "find"
                },
                "link": null
              },
              {
                "localized_name": "replace",
                "name": "replace",
                "type": "STRING",
                "widget": {
                  "name": "replace"
                },
                "link": 92
              }
            ],
            "outputs": [
              {
                "localized_name": "STRING",
                "name": "STRING",
                "type": "STRING",
                "links": [
                  115
                ]
              }
            ],
            "properties": {
              "Node name for S&R": "StringReplace",
              "cnr_id": "comfy-core",
              "ver": "0.18.1",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65,
              "ue_properties": {
                "widget_ue_connectable": {},
                "version": "7.7",
                "input_ue_unconnectable": {}
              }
            },
            "widgets_values": [
              "<s>[SYSTEM_PROMPT]你是一个专业的文生图 Prompt 增强助手。你将收到用户的简短图片描述及目标生成分辨率，请据此扩写为一段内容丰富、细节充分的视觉描述，以帮助文生图模型生成高质量的图片。仅输出增强后的描述，不要包含任何解释或前缀。[/SYSTEM_PROMPT][INST]{\"prompt\": \"{prompt}\", \"width\": {width}, \"height\": {height}}[/INST]",
              "{prompt}",
              ""
            ]
          },
          {
            "id": 78,
            "type": "PrimitiveStringMultiline",
            "pos": [
              -950,
              -650
            ],
            "size": [
              400,
              200
            ],
            "flags": {},
            "order": 11,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "value",
                "name": "value",
                "type": "STRING",
                "widget": {
                  "name": "value"
                },
                "link": 102
              }
            ],
            "outputs": [
              {
                "localized_name": "STRING",
                "name": "STRING",
                "type": "STRING",
                "links": [
                  87,
                  92
                ]
              }
            ],
            "title": "String (Multiline - Prompt)",
            "properties": {
              "Node name for S&R": "PrimitiveStringMultiline",
              "cnr_id": "comfy-core",
              "ver": "0.18.1",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65,
              "ue_properties": {
                "widget_ue_connectable": {},
                "version": "7.7",
                "input_ue_unconnectable": {}
              }
            },
            "widgets_values": [
              ""
            ]
          },
          {
            "id": 74,
            "type": "TextGenerate",
            "pos": [
              530,
              -650
            ],
            "size": [
              400,
              380
            ],
            "flags": {},
            "order": 8,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "clip",
                "name": "clip",
                "type": "CLIP",
                "link": 112
              },
              {
                "localized_name": "image",
                "name": "image",
                "shape": 7,
                "type": "IMAGE",
                "link": null
              },
              {
                "localized_name": "prompt",
                "name": "prompt",
                "type": "STRING",
                "widget": {
                  "name": "prompt"
                },
                "link": 119
              },
              {
                "localized_name": "max_length",
                "name": "max_length",
                "type": "INT",
                "widget": {
                  "name": "max_length"
                },
                "link": null
              },
              {
                "localized_name": "sampling_mode",
                "name": "sampling_mode",
                "type": "COMFY_DYNAMICCOMBO_V3",
                "widget": {
                  "name": "sampling_mode"
                },
                "link": null
              },
              {
                "localized_name": "temperature",
                "name": "sampling_mode.temperature",
                "type": "FLOAT",
                "widget": {
                  "name": "sampling_mode.temperature"
                },
                "link": null
              },
              {
                "localized_name": "top_k",
                "name": "sampling_mode.top_k",
                "type": "INT",
                "widget": {
                  "name": "sampling_mode.top_k"
                },
                "link": null
              },
              {
                "localized_name": "top_p",
                "name": "sampling_mode.top_p",
                "type": "FLOAT",
                "widget": {
                  "name": "sampling_mode.top_p"
                },
                "link": null
              },
              {
                "localized_name": "min_p",
                "name": "sampling_mode.min_p",
                "type": "FLOAT",
                "widget": {
                  "name": "sampling_mode.min_p"
                },
                "link": null
              },
              {
                "localized_name": "repetition_penalty",
                "name": "sampling_mode.repetition_penalty",
                "type": "FLOAT",
                "widget": {
                  "name": "sampling_mode.repetition_penalty"
                },
                "link": null
              },
              {
                "localized_name": "seed",
                "name": "sampling_mode.seed",
                "type": "INT",
                "widget": {
                  "name": "sampling_mode.seed"
                },
                "link": null
              },
              {
                "localized_name": "sampling_mode.presence_penalty",
                "name": "sampling_mode.presence_penalty",
                "shape": 7,
                "type": "FLOAT",
                "widget": {
                  "name": "sampling_mode.presence_penalty"
                },
                "link": null
              },
              {
                "localized_name": "thinking",
                "name": "thinking",
                "shape": 7,
                "type": "BOOLEAN",
                "widget": {
                  "name": "thinking"
                },
                "link": null
              },
              {
                "localized_name": "use_default_template",
                "name": "use_default_template",
                "shape": 7,
                "type": "BOOLEAN",
                "widget": {
                  "name": "use_default_template"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "generated_text",
                "name": "generated_text",
                "type": "STRING",
                "links": [
                  89
                ]
              }
            ],
            "properties": {
              "Node name for S&R": "TextGenerate",
              "cnr_id": "comfy-core",
              "ver": "0.18.1",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65,
              "ue_properties": {
                "widget_ue_connectable": {},
                "version": "7.7",
                "input_ue_unconnectable": {}
              }
            },
            "widgets_values": [
              "",
              2048,
              "on",
              0.6,
              64,
              0.8,
              0.05,
              1.05,
              0,
              0,
              false,
              true
            ]
          },
          {
            "id": 76,
            "type": "PrimitiveBoolean",
            "pos": [
              -500,
              60
            ],
            "size": [
              270,
              100
            ],
            "flags": {},
            "order": 10,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "value",
                "name": "value",
                "type": "BOOLEAN",
                "widget": {
                  "name": "value"
                },
                "link": 103
              }
            ],
            "outputs": [
              {
                "localized_name": "BOOLEAN",
                "name": "BOOLEAN",
                "type": "BOOLEAN",
                "links": [
                  88
                ]
              }
            ],
            "title": "Enable prompt enhancement?",
            "properties": {
              "Node name for S&R": "PrimitiveBoolean",
              "cnr_id": "comfy-core",
              "ver": "0.18.1",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65,
              "ue_properties": {
                "widget_ue_connectable": {},
                "version": "7.7",
                "input_ue_unconnectable": {}
              }
            },
            "widgets_values": [
              true
            ]
          },
          {
            "id": 75,
            "type": "ComfySwitchNode",
            "pos": [
              530,
              20
            ],
            "size": [
              270,
              130
            ],
            "flags": {},
            "order": 9,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "on_false",
                "name": "on_false",
                "type": "*",
                "link": 87
              },
              {
                "localized_name": "on_true",
                "name": "on_true",
                "type": "*",
                "link": 89
              },
              {
                "localized_name": "switch",
                "name": "switch",
                "type": "BOOLEAN",
                "widget": {
                  "name": "switch"
                },
                "link": 88
              }
            ],
            "outputs": [
              {
                "localized_name": "output",
                "name": "output",
                "type": "*",
                "links": [
                  100,
                  124
                ]
              }
            ],
            "properties": {
              "Node name for S&R": "ComfySwitchNode",
              "cnr_id": "comfy-core",
              "ver": "0.18.1",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65,
              "ue_properties": {
                "widget_ue_connectable": {},
                "version": "7.7",
                "input_ue_unconnectable": {}
              }
            },
            "widgets_values": [
              false
            ]
          },
          {
            "id": 62,
            "type": "CLIPLoader",
            "pos": [
              -460,
              520
            ],
            "size": [
              270,
              150
            ],
            "flags": {},
            "order": 0,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "clip_name",
                "name": "clip_name",
                "type": "COMBO",
                "widget": {
                  "name": "clip_name"
                },
                "link": 110
              },
              {
                "localized_name": "type",
                "name": "type",
                "type": "COMBO",
                "widget": {
                  "name": "type"
                },
                "link": null
              },
              {
                "localized_name": "device",
                "name": "device",
                "shape": 7,
                "type": "COMBO",
                "widget": {
                  "name": "device"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "CLIP",
                "name": "CLIP",
                "type": "CLIP",
                "links": [
                  79,
                  82
                ]
              }
            ],
            "properties": {
              "Node name for S&R": "CLIPLoader",
              "cnr_id": "comfy-core",
              "ver": "0.3.73",
              "models": [
                {
                  "name": "ministral-3-3b.safetensors",
                  "url": "https://huggingface.co/Comfy-Org/ERNIE-Image/resolve/main/text_encoders/ministral-3-3b.safetensors",
                  "directory": "text_encoders"
                }
              ],
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65,
              "ue_properties": {
                "widget_ue_connectable": {},
                "version": "7.7",
                "input_ue_unconnectable": {}
              }
            },
            "widgets_values": [
              "ministral-3-3b.safetensors",
              "flux2",
              "default"
            ]
          },
          {
            "id": 63,
            "type": "VAELoader",
            "pos": [
              -460,
              770
            ],
            "size": [
              270,
              110
            ],
            "flags": {},
            "order": 1,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "vae_name",
                "name": "vae_name",
                "type": "COMBO",
                "widget": {
                  "name": "vae_name"
                },
                "link": 121
              }
            ],
            "outputs": [
              {
                "localized_name": "VAE",
                "name": "VAE",
                "type": "VAE",
                "links": [
                  74
                ]
              }
            ],
            "properties": {
              "Node name for S&R": "VAELoader",
              "cnr_id": "comfy-core",
              "ver": "0.3.73",
              "models": [
                {
                  "name": "flux2-vae.safetensors",
                  "url": "https://huggingface.co/Comfy-Org/ERNIE-Image/resolve/main/vae/flux2-vae.safetensors",
                  "directory": "vae"
                }
              ],
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65,
              "ue_properties": {
                "widget_ue_connectable": {},
                "version": "7.7",
                "input_ue_unconnectable": {}
              }
            },
            "widgets_values": [
              "flux2-vae.safetensors"
            ]
          },
          {
            "id": 91,
            "type": "CLIPLoader",
            "pos": [
              -500,
              -150
            ],
            "size": [
              510,
              150
            ],
            "flags": {},
            "order": 13,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "clip_name",
                "name": "clip_name",
                "type": "COMBO",
                "widget": {
                  "name": "clip_name"
                },
                "link": 120
              },
              {
                "localized_name": "type",
                "name": "type",
                "type": "COMBO",
                "widget": {
                  "name": "type"
                },
                "link": null
              },
              {
                "localized_name": "device",
                "name": "device",
                "shape": 7,
                "type": "COMBO",
                "widget": {
                  "name": "device"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "CLIP",
                "name": "CLIP",
                "type": "CLIP",
                "links": [
                  112
                ]
              }
            ],
            "title": "Load CLIP (PE)",
            "properties": {
              "Node name for S&R": "CLIPLoader",
              "cnr_id": "comfy-core",
              "ver": "0.19.0",
              "models": [
                {
                  "name": "ernie-image-prompt-enhancer.safetensors",
                  "url": "https://huggingface.co/Comfy-Org/ERNIE-Image/resolve/main/text_encoders/ernie-image-prompt-enhancer.safetensors",
                  "directory": "text_encoders"
                }
              ],
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65,
              "ue_properties": {
                "widget_ue_connectable": {},
                "version": "7.7",
                "input_ue_unconnectable": {}
              }
            },
            "widgets_values": [
              "ernie-image-prompt-enhancer.safetensors",
              "flux2",
              "default"
            ]
          },
          {
            "id": 92,
            "type": "PreviewAny",
            "pos": [
              -950,
              -400
            ],
            "size": [
              400,
              180
            ],
            "flags": {},
            "order": 14,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "source",
                "name": "source",
                "type": "*",
                "link": 113
              }
            ],
            "outputs": [
              {
                "localized_name": "STRING",
                "name": "STRING",
                "type": "STRING",
                "links": [
                  116
                ]
              }
            ],
            "title": "Preview as Text (Int to String)",
            "properties": {
              "Node name for S&R": "PreviewAny",
              "cnr_id": "comfy-core",
              "ver": "0.19.0",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65,
              "ue_properties": {
                "widget_ue_connectable": {},
                "version": "7.7",
                "input_ue_unconnectable": {}
              }
            },
            "widgets_values": [
              null,
              null,
              null
            ]
          },
          {
            "id": 93,
            "type": "PreviewAny",
            "pos": [
              -950,
              -180
            ],
            "size": [
              400,
              180
            ],
            "flags": {},
            "order": 15,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "source",
                "name": "source",
                "type": "*",
                "link": 114
              }
            ],
            "outputs": [
              {
                "localized_name": "STRING",
                "name": "STRING",
                "type": "STRING",
                "links": [
                  118
                ]
              }
            ],
            "title": "Preview as Text (Int to String)",
            "properties": {
              "Node name for S&R": "PreviewAny",
              "cnr_id": "comfy-core",
              "ver": "0.19.0",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65,
              "ue_properties": {
                "widget_ue_connectable": {},
                "version": "7.7",
                "input_ue_unconnectable": {}
              }
            },
            "widgets_values": [
              null,
              null,
              null
            ]
          },
          {
            "id": 94,
            "type": "StringReplace",
            "pos": [
              -30,
              -640
            ],
            "size": [
              230,
              450
            ],
            "flags": {},
            "order": 16,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "string",
                "name": "string",
                "type": "STRING",
                "widget": {
                  "name": "string"
                },
                "link": 115
              },
              {
                "localized_name": "find",
                "name": "find",
                "type": "STRING",
                "widget": {
                  "name": "find"
                },
                "link": null
              },
              {
                "localized_name": "replace",
                "name": "replace",
                "type": "STRING",
                "widget": {
                  "name": "replace"
                },
                "link": 116
              }
            ],
            "outputs": [
              {
                "localized_name": "STRING",
                "name": "STRING",
                "type": "STRING",
                "links": [
                  117
                ]
              }
            ],
            "properties": {
              "Node name for S&R": "StringReplace",
              "cnr_id": "comfy-core",
              "ver": "0.18.1",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65,
              "ue_properties": {
                "widget_ue_connectable": {},
                "version": "7.7",
                "input_ue_unconnectable": {}
              }
            },
            "widgets_values": [
              "",
              "{width}",
              ""
            ]
          },
          {
            "id": 95,
            "type": "StringReplace",
            "pos": [
              220,
              -640
            ],
            "size": [
              250,
              450
            ],
            "flags": {},
            "order": 17,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "string",
                "name": "string",
                "type": "STRING",
                "widget": {
                  "name": "string"
                },
                "link": 117
              },
              {
                "localized_name": "find",
                "name": "find",
                "type": "STRING",
                "widget": {
                  "name": "find"
                },
                "link": null
              },
              {
                "localized_name": "replace",
                "name": "replace",
                "type": "STRING",
                "widget": {
                  "name": "replace"
                },
                "link": 118
              }
            ],
            "outputs": [
              {
                "localized_name": "STRING",
                "name": "STRING",
                "type": "STRING",
                "links": [
                  119
                ]
              }
            ],
            "properties": {
              "Node name for S&R": "StringReplace",
              "cnr_id": "comfy-core",
              "ver": "0.18.1",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65,
              "ue_properties": {
                "widget_ue_connectable": {},
                "version": "7.7",
                "input_ue_unconnectable": {}
              }
            },
            "widgets_values": [
              "",
              "{height}",
              ""
            ]
          },
          {
            "id": 97,
            "type": "PreviewAny",
            "pos": [
              970,
              -650
            ],
            "size": [
              570,
              790
            ],
            "flags": {},
            "order": 18,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "source",
                "name": "source",
                "type": "*",
                "link": 124
              }
            ],
            "outputs": [
              {
                "localized_name": "STRING",
                "name": "STRING",
                "type": "STRING",
                "links": []
              }
            ],
            "title": "Preview as Text (Int to String)",
            "properties": {
              "Node name for S&R": "PreviewAny",
              "cnr_id": "comfy-core",
              "ver": "0.19.0",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65,
              "ue_properties": {
                "widget_ue_connectable": {},
                "version": "7.7",
                "input_ue_unconnectable": {}
              }
            },
            "widgets_values": [
              null,
              null,
              null
            ]
          }
        ],
        "groups": [
          {
            "id": 6,
            "title": "Text to Image",
            "bounding": [
              -510,
              200,
              1450,
              1060
            ],
            "color": "#3f789e",
            "font_size": 24,
            "flags": {}
          },
          {
            "id": 2,
            "title": "Image Size",
            "bounding": [
              -480,
              940,
              310,
              290
            ],
            "color": "#3f789e",
            "font_size": 24,
            "flags": {}
          },
          {
            "id": 3,
            "title": "Prompt",
            "bounding": [
              -160,
              250,
              470,
              670
            ],
            "color": "#3f789e",
            "font_size": 24,
            "flags": {}
          },
          {
            "id": 4,
            "title": "Model",
            "bounding": [
              -490,
              250,
              320,
              670
            ],
            "color": "#3f789e",
            "font_size": 24,
            "flags": {}
          },
          {
            "id": 5,
            "title": "Prompt Enhancement",
            "bounding": [
              -510,
              -720,
              1450,
              890
            ],
            "color": "#3f789e",
            "font_size": 24,
            "flags": {}
          }
        ],
        "links": [
          {
            "id": 73,
            "origin_id": 70,
            "origin_slot": 0,
            "target_id": 65,
            "target_slot": 0,
            "type": "LATENT"
          },
          {
            "id": 74,
            "origin_id": 63,
            "origin_slot": 0,
            "target_id": 65,
            "target_slot": 1,
            "type": "VAE"
          },
          {
            "id": 85,
            "origin_id": 66,
            "origin_slot": 0,
            "target_id": 70,
            "target_slot": 0,
            "type": "MODEL"
          },
          {
            "id": 76,
            "origin_id": 67,
            "origin_slot": 0,
            "target_id": 70,
            "target_slot": 1,
            "type": "CONDITIONING"
          },
          {
            "id": 83,
            "origin_id": 72,
            "origin_slot": 0,
            "target_id": 70,
            "target_slot": 2,
            "type": "CONDITIONING"
          },
          {
            "id": 80,
            "origin_id": 71,
            "origin_slot": 0,
            "target_id": 70,
            "target_slot": 3,
            "type": "LATENT"
          },
          {
            "id": 79,
            "origin_id": 62,
            "origin_slot": 0,
            "target_id": 67,
            "target_slot": 0,
            "type": "CLIP"
          },
          {
            "id": 100,
            "origin_id": 75,
            "origin_slot": 0,
            "target_id": 67,
            "target_slot": 1,
            "type": "STRING"
          },
          {
            "id": 82,
            "origin_id": 62,
            "origin_slot": 0,
            "target_id": 72,
            "target_slot": 0,
            "type": "CLIP"
          },
          {
            "id": 92,
            "origin_id": 78,
            "origin_slot": 0,
            "target_id": 83,
            "target_slot": 2,
            "type": "STRING"
          },
          {
            "id": 87,
            "origin_id": 78,
            "origin_slot": 0,
            "target_id": 75,
            "target_slot": 0,
            "type": "STRING"
          },
          {
            "id": 89,
            "origin_id": 74,
            "origin_slot": 0,
            "target_id": 75,
            "target_slot": 1,
            "type": "STRING"
          },
          {
            "id": 88,
            "origin_id": 76,
            "origin_slot": 0,
            "target_id": 75,
            "target_slot": 2,
            "type": "BOOLEAN"
          },
          {
            "id": 84,
            "origin_id": 65,
            "origin_slot": 0,
            "target_id": -20,
            "target_slot": 0,
            "type": "IMAGE"
          },
          {
            "id": 102,
            "origin_id": -10,
            "origin_slot": 0,
            "target_id": 78,
            "target_slot": 0,
            "type": "STRING"
          },
          {
            "id": 103,
            "origin_id": -10,
            "origin_slot": 1,
            "target_id": 76,
            "target_slot": 0,
            "type": "BOOLEAN"
          },
          {
            "id": 104,
            "origin_id": -10,
            "origin_slot": 2,
            "target_id": 71,
            "target_slot": 0,
            "type": "INT"
          },
          {
            "id": 105,
            "origin_id": -10,
            "origin_slot": 3,
            "target_id": 71,
            "target_slot": 1,
            "type": "INT"
          },
          {
            "id": 106,
            "origin_id": -10,
            "origin_slot": 4,
            "target_id": 70,
            "target_slot": 5,
            "type": "INT"
          },
          {
            "id": 107,
            "origin_id": -10,
            "origin_slot": 5,
            "target_id": 70,
            "target_slot": 6,
            "type": "FLOAT"
          },
          {
            "id": 108,
            "origin_id": -10,
            "origin_slot": 6,
            "target_id": 70,
            "target_slot": 4,
            "type": "INT"
          },
          {
            "id": 109,
            "origin_id": -10,
            "origin_slot": 7,
            "target_id": 66,
            "target_slot": 0,
            "type": "COMBO"
          },
          {
            "id": 110,
            "origin_id": -10,
            "origin_slot": 8,
            "target_id": 62,
            "target_slot": 0,
            "type": "COMBO"
          },
          {
            "id": 112,
            "origin_id": 91,
            "origin_slot": 0,
            "target_id": 74,
            "target_slot": 0,
            "type": "CLIP"
          },
          {
            "id": 113,
            "origin_id": -10,
            "origin_slot": 2,
            "target_id": 92,
            "target_slot": 0,
            "type": "*"
          },
          {
            "id": 114,
            "origin_id": -10,
            "origin_slot": 3,
            "target_id": 93,
            "target_slot": 0,
            "type": "*"
          },
          {
            "id": 115,
            "origin_id": 83,
            "origin_slot": 0,
            "target_id": 94,
            "target_slot": 0,
            "type": "STRING"
          },
          {
            "id": 116,
            "origin_id": 92,
            "origin_slot": 0,
            "target_id": 94,
            "target_slot": 2,
            "type": "STRING"
          },
          {
            "id": 117,
            "origin_id": 94,
            "origin_slot": 0,
            "target_id": 95,
            "target_slot": 0,
            "type": "STRING"
          },
          {
            "id": 118,
            "origin_id": 93,
            "origin_slot": 0,
            "target_id": 95,
            "target_slot": 2,
            "type": "STRING"
          },
          {
            "id": 119,
            "origin_id": 95,
            "origin_slot": 0,
            "target_id": 74,
            "target_slot": 2,
            "type": "STRING"
          },
          {
            "id": 120,
            "origin_id": -10,
            "origin_slot": 9,
            "target_id": 91,
            "target_slot": 0,
            "type": "COMBO"
          },
          {
            "id": 121,
            "origin_id": -10,
            "origin_slot": 10,
            "target_id": 63,
            "target_slot": 0,
            "type": "COMBO"
          },
          {
            "id": 124,
            "origin_id": 75,
            "origin_slot": 0,
            "target_id": 97,
            "target_slot": 0,
            "type": "STRING"
          }
        ],
        "extra": {},
        "category": "Image generation and editing/Text to image",
        "description": "Generates images from text prompts using Baidu’s open ERNIE Image (~8B DiT): bilingual in-image typography and layouts (posters, infographics, multi-panel compositions) alongside general scenes, with bundled encoders and VAE."
      }
    ]
  },
  "extra": {
    "ue_links": []
  }
}
```
