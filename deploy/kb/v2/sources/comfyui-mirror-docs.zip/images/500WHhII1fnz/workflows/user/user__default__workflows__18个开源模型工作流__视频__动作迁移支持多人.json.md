# 动作迁移支持多人

- 来源类别：用户工作流
- 镜像内原始路径：`/ComfyUI/user/default/workflows/18个开源模型工作流/视频/动作迁移支持多人.json`
- 节点数量：46
- 连线数量：62

## 节点类型

- `INTConstant` × 4
- `ImageConcatMulti` × 3
- `VHS_VideoCombine` × 3
- `easy cleanGpuUsed` × 3
- `ImageResizeKJv2` × 2
- `SimpleMath+` × 2
- `CLIPVisionLoader` × 1
- `ConvertOpenPoseKeypointsToDWPose` × 1
- `DWPreprocessor` × 1
- `GetImageSizeAndCount` × 1
- `LayerUtility: PurgeVRAM V2` × 1
- `LayerUtility: TextBox` × 1
- `LoadImage` × 1
- `LoadNLFModel` × 1
- `LoadWanVideoT5TextEncoder` × 1
- `NLFPredict` × 1
- `OnnxDetectionModelLoader` × 1
- `PoseDetectionVitPoseToDWPose` × 1
- `RenderNLFPoses` × 1
- `VHS_LoadVideo` × 1
- `WanVideoAddSCAILPoseEmbeds` × 1
- `WanVideoAddSCAILReferenceEmbeds` × 1
- `WanVideoBlockSwap` × 1
- `WanVideoClipVisionEncode` × 1
- `WanVideoContextOptions` × 1
- `WanVideoDecode` × 1
- `WanVideoEmptyEmbeds` × 1
- `WanVideoLoraSelect` × 1
- `WanVideoModelLoader` × 1
- `WanVideoSamplerExtraArgs` × 1
- `WanVideoSamplerv2` × 1
- `WanVideoSchedulerv2` × 1
- `WanVideoTextEncode` × 1
- `WanVideoTorchCompileSettings` × 1
- `WanVideoVAELoader` × 1

## 工作流引用的模型或媒体文件

- `CAIL_00001-audio.mp4`
- `CAIL_2_fp16.safetensors`
- `Wan2_1_VAE_bf16.safetensors`
- `Wanimate_00008-audio.mp4`
- `cript.pt`
- `e-l-wholebody.onnx`
- `e_00001.mp4`
- `e_00001_p87_ytruu_1783314714.mp4`
- `ion_h.safetensors`
- `till_rank256_bf16.safetensors`
- `umt5-xxl-enc-bf16.safetensors`
- `yolov10m.onnx`

## 原始工作流 JSON

```json
{
  "id": "c6e410bc-5e2c-460b-ae81-c91b6094fbb1",
  "revision": 0,
  "last_node_id": 405,
  "last_link_id": 719,
  "nodes": [
    {
      "id": 400,
      "type": "INTConstant",
      "pos": [
        -2306.7547090624735,
        -3322.3653495698904
      ],
      "size": [
        210,
        58
      ],
      "flags": {
        "collapsed": false
      },
      "order": 0,
      "mode": 0,
      "inputs": [],
      "outputs": [
        {
          "name": "value",
          "type": "INT",
          "links": [
            709,
            710,
            711
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "INTConstant"
      },
      "widgets_values": [
        480
      ],
      "color": "#1b4669",
      "bgcolor": "#29699c"
    },
    {
      "id": 401,
      "type": "INTConstant",
      "pos": [
        -2305.575535099226,
        -3200.4864790422475
      ],
      "size": [
        210,
        58
      ],
      "flags": {
        "collapsed": false
      },
      "order": 1,
      "mode": 0,
      "inputs": [],
      "outputs": [
        {
          "name": "value",
          "type": "INT",
          "links": [
            712,
            713,
            714
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "INTConstant"
      },
      "widgets_values": [
        832
      ],
      "color": "#1b4669",
      "bgcolor": "#29699c"
    },
    {
      "id": 402,
      "type": "INTConstant",
      "pos": [
        -2308.871261965804,
        -3035.0920247715503
      ],
      "size": [
        210,
        58
      ],
      "flags": {
        "collapsed": false
      },
      "order": 2,
      "mode": 0,
      "inputs": [],
      "outputs": [
        {
          "name": "value",
          "type": "INT",
          "links": [
            715
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "INTConstant"
      },
      "widgets_values": [
        81
      ],
      "color": "#1b4669",
      "bgcolor": "#29699c"
    },
    {
      "id": 106,
      "type": "LoadImage",
      "pos": [
        -1744.3157516397048,
        -3376.6936934900555
      ],
      "size": [
        274.2650451660156,
        465.5579833984375
      ],
      "flags": {},
      "order": 3,
      "mode": 0,
      "inputs": [
        {
          "label": "image",
          "name": "image",
          "type": "COMBO",
          "widget": {
            "name": "image"
          }
        },
        {
          "label": "upload",
          "name": "upload",
          "type": "IMAGEUPLOAD",
          "widget": {
            "name": "upload"
          }
        }
      ],
      "outputs": [
        {
          "label": "IMAGE",
          "name": "IMAGE",
          "type": "IMAGE",
          "links": [
            564
          ]
        },
        {
          "label": "MASK",
          "name": "MASK",
          "type": "MASK"
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.76",
        "Node name for S&R": "LoadImage",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "ComfyUI_temp_pofoj_00040_.png",
        "image"
      ]
    },
    {
      "id": 404,
      "type": "LayerUtility: TextBox",
      "pos": [
        -1741.379970444486,
        -2856.7475746021596
      ],
      "size": [
        278.560019721087,
        114.10336685236575
      ],
      "flags": {},
      "order": 4,
      "mode": 0,
      "inputs": [],
      "outputs": [
        {
          "name": "text",
          "type": "STRING",
          "links": [
            718
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "LayerUtility: TextBox"
      },
      "widgets_values": [
        "画面中的人物在跳舞"
      ],
      "color": "rgba(38, 73, 116, 0.7)"
    },
    {
      "id": 35,
      "type": "WanVideoTorchCompileSettings",
      "pos": [
        -1249.5727615563308,
        -3379.504391764664
      ],
      "size": [
        323.49835205078125,
        257.5395202636719
      ],
      "flags": {},
      "order": 5,
      "mode": 0,
      "inputs": [
        {
          "label": "backend",
          "name": "backend",
          "type": "COMBO",
          "widget": {
            "name": "backend"
          }
        },
        {
          "label": "fullgraph",
          "name": "fullgraph",
          "type": "BOOLEAN",
          "widget": {
            "name": "fullgraph"
          }
        },
        {
          "label": "mode",
          "name": "mode",
          "type": "COMBO",
          "widget": {
            "name": "mode"
          }
        },
        {
          "label": "dynamic",
          "name": "dynamic",
          "type": "BOOLEAN",
          "widget": {
            "name": "dynamic"
          }
        },
        {
          "label": "dynamo_cache_size_limit",
          "name": "dynamo_cache_size_limit",
          "type": "INT",
          "widget": {
            "name": "dynamo_cache_size_limit"
          }
        },
        {
          "label": "compile_transformer_blocks_only",
          "name": "compile_transformer_blocks_only",
          "type": "BOOLEAN",
          "widget": {
            "name": "compile_transformer_blocks_only"
          }
        },
        {
          "label": "dynamo_recompile_limit",
          "name": "dynamo_recompile_limit",
          "shape": 7,
          "type": "INT",
          "widget": {
            "name": "dynamo_recompile_limit"
          }
        },
        {
          "label": "force_parameter_static_shapes",
          "name": "force_parameter_static_shapes",
          "shape": 7,
          "type": "BOOLEAN",
          "widget": {
            "name": "force_parameter_static_shapes"
          }
        },
        {
          "label": "allow_unmerged_lora_compile",
          "name": "allow_unmerged_lora_compile",
          "shape": 7,
          "type": "BOOLEAN",
          "widget": {
            "name": "allow_unmerged_lora_compile"
          }
        }
      ],
      "outputs": [
        {
          "label": "torch_compile_args",
          "name": "torch_compile_args",
          "type": "WANCOMPILEARGS",
          "slot_index": 0,
          "links": [
            563
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "WanVideoTorchCompileSettings",
        "cnr_id": "ComfyUI-WanVideoWrapper",
        "ver": "998a69cc0acbec503001b8b0ce0a5d5404420e1e",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "inductor",
        false,
        "default",
        false,
        64,
        true,
        128,
        false,
        false
      ]
    },
    {
      "id": 39,
      "type": "WanVideoBlockSwap",
      "pos": [
        -1242.8389992004093,
        -3072.843433907937
      ],
      "size": [
        315,
        202
      ],
      "flags": {},
      "order": 6,
      "mode": 0,
      "inputs": [
        {
          "label": "blocks_to_swap",
          "name": "blocks_to_swap",
          "type": "INT",
          "widget": {
            "name": "blocks_to_swap"
          }
        },
        {
          "label": "offload_img_emb",
          "name": "offload_img_emb",
          "type": "BOOLEAN",
          "widget": {
            "name": "offload_img_emb"
          }
        },
        {
          "label": "offload_txt_emb",
          "name": "offload_txt_emb",
          "type": "BOOLEAN",
          "widget": {
            "name": "offload_txt_emb"
          }
        },
        {
          "label": "use_non_blocking",
          "name": "use_non_blocking",
          "shape": 7,
          "type": "BOOLEAN",
          "widget": {
            "name": "use_non_blocking"
          }
        },
        {
          "label": "vace_blocks_to_swap",
          "name": "vace_blocks_to_swap",
          "shape": 7,
          "type": "INT",
          "widget": {
            "name": "vace_blocks_to_swap"
          }
        },
        {
          "label": "prefetch_blocks",
          "name": "prefetch_blocks",
          "shape": 7,
          "type": "INT",
          "widget": {
            "name": "prefetch_blocks"
          }
        },
        {
          "label": "block_swap_debug",
          "name": "block_swap_debug",
          "shape": 7,
          "type": "BOOLEAN",
          "widget": {
            "name": "block_swap_debug"
          }
        }
      ],
      "outputs": [
        {
          "label": "block_swap_args",
          "name": "block_swap_args",
          "type": "BLOCKSWAPARGS",
          "slot_index": 0,
          "links": [
            666
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "WanVideoBlockSwap",
        "cnr_id": "ComfyUI-WanVideoWrapper",
        "ver": "998a69cc0acbec503001b8b0ce0a5d5404420e1e",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        30,
        false,
        false,
        true,
        1,
        1,
        false
      ]
    },
    {
      "id": 56,
      "type": "WanVideoLoraSelect",
      "pos": [
        -1241.764408855472,
        -2823.5669643390547
      ],
      "size": [
        319.01435251413363,
        150
      ],
      "flags": {},
      "order": 7,
      "mode": 0,
      "inputs": [
        {
          "label": "prev_lora",
          "name": "prev_lora",
          "shape": 7,
          "type": "WANVIDLORA"
        },
        {
          "label": "blocks",
          "name": "blocks",
          "shape": 7,
          "type": "SELECTEDBLOCKS"
        },
        {
          "label": "lora",
          "name": "lora",
          "type": "COMBO",
          "widget": {
            "name": "lora"
          }
        },
        {
          "label": "strength",
          "name": "strength",
          "type": "FLOAT",
          "widget": {
            "name": "strength"
          }
        },
        {
          "label": "low_mem_load",
          "name": "low_mem_load",
          "shape": 7,
          "type": "BOOLEAN",
          "widget": {
            "name": "low_mem_load"
          }
        },
        {
          "label": "merge_loras",
          "name": "merge_loras",
          "shape": 7,
          "type": "BOOLEAN",
          "widget": {
            "name": "merge_loras"
          }
        }
      ],
      "outputs": [
        {
          "label": "lora",
          "name": "lora",
          "type": "WANVIDLORA",
          "links": [
            667
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "WanVideoLoraSelect",
        "cnr_id": "ComfyUI-WanVideoWrapper",
        "ver": "998a69cc0acbec503001b8b0ce0a5d5404420e1e",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "lightx2v/lightx2v_I2V_14B_480p_cfg_step_distill_rank256_bf16.safetensors",
        1,
        false,
        false
      ]
    },
    {
      "id": 38,
      "type": "WanVideoVAELoader",
      "pos": [
        -912.7820617531761,
        -2997.2344401242967
      ],
      "size": [
        478.6675806616772,
        124.02673454469596
      ],
      "flags": {},
      "order": 8,
      "mode": 0,
      "inputs": [
        {
          "label": "compile_args",
          "name": "compile_args",
          "shape": 7,
          "type": "WANCOMPILEARGS"
        },
        {
          "label": "model_name",
          "name": "model_name",
          "type": "COMBO",
          "widget": {
            "name": "model_name"
          }
        },
        {
          "label": "precision",
          "name": "precision",
          "shape": 7,
          "type": "COMBO",
          "widget": {
            "name": "precision"
          }
        },
        {
          "label": "use_cpu_cache",
          "name": "use_cpu_cache",
          "shape": 7,
          "type": "BOOLEAN",
          "widget": {
            "name": "use_cpu_cache"
          }
        }
      ],
      "outputs": [
        {
          "label": "vae",
          "name": "vae",
          "type": "WANVAE",
          "slot_index": 0,
          "links": [
            654,
            655,
            656
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "WanVideoVAELoader",
        "cnr_id": "ComfyUI-WanVideoWrapper",
        "ver": "998a69cc0acbec503001b8b0ce0a5d5404420e1e",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "Wan2_1_VAE_bf16.safetensors",
        "bf16",
        false
      ]
    },
    {
      "id": 11,
      "type": "LoadWanVideoT5TextEncoder",
      "pos": [
        -1237.7008072818412,
        -2628.6548575575807
      ],
      "size": [
        323.40682515925323,
        130
      ],
      "flags": {},
      "order": 9,
      "mode": 0,
      "inputs": [
        {
          "label": "model_name",
          "name": "model_name",
          "type": "COMBO",
          "widget": {
            "name": "model_name"
          }
        },
        {
          "label": "precision",
          "name": "precision",
          "type": "COMBO",
          "widget": {
            "name": "precision"
          }
        },
        {
          "label": "load_device",
          "name": "load_device",
          "shape": 7,
          "type": "COMBO",
          "widget": {
            "name": "load_device"
          }
        },
        {
          "label": "quantization",
          "name": "quantization",
          "shape": 7,
          "type": "COMBO",
          "widget": {
            "name": "quantization"
          }
        }
      ],
      "outputs": [
        {
          "label": "wan_t5_model",
          "name": "wan_t5_model",
          "type": "WANTEXTENCODER",
          "slot_index": 0,
          "links": [
            15
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "LoadWanVideoT5TextEncoder",
        "cnr_id": "ComfyUI-WanVideoWrapper",
        "ver": "998a69cc0acbec503001b8b0ce0a5d5404420e1e",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "umt5-xxl-enc-bf16.safetensors",
        "bf16",
        "offload_device",
        "disabled"
      ]
    },
    {
      "id": 16,
      "type": "WanVideoTextEncode",
      "pos": [
        -902.1073955599495,
        -2821.8020624923884
      ],
      "size": [
        474.3573303222656,
        316.48370361328125
      ],
      "flags": {},
      "order": 21,
      "mode": 0,
      "inputs": [
        {
          "label": "t5",
          "name": "t5",
          "shape": 7,
          "type": "WANTEXTENCODER",
          "link": 15
        },
        {
          "label": "model_to_offload",
          "name": "model_to_offload",
          "shape": 7,
          "type": "WANVIDEOMODEL"
        },
        {
          "label": "positive_prompt",
          "name": "positive_prompt",
          "type": "STRING",
          "widget": {
            "name": "positive_prompt"
          },
          "link": 718
        },
        {
          "label": "negative_prompt",
          "name": "negative_prompt",
          "type": "STRING",
          "widget": {
            "name": "negative_prompt"
          }
        },
        {
          "label": "force_offload",
          "name": "force_offload",
          "shape": 7,
          "type": "BOOLEAN",
          "widget": {
            "name": "force_offload"
          }
        },
        {
          "label": "use_disk_cache",
          "name": "use_disk_cache",
          "shape": 7,
          "type": "BOOLEAN",
          "widget": {
            "name": "use_disk_cache"
          }
        },
        {
          "label": "device",
          "name": "device",
          "shape": 7,
          "type": "COMBO",
          "widget": {
            "name": "device"
          }
        }
      ],
      "outputs": [
        {
          "label": "text_embeds",
          "name": "text_embeds",
          "type": "WANVIDEOTEXTEMBEDS",
          "slot_index": 0,
          "links": [
            658
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "WanVideoTextEncode",
        "cnr_id": "ComfyUI-WanVideoWrapper",
        "ver": "998a69cc0acbec503001b8b0ce0a5d5404420e1e",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "",
        "色调艳丽，过曝，静态，细节模糊不清，字幕，风格，作品，画作，画面，静止，整体发灰，最差质量，低质量，JPEG压缩残留，丑陋的，残缺的，多余的手指，画得不好的手部，画得不好的脸部，畸形的，毁容的，形态畸形的肢体，手指融合，静止不动的画面，杂乱的背景，三条腿，背景人很多，倒着走",
        true,
        true,
        "gpu"
      ]
    },
    {
      "id": 131,
      "type": "ImageResizeKJv2",
      "pos": [
        -1248.8830739385642,
        -2434.692717002471
      ],
      "size": [
        270,
        336
      ],
      "flags": {},
      "order": 23,
      "mode": 0,
      "inputs": [
        {
          "label": "image",
          "name": "image",
          "type": "IMAGE",
          "link": 234
        },
        {
          "label": "mask",
          "name": "mask",
          "shape": 7,
          "type": "MASK"
        },
        {
          "label": "width",
          "name": "width",
          "type": "INT",
          "widget": {
            "name": "width"
          },
          "link": 709
        },
        {
          "label": "height",
          "name": "height",
          "type": "INT",
          "widget": {
            "name": "height"
          },
          "link": 714
        },
        {
          "label": "upscale_method",
          "name": "upscale_method",
          "type": "COMBO",
          "widget": {
            "name": "upscale_method"
          }
        },
        {
          "label": "keep_proportion",
          "name": "keep_proportion",
          "type": "COMBO",
          "widget": {
            "name": "keep_proportion"
          }
        },
        {
          "label": "pad_color",
          "name": "pad_color",
          "type": "STRING",
          "widget": {
            "name": "pad_color"
          }
        },
        {
          "label": "crop_position",
          "name": "crop_position",
          "type": "COMBO",
          "widget": {
            "name": "crop_position"
          }
        },
        {
          "label": "divisible_by",
          "name": "divisible_by",
          "type": "INT",
          "widget": {
            "name": "divisible_by"
          }
        },
        {
          "label": "device",
          "name": "device",
          "shape": 7,
          "type": "COMBO",
          "widget": {
            "name": "device"
          }
        }
      ],
      "outputs": [
        {
          "label": "IMAGE",
          "name": "IMAGE",
          "type": "IMAGE",
          "links": [
            603,
            683
          ]
        },
        {
          "label": "width",
          "name": "width",
          "type": "INT",
          "links": []
        },
        {
          "label": "height",
          "name": "height",
          "type": "INT",
          "links": []
        },
        {
          "label": "mask",
          "name": "mask",
          "type": "MASK"
        }
      ],
      "properties": {
        "Node name for S&R": "ImageResizeKJv2",
        "cnr_id": "comfyui-kjnodes",
        "ver": "50e7dd34d3b6e6bbab1d41e8068e1ddd19bd4d1b",
        "widget_ue_connectable": {
          "width": true,
          "height": true
        }
      },
      "widgets_values": [
        512,
        896,
        "lanczos",
        "crop",
        "0, 0, 0",
        "center",
        16,
        "cpu"
      ]
    },
    {
      "id": 107,
      "type": "ImageResizeKJv2",
      "pos": [
        -1249.7131259176333,
        -2045.3079428878434
      ],
      "size": [
        270,
        336
      ],
      "flags": {},
      "order": 19,
      "mode": 0,
      "inputs": [
        {
          "label": "image",
          "name": "image",
          "type": "IMAGE",
          "link": 564
        },
        {
          "label": "mask",
          "name": "mask",
          "shape": 7,
          "type": "MASK"
        },
        {
          "label": "width",
          "name": "width",
          "type": "INT",
          "widget": {
            "name": "width"
          },
          "link": 711
        },
        {
          "label": "height",
          "name": "height",
          "type": "INT",
          "widget": {
            "name": "height"
          },
          "link": 713
        },
        {
          "label": "upscale_method",
          "name": "upscale_method",
          "type": "COMBO",
          "widget": {
            "name": "upscale_method"
          }
        },
        {
          "label": "keep_proportion",
          "name": "keep_proportion",
          "type": "COMBO",
          "widget": {
            "name": "keep_proportion"
          }
        },
        {
          "label": "pad_color",
          "name": "pad_color",
          "type": "STRING",
          "widget": {
            "name": "pad_color"
          }
        },
        {
          "label": "crop_position",
          "name": "crop_position",
          "type": "COMBO",
          "widget": {
            "name": "crop_position"
          }
        },
        {
          "label": "divisible_by",
          "name": "divisible_by",
          "type": "INT",
          "widget": {
            "name": "divisible_by"
          }
        },
        {
          "label": "device",
          "name": "device",
          "shape": 7,
          "type": "COMBO",
          "widget": {
            "name": "device"
          }
        }
      ],
      "outputs": [
        {
          "label": "IMAGE",
          "name": "IMAGE",
          "type": "IMAGE",
          "links": [
            630,
            649,
            650,
            651
          ]
        },
        {
          "label": "width",
          "name": "width",
          "type": "INT",
          "links": [
            647
          ]
        },
        {
          "label": "height",
          "name": "height",
          "type": "INT",
          "links": [
            648
          ]
        },
        {
          "label": "mask",
          "name": "mask",
          "type": "MASK"
        }
      ],
      "properties": {
        "Node name for S&R": "ImageResizeKJv2",
        "cnr_id": "comfyui-kjnodes",
        "ver": "50e7dd34d3b6e6bbab1d41e8068e1ddd19bd4d1b",
        "widget_ue_connectable": {
          "width": true,
          "height": true
        }
      },
      "widgets_values": [
        480,
        832,
        "lanczos",
        "crop",
        "255,255,255",
        "center",
        16,
        "cpu"
      ]
    },
    {
      "id": 380,
      "type": "DWPreprocessor",
      "pos": [
        -955.4017192048389,
        -2438.1709385500494
      ],
      "size": [
        294.72265625,
        222
      ],
      "flags": {},
      "order": 29,
      "mode": 0,
      "inputs": [
        {
          "label": "image",
          "name": "image",
          "type": "IMAGE",
          "link": 683
        },
        {
          "label": "detect_hand",
          "name": "detect_hand",
          "shape": 7,
          "type": "COMBO",
          "widget": {
            "name": "detect_hand"
          }
        },
        {
          "label": "detect_body",
          "name": "detect_body",
          "shape": 7,
          "type": "COMBO",
          "widget": {
            "name": "detect_body"
          }
        },
        {
          "label": "detect_face",
          "name": "detect_face",
          "shape": 7,
          "type": "COMBO",
          "widget": {
            "name": "detect_face"
          }
        },
        {
          "label": "resolution",
          "name": "resolution",
          "shape": 7,
          "type": "INT",
          "widget": {
            "name": "resolution"
          }
        },
        {
          "label": "bbox_detector",
          "name": "bbox_detector",
          "shape": 7,
          "type": "COMBO",
          "widget": {
            "name": "bbox_detector"
          }
        },
        {
          "label": "pose_estimator",
          "name": "pose_estimator",
          "shape": 7,
          "type": "COMBO",
          "widget": {
            "name": "pose_estimator"
          }
        },
        {
          "label": "scale_stick_for_xinsr_cn",
          "name": "scale_stick_for_xinsr_cn",
          "shape": 7,
          "type": "COMBO",
          "widget": {
            "name": "scale_stick_for_xinsr_cn"
          }
        }
      ],
      "outputs": [
        {
          "label": "IMAGE",
          "name": "IMAGE",
          "type": "IMAGE"
        },
        {
          "label": "POSE_KEYPOINT",
          "name": "POSE_KEYPOINT",
          "type": "POSE_KEYPOINT",
          "links": [
            708
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "DWPreprocessor",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "enable",
        "enable",
        "enable",
        512,
        "yolox_l.torchscript.pt",
        "dw-ll_ucoco_384_bs5.torchscript.pt",
        "disable"
      ]
    },
    {
      "id": 364,
      "type": "OnnxDetectionModelLoader",
      "pos": [
        -959.5022077727797,
        -2162.3506504750394
      ],
      "size": [
        304.0484313964844,
        106
      ],
      "flags": {},
      "order": 10,
      "mode": 0,
      "inputs": [
        {
          "label": "vitpose_model",
          "name": "vitpose_model",
          "type": "COMBO",
          "widget": {
            "name": "vitpose_model"
          }
        },
        {
          "label": "yolo_model",
          "name": "yolo_model",
          "type": "COMBO",
          "widget": {
            "name": "yolo_model"
          }
        },
        {
          "label": "onnx_device",
          "name": "onnx_device",
          "type": "COMBO",
          "widget": {
            "name": "onnx_device"
          }
        }
      ],
      "outputs": [
        {
          "label": "model",
          "name": "model",
          "type": "POSEMODEL",
          "links": [
            629
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "OnnxDetectionModelLoader",
        "cnr_id": "ComfyUI-WanAnimatePreprocess",
        "ver": "74f834b9ecec0e9f48535ab2ec95219f5288018a",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "vitpose-l-wholebody.onnx",
        "yolov10m.onnx",
        "CUDAExecutionProvider"
      ]
    },
    {
      "id": 326,
      "type": "CLIPVisionLoader",
      "pos": [
        -953.4479603160769,
        -2015.282544253861
      ],
      "size": [
        299.32312218025663,
        58
      ],
      "flags": {},
      "order": 11,
      "mode": 0,
      "inputs": [
        {
          "label": "clip_name",
          "name": "clip_name",
          "type": "COMBO",
          "widget": {
            "name": "clip_name"
          }
        }
      ],
      "outputs": [
        {
          "label": "CLIP_VISION",
          "name": "CLIP_VISION",
          "type": "CLIP_VISION",
          "links": [
            554
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.4.0",
        "Node name for S&R": "CLIPVisionLoader",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "clip_vision_h.safetensors"
      ]
    },
    {
      "id": 327,
      "type": "WanVideoClipVisionEncode",
      "pos": [
        -952.8522470084664,
        -1908.5493143978251
      ],
      "size": [
        297.2404320347264,
        262
      ],
      "flags": {},
      "order": 25,
      "mode": 0,
      "inputs": [
        {
          "label": "clip_vision",
          "name": "clip_vision",
          "type": "CLIP_VISION",
          "link": 554
        },
        {
          "label": "image_1",
          "name": "image_1",
          "type": "IMAGE",
          "link": 650
        },
        {
          "label": "image_2",
          "name": "image_2",
          "shape": 7,
          "type": "IMAGE"
        },
        {
          "label": "negative_image",
          "name": "negative_image",
          "shape": 7,
          "type": "IMAGE"
        },
        {
          "label": "strength_1",
          "name": "strength_1",
          "type": "FLOAT",
          "widget": {
            "name": "strength_1"
          }
        },
        {
          "label": "strength_2",
          "name": "strength_2",
          "type": "FLOAT",
          "widget": {
            "name": "strength_2"
          }
        },
        {
          "label": "crop",
          "name": "crop",
          "type": "COMBO",
          "widget": {
            "name": "crop"
          }
        },
        {
          "label": "combine_embeds",
          "name": "combine_embeds",
          "type": "COMBO",
          "widget": {
            "name": "combine_embeds"
          }
        },
        {
          "label": "force_offload",
          "name": "force_offload",
          "type": "BOOLEAN",
          "widget": {
            "name": "force_offload"
          }
        },
        {
          "label": "tiles",
          "name": "tiles",
          "shape": 7,
          "type": "INT",
          "widget": {
            "name": "tiles"
          }
        },
        {
          "label": "ratio",
          "name": "ratio",
          "shape": 7,
          "type": "FLOAT",
          "widget": {
            "name": "ratio"
          }
        }
      ],
      "outputs": [
        {
          "label": "image_embeds",
          "name": "image_embeds",
          "type": "WANVIDIMAGE_CLIPEMBEDS",
          "links": [
            607
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "WanVideoClipVisionEncode",
        "cnr_id": "ComfyUI-WanVideoWrapper",
        "ver": "4a3ab6958a5d9650eb4e3c2eb1753c2d7c5b77c6",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        1,
        1,
        "center",
        "average",
        true,
        0,
        0.5
      ]
    },
    {
      "id": 99,
      "type": "WanVideoEmptyEmbeds",
      "pos": [
        -641.9780015408928,
        -2108.2989573652835
      ],
      "size": [
        328.9061782248475,
        126
      ],
      "flags": {},
      "order": 26,
      "mode": 0,
      "inputs": [
        {
          "label": "control_embeds",
          "name": "control_embeds",
          "shape": 7,
          "type": "WANVIDIMAGE_EMBEDS"
        },
        {
          "label": "extra_latents",
          "name": "extra_latents",
          "shape": 7,
          "type": "LATENT"
        },
        {
          "label": "width",
          "name": "width",
          "type": "INT",
          "widget": {
            "name": "width"
          },
          "link": 647
        },
        {
          "label": "height",
          "name": "height",
          "type": "INT",
          "widget": {
            "name": "height"
          },
          "link": 648
        },
        {
          "label": "num_frames",
          "name": "num_frames",
          "type": "INT",
          "widget": {
            "name": "num_frames"
          },
          "link": 584
        }
      ],
      "outputs": [
        {
          "label": "image_embeds",
          "name": "image_embeds",
          "type": "WANVIDIMAGE_EMBEDS",
          "links": [
            604
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "WanVideoEmptyEmbeds",
        "cnr_id": "ComfyUI-WanVideoWrapper",
        "ver": "0f217be4d8742741b0f89db50138214302a58dc3",
        "widget_ue_connectable": {
          "width": true,
          "num_frames": true,
          "height": true
        }
      },
      "widgets_values": [
        480,
        1216,
        65
      ]
    },
    {
      "id": 350,
      "type": "WanVideoAddSCAILReferenceEmbeds",
      "pos": [
        -633.8211281163647,
        -1936.2744444880486
      ],
      "size": [
        323.443603515625,
        166
      ],
      "flags": {},
      "order": 30,
      "mode": 0,
      "inputs": [
        {
          "label": "embeds",
          "name": "embeds",
          "type": "WANVIDIMAGE_EMBEDS",
          "link": 604
        },
        {
          "label": "vae",
          "name": "vae",
          "type": "WANVAE",
          "link": 656
        },
        {
          "label": "ref_image",
          "name": "ref_image",
          "type": "IMAGE",
          "link": 649
        },
        {
          "label": "clip_embeds",
          "name": "clip_embeds",
          "shape": 7,
          "type": "WANVIDIMAGE_CLIPEMBEDS",
          "link": 607
        },
        {
          "label": "strength",
          "name": "strength",
          "type": "FLOAT",
          "widget": {
            "name": "strength"
          }
        },
        {
          "label": "start_percent",
          "name": "start_percent",
          "type": "FLOAT",
          "widget": {
            "name": "start_percent"
          }
        },
        {
          "label": "end_percent",
          "name": "end_percent",
          "type": "FLOAT",
          "widget": {
            "name": "end_percent"
          }
        }
      ],
      "outputs": [
        {
          "label": "image_embeds",
          "name": "image_embeds",
          "type": "WANVIDIMAGE_EMBEDS",
          "links": [
            608
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "WanVideoAddSCAILReferenceEmbeds",
        "cnr_id": "ComfyUI-WanVideoWrapper",
        "ver": "98f8e56bcacfc07e12cbb4b26555b2b28d9db92f",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        1,
        0,
        1
      ]
    },
    {
      "id": 324,
      "type": "WanVideoAddSCAILPoseEmbeds",
      "pos": [
        -637.3648202196016,
        -1729.5484402688674
      ],
      "size": [
        335.5962829589844,
        146
      ],
      "flags": {},
      "order": 36,
      "mode": 0,
      "inputs": [
        {
          "label": "embeds",
          "name": "embeds",
          "type": "WANVIDIMAGE_EMBEDS",
          "link": 608
        },
        {
          "label": "vae",
          "name": "vae",
          "type": "WANVAE",
          "link": 655
        },
        {
          "label": "pose_images",
          "name": "pose_images",
          "type": "IMAGE",
          "link": 693
        },
        {
          "label": "strength",
          "name": "strength",
          "type": "FLOAT",
          "widget": {
            "name": "strength"
          }
        },
        {
          "label": "start_percent",
          "name": "start_percent",
          "type": "FLOAT",
          "widget": {
            "name": "start_percent"
          }
        },
        {
          "label": "end_percent",
          "name": "end_percent",
          "type": "FLOAT",
          "widget": {
            "name": "end_percent"
          }
        }
      ],
      "outputs": [
        {
          "label": "image_embeds",
          "name": "image_embeds",
          "type": "WANVIDIMAGE_EMBEDS",
          "links": [
            700
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "WanVideoAddSCAILPoseEmbeds",
        "cnr_id": "ComfyUI-WanVideoWrapper",
        "ver": "4a3ab6958a5d9650eb4e3c2eb1753c2d7c5b77c6",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        1,
        0,
        1
      ]
    },
    {
      "id": 355,
      "type": "WanVideoContextOptions",
      "pos": [
        -1258.9177958441499,
        -1660.4296804176993
      ],
      "size": [
        286.8515625,
        202
      ],
      "flags": {},
      "order": 12,
      "mode": 0,
      "inputs": [
        {
          "label": "reference_latent",
          "name": "reference_latent",
          "shape": 7,
          "type": "LATENT"
        },
        {
          "label": "context_schedule",
          "name": "context_schedule",
          "type": "COMBO",
          "widget": {
            "name": "context_schedule"
          }
        },
        {
          "label": "context_frames",
          "name": "context_frames",
          "type": "INT",
          "widget": {
            "name": "context_frames"
          }
        },
        {
          "label": "context_stride",
          "name": "context_stride",
          "type": "INT",
          "widget": {
            "name": "context_stride"
          }
        },
        {
          "label": "context_overlap",
          "name": "context_overlap",
          "type": "INT",
          "widget": {
            "name": "context_overlap"
          }
        },
        {
          "label": "freenoise",
          "name": "freenoise",
          "type": "BOOLEAN",
          "widget": {
            "name": "freenoise"
          }
        },
        {
          "label": "verbose",
          "name": "verbose",
          "type": "BOOLEAN",
          "widget": {
            "name": "verbose"
          }
        },
        {
          "label": "fuse_method",
          "name": "fuse_method",
          "shape": 7,
          "type": "COMBO",
          "widget": {
            "name": "fuse_method"
          }
        }
      ],
      "outputs": [
        {
          "label": "context_options",
          "name": "context_options",
          "type": "WANVIDCONTEXT",
          "links": [
            614
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "WanVideoContextOptions",
        "cnr_id": "ComfyUI-WanVideoWrapper",
        "ver": "98f8e56bcacfc07e12cbb4b26555b2b28d9db92f",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "uniform_standard",
        81,
        4,
        48,
        true,
        false,
        "linear"
      ]
    },
    {
      "id": 354,
      "type": "WanVideoSamplerExtraArgs",
      "pos": [
        -963.2568741918733,
        -1599.679186149149
      ],
      "size": [
        314.0220642089844,
        262
      ],
      "flags": {},
      "order": 22,
      "mode": 0,
      "inputs": [
        {
          "label": "feta_args",
          "name": "feta_args",
          "shape": 7,
          "type": "FETAARGS"
        },
        {
          "label": "context_options",
          "name": "context_options",
          "shape": 7,
          "type": "WANVIDCONTEXT",
          "link": 614
        },
        {
          "label": "cache_args",
          "name": "cache_args",
          "shape": 7,
          "type": "CACHEARGS"
        },
        {
          "label": "slg_args",
          "name": "slg_args",
          "shape": 7,
          "type": "SLGARGS"
        },
        {
          "label": "loop_args",
          "name": "loop_args",
          "shape": 7,
          "type": "LOOPARGS"
        },
        {
          "label": "experimental_args",
          "name": "experimental_args",
          "shape": 7,
          "type": "EXPERIMENTALARGS"
        },
        {
          "label": "unianimate_poses",
          "name": "unianimate_poses",
          "shape": 7,
          "type": "UNIANIMATE_POSE"
        },
        {
          "label": "fantasytalking_embeds",
          "name": "fantasytalking_embeds",
          "shape": 7,
          "type": "FANTASYTALKING_EMBEDS"
        },
        {
          "label": "uni3c_embeds",
          "name": "uni3c_embeds",
          "shape": 7,
          "type": "UNI3C_EMBEDS",
          "link": null
        },
        {
          "label": "multitalk_embeds",
          "name": "multitalk_embeds",
          "shape": 7,
          "type": "MULTITALK_EMBEDS"
        },
        {
          "label": "riflex_freq_index",
          "name": "riflex_freq_index",
          "shape": 7,
          "type": "INT",
          "widget": {
            "name": "riflex_freq_index"
          }
        },
        {
          "label": "rope_function",
          "name": "rope_function",
          "shape": 7,
          "type": "COMBO",
          "widget": {
            "name": "rope_function"
          }
        }
      ],
      "outputs": [
        {
          "label": "extra_args",
          "name": "extra_args",
          "type": "WANVIDSAMPLEREXTRAARGS",
          "links": [
            696
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "WanVideoSamplerExtraArgs",
        "cnr_id": "ComfyUI-WanVideoWrapper",
        "ver": "98f8e56bcacfc07e12cbb4b26555b2b28d9db92f",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        0,
        "comfy"
      ]
    },
    {
      "id": 390,
      "type": "easy cleanGpuUsed",
      "pos": [
        -296.22458759721565,
        -1776.3529854317285
      ],
      "size": [
        157.38925170898438,
        26
      ],
      "flags": {},
      "order": 27,
      "mode": 0,
      "inputs": [
        {
          "label": "anything",
          "name": "anything",
          "type": "*",
          "link": 696
        }
      ],
      "outputs": [
        {
          "label": "output",
          "name": "output",
          "type": "*",
          "links": [
            695
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "easy cleanGpuUsed",
        "widget_ue_connectable": {}
      },
      "widgets_values": []
    },
    {
      "id": 349,
      "type": "WanVideoSchedulerv2",
      "pos": [
        -628.4976219924433,
        -1540.0245580179983
      ],
      "size": [
        324.675375311484,
        204
      ],
      "flags": {},
      "order": 13,
      "mode": 0,
      "inputs": [
        {
          "label": "sigmas",
          "name": "sigmas",
          "shape": 7,
          "type": "SIGMAS"
        },
        {
          "label": "scheduler",
          "name": "scheduler",
          "type": "COMBO",
          "widget": {
            "name": "scheduler"
          }
        },
        {
          "label": "steps",
          "name": "steps",
          "type": "INT",
          "widget": {
            "name": "steps"
          }
        },
        {
          "label": "shift",
          "name": "shift",
          "type": "FLOAT",
          "widget": {
            "name": "shift"
          }
        },
        {
          "label": "start_step",
          "name": "start_step",
          "type": "INT",
          "widget": {
            "name": "start_step"
          }
        },
        {
          "label": "end_step",
          "name": "end_step",
          "type": "INT",
          "widget": {
            "name": "end_step"
          }
        }
      ],
      "outputs": [
        {
          "label": "scheduler",
          "name": "scheduler",
          "type": "WANVIDEOSCHEDULER",
          "links": [
            598
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "WanVideoSchedulerv2",
        "cnr_id": "ComfyUI-WanVideoWrapper",
        "ver": "98f8e56bcacfc07e12cbb4b26555b2b28d9db92f",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "dpm++_sde",
        6,
        7,
        0,
        -1
      ]
    },
    {
      "id": 389,
      "type": "easy cleanGpuUsed",
      "pos": [
        -297.0433902679501,
        -1928.0802279316176
      ],
      "size": [
        157.38925170898438,
        26
      ],
      "flags": {},
      "order": 33,
      "mode": 0,
      "inputs": [
        {
          "label": "anything",
          "name": "anything",
          "type": "*",
          "link": 694
        }
      ],
      "outputs": [
        {
          "label": "output",
          "name": "output",
          "type": "*",
          "links": [
            691,
            692,
            693
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "easy cleanGpuUsed",
        "widget_ue_connectable": {}
      },
      "widgets_values": []
    },
    {
      "id": 393,
      "type": "easy cleanGpuUsed",
      "pos": [
        -294.6451841574238,
        -1850.0942853421798
      ],
      "size": [
        157.38925170898438,
        26
      ],
      "flags": {},
      "order": 38,
      "mode": 0,
      "inputs": [
        {
          "label": "anything",
          "name": "anything",
          "type": "*",
          "link": 700
        }
      ],
      "outputs": [
        {
          "label": "output",
          "name": "output",
          "type": "*",
          "links": [
            701
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "easy cleanGpuUsed",
        "widget_ue_connectable": {}
      },
      "widgets_values": []
    },
    {
      "id": 348,
      "type": "WanVideoSamplerv2",
      "pos": [
        -294.0871800588931,
        -1707.2691434429116
      ],
      "size": [
        305.48956456825,
        267.5626421462489
      ],
      "flags": {},
      "order": 39,
      "mode": 0,
      "inputs": [
        {
          "label": "model",
          "name": "model",
          "type": "WANVIDEOMODEL",
          "link": 669
        },
        {
          "label": "image_embeds",
          "name": "image_embeds",
          "type": "WANVIDIMAGE_EMBEDS",
          "link": 701
        },
        {
          "label": "scheduler",
          "name": "scheduler",
          "type": "WANVIDEOSCHEDULER",
          "link": 598
        },
        {
          "label": "text_embeds",
          "name": "text_embeds",
          "shape": 7,
          "type": "WANVIDEOTEXTEMBEDS",
          "link": 658
        },
        {
          "label": "samples",
          "name": "samples",
          "shape": 7,
          "type": "LATENT"
        },
        {
          "label": "extra_args",
          "name": "extra_args",
          "shape": 7,
          "type": "WANVIDSAMPLEREXTRAARGS",
          "link": 695
        },
        {
          "label": "cfg",
          "name": "cfg",
          "type": "FLOAT",
          "widget": {
            "name": "cfg"
          }
        },
        {
          "label": "seed",
          "name": "seed",
          "type": "INT",
          "widget": {
            "name": "seed"
          }
        },
        {
          "label": "force_offload",
          "name": "force_offload",
          "type": "BOOLEAN",
          "widget": {
            "name": "force_offload"
          }
        },
        {
          "label": "add_noise_to_samples",
          "name": "add_noise_to_samples",
          "shape": 7,
          "type": "BOOLEAN",
          "widget": {
            "name": "add_noise_to_samples"
          }
        }
      ],
      "outputs": [
        {
          "label": "samples",
          "name": "samples",
          "type": "LATENT",
          "links": [
            596
          ]
        },
        {
          "label": "denoised_samples",
          "name": "denoised_samples",
          "type": "LATENT"
        }
      ],
      "properties": {
        "Node name for S&R": "WanVideoSamplerv2",
        "cnr_id": "ComfyUI-WanVideoWrapper",
        "ver": "98f8e56bcacfc07e12cbb4b26555b2b28d9db92f",
        "widget_ue_connectable": {
          "cfg": true
        }
      },
      "widgets_values": [
        1.0000000000000002,
        42,
        "fixed",
        true,
        false
      ]
    },
    {
      "id": 28,
      "type": "WanVideoDecode",
      "pos": [
        -287.4829074386592,
        -1390.3953847398252
      ],
      "size": [
        315,
        198
      ],
      "flags": {},
      "order": 40,
      "mode": 0,
      "inputs": [
        {
          "label": "vae",
          "name": "vae",
          "type": "WANVAE",
          "link": 654
        },
        {
          "label": "samples",
          "name": "samples",
          "type": "LATENT",
          "link": 596
        },
        {
          "label": "enable_vae_tiling",
          "name": "enable_vae_tiling",
          "type": "BOOLEAN",
          "widget": {
            "name": "enable_vae_tiling"
          }
        },
        {
          "label": "tile_x",
          "name": "tile_x",
          "type": "INT",
          "widget": {
            "name": "tile_x"
          }
        },
        {
          "label": "tile_y",
          "name": "tile_y",
          "type": "INT",
          "widget": {
            "name": "tile_y"
          }
        },
        {
          "label": "tile_stride_x",
          "name": "tile_stride_x",
          "type": "INT",
          "widget": {
            "name": "tile_stride_x"
          }
        },
        {
          "label": "tile_stride_y",
          "name": "tile_stride_y",
          "type": "INT",
          "widget": {
            "name": "tile_stride_y"
          }
        },
        {
          "label": "normalization",
          "name": "normalization",
          "shape": 7,
          "type": "COMBO",
          "widget": {
            "name": "normalization"
          }
        }
      ],
      "outputs": [
        {
          "label": "images",
          "name": "images",
          "type": "IMAGE",
          "slot_index": 0,
          "links": [
            675
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "WanVideoDecode",
        "cnr_id": "ComfyUI-WanVideoWrapper",
        "ver": "998a69cc0acbec503001b8b0ce0a5d5404420e1e",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        false,
        272,
        272,
        144,
        128,
        "default"
      ]
    },
    {
      "id": 378,
      "type": "LayerUtility: PurgeVRAM V2",
      "pos": [
        46.74444551128764,
        -1390.219719784985
      ],
      "size": [
        279.6304626464844,
        82
      ],
      "flags": {},
      "order": 41,
      "mode": 0,
      "inputs": [
        {
          "label": "anything",
          "name": "anything",
          "type": "*",
          "link": 675
        },
        {
          "label": "purge_cache",
          "name": "purge_cache",
          "type": "BOOLEAN",
          "widget": {
            "name": "purge_cache"
          }
        },
        {
          "label": "purge_models",
          "name": "purge_models",
          "type": "BOOLEAN",
          "widget": {
            "name": "purge_models"
          }
        }
      ],
      "outputs": [
        {
          "label": "any",
          "name": "any",
          "type": "*",
          "links": [
            676
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "LayerUtility: PurgeVRAM V2",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        true,
        true
      ],
      "color": "rgba(38, 73, 116, 0.7)"
    },
    {
      "id": 323,
      "type": "GetImageSizeAndCount",
      "pos": [
        337.1553807646825,
        -1402.380144103501
      ],
      "size": [
        196.2994140625,
        86
      ],
      "flags": {},
      "order": 42,
      "mode": 0,
      "inputs": [
        {
          "label": "image",
          "name": "image",
          "type": "IMAGE",
          "link": 676
        }
      ],
      "outputs": [
        {
          "label": "image",
          "name": "image",
          "type": "IMAGE",
          "links": [
            544,
            546
          ]
        },
        {
          "label": "480 width",
          "name": "width",
          "type": "INT"
        },
        {
          "label": "832 height",
          "name": "height",
          "type": "INT"
        },
        {
          "label": "81 count",
          "name": "count",
          "type": "INT"
        }
      ],
      "properties": {
        "Node name for S&R": "GetImageSizeAndCount",
        "cnr_id": "comfyui-kjnodes",
        "ver": "ff7f876c09ff5a53be051073c3c1731b96ee31a3",
        "widget_ue_connectable": {}
      },
      "widgets_values": []
    },
    {
      "id": 328,
      "type": "ImageConcatMulti",
      "pos": [
        49.458036151900664,
        -1596.8838375074733
      ],
      "size": [
        270,
        150
      ],
      "flags": {},
      "order": 35,
      "mode": 0,
      "inputs": [
        {
          "label": "image_1",
          "name": "image_1",
          "type": "IMAGE",
          "link": 651
        },
        {
          "label": "image_2",
          "name": "image_2",
          "shape": 7,
          "type": "IMAGE",
          "link": 692
        },
        {
          "label": "inputcount",
          "name": "inputcount",
          "type": "INT",
          "widget": {
            "name": "inputcount"
          }
        },
        {
          "label": "direction",
          "name": "direction",
          "type": "COMBO",
          "widget": {
            "name": "direction"
          }
        },
        {
          "label": "match_image_size",
          "name": "match_image_size",
          "type": "BOOLEAN",
          "widget": {
            "name": "match_image_size"
          }
        }
      ],
      "outputs": [
        {
          "label": "output",
          "name": "images",
          "type": "IMAGE",
          "links": [
            678
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "ImageConcatMulti",
        "cnr_id": "comfyui-kjnodes",
        "ver": "ff7f876c09ff5a53be051073c3c1731b96ee31a3",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        2,
        "down",
        true,
        null
      ]
    },
    {
      "id": 379,
      "type": "ImageConcatMulti",
      "pos": [
        331.6249815962236,
        -1596.7119615088186
      ],
      "size": [
        270,
        150
      ],
      "flags": {},
      "order": 37,
      "mode": 0,
      "inputs": [
        {
          "label": "image_1",
          "name": "image_1",
          "type": "IMAGE",
          "link": 680
        },
        {
          "label": "image_2",
          "name": "image_2",
          "shape": 7,
          "type": "IMAGE",
          "link": 678
        },
        {
          "label": "inputcount",
          "name": "inputcount",
          "type": "INT",
          "widget": {
            "name": "inputcount"
          }
        },
        {
          "label": "direction",
          "name": "direction",
          "type": "COMBO",
          "widget": {
            "name": "direction"
          }
        },
        {
          "label": "match_image_size",
          "name": "match_image_size",
          "type": "BOOLEAN",
          "widget": {
            "name": "match_image_size"
          }
        }
      ],
      "outputs": [
        {
          "label": "output",
          "name": "images",
          "type": "IMAGE",
          "links": [
            679
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "ImageConcatMulti",
        "cnr_id": "comfyui-kjnodes",
        "ver": "ff7f876c09ff5a53be051073c3c1731b96ee31a3",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        2,
        "down",
        true,
        null
      ]
    },
    {
      "id": 318,
      "type": "ImageConcatMulti",
      "pos": [
        41.725120768001425,
        -1788.7446759857137
      ],
      "size": [
        270,
        150
      ],
      "flags": {},
      "order": 44,
      "mode": 0,
      "inputs": [
        {
          "label": "image_1",
          "name": "image_1",
          "type": "IMAGE",
          "link": 546
        },
        {
          "label": "image_2",
          "name": "image_2",
          "shape": 7,
          "type": "IMAGE",
          "link": 679
        },
        {
          "label": "inputcount",
          "name": "inputcount",
          "type": "INT",
          "widget": {
            "name": "inputcount"
          }
        },
        {
          "label": "direction",
          "name": "direction",
          "type": "COMBO",
          "widget": {
            "name": "direction"
          }
        },
        {
          "label": "match_image_size",
          "name": "match_image_size",
          "type": "BOOLEAN",
          "widget": {
            "name": "match_image_size"
          }
        }
      ],
      "outputs": [
        {
          "label": "output",
          "name": "images",
          "type": "IMAGE",
          "links": [
            533
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "ImageConcatMulti",
        "cnr_id": "comfyui-kjnodes",
        "ver": "ff7f876c09ff5a53be051073c3c1731b96ee31a3",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        2,
        "left",
        true,
        null
      ]
    },
    {
      "id": 137,
      "type": "VHS_VideoCombine",
      "pos": [
        710,
        -3430
      ],
      "size": [
        287.28399658203125,
        811.2922607421875
      ],
      "flags": {},
      "order": 34,
      "mode": 0,
      "inputs": [
        {
          "label": "images",
          "name": "images",
          "type": "IMAGE",
          "link": 691
        },
        {
          "label": "audio",
          "name": "audio",
          "shape": 7,
          "type": "AUDIO"
        },
        {
          "label": "meta_batch",
          "name": "meta_batch",
          "shape": 7,
          "type": "VHS_BatchManager"
        },
        {
          "label": "vae",
          "name": "vae",
          "shape": 7,
          "type": "VAE"
        },
        {
          "label": "frame_rate",
          "name": "frame_rate",
          "type": "FLOAT",
          "widget": {
            "name": "frame_rate"
          }
        },
        {
          "label": "loop_count",
          "name": "loop_count",
          "type": "INT",
          "widget": {
            "name": "loop_count"
          }
        },
        {
          "label": "filename_prefix",
          "name": "filename_prefix",
          "type": "STRING",
          "widget": {
            "name": "filename_prefix"
          }
        },
        {
          "label": "format",
          "name": "format",
          "type": "COMBO",
          "widget": {
            "name": "format"
          }
        },
        {
          "label": "pingpong",
          "name": "pingpong",
          "type": "BOOLEAN",
          "widget": {
            "name": "pingpong"
          }
        },
        {
          "label": "save_output",
          "name": "save_output",
          "type": "BOOLEAN",
          "widget": {
            "name": "save_output"
          }
        }
      ],
      "outputs": [
        {
          "label": "Filenames",
          "name": "Filenames",
          "type": "VHS_FILENAMES"
        }
      ],
      "properties": {
        "Node name for S&R": "VHS_VideoCombine",
        "cnr_id": "comfyui-videohelpersuite",
        "ver": "0a75c7958fe320efcb052f1d9f8451fd20c730a8",
        "widget_ue_connectable": {}
      },
      "widgets_values": {
        "frame_rate": 16,
        "loop_count": 0,
        "filename_prefix": "onetotall_pose",
        "format": "video/h264-mp4",
        "pix_fmt": "yuv420p",
        "crf": 19,
        "save_metadata": true,
        "trim_to_audio": false,
        "pingpong": false,
        "save_output": false,
        "videopreview": {
          "paused": false,
          "hidden": false,
          "params": {
            "score": "0",
            "filename": "onetotall_pose_00001.mp4",
            "workflow": "onetotall_pose_00001.png",
            "fullpath": "/ComfyUI/temp/onetotall_pose_00001.mp4",
            "format": "video/h264-mp4",
            "subfolder": "",
            "label": "Normal",
            "type": "temp",
            "frame_rate": 16,
            "cos_url": "https://rh-images.xiaoyaoyou.com//4a08c15e8c4bf5a2de977f41abfd360c/temp/onetotall_pose_00001_p87_ytruu_1783314714.mp4"
          }
        }
      }
    },
    {
      "id": 139,
      "type": "VHS_VideoCombine",
      "pos": [
        1020,
        -3430
      ],
      "size": [
        434.2347106933594,
        1066.0068318684896
      ],
      "flags": {},
      "order": 43,
      "mode": 0,
      "inputs": [
        {
          "label": "images",
          "name": "images",
          "type": "IMAGE",
          "link": 544
        },
        {
          "label": "audio",
          "name": "audio",
          "shape": 7,
          "type": "AUDIO",
          "link": 639
        },
        {
          "label": "meta_batch",
          "name": "meta_batch",
          "shape": 7,
          "type": "VHS_BatchManager"
        },
        {
          "label": "vae",
          "name": "vae",
          "shape": 7,
          "type": "VAE"
        },
        {
          "label": "frame_rate",
          "name": "frame_rate",
          "type": "FLOAT",
          "widget": {
            "name": "frame_rate"
          }
        },
        {
          "label": "loop_count",
          "name": "loop_count",
          "type": "INT",
          "widget": {
            "name": "loop_count"
          }
        },
        {
          "label": "filename_prefix",
          "name": "filename_prefix",
          "type": "STRING",
          "widget": {
            "name": "filename_prefix"
          }
        },
        {
          "label": "format",
          "name": "format",
          "type": "COMBO",
          "widget": {
            "name": "format"
          }
        },
        {
          "label": "pingpong",
          "name": "pingpong",
          "type": "BOOLEAN",
          "widget": {
            "name": "pingpong"
          }
        },
        {
          "label": "save_output",
          "name": "save_output",
          "type": "BOOLEAN",
          "widget": {
            "name": "save_output"
          }
        }
      ],
      "outputs": [
        {
          "label": "Filenames",
          "name": "Filenames",
          "type": "VHS_FILENAMES"
        }
      ],
      "properties": {
        "Node name for S&R": "VHS_VideoCombine",
        "cnr_id": "comfyui-videohelpersuite",
        "ver": "0a75c7958fe320efcb052f1d9f8451fd20c730a8",
        "widget_ue_connectable": {}
      },
      "widgets_values": {
        "frame_rate": 16,
        "loop_count": 0,
        "filename_prefix": "WanVideo_SCAIL",
        "format": "video/h264-mp4",
        "pix_fmt": "yuv420p",
        "crf": 19,
        "save_metadata": true,
        "trim_to_audio": false,
        "pingpong": false,
        "save_output": true,
        "videopreview": {
          "paused": false,
          "hidden": false,
          "params": {
            "score": "0",
            "filename": "WanVideo_SCAIL_00001-audio.mp4",
            "workflow": "WanVideo_SCAIL_00001.png",
            "fullpath": "/ComfyUI/output/WanVideo_SCAIL_00001-audio.mp4",
            "format": "video/h264-mp4",
            "subfolder": "",
            "label": "Normal",
            "type": "output",
            "frame_rate": 16
          }
        }
      }
    },
    {
      "id": 130,
      "type": "VHS_LoadVideo",
      "pos": [
        -2039.7625289834564,
        -3364.4849532556805
      ],
      "size": [
        266.795654296875,
        762.5253411035751
      ],
      "flags": {},
      "order": 18,
      "mode": 0,
      "inputs": [
        {
          "label": "meta_batch",
          "name": "meta_batch",
          "shape": 7,
          "type": "VHS_BatchManager"
        },
        {
          "label": "vae",
          "name": "vae",
          "shape": 7,
          "type": "VAE"
        },
        {
          "label": "video",
          "name": "video",
          "type": "COMBO",
          "widget": {
            "name": "video"
          }
        },
        {
          "label": "force_rate",
          "name": "force_rate",
          "type": "FLOAT",
          "widget": {
            "name": "force_rate"
          }
        },
        {
          "label": "custom_width",
          "name": "custom_width",
          "type": "INT",
          "widget": {
            "name": "custom_width"
          }
        },
        {
          "label": "custom_height",
          "name": "custom_height",
          "type": "INT",
          "widget": {
            "name": "custom_height"
          }
        },
        {
          "label": "frame_load_cap",
          "name": "frame_load_cap",
          "type": "INT",
          "widget": {
            "name": "frame_load_cap"
          },
          "link": 715
        },
        {
          "label": "skip_first_frames",
          "name": "skip_first_frames",
          "type": "INT",
          "widget": {
            "name": "skip_first_frames"
          }
        },
        {
          "label": "select_every_nth",
          "name": "select_every_nth",
          "type": "INT",
          "widget": {
            "name": "select_every_nth"
          }
        },
        {
          "label": "format",
          "name": "format",
          "shape": 7,
          "type": "COMBO",
          "widget": {
            "name": "format"
          }
        }
      ],
      "outputs": [
        {
          "label": "IMAGE",
          "name": "IMAGE",
          "type": "IMAGE",
          "links": [
            234,
            680
          ]
        },
        {
          "label": "frame_count",
          "name": "frame_count",
          "type": "INT",
          "links": [
            584
          ]
        },
        {
          "label": "audio",
          "name": "audio",
          "type": "AUDIO",
          "links": [
            639,
            640
          ]
        },
        {
          "label": "video_info",
          "name": "video_info",
          "type": "VHS_VIDEOINFO"
        }
      ],
      "properties": {
        "Node name for S&R": "VHS_LoadVideo",
        "cnr_id": "comfyui-videohelpersuite",
        "ver": "8550981384301e9bc5bfea83e5c2c75258102593",
        "widget_ue_connectable": {}
      },
      "widgets_values": {
        "video": "Wanimate_00008-audio.mp4",
        "force_rate": 16,
        "custom_width": 0,
        "custom_height": 0,
        "frame_load_cap": 81,
        "skip_first_frames": 0,
        "select_every_nth": 1,
        "format": "AnimateDiff",
        "videopreview": {
          "paused": false,
          "hidden": false,
          "params": {
            "custom_height": 0,
            "filename": "Wanimate_00008-audio.mp4",
            "force_rate": 16,
            "custom_width": 0,
            "select_every_nth": 1,
            "frame_load_cap": 81,
            "format": "video/mp4",
            "skip_first_frames": 0,
            "type": "input"
          }
        }
      }
    },
    {
      "id": 319,
      "type": "VHS_VideoCombine",
      "pos": [
        1470,
        -3430
      ],
      "size": [
        926.5979614257812,
        1530.2719496963166
      ],
      "flags": {},
      "order": 45,
      "mode": 0,
      "inputs": [
        {
          "label": "images",
          "name": "images",
          "type": "IMAGE",
          "link": 533
        },
        {
          "label": "audio",
          "name": "audio",
          "shape": 7,
          "type": "AUDIO",
          "link": 640
        },
        {
          "label": "meta_batch",
          "name": "meta_batch",
          "shape": 7,
          "type": "VHS_BatchManager"
        },
        {
          "label": "vae",
          "name": "vae",
          "shape": 7,
          "type": "VAE"
        },
        {
          "label": "frame_rate",
          "name": "frame_rate",
          "type": "FLOAT",
          "widget": {
            "name": "frame_rate"
          }
        },
        {
          "label": "loop_count",
          "name": "loop_count",
          "type": "INT",
          "widget": {
            "name": "loop_count"
          }
        },
        {
          "label": "filename_prefix",
          "name": "filename_prefix",
          "type": "STRING",
          "widget": {
            "name": "filename_prefix"
          }
        },
        {
          "label": "format",
          "name": "format",
          "type": "COMBO",
          "widget": {
            "name": "format"
          }
        },
        {
          "label": "pingpong",
          "name": "pingpong",
          "type": "BOOLEAN",
          "widget": {
            "name": "pingpong"
          }
        },
        {
          "label": "save_output",
          "name": "save_output",
          "type": "BOOLEAN",
          "widget": {
            "name": "save_output"
          }
        }
      ],
      "outputs": [
        {
          "label": "Filenames",
          "name": "Filenames",
          "type": "VHS_FILENAMES"
        }
      ],
      "properties": {
        "Node name for S&R": "VHS_VideoCombine",
        "cnr_id": "comfyui-videohelpersuite",
        "ver": "0a75c7958fe320efcb052f1d9f8451fd20c730a8",
        "widget_ue_connectable": {}
      },
      "widgets_values": {
        "frame_rate": 16,
        "loop_count": 0,
        "filename_prefix": "WanVideo_SCAIL",
        "format": "video/h264-mp4",
        "pix_fmt": "yuv420p",
        "crf": 19,
        "save_metadata": true,
        "trim_to_audio": false,
        "pingpong": false,
        "save_output": false,
        "videopreview": {
          "paused": false,
          "hidden": false,
          "params": {
            "score": "0",
            "filename": "WanVideo_SCAIL_00001-audio.mp4",
            "workflow": "WanVideo_SCAIL_00001.png",
            "fullpath": "/ComfyUI/temp/WanVideo_SCAIL_00001-audio.mp4",
            "format": "video/h264-mp4",
            "subfolder": "",
            "label": "Normal",
            "type": "temp",
            "frame_rate": 16
          }
        }
      }
    },
    {
      "id": 334,
      "type": "NLFPredict",
      "pos": [
        -304.928622136622,
        -2344.8305680515296
      ],
      "size": [
        210,
        78
      ],
      "flags": {},
      "order": 28,
      "mode": 0,
      "inputs": [
        {
          "label": "model",
          "name": "model",
          "type": "NLFMODEL",
          "link": 719
        },
        {
          "label": "images",
          "name": "images",
          "type": "IMAGE",
          "link": 603
        },
        {
          "label": "per_batch",
          "name": "per_batch",
          "shape": 7,
          "type": "INT",
          "widget": {
            "name": "per_batch"
          }
        }
      ],
      "outputs": [
        {
          "label": "pose_results",
          "name": "pose_results",
          "type": "NLFPRED",
          "links": [
            621
          ]
        },
        {
          "label": "bboxes",
          "name": "bboxes",
          "type": "BBOX"
        }
      ],
      "properties": {
        "Node name for S&R": "NLFPredict",
        "cnr_id": "ComfyUI-WanVideoWrapper",
        "ver": "4a3ab6958a5d9650eb4e3c2eb1753c2d7c5b77c6",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        -1
      ]
    },
    {
      "id": 405,
      "type": "LoadNLFModel",
      "pos": [
        -642.954038615448,
        -2438.1538620199008
      ],
      "size": [
        323.4083904690697,
        82.74179508565385
      ],
      "flags": {},
      "order": 14,
      "mode": 0,
      "inputs": [],
      "outputs": [
        {
          "name": "nlf_model",
          "type": "NLFMODEL",
          "links": [
            719
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "LoadNLFModel"
      },
      "widgets_values": [
        "nlf_l_multi_0.3.2.torchscript",
        true
      ]
    },
    {
      "id": 340,
      "type": "SimpleMath+",
      "pos": [
        -78.68243912398567,
        -2385.7415277892856
      ],
      "size": [
        270,
        98
      ],
      "flags": {
        "collapsed": false
      },
      "order": 17,
      "mode": 0,
      "inputs": [
        {
          "label": "a",
          "name": "a",
          "shape": 7,
          "type": "*",
          "link": 712
        },
        {
          "label": "b",
          "name": "b",
          "shape": 7,
          "type": "*"
        },
        {
          "label": "c",
          "name": "c",
          "shape": 7,
          "type": "*"
        },
        {
          "label": "value",
          "name": "value",
          "type": "STRING",
          "widget": {
            "name": "value"
          }
        }
      ],
      "outputs": [
        {
          "label": "INT",
          "name": "INT",
          "type": "INT",
          "links": [
            625
          ]
        },
        {
          "label": "FLOAT",
          "name": "FLOAT",
          "type": "FLOAT"
        }
      ],
      "properties": {
        "aux_id": "kijai/ComfyUI_essentials",
        "Node name for S&R": "SimpleMath+",
        "ver": "76e9d1e4399bd025ce8b12c290753d58f9f53e93",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "a / 2"
      ]
    },
    {
      "id": 339,
      "type": "SimpleMath+",
      "pos": [
        -301.728248093688,
        -2532.603672788629
      ],
      "size": [
        270,
        98
      ],
      "flags": {
        "collapsed": false
      },
      "order": 16,
      "mode": 0,
      "inputs": [
        {
          "label": "a",
          "name": "a",
          "shape": 7,
          "type": "*",
          "link": 710
        },
        {
          "label": "b",
          "name": "b",
          "shape": 7,
          "type": "*"
        },
        {
          "label": "c",
          "name": "c",
          "shape": 7,
          "type": "*"
        },
        {
          "label": "value",
          "name": "value",
          "type": "STRING",
          "widget": {
            "name": "value"
          }
        }
      ],
      "outputs": [
        {
          "label": "INT",
          "name": "INT",
          "type": "INT",
          "links": [
            624
          ]
        },
        {
          "label": "FLOAT",
          "name": "FLOAT",
          "type": "FLOAT"
        }
      ],
      "properties": {
        "aux_id": "kijai/ComfyUI_essentials",
        "Node name for S&R": "SimpleMath+",
        "ver": "76e9d1e4399bd025ce8b12c290753d58f9f53e93",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "a / 2"
      ]
    },
    {
      "id": 365,
      "type": "PoseDetectionVitPoseToDWPose",
      "pos": [
        -642.0821446501914,
        -2200.046081426546
      ],
      "size": [
        328.43424711539626,
        48.171985166762624
      ],
      "flags": {},
      "order": 24,
      "mode": 0,
      "inputs": [
        {
          "label": "vitpose_model",
          "name": "vitpose_model",
          "type": "POSEMODEL",
          "link": 629
        },
        {
          "label": "images",
          "name": "images",
          "type": "IMAGE",
          "link": 630
        }
      ],
      "outputs": [
        {
          "label": "dw_poses",
          "name": "dw_poses",
          "type": "DWPOSES",
          "links": [
            633
          ]
        }
      ],
      "properties": {
        "aux_id": "kijai/ComfyUI-SCAIL-Pose",
        "Node name for S&R": "PoseDetectionVitPoseToDWPose",
        "ver": "93059f0fe4ea3881c0d6ec0e327e5d920554277d",
        "widget_ue_connectable": {}
      },
      "widgets_values": []
    },
    {
      "id": 362,
      "type": "RenderNLFPoses",
      "pos": [
        -300.6420545690292,
        -2217.5142980431688
      ],
      "size": [
        270,
        242
      ],
      "flags": {},
      "order": 32,
      "mode": 0,
      "inputs": [
        {
          "label": "nlf_poses",
          "name": "nlf_poses",
          "type": "NLFPRED",
          "link": 621
        },
        {
          "label": "dw_poses",
          "name": "dw_poses",
          "shape": 7,
          "type": "DWPOSES",
          "link": 682
        },
        {
          "label": "ref_dw_pose",
          "name": "ref_dw_pose",
          "shape": 7,
          "type": "DWPOSES",
          "link": 633
        },
        {
          "label": "width",
          "name": "width",
          "type": "INT",
          "widget": {
            "name": "width"
          },
          "link": 624
        },
        {
          "label": "height",
          "name": "height",
          "type": "INT",
          "widget": {
            "name": "height"
          },
          "link": 625
        },
        {
          "label": "draw_face",
          "name": "draw_face",
          "shape": 7,
          "type": "BOOLEAN",
          "widget": {
            "name": "draw_face"
          }
        },
        {
          "label": "draw_hands",
          "name": "draw_hands",
          "shape": 7,
          "type": "BOOLEAN",
          "widget": {
            "name": "draw_hands"
          }
        }
      ],
      "outputs": [
        {
          "label": "image",
          "name": "image",
          "type": "IMAGE",
          "links": [
            694
          ]
        },
        {
          "label": "mask",
          "name": "mask",
          "type": "MASK",
          "links": []
        }
      ],
      "properties": {
        "aux_id": "kijai/ComfyUI-SCAIL-Pose",
        "Node name for S&R": "RenderNLFPoses",
        "ver": "93059f0fe4ea3881c0d6ec0e327e5d920554277d",
        "widget_ue_connectable": {
          "width": true,
          "height": true
        }
      },
      "widgets_values": [
        512,
        896,
        true,
        true,
        "gpu",
        true,
        "taichi"
      ]
    },
    {
      "id": 381,
      "type": "ConvertOpenPoseKeypointsToDWPose",
      "pos": [
        -643.243793377026,
        -2302.724012261605
      ],
      "size": [
        329.7066153256792,
        58
      ],
      "flags": {},
      "order": 31,
      "mode": 0,
      "inputs": [
        {
          "label": "keypoints",
          "name": "keypoints",
          "type": "POSE_KEYPOINT",
          "link": 708
        },
        {
          "label": "max_people",
          "name": "max_people",
          "type": "INT",
          "widget": {
            "name": "max_people"
          },
          "link": 716
        }
      ],
      "outputs": [
        {
          "label": "dw_poses",
          "name": "dw_poses",
          "type": "DWPOSES",
          "links": [
            682
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "ConvertOpenPoseKeypointsToDWPose",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        2
      ]
    },
    {
      "id": 403,
      "type": "INTConstant",
      "pos": [
        -2307.9966135921572,
        -2872.8923022973663
      ],
      "size": [
        210,
        58
      ],
      "flags": {
        "collapsed": false
      },
      "order": 15,
      "mode": 0,
      "inputs": [],
      "outputs": [
        {
          "name": "value",
          "type": "INT",
          "links": [
            716
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "INTConstant"
      },
      "widgets_values": [
        0
      ],
      "color": "#1b4669",
      "bgcolor": "#29699c"
    },
    {
      "id": 22,
      "type": "WanVideoModelLoader",
      "pos": [
        -908.3135121278549,
        -3379.8181698890467
      ],
      "size": [
        477.4410095214844,
        338
      ],
      "flags": {},
      "order": 20,
      "mode": 0,
      "inputs": [
        {
          "label": "compile_args",
          "name": "compile_args",
          "shape": 7,
          "type": "WANCOMPILEARGS",
          "link": 563
        },
        {
          "label": "block_swap_args",
          "name": "block_swap_args",
          "shape": 7,
          "type": "BLOCKSWAPARGS",
          "link": 666
        },
        {
          "label": "lora",
          "name": "lora",
          "shape": 7,
          "type": "WANVIDLORA",
          "link": 667
        },
        {
          "label": "vram_management_args",
          "name": "vram_management_args",
          "shape": 7,
          "type": "VRAM_MANAGEMENTARGS"
        },
        {
          "label": "extra_model",
          "name": "extra_model",
          "shape": 7,
          "type": "VACEPATH"
        },
        {
          "label": "fantasytalking_model",
          "name": "fantasytalking_model",
          "shape": 7,
          "type": "FANTASYTALKINGMODEL"
        },
        {
          "label": "multitalk_model",
          "name": "multitalk_model",
          "shape": 7,
          "type": "MULTITALKMODEL"
        },
        {
          "label": "fantasyportrait_model",
          "name": "fantasyportrait_model",
          "shape": 7,
          "type": "FANTASYPORTRAITMODEL"
        },
        {
          "label": "model",
          "name": "model",
          "type": "COMBO",
          "widget": {
            "name": "model"
          }
        },
        {
          "label": "base_precision",
          "name": "base_precision",
          "type": "COMBO",
          "widget": {
            "name": "base_precision"
          }
        },
        {
          "label": "quantization",
          "name": "quantization",
          "type": "COMBO",
          "widget": {
            "name": "quantization"
          }
        },
        {
          "label": "load_device",
          "name": "load_device",
          "type": "COMBO",
          "widget": {
            "name": "load_device"
          }
        },
        {
          "label": "attention_mode",
          "name": "attention_mode",
          "shape": 7,
          "type": "COMBO",
          "widget": {
            "name": "attention_mode"
          }
        },
        {
          "label": "rms_norm_function",
          "name": "rms_norm_function",
          "shape": 7,
          "type": "COMBO",
          "widget": {
            "name": "rms_norm_function"
          }
        },
        {
          "label": "vace_model",
          "name": "vace_model",
          "shape": 7,
          "type": "VACEPATH"
        }
      ],
      "outputs": [
        {
          "label": "model",
          "name": "model",
          "type": "WANVIDEOMODEL",
          "slot_index": 0,
          "links": [
            669
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "WanVideoModelLoader",
        "cnr_id": "ComfyUI-WanVideoWrapper",
        "ver": "998a69cc0acbec503001b8b0ce0a5d5404420e1e",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "wan2.1_14B_SCAIL_2_fp16.safetensors",
        "fp16",
        "disabled",
        "offload_device",
        "sageattn",
        "default"
      ]
    }
  ],
  "links": [
    [
      15,
      11,
      0,
      16,
      0,
      "WANTEXTENCODER"
    ],
    [
      234,
      130,
      0,
      131,
      0,
      "IMAGE"
    ],
    [
      533,
      318,
      0,
      319,
      0,
      "IMAGE"
    ],
    [
      544,
      323,
      0,
      139,
      0,
      "IMAGE"
    ],
    [
      546,
      323,
      0,
      318,
      0,
      "IMAGE"
    ],
    [
      554,
      326,
      0,
      327,
      0,
      "CLIP_VISION"
    ],
    [
      563,
      35,
      0,
      22,
      0,
      "WANCOMPILEARGS"
    ],
    [
      564,
      106,
      0,
      107,
      0,
      "IMAGE"
    ],
    [
      584,
      130,
      1,
      99,
      4,
      "INT"
    ],
    [
      596,
      348,
      0,
      28,
      1,
      "LATENT"
    ],
    [
      598,
      349,
      0,
      348,
      2,
      "WANVIDEOSCHEDULER"
    ],
    [
      603,
      131,
      0,
      334,
      1,
      "IMAGE"
    ],
    [
      604,
      99,
      0,
      350,
      0,
      "WANVIDIMAGE_EMBEDS"
    ],
    [
      607,
      327,
      0,
      350,
      3,
      "WANVIDIMAGE_CLIPEMBEDS"
    ],
    [
      608,
      350,
      0,
      324,
      0,
      "WANVIDIMAGE_EMBEDS"
    ],
    [
      614,
      355,
      0,
      354,
      1,
      "WANVIDCONTEXT"
    ],
    [
      621,
      334,
      0,
      362,
      0,
      "NLFPRED"
    ],
    [
      624,
      339,
      0,
      362,
      3,
      "INT"
    ],
    [
      625,
      340,
      0,
      362,
      4,
      "INT"
    ],
    [
      629,
      364,
      0,
      365,
      0,
      "POSEMODEL"
    ],
    [
      630,
      107,
      0,
      365,
      1,
      "IMAGE"
    ],
    [
      633,
      365,
      0,
      362,
      2,
      "DWPOSES"
    ],
    [
      639,
      130,
      2,
      139,
      1,
      "AUDIO"
    ],
    [
      640,
      130,
      2,
      319,
      1,
      "AUDIO"
    ],
    [
      647,
      107,
      1,
      99,
      2,
      "INT"
    ],
    [
      648,
      107,
      2,
      99,
      3,
      "INT"
    ],
    [
      649,
      107,
      0,
      350,
      2,
      "IMAGE"
    ],
    [
      650,
      107,
      0,
      327,
      1,
      "IMAGE"
    ],
    [
      651,
      107,
      0,
      328,
      0,
      "IMAGE"
    ],
    [
      654,
      38,
      0,
      28,
      0,
      "WANVAE"
    ],
    [
      655,
      38,
      0,
      324,
      1,
      "WANVAE"
    ],
    [
      656,
      38,
      0,
      350,
      1,
      "WANVAE"
    ],
    [
      658,
      16,
      0,
      348,
      3,
      "WANVIDEOTEXTEMBEDS"
    ],
    [
      666,
      39,
      0,
      22,
      1,
      "BLOCKSWAPARGS"
    ],
    [
      667,
      56,
      0,
      22,
      2,
      "WANVIDLORA"
    ],
    [
      669,
      22,
      0,
      348,
      0,
      "WANVIDEOMODEL"
    ],
    [
      675,
      28,
      0,
      378,
      0,
      "*"
    ],
    [
      676,
      378,
      0,
      323,
      0,
      "IMAGE"
    ],
    [
      678,
      328,
      0,
      379,
      1,
      "IMAGE"
    ],
    [
      679,
      379,
      0,
      318,
      1,
      "IMAGE"
    ],
    [
      680,
      130,
      0,
      379,
      0,
      "IMAGE"
    ],
    [
      682,
      381,
      0,
      362,
      1,
      "DWPOSES"
    ],
    [
      683,
      131,
      0,
      380,
      0,
      "IMAGE"
    ],
    [
      691,
      389,
      0,
      137,
      0,
      "IMAGE"
    ],
    [
      692,
      389,
      0,
      328,
      1,
      "IMAGE"
    ],
    [
      693,
      389,
      0,
      324,
      2,
      "IMAGE"
    ],
    [
      694,
      362,
      0,
      389,
      0,
      "*"
    ],
    [
      695,
      390,
      0,
      348,
      5,
      "WANVIDSAMPLEREXTRAARGS"
    ],
    [
      696,
      354,
      0,
      390,
      0,
      "*"
    ],
    [
      700,
      324,
      0,
      393,
      0,
      "*"
    ],
    [
      701,
      393,
      0,
      348,
      1,
      "WANVIDIMAGE_EMBEDS"
    ],
    [
      708,
      380,
      1,
      381,
      0,
      "POSE_KEYPOINT"
    ],
    [
      709,
      400,
      0,
      131,
      2,
      "INT"
    ],
    [
      710,
      400,
      0,
      339,
      0,
      "INT"
    ],
    [
      711,
      400,
      0,
      107,
      2,
      "INT"
    ],
    [
      712,
      401,
      0,
      340,
      0,
      "INT"
    ],
    [
      713,
      401,
      0,
      107,
      3,
      "INT"
    ],
    [
      714,
      401,
      0,
      131,
      3,
      "INT"
    ],
    [
      715,
      402,
      0,
      130,
      6,
      "INT"
    ],
    [
      716,
      403,
      0,
      381,
      1,
      "INT"
    ],
    [
      718,
      404,
      0,
      16,
      2,
      "STRING"
    ],
    [
      719,
      405,
      0,
      334,
      0,
      "NLFMODEL"
    ]
  ],
  "groups": [
    {
      "id": 5,
      "title": "多宽和多高",
      "bounding": [
        -2325.838858720137,
        -3385.8866902103273,
        250.7803497314453,
        265.0298156738281
      ],
      "color": "#3f789e",
      "flags": {}
    },
    {
      "id": 7,
      "title": "多少帧",
      "bounding": [
        -2324.1326455802846,
        -3106.450445357664,
        230,
        141.59988403320312
      ],
      "color": "#3f789e",
      "flags": {}
    },
    {
      "id": 9,
      "title": "多少人",
      "bounding": [
        -2317.7558783215586,
        -2945.885662979427,
        230,
        141.60000610351562
      ],
      "color": "#3f789e",
      "flags": {}
    },
    {
      "id": 10,
      "title": "Group",
      "bounding": [
        -1303.5410065448275,
        -3531.850899033058,
        1961.446321916207,
        2358.125401275949
      ],
      "color": "#3f789e",
      "flags": {}
    }
  ],
  "config": {},
  "extra": {
    "VHS_KeepIntermediate": true,
    "links_added_by_ue": [],
    "VHS_MetadataImage": true,
    "ue_links": [],
    "0246.VERSION": [
      0,
      0,
      4
    ],
    "workflowRendererVersion": "LG",
    "VHS_latentpreviewrate": 0,
    "frontendVersion": "1.45.20",
    "VHS_latentpreview": false,
    "node_versions": {
      "ComfyUI-WanVideoWrapper": "5a2383621a05825d0d0437781afcb8552d9590fd",
      "ComfyUI-VideoHelperSuite": "0a75c7958fe320efcb052f1d9f8451fd20c730a8",
      "comfy-core": "0.3.26"
    },
    "ds": {
      "scale": 0.4090909090909136,
      "offset": [
        2913.4254147695365,
        3913.983270118443
      ]
    }
  },
  "version": 0.4
}
```
