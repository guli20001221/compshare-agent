# 音乐生成

- 来源类别：用户工作流
- 镜像内原始路径：`/ComfyUI/user/default/workflows/18个开源模型工作流/音频/音乐生成.json`
- 节点数量：13
- 连线数量：15

## 节点类型

- `ACEStep15XLEmptyLatentAudio` × 1
- `ACEStep15XLPromptLyrics` × 1
- `ACEStep15XLTextEncode` × 1
- `ConditioningZeroOut` × 1
- `DualCLIPLoader` × 1
- `KSampler` × 1
- `ModelSamplingAuraFlow` × 1
- `PreviewAudio` × 1
- `PrimitiveFloat` × 1
- `PrimitiveNode` × 1
- `UNETLoader` × 1
- `VAEDecodeAudio` × 1
- `VAELoader` × 1

## 工作流引用的模型或媒体文件

- `ace15Vae_v15.safetensors`
- `qwen06bAce15_v06.safetensors`
- `qwen4bAce15_v15.safetensors`
- `tepV15Turbo_v15.safetensors`

## 原始工作流 JSON

```json
{
  "id": "comfyui-acestep-text-generation",
  "revision": 0,
  "last_node_id": 15,
  "last_link_id": 19,
  "nodes": [
    {
      "id": 2,
      "type": "ModelSamplingAuraFlow",
      "pos": [
        -360,
        -640
      ],
      "size": [
        330,
        110
      ],
      "flags": {},
      "order": 6,
      "mode": 0,
      "inputs": [
        {
          "label": "模型",
          "name": "model",
          "type": "MODEL",
          "link": 1
        }
      ],
      "outputs": [
        {
          "label": "模型",
          "name": "MODEL",
          "type": "MODEL",
          "slot_index": 0,
          "links": [
            9
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.11.1",
        "Node name for S&R": "ModelSamplingAuraFlow"
      },
      "widgets_values": [
        3
      ]
    },
    {
      "id": 1,
      "type": "UNETLoader",
      "pos": [
        -780,
        -640
      ],
      "size": [
        380,
        110
      ],
      "flags": {},
      "order": 0,
      "mode": 0,
      "inputs": [],
      "outputs": [
        {
          "label": "模型",
          "name": "MODEL",
          "type": "MODEL",
          "slot_index": 0,
          "links": [
            1
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.11.1",
        "Node name for S&R": "UNETLoader",
        "models": [
          {
            "name": "acestep_v1.5_xl_turbo_bf16.safetensors",
            "directory": "diffusion_models"
          }
        ]
      },
      "widgets_values": [
        "acestepV15Turbo_v15.safetensors",
        "default"
      ]
    },
    {
      "id": 3,
      "type": "DualCLIPLoader",
      "pos": [
        -780,
        -470
      ],
      "size": [
        378.95243530273433,
        133.90460205078125
      ],
      "flags": {},
      "order": 1,
      "mode": 0,
      "inputs": [],
      "outputs": [
        {
          "label": "CLIP",
          "name": "CLIP",
          "type": "CLIP",
          "slot_index": 0,
          "links": [
            2
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.11.1",
        "Node name for S&R": "DualCLIPLoader"
      },
      "widgets_values": [
        "qwen06bAce15_v06.safetensors",
        "qwen4bAce15_v15.safetensors",
        "ace",
        "default"
      ]
    },
    {
      "id": 8,
      "type": "ACEStep15XLTextEncode",
      "pos": [
        -358.6665771484378,
        -469.33335571289075
      ],
      "size": [
        526,
        762.8571044921875
      ],
      "flags": {},
      "order": 8,
      "mode": 0,
      "inputs": [
        {
          "label": "clip",
          "name": "clip",
          "type": "CLIP",
          "link": 2
        },
        {
          "label": "tags",
          "name": "tags",
          "type": "STRING",
          "widget": {
            "name": "tags"
          },
          "link": 3
        },
        {
          "label": "lyrics",
          "name": "lyrics",
          "type": "STRING",
          "widget": {
            "name": "lyrics"
          },
          "link": 4
        },
        {
          "label": "seed",
          "name": "seed",
          "type": "INT",
          "widget": {
            "name": "seed"
          },
          "link": null
        },
        {
          "label": "bpm",
          "name": "bpm",
          "type": "INT",
          "widget": {
            "name": "bpm"
          },
          "link": 6
        },
        {
          "label": "duration",
          "name": "duration",
          "type": "FLOAT",
          "widget": {
            "name": "duration"
          },
          "link": 18
        },
        {
          "label": "timesignature",
          "name": "timesignature",
          "type": "COMBO",
          "widget": {
            "name": "timesignature"
          },
          "link": null
        },
        {
          "label": "language",
          "name": "language",
          "type": "COMBO",
          "widget": {
            "name": "language"
          },
          "link": null
        },
        {
          "label": "keyscale",
          "name": "keyscale",
          "type": "COMBO",
          "widget": {
            "name": "keyscale"
          },
          "link": null
        },
        {
          "label": "generate_audio_codes",
          "name": "generate_audio_codes",
          "type": "BOOLEAN",
          "widget": {
            "name": "generate_audio_codes"
          },
          "link": null
        },
        {
          "label": "cfg_scale",
          "name": "cfg_scale",
          "type": "FLOAT",
          "widget": {
            "name": "cfg_scale"
          },
          "link": null
        },
        {
          "label": "temperature",
          "name": "temperature",
          "type": "FLOAT",
          "widget": {
            "name": "temperature"
          },
          "link": null
        },
        {
          "label": "top_p",
          "name": "top_p",
          "type": "FLOAT",
          "widget": {
            "name": "top_p"
          },
          "link": null
        },
        {
          "label": "top_k",
          "name": "top_k",
          "type": "INT",
          "widget": {
            "name": "top_k"
          },
          "link": null
        },
        {
          "label": "min_p",
          "name": "min_p",
          "type": "FLOAT",
          "widget": {
            "name": "min_p"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "conditioning",
          "name": "conditioning",
          "type": "CONDITIONING",
          "slot_index": 0,
          "links": [
            10,
            11
          ]
        },
        {
          "label": "tags",
          "name": "tags",
          "type": "STRING",
          "slot_index": 1,
          "links": []
        },
        {
          "label": "lyrics",
          "name": "lyrics",
          "type": "STRING",
          "slot_index": 2,
          "links": []
        }
      ],
      "properties": {
        "Node name for S&R": "ACEStep15XLTextEncode",
        "cnr_id": "ComfyUI-ACEStep"
      },
      "widgets_values": [
        "gentle female vocal, moonlit romance, soft love ballad, dreamy atmosphere, tender emotional pop, slow dance, intimate night scene, warm piano, airy strings, soft reverb, romantic lyrics, soothing melody",
        "[verse]  \nMoonlight falls on your silver skin  \nSoft as a secret drifting in  \nNight wind carries your name to me  \nLike a wave on a quiet sea  \n\n[verse]  \nYour eyes shine where the shadows fade  \nTwo little stars that heaven made  \nI move closer, slow and light  \nWrapped in the hush of the blue midnight  \n\n[pre-chorus]  \nNo need for words, no need to run  \nOur hearts are speaking one by one  \nEvery breath becomes a vow  \nOnly love can find us now  \n\n[chorus]  \nHold me under the moonlight glow  \nLet the tender feelings flow  \nIn your arms I lose my way  \nBut I want to stay, I want to stay  \n\nKiss me where the night is warm  \nKeep me safe inside your storm  \nIf the world should fade from view  \nI’ll still be here loving you  \n\n[verse]  \nWhite roses bloom beside the lane  \nDancing softly after rain  \nYour hand in mine, so calm, so true  \nEvery dream leads back to you  \n\n[verse]  \nThe river mirrors the moon above  \nLike a song made out of love  \nFootsteps vanish in the sand  \nBut I still feel your gentle hand  \n\n[pre-chorus]  \nNo need for gold, no need for time  \nYour heartbeat softly answers mine  \nEvery star begins to sway  \nWhen you whisper, “please don’t fade”  \n\n[chorus]  \nHold me under the moonlight glow  \nLet the tender feelings flow  \nIn your arms I lose my way  \nBut I want to stay, I want to stay  \n\nKiss me where the night is warm  \nKeep me safe inside your storm  \nIf the world should fade from view  \nI’ll still be here loving you  \n\n[bridge]  \nAnd if dawn comes stealing the sky  \nI won’t say goodbye  \nI’ll keep your warmth inside my chest  \nWhere lonely dreams can rest  \n\nYour voice is silk, your touch is fire  \nSoftly lifting my desire  \nIn this silence, pure and bright  \nWe become the song of night  \n\n[final chorus]  \nHold me under the moonlight glow  \nLet the tender feelings flow  \nIn your arms I lose my way  \nBut I want to stay, I want to stay  \n\nLove me till the morning dew  \nPaints the fields in pale blue  \nIf the stars all disappear  \nI’ll still feel you near, still feel you near  \n\n[outro]  \nMoonlight fades, but love remains  \nSweet as roses after rain  \nClose your eyes and stay with me  \nForever in this silver dream",
        0,
        "fixed",
        72,
        120,
        "4",
        "en",
        "E minor",
        true,
        2,
        0.85,
        0.9,
        0,
        0
      ],
      "color": "#2B6E7F",
      "bgcolor": "#18323D"
    },
    {
      "id": 12,
      "type": "KSampler",
      "pos": [
        192.5714477539065,
        -470.7619079589844
      ],
      "size": [
        330,
        350
      ],
      "flags": {},
      "order": 10,
      "mode": 0,
      "inputs": [
        {
          "label": "模型",
          "name": "model",
          "type": "MODEL",
          "link": 9
        },
        {
          "label": "正面条件",
          "name": "positive",
          "type": "CONDITIONING",
          "link": 10
        },
        {
          "label": "负面条件",
          "name": "negative",
          "type": "CONDITIONING",
          "link": 12
        },
        {
          "label": "Latent",
          "name": "latent_image",
          "type": "LATENT",
          "link": 13
        }
      ],
      "outputs": [
        {
          "label": "Latent",
          "name": "LATENT",
          "type": "LATENT",
          "slot_index": 0,
          "links": [
            15
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.11.1",
        "Node name for S&R": "KSampler"
      },
      "widgets_values": [
        0,
        "fixed",
        8,
        1,
        "euler",
        "simple",
        1
      ]
    },
    {
      "id": 11,
      "type": "ConditioningZeroOut",
      "pos": [
        -12.095263671874896,
        -636.6668289184572
      ],
      "size": [
        140,
        102.00001678466788
      ],
      "flags": {},
      "order": 9,
      "mode": 0,
      "inputs": [
        {
          "label": "条件",
          "name": "conditioning",
          "type": "CONDITIONING",
          "link": 11
        }
      ],
      "outputs": [
        {
          "label": "条件",
          "name": "CONDITIONING",
          "type": "CONDITIONING",
          "slot_index": 0,
          "links": [
            12
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.11.1",
        "Node name for S&R": "ConditioningZeroOut"
      },
      "widgets_values": []
    },
    {
      "id": 13,
      "type": "VAEDecodeAudio",
      "pos": [
        150.85697021484398,
        -632.2857238769534
      ],
      "size": [
        140.95230102539062,
        46
      ],
      "flags": {},
      "order": 11,
      "mode": 0,
      "inputs": [
        {
          "label": "Latent",
          "name": "samples",
          "type": "LATENT",
          "link": 15
        },
        {
          "label": "VAE",
          "name": "vae",
          "type": "VAE",
          "link": 16
        }
      ],
      "outputs": [
        {
          "label": "音频",
          "name": "AUDIO",
          "type": "AUDIO",
          "slot_index": 0,
          "links": [
            17
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.11.1",
        "Node name for S&R": "VAEDecodeAudio"
      },
      "widgets_values": []
    },
    {
      "id": 14,
      "type": "PreviewAudio",
      "pos": [
        307.22649249267533,
        -627.3660883483886
      ],
      "size": [
        210,
        88
      ],
      "flags": {},
      "order": 12,
      "mode": 0,
      "inputs": [
        {
          "label": "音频",
          "name": "audio",
          "type": "AUDIO",
          "link": 17
        }
      ],
      "outputs": [
        {
          "name": "audio",
          "type": "AUDIO",
          "links": null
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.11.1",
        "Node name for S&R": "PreviewAudio"
      },
      "widgets_values": []
    },
    {
      "id": 4,
      "type": "VAELoader",
      "pos": [
        -777.9048034667968,
        -288.6667449951173
      ],
      "size": [
        377.90473632812495,
        68.09523010253906
      ],
      "flags": {},
      "order": 2,
      "mode": 0,
      "inputs": [],
      "outputs": [
        {
          "name": "VAE",
          "type": "VAE",
          "slot_index": 0,
          "links": [
            16
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.11.1",
        "Node name for S&R": "VAELoader"
      },
      "widgets_values": [
        "ace15Vae_v15.safetensors"
      ]
    },
    {
      "id": 6,
      "type": "ACEStep15XLPromptLyrics",
      "pos": [
        -1129.9614510370434,
        -636.5776915050996
      ],
      "size": [
        324.0464611898949,
        515.0693122754858
      ],
      "flags": {},
      "order": 3,
      "mode": 0,
      "inputs": [
        {
          "label": "tags",
          "name": "tags",
          "type": "STRING",
          "widget": {
            "name": "tags"
          },
          "link": null
        },
        {
          "label": "lyrics",
          "name": "lyrics",
          "type": "STRING",
          "widget": {
            "name": "lyrics"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "tags",
          "name": "tags",
          "type": "STRING",
          "slot_index": 0,
          "links": [
            3
          ]
        },
        {
          "label": "lyrics",
          "name": "lyrics",
          "type": "STRING",
          "slot_index": 1,
          "links": [
            4
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "ACEStep15XLPromptLyrics",
        "cnr_id": "ComfyUI-ACEStep"
      },
      "widgets_values": [
        "R&B, Middle Eastern pop, mysterious, rhythmic, male vocal, high fidelity, ancient vibe",
        "大老板颁布了 今天的KPI法典\n刻在黑色的打卡机 距今已经八个小时半\n你在工位前 凝视PPT的字眼\n我却在旁静静欣赏 你那张我深爱的脸\n老板 画饼 甩锅 摸鱼 是谁的从前\n喜欢在摸鱼中 你只属于我的那画面\n经过茶水间女神身边 我以冰美式许愿\n思念像底格里斯河般的蔓延"
      ],
      "color": "#2B6E7F",
      "bgcolor": "#18323D"
    },
    {
      "id": 15,
      "type": "PrimitiveFloat",
      "pos": [
        -1125.199091965043,
        -74.96511546390742
      ],
      "size": [
        319.23809204101565,
        58
      ],
      "flags": {},
      "order": 4,
      "mode": 0,
      "inputs": [
        {
          "label": "value",
          "name": "value",
          "type": "FLOAT",
          "widget": {
            "name": "value"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "FLOAT",
          "name": "FLOAT",
          "type": "FLOAT",
          "links": [
            18,
            19
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.27.0",
        "Node name for S&R": "PrimitiveFloat"
      },
      "widgets_values": [
        60
      ]
    },
    {
      "id": 10,
      "type": "PrimitiveNode",
      "pos": [
        -1121.8095062255845,
        33.14282836914062
      ],
      "size": [
        314.7618408203125,
        82
      ],
      "flags": {},
      "order": 5,
      "mode": 0,
      "inputs": [],
      "outputs": [
        {
          "name": "INT",
          "type": "INT",
          "widget": {
            "name": "bpm"
          },
          "slot_index": 0,
          "links": [
            6
          ]
        }
      ],
      "properties": {
        "Run widget replace on values": false,
        "Node name for S&R": "PrimitiveNode"
      },
      "widgets_values": [
        72,
        "fixed"
      ]
    },
    {
      "id": 9,
      "type": "ACEStep15XLEmptyLatentAudio",
      "pos": [
        -774.5717163085943,
        -170.09529724121094
      ],
      "size": [
        378.19052734374986,
        138.95240173339846
      ],
      "flags": {},
      "order": 7,
      "mode": 0,
      "inputs": [
        {
          "label": "seconds",
          "name": "seconds",
          "type": "FLOAT",
          "widget": {
            "name": "seconds"
          },
          "link": 19
        },
        {
          "label": "batch_size",
          "name": "batch_size",
          "type": "INT",
          "widget": {
            "name": "batch_size"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "latent",
          "name": "latent",
          "type": "LATENT",
          "slot_index": 0,
          "links": [
            13
          ]
        },
        {
          "label": "seconds",
          "name": "seconds",
          "type": "FLOAT",
          "slot_index": 1,
          "links": []
        },
        {
          "label": "latent_frames",
          "name": "latent_frames",
          "type": "INT",
          "slot_index": 2,
          "links": []
        }
      ],
      "properties": {
        "Node name for S&R": "ACEStep15XLEmptyLatentAudio",
        "cnr_id": "ComfyUI-ACEStep"
      },
      "widgets_values": [
        120,
        1
      ],
      "color": "#2B6E7F",
      "bgcolor": "#18323D"
    }
  ],
  "links": [
    [
      1,
      1,
      0,
      2,
      0,
      "MODEL"
    ],
    [
      2,
      3,
      0,
      8,
      0,
      "CLIP"
    ],
    [
      3,
      6,
      0,
      8,
      1,
      "STRING"
    ],
    [
      4,
      6,
      1,
      8,
      2,
      "STRING"
    ],
    [
      6,
      10,
      0,
      8,
      4,
      "INT"
    ],
    [
      9,
      2,
      0,
      12,
      0,
      "MODEL"
    ],
    [
      10,
      8,
      0,
      12,
      1,
      "CONDITIONING"
    ],
    [
      11,
      8,
      0,
      11,
      0,
      "CONDITIONING"
    ],
    [
      12,
      11,
      0,
      12,
      2,
      "CONDITIONING"
    ],
    [
      13,
      9,
      0,
      12,
      3,
      "LATENT"
    ],
    [
      15,
      12,
      0,
      13,
      0,
      "LATENT"
    ],
    [
      16,
      4,
      0,
      13,
      1,
      "VAE"
    ],
    [
      17,
      13,
      0,
      14,
      0,
      "AUDIO"
    ],
    [
      18,
      15,
      0,
      8,
      5,
      "FLOAT"
    ],
    [
      19,
      15,
      0,
      9,
      0,
      "FLOAT"
    ]
  ],
  "groups": [],
  "config": {},
  "extra": {
    "ds": {
      "scale": 1,
      "offset": [
        1437.9703011722045,
        832.9545278902676
      ]
    },
    "source": "ComfyUI-ACEStep example workflow",
    "note": "Example workflow for ACE-Step 1.5XL text-to-audio generation.",
    "frontendVersion": "1.45.20",
    "VHS_latentpreview": false,
    "VHS_latentpreviewrate": 0,
    "VHS_MetadataImage": true,
    "VHS_KeepIntermediate": true
  },
  "version": 0.4
}
```
