# Text to Image (Flux.1 Dev)

- 来源类别：内置工作流蓝图
- 镜像内原始路径：`/ComfyUI/blueprints/Text to Image (Flux.1 Dev).json`
- 节点数量：1
- 连线数量：0

## 节点类型

- `1fd98b34-59ef-4d8d-afbf-58bdd7a1cd35` × 1

## 原始工作流 JSON

```json
{
  "revision": 0,
  "last_node_id": 193,
  "last_link_id": 0,
  "nodes": [
    {
      "id": 193,
      "type": "1fd98b34-59ef-4d8d-afbf-58bdd7a1cd35",
      "pos": [
        -1210,
        -1770
      ],
      "size": [
        400,
        380
      ],
      "flags": {},
      "order": 0,
      "mode": 0,
      "inputs": [
        {
          "label": "prompt",
          "name": "text",
          "type": "STRING",
          "widget": {
            "name": "text"
          },
          "link": null
        },
        {
          "name": "width",
          "type": "INT",
          "widget": {
            "name": "width"
          },
          "link": null
        },
        {
          "name": "height",
          "type": "INT",
          "widget": {
            "name": "height"
          },
          "link": null
        },
        {
          "name": "seed",
          "type": "INT",
          "widget": {
            "name": "seed"
          },
          "link": null
        },
        {
          "name": "unet_name",
          "type": "COMBO",
          "widget": {
            "name": "unet_name"
          },
          "link": null
        },
        {
          "name": "clip_name1",
          "type": "COMBO",
          "widget": {
            "name": "clip_name1"
          },
          "link": null
        },
        {
          "name": "clip_name2",
          "type": "COMBO",
          "widget": {
            "name": "clip_name2"
          },
          "link": null
        },
        {
          "name": "vae_name",
          "type": "COMBO",
          "widget": {
            "name": "vae_name"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "localized_name": "IMAGE",
          "name": "IMAGE",
          "type": "IMAGE",
          "links": []
        }
      ],
      "properties": {
        "proxyWidgets": [
          [
            "45",
            "text"
          ],
          [
            "27",
            "width"
          ],
          [
            "27",
            "height"
          ],
          [
            "31",
            "seed"
          ],
          [
            "38",
            "unet_name"
          ],
          [
            "40",
            "clip_name1"
          ],
          [
            "40",
            "clip_name2"
          ],
          [
            "39",
            "vae_name"
          ],
          [
            "31",
            "control_after_generate"
          ]
        ],
        "ue_properties": {
          "widget_ue_connectable": {},
          "input_ue_unconnectable": {}
        },
        "cnr_id": "comfy-core",
        "ver": "0.18.1"
      },
      "widgets_values": [],
      "title": "Text to Image (Flux.1 Dev)"
    }
  ],
  "links": [],
  "version": 0.4,
  "definitions": {
    "subgraphs": [
      {
        "id": "1fd98b34-59ef-4d8d-afbf-58bdd7a1cd35",
        "version": 1,
        "state": {
          "lastGroupId": 8,
          "lastNodeId": 193,
          "lastLinkId": 388,
          "lastRerouteId": 0
        },
        "revision": 0,
        "config": {},
        "name": "Text to Image (Flux.1 Dev)",
        "inputNode": {
          "id": -10,
          "bounding": [
            -1090,
            411,
            120,
            200
          ]
        },
        "outputNode": {
          "id": -20,
          "bounding": [
            540,
            100,
            120,
            60
          ]
        },
        "inputs": [
          {
            "id": "669e384e-5e26-4291-9bac-e1d1f04b4a16",
            "name": "text",
            "type": "STRING",
            "linkIds": [
              68
            ],
            "label": "prompt",
            "pos": [
              -990,
              431
            ]
          },
          {
            "id": "5a5c0b01-5836-4ca6-a24f-68c0a4fb9802",
            "name": "width",
            "type": "INT",
            "linkIds": [
              69
            ],
            "pos": [
              -990,
              451
            ]
          },
          {
            "id": "5e01104a-ed7f-457b-aaee-934e8ecc088d",
            "name": "height",
            "type": "INT",
            "linkIds": [
              70
            ],
            "pos": [
              -990,
              471
            ]
          },
          {
            "id": "ea5ea317-a484-4605-8138-8628a4b8e502",
            "name": "seed",
            "type": "INT",
            "linkIds": [
              382
            ],
            "pos": [
              -990,
              491
            ]
          },
          {
            "id": "ea2332f5-bd49-4e2e-8c7a-95817dc56ed6",
            "name": "unet_name",
            "type": "COMBO",
            "linkIds": [
              385
            ],
            "pos": [
              -990,
              511
            ]
          },
          {
            "id": "4fca3f43-c05f-4337-bf84-2afe67e43739",
            "name": "clip_name1",
            "type": "COMBO",
            "linkIds": [
              386
            ],
            "pos": [
              -990,
              531
            ]
          },
          {
            "id": "357a679f-1370-4cd5-9269-0d5ae1986b49",
            "name": "clip_name2",
            "type": "COMBO",
            "linkIds": [
              387
            ],
            "pos": [
              -990,
              551
            ]
          },
          {
            "id": "924ffec5-81f8-4585-8761-5a80d5d775bc",
            "name": "vae_name",
            "type": "COMBO",
            "linkIds": [
              388
            ],
            "pos": [
              -990,
              571
            ]
          }
        ],
        "outputs": [
          {
            "id": "2185cb4d-8689-4cf8-b345-75319fb46a8e",
            "name": "IMAGE",
            "type": "IMAGE",
            "linkIds": [
              9
            ],
            "localized_name": "IMAGE",
            "pos": [
              560,
              120
            ]
          }
        ],
        "widgets": [],
        "nodes": [
          {
            "id": 39,
            "type": "VAELoader",
            "pos": [
              -800,
              670
            ],
            "size": [
              270,
              110
            ],
            "flags": {},
            "order": 4,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "vae_name",
                "name": "vae_name",
                "type": "COMBO",
                "widget": {
                  "name": "vae_name"
                },
                "link": 388
              }
            ],
            "outputs": [
              {
                "localized_name": "VAE",
                "name": "VAE",
                "type": "VAE",
                "links": [
                  58
                ]
              }
            ],
            "properties": {
              "ue_properties": {
                "widget_ue_connectable": {},
                "input_ue_unconnectable": {}
              },
              "cnr_id": "comfy-core",
              "ver": "0.3.40",
              "Node name for S&R": "VAELoader",
              "models": [
                {
                  "name": "ae.safetensors",
                  "url": "https://huggingface.co/Comfy-Org/Lumina_Image_2.0_Repackaged/resolve/main/split_files/vae/ae.safetensors",
                  "directory": "vae"
                }
              ]
            },
            "widgets_values": [
              "ae.safetensors"
            ]
          },
          {
            "id": 38,
            "type": "UNETLoader",
            "pos": [
              -800,
              160
            ],
            "size": [
              270,
              110
            ],
            "flags": {},
            "order": 3,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "unet_name",
                "name": "unet_name",
                "type": "COMBO",
                "widget": {
                  "name": "unet_name"
                },
                "link": 385
              },
              {
                "localized_name": "weight_dtype",
                "name": "weight_dtype",
                "type": "COMBO",
                "widget": {
                  "name": "weight_dtype"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "MODEL",
                "name": "MODEL",
                "type": "MODEL",
                "links": [
                  61
                ]
              }
            ],
            "properties": {
              "ue_properties": {
                "widget_ue_connectable": {},
                "input_ue_unconnectable": {}
              },
              "cnr_id": "comfy-core",
              "ver": "0.3.40",
              "Node name for S&R": "UNETLoader",
              "models": [
                {
                  "name": "flux1-dev.safetensors",
                  "url": "https://huggingface.co/Comfy-Org/flux1-dev/resolve/main/flux1-dev.safetensors",
                  "directory": "diffusion_models"
                }
              ]
            },
            "widgets_values": [
              "flux1-dev.safetensors",
              "default"
            ]
          },
          {
            "id": 40,
            "type": "DualCLIPLoader",
            "pos": [
              -800,
              380
            ],
            "size": [
              270,
              180
            ],
            "flags": {},
            "order": 5,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "clip_name1",
                "name": "clip_name1",
                "type": "COMBO",
                "widget": {
                  "name": "clip_name1"
                },
                "link": 386
              },
              {
                "localized_name": "clip_name2",
                "name": "clip_name2",
                "type": "COMBO",
                "widget": {
                  "name": "clip_name2"
                },
                "link": 387
              },
              {
                "localized_name": "type",
                "name": "type",
                "type": "COMBO",
                "widget": {
                  "name": "type"
                },
                "link": null
              },
              {
                "localized_name": "device",
                "name": "device",
                "shape": 7,
                "type": "COMBO",
                "widget": {
                  "name": "device"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "CLIP",
                "name": "CLIP",
                "type": "CLIP",
                "links": [
                  64
                ]
              }
            ],
            "properties": {
              "ue_properties": {
                "widget_ue_connectable": {},
                "input_ue_unconnectable": {}
              },
              "cnr_id": "comfy-core",
              "ver": "0.3.40",
              "Node name for S&R": "DualCLIPLoader",
              "models": [
                {
                  "name": "clip_l.safetensors",
                  "url": "https://huggingface.co/comfyanonymous/flux_text_encoders/resolve/main/clip_l.safetensors",
                  "directory": "text_encoders"
                },
                {
                  "name": "t5xxl_fp16.safetensors",
                  "url": "https://huggingface.co/comfyanonymous/flux_text_encoders/resolve/main/t5xxl_fp16.safetensors",
                  "directory": "text_encoders"
                }
              ]
            },
            "widgets_values": [
              "clip_l.safetensors",
              "t5xxl_fp16.safetensors",
              "flux",
              "default"
            ]
          },
          {
            "id": 27,
            "type": "EmptySD3LatentImage",
            "pos": [
              -420,
              640
            ],
            "size": [
              270,
              170
            ],
            "flags": {},
            "order": 1,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "width",
                "name": "width",
                "type": "INT",
                "widget": {
                  "name": "width"
                },
                "link": 69
              },
              {
                "localized_name": "height",
                "name": "height",
                "type": "INT",
                "widget": {
                  "name": "height"
                },
                "link": 70
              },
              {
                "localized_name": "batch_size",
                "name": "batch_size",
                "type": "INT",
                "widget": {
                  "name": "batch_size"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "LATENT",
                "name": "LATENT",
                "type": "LATENT",
                "slot_index": 0,
                "links": [
                  51
                ]
              }
            ],
            "properties": {
              "ue_properties": {
                "widget_ue_connectable": {},
                "input_ue_unconnectable": {}
              },
              "cnr_id": "comfy-core",
              "ver": "0.3.40",
              "Node name for S&R": "EmptySD3LatentImage"
            },
            "widgets_values": [
              1024,
              1024,
              1
            ]
          },
          {
            "id": 45,
            "type": "CLIPTextEncode",
            "pos": [
              -460,
              150
            ],
            "size": [
              330,
              220
            ],
            "flags": {},
            "order": 7,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "clip",
                "name": "clip",
                "type": "CLIP",
                "link": 64
              },
              {
                "localized_name": "text",
                "name": "text",
                "type": "STRING",
                "widget": {
                  "name": "text"
                },
                "link": 68
              }
            ],
            "outputs": [
              {
                "localized_name": "CONDITIONING",
                "name": "CONDITIONING",
                "type": "CONDITIONING",
                "links": [
                  65,
                  66
                ]
              }
            ],
            "properties": {
              "ue_properties": {
                "widget_ue_connectable": {},
                "input_ue_unconnectable": {}
              },
              "cnr_id": "comfy-core",
              "ver": "0.18.1",
              "Node name for S&R": "CLIPTextEncode"
            },
            "widgets_values": [
              ""
            ]
          },
          {
            "id": 31,
            "type": "KSampler",
            "pos": [
              -50,
              260
            ],
            "size": [
              320,
              350
            ],
            "flags": {},
            "order": 2,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "model",
                "name": "model",
                "type": "MODEL",
                "link": 61
              },
              {
                "localized_name": "positive",
                "name": "positive",
                "type": "CONDITIONING",
                "link": 65
              },
              {
                "localized_name": "negative",
                "name": "negative",
                "type": "CONDITIONING",
                "link": 63
              },
              {
                "localized_name": "latent_image",
                "name": "latent_image",
                "type": "LATENT",
                "link": 51
              },
              {
                "localized_name": "seed",
                "name": "seed",
                "type": "INT",
                "widget": {
                  "name": "seed"
                },
                "link": 382
              },
              {
                "localized_name": "steps",
                "name": "steps",
                "type": "INT",
                "widget": {
                  "name": "steps"
                },
                "link": null
              },
              {
                "localized_name": "cfg",
                "name": "cfg",
                "type": "FLOAT",
                "widget": {
                  "name": "cfg"
                },
                "link": null
              },
              {
                "localized_name": "sampler_name",
                "name": "sampler_name",
                "type": "COMBO",
                "widget": {
                  "name": "sampler_name"
                },
                "link": null
              },
              {
                "localized_name": "scheduler",
                "name": "scheduler",
                "type": "COMBO",
                "widget": {
                  "name": "scheduler"
                },
                "link": null
              },
              {
                "localized_name": "denoise",
                "name": "denoise",
                "type": "FLOAT",
                "widget": {
                  "name": "denoise"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "LATENT",
                "name": "LATENT",
                "type": "LATENT",
                "slot_index": 0,
                "links": [
                  52
                ]
              }
            ],
            "properties": {
              "ue_properties": {
                "widget_ue_connectable": {},
                "input_ue_unconnectable": {}
              },
              "cnr_id": "comfy-core",
              "ver": "0.3.40",
              "Node name for S&R": "KSampler"
            },
            "widgets_values": [
              0,
              "randomize",
              20,
              1,
              "euler",
              "simple",
              1
            ]
          },
          {
            "id": 8,
            "type": "VAEDecode",
            "pos": [
              20,
              120
            ],
            "size": [
              230,
              100
            ],
            "flags": {
              "collapsed": false
            },
            "order": 0,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "samples",
                "name": "samples",
                "type": "LATENT",
                "link": 52
              },
              {
                "localized_name": "vae",
                "name": "vae",
                "type": "VAE",
                "link": 58
              }
            ],
            "outputs": [
              {
                "localized_name": "IMAGE",
                "name": "IMAGE",
                "type": "IMAGE",
                "slot_index": 0,
                "links": [
                  9
                ]
              }
            ],
            "properties": {
              "ue_properties": {
                "widget_ue_connectable": {},
                "input_ue_unconnectable": {}
              },
              "cnr_id": "comfy-core",
              "ver": "0.3.40",
              "Node name for S&R": "VAEDecode"
            }
          },
          {
            "id": 42,
            "type": "ConditioningZeroOut",
            "pos": [
              -350,
              420
            ],
            "size": [
              230,
              80
            ],
            "flags": {
              "collapsed": false
            },
            "order": 6,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "conditioning",
                "name": "conditioning",
                "type": "CONDITIONING",
                "link": 66
              }
            ],
            "outputs": [
              {
                "localized_name": "CONDITIONING",
                "name": "CONDITIONING",
                "type": "CONDITIONING",
                "links": [
                  63
                ]
              }
            ],
            "properties": {
              "ue_properties": {
                "widget_ue_connectable": {},
                "input_ue_unconnectable": {}
              },
              "cnr_id": "comfy-core",
              "ver": "0.3.40",
              "Node name for S&R": "ConditioningZeroOut"
            }
          }
        ],
        "groups": [
          {
            "id": 1,
            "title": "Model",
            "bounding": [
              -820,
              70,
              320,
              750
            ],
            "color": "#3f789e",
            "font_size": 24,
            "flags": {}
          },
          {
            "id": 2,
            "title": "Image Size",
            "bounding": [
              -470,
              570,
              380,
              250
            ],
            "color": "#3f789e",
            "font_size": 24,
            "flags": {}
          },
          {
            "id": 3,
            "title": "Prompt",
            "bounding": [
              -470,
              70,
              380,
              470
            ],
            "color": "#3f789e",
            "font_size": 24,
            "flags": {}
          }
        ],
        "links": [
          {
            "id": 52,
            "origin_id": 31,
            "origin_slot": 0,
            "target_id": 8,
            "target_slot": 0,
            "type": "LATENT"
          },
          {
            "id": 58,
            "origin_id": 39,
            "origin_slot": 0,
            "target_id": 8,
            "target_slot": 1,
            "type": "VAE"
          },
          {
            "id": 61,
            "origin_id": 38,
            "origin_slot": 0,
            "target_id": 31,
            "target_slot": 0,
            "type": "MODEL"
          },
          {
            "id": 63,
            "origin_id": 42,
            "origin_slot": 0,
            "target_id": 31,
            "target_slot": 2,
            "type": "CONDITIONING"
          },
          {
            "id": 51,
            "origin_id": 27,
            "origin_slot": 0,
            "target_id": 31,
            "target_slot": 3,
            "type": "LATENT"
          },
          {
            "id": 9,
            "origin_id": 8,
            "origin_slot": 0,
            "target_id": -20,
            "target_slot": 0,
            "type": "IMAGE"
          },
          {
            "id": 64,
            "origin_id": 40,
            "origin_slot": 0,
            "target_id": 45,
            "target_slot": 0,
            "type": "CLIP"
          },
          {
            "id": 65,
            "origin_id": 45,
            "origin_slot": 0,
            "target_id": 31,
            "target_slot": 1,
            "type": "CONDITIONING"
          },
          {
            "id": 66,
            "origin_id": 45,
            "origin_slot": 0,
            "target_id": 42,
            "target_slot": 0,
            "type": "CONDITIONING"
          },
          {
            "id": 68,
            "origin_id": -10,
            "origin_slot": 0,
            "target_id": 45,
            "target_slot": 1,
            "type": "STRING"
          },
          {
            "id": 69,
            "origin_id": -10,
            "origin_slot": 1,
            "target_id": 27,
            "target_slot": 0,
            "type": "INT"
          },
          {
            "id": 70,
            "origin_id": -10,
            "origin_slot": 2,
            "target_id": 27,
            "target_slot": 1,
            "type": "INT"
          },
          {
            "id": 382,
            "origin_id": -10,
            "origin_slot": 3,
            "target_id": 31,
            "target_slot": 4,
            "type": "INT"
          },
          {
            "id": 385,
            "origin_id": -10,
            "origin_slot": 4,
            "target_id": 38,
            "target_slot": 0,
            "type": "COMBO"
          },
          {
            "id": 386,
            "origin_id": -10,
            "origin_slot": 5,
            "target_id": 40,
            "target_slot": 0,
            "type": "COMBO"
          },
          {
            "id": 387,
            "origin_id": -10,
            "origin_slot": 6,
            "target_id": 40,
            "target_slot": 1,
            "type": "COMBO"
          },
          {
            "id": 388,
            "origin_id": -10,
            "origin_slot": 7,
            "target_id": 39,
            "target_slot": 0,
            "type": "COMBO"
          }
        ],
        "extra": {
          "workflowRendererVersion": "LG"
        },
        "category": "Image generation and editing/Text to image",
        "description": "Generates images from prompts using FLUX.1 [dev]: a 12B rectified-flow MMDiT with dual CLIP plus T5-XXL text encoders and guidance-distilled sampling for sharp prompt following versus classic DDPM diffusion."
      }
    ]
  },
  "extra": {
    "ds": {
      "scale": 0.7513148009015777,
      "offset": [
        1726.1426909346173,
        146.66925047394233
      ]
    },
    "ue_links": []
  }
}
```
