# 人物换装

- 来源类别：用户工作流
- 镜像内原始路径：`/ComfyUI/user/default/workflows/18个开源模型工作流/图片/人物换装.json`
- 节点数量：20
- 连线数量：25

## 节点类型

- `ImageScaleToTotalPixels` × 2
- `LoadImage` × 2
- `SaveImage` × 2
- `easy imageConcat` × 2
- `CFGNorm` × 1
- `CLIPLoader` × 1
- `ConditioningZeroOut` × 1
- `KSampler` × 1
- `LoraLoaderModelOnly` × 1
- `ModelSamplingAuraFlow` × 1
- `PrimitiveStringMultiline` × 1
- `TextEncodeQwenImageEditPlus` × 1
- `UNETLoader` × 1
- `VAEDecode` × 1
- `VAEEncode` × 1
- `VAELoader` × 1

## 工作流引用的模型或媒体文件

- `-V1.0-fp32-1c18194f7240.safetensors`
- `caled.safetensors`
- `qwen_image_edit_2511_bf16.safetensors`
- `qwen_image_vae.safetensors`

## 原始工作流 JSON

```json
{
  "id": "91f6bbe2-ed41-4fd6-bac7-71d5b5864ecb",
  "revision": 0,
  "last_node_id": 144,
  "last_link_id": 279,
  "nodes": [
    {
      "id": 136,
      "type": "UNETLoader",
      "pos": [
        -961.8116819714635,
        -263.59248438823244
      ],
      "size": [
        317.16497802734375,
        82
      ],
      "flags": {},
      "order": 0,
      "mode": 0,
      "inputs": [
        {
          "label": "unet_name",
          "name": "unet_name",
          "type": "COMBO",
          "widget": {
            "name": "unet_name"
          }
        },
        {
          "label": "weight_dtype",
          "name": "weight_dtype",
          "type": "COMBO",
          "widget": {
            "name": "weight_dtype"
          }
        }
      ],
      "outputs": [
        {
          "label": "MODEL",
          "name": "MODEL",
          "type": "MODEL",
          "links": [
            267
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.27.0",
        "Node name for S&R": "UNETLoader",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "qwen_image_edit_2511_bf16.safetensors",
        "default"
      ]
    },
    {
      "id": 131,
      "type": "LoraLoaderModelOnly",
      "pos": [
        -625.5446291149239,
        -257.9252311221008
      ],
      "size": [
        270,
        82
      ],
      "flags": {},
      "order": 6,
      "mode": 0,
      "inputs": [
        {
          "label": "model",
          "name": "model",
          "type": "MODEL",
          "link": 267
        },
        {
          "label": "lora_name",
          "name": "lora_name",
          "type": "COMBO",
          "widget": {
            "name": "lora_name"
          }
        },
        {
          "label": "strength_model",
          "name": "strength_model",
          "type": "FLOAT",
          "widget": {
            "name": "strength_model"
          }
        }
      ],
      "outputs": [
        {
          "label": "MODEL",
          "name": "MODEL",
          "type": "MODEL",
          "links": [
            266
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.59",
        "Node name for S&R": "LoraLoaderModelOnly",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "Qwen-Image-Edit-2511-Lightning-4steps-V1.0-fp32-1c18194f7240.safetensors",
        1
      ]
    },
    {
      "id": 38,
      "type": "CLIPLoader",
      "pos": [
        -964.3866732976902,
        -130.66007057248999
      ],
      "size": [
        330,
        110
      ],
      "flags": {},
      "order": 1,
      "mode": 0,
      "inputs": [
        {
          "label": "clip_name",
          "name": "clip_name",
          "type": "COMBO",
          "widget": {
            "name": "clip_name"
          }
        },
        {
          "label": "type",
          "name": "type",
          "type": "COMBO",
          "widget": {
            "name": "type"
          }
        },
        {
          "label": "device",
          "name": "device",
          "shape": 7,
          "type": "COMBO",
          "widget": {
            "name": "device"
          }
        }
      ],
      "outputs": [
        {
          "label": "CLIP",
          "name": "CLIP",
          "type": "CLIP",
          "slot_index": 0,
          "links": [
            248
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.48",
        "Node name for S&R": "CLIPLoader",
        "hasSecondTab": false,
        "models": [
          {
            "directory_invalid": true,
            "name": "qwen_2.5_vl_7b_fp8_scaled.safetensors",
            "directory": "text_encoders",
            "url": "https://huggingface.co/Comfy-Org/Qwen-Image_ComfyUI/resolve/main/split_files/text_encoders/qwen_2.5_vl_7b_fp8_scaled.safetensors"
          }
        ],
        "widget_ue_connectable": {},
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": [
        "qwen_2.5_vl_7b_fp8_scaled.safetensors",
        "qwen_image",
        "default"
      ]
    },
    {
      "id": 39,
      "type": "VAELoader",
      "pos": [
        -959.5028224128212,
        29.35256006001537
      ],
      "size": [
        330,
        60
      ],
      "flags": {},
      "order": 2,
      "mode": 0,
      "inputs": [
        {
          "label": "vae_name",
          "name": "vae_name",
          "type": "COMBO",
          "widget": {
            "name": "vae_name"
          }
        }
      ],
      "outputs": [
        {
          "label": "VAE",
          "name": "VAE",
          "type": "VAE",
          "slot_index": 0,
          "links": [
            76,
            168,
            249
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.48",
        "Node name for S&R": "VAELoader",
        "hasSecondTab": false,
        "models": [
          {
            "directory_invalid": true,
            "name": "qwen_image_vae.safetensors",
            "directory": "vae",
            "url": "https://huggingface.co/Comfy-Org/Qwen-Image_ComfyUI/resolve/main/split_files/vae/qwen_image_vae.safetensors"
          }
        ],
        "widget_ue_connectable": {},
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": [
        "qwen_image_vae.safetensors"
      ]
    },
    {
      "id": 140,
      "type": "ImageScaleToTotalPixels",
      "pos": [
        -957.5299968021199,
        136.0473888271647
      ],
      "size": [
        328.2516669919439,
        106
      ],
      "flags": {},
      "order": 7,
      "mode": 0,
      "inputs": [
        {
          "label": "image",
          "name": "image",
          "type": "IMAGE",
          "link": 272
        },
        {
          "label": "upscale_method",
          "name": "upscale_method",
          "type": "COMBO",
          "widget": {
            "name": "upscale_method"
          }
        },
        {
          "label": "megapixels",
          "name": "megapixels",
          "type": "FLOAT",
          "widget": {
            "name": "megapixels"
          }
        },
        {
          "label": "resolution_steps",
          "name": "resolution_steps",
          "type": "INT",
          "widget": {
            "name": "resolution_steps"
          }
        }
      ],
      "outputs": [
        {
          "label": "IMAGE",
          "name": "IMAGE",
          "type": "IMAGE",
          "links": [
            273,
            276
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.50",
        "Node name for S&R": "ImageScaleToTotalPixels",
        "hasSecondTab": false,
        "ue_properties": {
          "widget_ue_connectable": {
            "megapixels": true,
            "upscale_method": true
          }
        },
        "widget_ue_connectable": {
          "megapixels": true,
          "upscale_method": true
        },
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": [
        "lanczos",
        1,
        1
      ]
    },
    {
      "id": 139,
      "type": "LoadImage",
      "pos": [
        -1373.720003632433,
        -264.0367997489907
      ],
      "size": [
        328.5917053222656,
        314
      ],
      "flags": {},
      "order": 3,
      "mode": 0,
      "inputs": [
        {
          "label": "image",
          "name": "image",
          "type": "COMBO",
          "widget": {
            "name": "image"
          }
        },
        {
          "label": "upload",
          "name": "upload",
          "type": "IMAGEUPLOAD",
          "widget": {
            "name": "upload"
          }
        }
      ],
      "outputs": [
        {
          "label": "IMAGE",
          "name": "IMAGE",
          "type": "IMAGE",
          "links": [
            272
          ]
        },
        {
          "label": "MASK",
          "name": "MASK",
          "type": "MASK"
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.50",
        "Node name for S&R": "LoadImage",
        "hasSecondTab": false,
        "ue_properties": {
          "widget_ue_connectable": {
            "image": true,
            "upload": true
          }
        },
        "widget_ue_connectable": {
          "image": true,
          "upload": true
        },
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": [
        "u=3566879136,4171000737&fm=253&app=138&f=JPEG.jpg",
        "image"
      ]
    },
    {
      "id": 133,
      "type": "PrimitiveStringMultiline",
      "pos": [
        -1706.9370975273878,
        121.55035402473735
      ],
      "size": [
        318.67527318134626,
        116.96364249628323
      ],
      "flags": {},
      "order": 4,
      "mode": 0,
      "inputs": [
        {
          "label": "value",
          "name": "value",
          "type": "STRING",
          "widget": {
            "name": "value"
          }
        }
      ],
      "outputs": [
        {
          "label": "STRING",
          "name": "STRING",
          "type": "STRING",
          "links": [
            274
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.57",
        "Node name for S&R": "PrimitiveStringMultiline",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "让图一的人物换上图二的衣服服饰 确保比例正确 衣服合身 可以适当修改构图 以及摄像机景别 保证画面中的 人物 比例正确 衣服展示完整 "
      ],
      "color": "#232",
      "bgcolor": "#353"
    },
    {
      "id": 93,
      "type": "ImageScaleToTotalPixels",
      "pos": [
        -953.8355781935153,
        290.6022068079161
      ],
      "size": [
        321.3701288526206,
        106
      ],
      "flags": {},
      "order": 8,
      "mode": 0,
      "inputs": [
        {
          "label": "image",
          "name": "image",
          "type": "IMAGE",
          "link": 177
        },
        {
          "label": "upscale_method",
          "name": "upscale_method",
          "type": "COMBO",
          "widget": {
            "name": "upscale_method"
          }
        },
        {
          "label": "megapixels",
          "name": "megapixels",
          "type": "FLOAT",
          "widget": {
            "name": "megapixels"
          }
        },
        {
          "label": "resolution_steps",
          "name": "resolution_steps",
          "type": "INT",
          "widget": {
            "name": "resolution_steps"
          }
        }
      ],
      "outputs": [
        {
          "label": "IMAGE",
          "name": "IMAGE",
          "type": "IMAGE",
          "links": [
            178,
            250,
            275
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.50",
        "Node name for S&R": "ImageScaleToTotalPixels",
        "hasSecondTab": false,
        "ue_properties": {
          "widget_ue_connectable": {
            "megapixels": true,
            "upscale_method": true
          }
        },
        "widget_ue_connectable": {
          "megapixels": true,
          "upscale_method": true
        },
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": [
        "lanczos",
        1,
        1
      ]
    },
    {
      "id": 75,
      "type": "CFGNorm",
      "pos": [
        -625.2781942195182,
        -120.73060799823104
      ],
      "size": [
        272.2284137647157,
        82
      ],
      "flags": {},
      "order": 13,
      "mode": 0,
      "inputs": [
        {
          "label": "model",
          "name": "model",
          "type": "MODEL",
          "link": 141
        },
        {
          "label": "strength",
          "name": "strength",
          "type": "FLOAT",
          "widget": {
            "name": "strength"
          }
        }
      ],
      "outputs": [
        {
          "label": "patched_model",
          "name": "patched_model",
          "type": "MODEL",
          "links": [
            186
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.50",
        "Node name for S&R": "CFGNorm",
        "hasSecondTab": false,
        "ue_properties": {
          "widget_ue_connectable": {
            "strength": true
          }
        },
        "widget_ue_connectable": {
          "strength": true
        },
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": [
        1,
        false
      ]
    },
    {
      "id": 66,
      "type": "ModelSamplingAuraFlow",
      "pos": [
        -626.4364739061944,
        9.450332707267258
      ],
      "size": [
        275.43124004386095,
        58
      ],
      "flags": {},
      "order": 9,
      "mode": 0,
      "inputs": [
        {
          "label": "model",
          "name": "model",
          "type": "MODEL",
          "link": 266
        },
        {
          "label": "shift",
          "name": "shift",
          "type": "FLOAT",
          "widget": {
            "name": "shift"
          }
        }
      ],
      "outputs": [
        {
          "label": "MODEL",
          "name": "MODEL",
          "type": "MODEL",
          "links": [
            141
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.48",
        "Node name for S&R": "ModelSamplingAuraFlow",
        "hasSecondTab": false,
        "widget_ue_connectable": {},
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": [
        3
      ]
    },
    {
      "id": 129,
      "type": "TextEncodeQwenImageEditPlus",
      "pos": [
        -624.4621656763186,
        117.37447614587067
      ],
      "size": [
        272.5199777711757,
        168
      ],
      "flags": {},
      "order": 11,
      "mode": 0,
      "inputs": [
        {
          "label": "clip",
          "name": "clip",
          "type": "CLIP",
          "link": 248
        },
        {
          "label": "vae",
          "name": "vae",
          "shape": 7,
          "type": "VAE",
          "link": 249
        },
        {
          "label": "image1",
          "name": "image1",
          "shape": 7,
          "type": "IMAGE",
          "link": 250
        },
        {
          "label": "image2",
          "name": "image2",
          "shape": 7,
          "type": "IMAGE",
          "link": 273
        },
        {
          "label": "image3",
          "name": "image3",
          "shape": 7,
          "type": "IMAGE"
        },
        {
          "label": "prompt",
          "name": "prompt",
          "type": "STRING",
          "widget": {
            "name": "prompt"
          },
          "link": 274
        }
      ],
      "outputs": [
        {
          "label": "CONDITIONING",
          "name": "CONDITIONING",
          "type": "CONDITIONING",
          "links": [
            252,
            268
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.59",
        "Node name for S&R": "TextEncodeQwenImageEditPlus",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        ""
      ]
    },
    {
      "id": 88,
      "type": "VAEEncode",
      "pos": [
        -618.9518724486281,
        334.03451485417315
      ],
      "size": [
        267.3938213306701,
        52.650687447752716
      ],
      "flags": {},
      "order": 10,
      "mode": 0,
      "inputs": [
        {
          "label": "pixels",
          "name": "pixels",
          "type": "IMAGE",
          "link": 178
        },
        {
          "label": "vae",
          "name": "vae",
          "type": "VAE",
          "link": 168
        }
      ],
      "outputs": [
        {
          "label": "LATENT",
          "name": "LATENT",
          "type": "LATENT",
          "links": [
            253
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.50",
        "Node name for S&R": "VAEEncode",
        "hasSecondTab": false,
        "ue_properties": {
          "widget_ue_connectable": {}
        },
        "widget_ue_connectable": {},
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": []
    },
    {
      "id": 113,
      "type": "ConditioningZeroOut",
      "pos": [
        -953.6242751982405,
        440.33085293210956
      ],
      "size": [
        320.32376218182355,
        35.531181922683345
      ],
      "flags": {},
      "order": 14,
      "mode": 0,
      "inputs": [
        {
          "label": "conditioning",
          "name": "conditioning",
          "type": "CONDITIONING",
          "link": 252
        }
      ],
      "outputs": [
        {
          "label": "CONDITIONING",
          "name": "CONDITIONING",
          "type": "CONDITIONING",
          "links": [
            205
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.57",
        "Node name for S&R": "ConditioningZeroOut",
        "widget_ue_connectable": {}
      },
      "widgets_values": []
    },
    {
      "id": 8,
      "type": "VAEDecode",
      "pos": [
        -616.3510166961253,
        443.54698282260836
      ],
      "size": [
        262.7963503658175,
        46
      ],
      "flags": {
        "collapsed": false
      },
      "order": 16,
      "mode": 0,
      "inputs": [
        {
          "label": "samples",
          "name": "samples",
          "type": "LATENT",
          "link": 128
        },
        {
          "label": "vae",
          "name": "vae",
          "type": "VAE",
          "link": 76
        }
      ],
      "outputs": [
        {
          "label": "IMAGE",
          "name": "IMAGE",
          "type": "IMAGE",
          "slot_index": 0,
          "links": [
            110,
            277
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.48",
        "Node name for S&R": "VAEDecode",
        "hasSecondTab": false,
        "widget_ue_connectable": {},
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": []
    },
    {
      "id": 3,
      "type": "KSampler",
      "pos": [
        -336.8819037673061,
        -238.5741809182918
      ],
      "size": [
        365.0173034667969,
        491.39898681640625
      ],
      "flags": {},
      "order": 15,
      "mode": 0,
      "inputs": [
        {
          "label": "model",
          "name": "model",
          "type": "MODEL",
          "link": 186
        },
        {
          "label": "positive",
          "name": "positive",
          "type": "CONDITIONING",
          "link": 268
        },
        {
          "label": "negative",
          "name": "negative",
          "type": "CONDITIONING",
          "link": 205
        },
        {
          "label": "latent_image",
          "name": "latent_image",
          "type": "LATENT",
          "link": 253
        },
        {
          "label": "seed",
          "name": "seed",
          "type": "INT",
          "widget": {
            "name": "seed"
          }
        },
        {
          "label": "steps",
          "name": "steps",
          "type": "INT",
          "widget": {
            "name": "steps"
          }
        },
        {
          "label": "cfg",
          "name": "cfg",
          "type": "FLOAT",
          "widget": {
            "name": "cfg"
          }
        },
        {
          "label": "sampler_name",
          "name": "sampler_name",
          "type": "COMBO",
          "widget": {
            "name": "sampler_name"
          }
        },
        {
          "label": "scheduler",
          "name": "scheduler",
          "type": "COMBO",
          "widget": {
            "name": "scheduler"
          }
        },
        {
          "label": "denoise",
          "name": "denoise",
          "type": "FLOAT",
          "widget": {
            "name": "denoise"
          }
        }
      ],
      "outputs": [
        {
          "label": "LATENT",
          "name": "LATENT",
          "type": "LATENT",
          "slot_index": 0,
          "links": [
            128
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.48",
        "Node name for S&R": "KSampler",
        "hasSecondTab": false,
        "widget_ue_connectable": {},
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": [
        704822774765022,
        "randomize",
        4,
        1,
        "euler",
        "simple",
        1
      ]
    },
    {
      "id": 142,
      "type": "easy imageConcat",
      "pos": [
        49.86144089985699,
        -221.72582339926865
      ],
      "size": [
        270,
        102
      ],
      "flags": {},
      "order": 12,
      "mode": 0,
      "inputs": [
        {
          "label": "image1",
          "name": "image1",
          "type": "IMAGE",
          "link": 275
        },
        {
          "label": "image2",
          "name": "image2",
          "type": "IMAGE",
          "link": 276
        },
        {
          "label": "direction",
          "name": "direction",
          "type": "COMBO",
          "widget": {
            "name": "direction"
          }
        },
        {
          "label": "match_image_size",
          "name": "match_image_size",
          "type": "BOOLEAN",
          "widget": {
            "name": "match_image_size"
          }
        }
      ],
      "outputs": [
        {
          "label": "IMAGE",
          "name": "IMAGE",
          "type": "IMAGE",
          "links": [
            278
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "easy imageConcat",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "down",
        true
      ]
    },
    {
      "id": 143,
      "type": "easy imageConcat",
      "pos": [
        49.067380408507894,
        -71.40718316870655
      ],
      "size": [
        270,
        102
      ],
      "flags": {},
      "order": 18,
      "mode": 0,
      "inputs": [
        {
          "label": "image1",
          "name": "image1",
          "type": "IMAGE",
          "link": 278
        },
        {
          "label": "image2",
          "name": "image2",
          "type": "IMAGE",
          "link": 277
        },
        {
          "label": "direction",
          "name": "direction",
          "type": "COMBO",
          "widget": {
            "name": "direction"
          }
        },
        {
          "label": "match_image_size",
          "name": "match_image_size",
          "type": "BOOLEAN",
          "widget": {
            "name": "match_image_size"
          }
        }
      ],
      "outputs": [
        {
          "label": "IMAGE",
          "name": "IMAGE",
          "type": "IMAGE",
          "links": [
            279
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "easy imageConcat",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "right",
        true
      ]
    },
    {
      "id": 60,
      "type": "SaveImage",
      "pos": [
        341.695501017928,
        -214.14746657693448
      ],
      "size": [
        351.06591796875,
        467.7684020996094
      ],
      "flags": {},
      "order": 17,
      "mode": 0,
      "inputs": [
        {
          "label": "images",
          "name": "images",
          "type": "IMAGE",
          "link": 110
        },
        {
          "label": "filename_prefix",
          "name": "filename_prefix",
          "type": "STRING",
          "widget": {
            "name": "filename_prefix"
          }
        }
      ],
      "outputs": [
        {
          "label": "image_urls",
          "name": "images",
          "type": "IMAGE"
        },
        {
          "label": "images",
          "name": "images",
          "type": "IMAGE",
          "links": null
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.48",
        "Node name for S&R": "SaveImage",
        "hasSecondTab": false,
        "widget_ue_connectable": {},
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": [
        "ComfyUI"
      ]
    },
    {
      "id": 144,
      "type": "SaveImage",
      "pos": [
        716.5983913111671,
        -200.10374053710942
      ],
      "size": [
        350.6666564941406,
        568.888916015625
      ],
      "flags": {},
      "order": 19,
      "mode": 0,
      "inputs": [
        {
          "label": "images",
          "name": "images",
          "type": "IMAGE",
          "link": 279
        },
        {
          "label": "filename_prefix",
          "name": "filename_prefix",
          "type": "STRING",
          "widget": {
            "name": "filename_prefix"
          }
        }
      ],
      "outputs": [
        {
          "label": "image_urls",
          "name": "images",
          "type": "IMAGE"
        },
        {
          "label": "images",
          "name": "images",
          "type": "IMAGE",
          "links": null
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.27.0",
        "Node name for S&R": "SaveImage",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "ComfyUI"
      ]
    },
    {
      "id": 78,
      "type": "LoadImage",
      "pos": [
        -1717.701360269417,
        -268.04527960716564
      ],
      "size": [
        328.5917053222656,
        314
      ],
      "flags": {},
      "order": 5,
      "mode": 0,
      "inputs": [
        {
          "label": "image",
          "name": "image",
          "type": "COMBO",
          "widget": {
            "name": "image"
          }
        },
        {
          "label": "upload",
          "name": "upload",
          "type": "IMAGEUPLOAD",
          "widget": {
            "name": "upload"
          }
        }
      ],
      "outputs": [
        {
          "label": "IMAGE",
          "name": "IMAGE",
          "type": "IMAGE",
          "links": [
            177
          ]
        },
        {
          "label": "MASK",
          "name": "MASK",
          "type": "MASK"
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.50",
        "Node name for S&R": "LoadImage",
        "hasSecondTab": false,
        "ue_properties": {
          "widget_ue_connectable": {
            "image": true,
            "upload": true
          }
        },
        "widget_ue_connectable": {
          "image": true,
          "upload": true
        },
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": [
        "居家黑白吊带少女CCD风写真.jpg",
        "image"
      ]
    }
  ],
  "links": [
    [
      76,
      39,
      0,
      8,
      1,
      "VAE"
    ],
    [
      110,
      8,
      0,
      60,
      0,
      "IMAGE"
    ],
    [
      128,
      3,
      0,
      8,
      0,
      "LATENT"
    ],
    [
      141,
      66,
      0,
      75,
      0,
      "MODEL"
    ],
    [
      168,
      39,
      0,
      88,
      1,
      "VAE"
    ],
    [
      177,
      78,
      0,
      93,
      0,
      "IMAGE"
    ],
    [
      178,
      93,
      0,
      88,
      0,
      "IMAGE"
    ],
    [
      186,
      75,
      0,
      3,
      0,
      "MODEL"
    ],
    [
      205,
      113,
      0,
      3,
      2,
      "CONDITIONING"
    ],
    [
      248,
      38,
      0,
      129,
      0,
      "CLIP"
    ],
    [
      249,
      39,
      0,
      129,
      1,
      "VAE"
    ],
    [
      250,
      93,
      0,
      129,
      2,
      "IMAGE"
    ],
    [
      252,
      129,
      0,
      113,
      0,
      "CONDITIONING"
    ],
    [
      253,
      88,
      0,
      3,
      3,
      "LATENT"
    ],
    [
      266,
      131,
      0,
      66,
      0,
      "MODEL"
    ],
    [
      267,
      136,
      0,
      131,
      0,
      "MODEL"
    ],
    [
      268,
      129,
      0,
      3,
      1,
      "CONDITIONING"
    ],
    [
      272,
      139,
      0,
      140,
      0,
      "IMAGE"
    ],
    [
      273,
      140,
      0,
      129,
      3,
      "IMAGE"
    ],
    [
      274,
      133,
      0,
      129,
      5,
      "STRING"
    ],
    [
      275,
      93,
      0,
      142,
      0,
      "IMAGE"
    ],
    [
      276,
      140,
      0,
      142,
      1,
      "IMAGE"
    ],
    [
      277,
      8,
      0,
      143,
      1,
      "IMAGE"
    ],
    [
      278,
      142,
      0,
      143,
      0,
      "IMAGE"
    ],
    [
      279,
      143,
      0,
      144,
      0,
      "IMAGE"
    ]
  ],
  "groups": [
    {
      "id": 6,
      "title": "参考图+服饰图+提示词",
      "bounding": [
        -1735.9988591871238,
        -359.3764781791146,
        730.5220689180333,
        636.6122488926279
      ],
      "color": "#3f789e",
      "flags": {}
    },
    {
      "id": 9,
      "title": "生成区",
      "bounding": [
        -981.3506469726562,
        -362.7677917480469,
        2090.7674741851934,
        876.9604934518572
      ],
      "color": "#3f789e",
      "flags": {}
    }
  ],
  "config": {},
  "extra": {
    "links_added_by_ue": [],
    "VHS_KeepIntermediate": true,
    "ue_links": [],
    "VHS_MetadataImage": true,
    "0246.VERSION": [
      0,
      0,
      4
    ],
    "VHS_latentpreviewrate": 0,
    "frontendVersion": "1.45.20",
    "VHS_latentpreview": false,
    "ds": {
      "scale": 0.6588450000000031,
      "offset": [
        2285.8555293781455,
        888.3820485272892
      ]
    }
  },
  "version": 0.4
}
```
