# 照片换脸

- 来源类别：用户工作流
- 镜像内原始路径：`/ComfyUI/user/default/workflows/18个开源模型工作流/图片/照片换脸.json`
- 节点数量：22
- 连线数量：28

## 节点类型

- `ReferenceLatent` × 4
- `CLIPTextEncode` × 2
- `ImageResizeKJv2` × 2
- `LoadImage` × 2
- `VAEEncode` × 2
- `CLIPLoader` × 1
- `EmptyFlux2LatentImage` × 1
- `KSampler` × 1
- `OnnxDetectionModelLoader` × 1
- `PoseAndFaceDetection` × 1
- `PreviewImage` × 1
- `SaveImage` × 1
- `UNETLoader` × 1
- `VAEDecode` × 1
- `VAELoader` × 1

## 工作流引用的模型或媒体文件

- `FLUX.2-klein-9b-fp8/flux-2-klein-9b-fp8.safetensors`
- `e-l-wholebody.onnx`
- `flux2-vae.safetensors`
- `qwen_3_8b_fp8mixed.safetensors`
- `yolov10m.onnx`

## 原始工作流 JSON

```json
{
  "id": "f6ca6fcf-dcc1-4184-9b15-7baa3c29acc3",
  "revision": 0,
  "last_node_id": 76,
  "last_link_id": 131,
  "nodes": [
    {
      "id": 54,
      "type": "VAEEncode",
      "pos": [
        3410,
        -1710
      ],
      "size": [
        210,
        46
      ],
      "flags": {},
      "order": 10,
      "mode": 0,
      "inputs": [
        {
          "label": "pixels",
          "name": "pixels",
          "type": "IMAGE",
          "link": 99
        },
        {
          "label": "vae",
          "name": "vae",
          "type": "VAE",
          "link": 100
        }
      ],
      "outputs": [
        {
          "label": "LATENT",
          "name": "LATENT",
          "type": "LATENT",
          "links": [
            96,
            98
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.27.0",
        "Node name for S&R": "VAEEncode",
        "hasSecondTab": false,
        "widget_ue_connectable": {},
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": []
    },
    {
      "id": 53,
      "type": "VAELoader",
      "pos": [
        3084.260412065059,
        -1817.7041984732327
      ],
      "size": [
        315,
        58
      ],
      "flags": {},
      "order": 0,
      "mode": 0,
      "inputs": [
        {
          "label": "vae_name",
          "name": "vae_name",
          "type": "COMBO",
          "widget": {
            "name": "vae_name"
          }
        }
      ],
      "outputs": [
        {
          "label": "VAE",
          "name": "VAE",
          "type": "VAE",
          "links": [
            100,
            106,
            116
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.27.0",
        "Node name for S&R": "VAELoader",
        "hasSecondTab": false,
        "widget_ue_connectable": {},
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": [
        "flux2-vae.safetensors"
      ]
    },
    {
      "id": 62,
      "type": "ImageResizeKJv2",
      "pos": [
        3550,
        -1310
      ],
      "size": [
        315,
        336
      ],
      "flags": {},
      "order": 15,
      "mode": 0,
      "inputs": [
        {
          "label": "image",
          "name": "image",
          "type": "IMAGE",
          "link": 131
        },
        {
          "label": "mask",
          "name": "mask",
          "shape": 7,
          "type": "MASK"
        },
        {
          "label": "width",
          "name": "width",
          "type": "INT",
          "widget": {
            "name": "width"
          }
        },
        {
          "label": "height",
          "name": "height",
          "type": "INT",
          "widget": {
            "name": "height"
          }
        },
        {
          "label": "upscale_method",
          "name": "upscale_method",
          "type": "COMBO",
          "widget": {
            "name": "upscale_method"
          }
        },
        {
          "label": "keep_proportion",
          "name": "keep_proportion",
          "type": "COMBO",
          "widget": {
            "name": "keep_proportion"
          }
        },
        {
          "label": "pad_color",
          "name": "pad_color",
          "type": "STRING",
          "widget": {
            "name": "pad_color"
          }
        },
        {
          "label": "crop_position",
          "name": "crop_position",
          "type": "COMBO",
          "widget": {
            "name": "crop_position"
          }
        },
        {
          "label": "divisible_by",
          "name": "divisible_by",
          "type": "INT",
          "widget": {
            "name": "divisible_by"
          }
        },
        {
          "label": "device",
          "name": "device",
          "shape": 7,
          "type": "COMBO",
          "widget": {
            "name": "device"
          }
        }
      ],
      "outputs": [
        {
          "label": "IMAGE",
          "name": "IMAGE",
          "type": "IMAGE",
          "links": [
            115
          ]
        },
        {
          "label": "width",
          "name": "width",
          "type": "INT"
        },
        {
          "label": "height",
          "name": "height",
          "type": "INT"
        },
        {
          "label": "mask",
          "name": "mask",
          "type": "MASK"
        }
      ],
      "properties": {
        "Node name for S&R": "ImageResizeKJv2",
        "hasSecondTab": false,
        "widget_ue_connectable": {},
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": [
        1024,
        1024,
        "lanczos",
        "resize",
        "0, 0, 0",
        "center",
        2,
        "cpu"
      ]
    },
    {
      "id": 49,
      "type": "CLIPTextEncode",
      "pos": [
        3640,
        -1700
      ],
      "size": [
        400,
        200
      ],
      "flags": {
        "collapsed": true
      },
      "order": 7,
      "mode": 0,
      "inputs": [
        {
          "label": "clip",
          "name": "clip",
          "type": "CLIP",
          "link": 94
        },
        {
          "label": "text",
          "name": "text",
          "type": "STRING",
          "widget": {
            "name": "text"
          }
        }
      ],
      "outputs": [
        {
          "label": "CONDITIONING",
          "name": "CONDITIONING",
          "type": "CONDITIONING",
          "links": [
            97
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.27.0",
        "Node name for S&R": "CLIPTextEncode",
        "hasSecondTab": false,
        "widget_ue_connectable": {},
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": [
        ""
      ]
    },
    {
      "id": 63,
      "type": "VAEEncode",
      "pos": [
        3410,
        -1460
      ],
      "size": [
        210,
        46
      ],
      "flags": {},
      "order": 16,
      "mode": 0,
      "inputs": [
        {
          "label": "pixels",
          "name": "pixels",
          "type": "IMAGE",
          "link": 115
        },
        {
          "label": "vae",
          "name": "vae",
          "type": "VAE",
          "link": 116
        }
      ],
      "outputs": [
        {
          "label": "LATENT",
          "name": "LATENT",
          "type": "LATENT",
          "links": [
            110,
            112
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.27.0",
        "Node name for S&R": "VAEEncode",
        "hasSecondTab": false,
        "widget_ue_connectable": {},
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": []
    },
    {
      "id": 50,
      "type": "ReferenceLatent",
      "pos": [
        3640,
        -1660
      ],
      "size": [
        211.60000610351562,
        46
      ],
      "flags": {
        "collapsed": true
      },
      "order": 13,
      "mode": 0,
      "inputs": [
        {
          "label": "conditioning",
          "name": "conditioning",
          "type": "CONDITIONING",
          "link": 95
        },
        {
          "label": "latent",
          "name": "latent",
          "shape": 7,
          "type": "LATENT",
          "link": 96
        }
      ],
      "outputs": [
        {
          "label": "CONDITIONING",
          "name": "CONDITIONING",
          "type": "CONDITIONING",
          "links": [
            109
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.27.0",
        "Node name for S&R": "ReferenceLatent",
        "hasSecondTab": false,
        "widget_ue_connectable": {},
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": []
    },
    {
      "id": 59,
      "type": "ReferenceLatent",
      "pos": [
        3640,
        -1630
      ],
      "size": [
        211.60000610351562,
        46
      ],
      "flags": {
        "collapsed": true
      },
      "order": 17,
      "mode": 0,
      "inputs": [
        {
          "label": "conditioning",
          "name": "conditioning",
          "type": "CONDITIONING",
          "link": 109
        },
        {
          "label": "latent",
          "name": "latent",
          "shape": 7,
          "type": "LATENT",
          "link": 110
        }
      ],
      "outputs": [
        {
          "label": "CONDITIONING",
          "name": "CONDITIONING",
          "type": "CONDITIONING",
          "links": [
            102
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.27.0",
        "Node name for S&R": "ReferenceLatent",
        "hasSecondTab": false,
        "widget_ue_connectable": {},
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": []
    },
    {
      "id": 51,
      "type": "ReferenceLatent",
      "pos": [
        3640,
        -1590
      ],
      "size": [
        211.60000610351562,
        46
      ],
      "flags": {
        "collapsed": true
      },
      "order": 14,
      "mode": 0,
      "inputs": [
        {
          "label": "conditioning",
          "name": "conditioning",
          "type": "CONDITIONING",
          "link": 97
        },
        {
          "label": "latent",
          "name": "latent",
          "shape": 7,
          "type": "LATENT",
          "link": 98
        }
      ],
      "outputs": [
        {
          "label": "CONDITIONING",
          "name": "CONDITIONING",
          "type": "CONDITIONING",
          "links": [
            111
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.27.0",
        "Node name for S&R": "ReferenceLatent",
        "hasSecondTab": false,
        "widget_ue_connectable": {},
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": []
    },
    {
      "id": 60,
      "type": "ReferenceLatent",
      "pos": [
        3640,
        -1550
      ],
      "size": [
        211.60000610351562,
        46
      ],
      "flags": {
        "collapsed": true
      },
      "order": 18,
      "mode": 0,
      "inputs": [
        {
          "label": "conditioning",
          "name": "conditioning",
          "type": "CONDITIONING",
          "link": 111
        },
        {
          "label": "latent",
          "name": "latent",
          "shape": 7,
          "type": "LATENT",
          "link": 112
        }
      ],
      "outputs": [
        {
          "label": "CONDITIONING",
          "name": "CONDITIONING",
          "type": "CONDITIONING",
          "links": [
            103
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.27.0",
        "Node name for S&R": "ReferenceLatent",
        "hasSecondTab": false,
        "widget_ue_connectable": {},
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": []
    },
    {
      "id": 57,
      "type": "EmptyFlux2LatentImage",
      "pos": [
        3410,
        -1610
      ],
      "size": [
        210,
        106
      ],
      "flags": {},
      "order": 11,
      "mode": 0,
      "inputs": [
        {
          "label": "width",
          "name": "width",
          "type": "INT",
          "widget": {
            "name": "width"
          },
          "link": 107
        },
        {
          "label": "height",
          "name": "height",
          "type": "INT",
          "widget": {
            "name": "height"
          },
          "link": 108
        },
        {
          "label": "batch_size",
          "name": "batch_size",
          "type": "INT",
          "widget": {
            "name": "batch_size"
          }
        }
      ],
      "outputs": [
        {
          "label": "LATENT",
          "name": "LATENT",
          "type": "LATENT",
          "links": [
            104
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.27.0",
        "Node name for S&R": "EmptyFlux2LatentImage",
        "hasSecondTab": false,
        "widget_ue_connectable": {
          "width": true,
          "height": true
        },
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": [
        1024,
        1536,
        1
      ]
    },
    {
      "id": 56,
      "type": "VAEDecode",
      "pos": [
        3640,
        -1500
      ],
      "size": [
        140,
        46
      ],
      "flags": {},
      "order": 20,
      "mode": 0,
      "inputs": [
        {
          "label": "samples",
          "name": "samples",
          "type": "LATENT",
          "link": 105
        },
        {
          "label": "vae",
          "name": "vae",
          "type": "VAE",
          "link": 106
        }
      ],
      "outputs": [
        {
          "label": "IMAGE",
          "name": "IMAGE",
          "type": "IMAGE",
          "links": [
            119
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.27.0",
        "Node name for S&R": "VAEDecode",
        "hasSecondTab": false,
        "widget_ue_connectable": {},
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": []
    },
    {
      "id": 76,
      "type": "PreviewImage",
      "pos": [
        3390,
        -1310
      ],
      "size": [
        140,
        246
      ],
      "flags": {},
      "order": 12,
      "mode": 0,
      "inputs": [
        {
          "name": "images",
          "type": "IMAGE",
          "link": 130
        }
      ],
      "outputs": [
        {
          "name": "images",
          "type": "IMAGE",
          "links": [
            131
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.27.0",
        "Node name for S&R": "PreviewImage"
      },
      "widgets_values": []
    },
    {
      "id": 70,
      "type": "LoadImage",
      "pos": [
        2710.078058734137,
        -1784.3901949280637
      ],
      "size": [
        330.55023193359375,
        417.1516418457031
      ],
      "flags": {},
      "order": 1,
      "mode": 0,
      "inputs": [
        {
          "label": "image",
          "name": "image",
          "type": "COMBO",
          "widget": {
            "name": "image"
          }
        },
        {
          "label": "upload",
          "name": "upload",
          "type": "IMAGEUPLOAD",
          "widget": {
            "name": "upload"
          }
        }
      ],
      "outputs": [
        {
          "label": "IMAGE",
          "name": "IMAGE",
          "type": "IMAGE",
          "links": [
            113
          ]
        },
        {
          "label": "MASK",
          "name": "MASK",
          "type": "MASK"
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.27.0",
        "Node name for S&R": "LoadImage",
        "hasSecondTab": false,
        "widget_ue_connectable": {},
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": [
        "居家黑白吊带少女CCD风写真.jpg",
        "image"
      ]
    },
    {
      "id": 66,
      "type": "CLIPTextEncode",
      "pos": [
        3640,
        -1400
      ],
      "size": [
        400,
        200
      ],
      "flags": {
        "collapsed": true
      },
      "order": 8,
      "mode": 0,
      "inputs": [
        {
          "label": "clip",
          "name": "clip",
          "type": "CLIP",
          "link": 118
        },
        {
          "label": "text",
          "name": "text",
          "type": "STRING",
          "widget": {
            "name": "text"
          }
        }
      ],
      "outputs": [
        {
          "label": "CONDITIONING",
          "name": "CONDITIONING",
          "type": "CONDITIONING",
          "links": [
            95
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.27.0",
        "Node name for S&R": "CLIPTextEncode",
        "hasSecondTab": false,
        "widget_ue_connectable": {},
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": [
        "将图2的脸部自然地移植到图1人物头部，保留图1人物的发型、身体、服装、配饰、背景、光影、色彩、动作妆容 以及整体氛围不做任何修改 并确保生成结果中人物的面部光影 肤色 妆容都要保持和图1中的人物一致"
      ],
      "color": "#232",
      "bgcolor": "#353"
    },
    {
      "id": 71,
      "type": "LoadImage",
      "pos": [
        2720,
        -1310
      ],
      "size": [
        330.55023193359375,
        417.1516418457031
      ],
      "flags": {},
      "order": 2,
      "mode": 0,
      "inputs": [
        {
          "label": "image",
          "name": "image",
          "type": "COMBO",
          "widget": {
            "name": "image"
          }
        },
        {
          "label": "upload",
          "name": "upload",
          "type": "IMAGEUPLOAD",
          "widget": {
            "name": "upload"
          }
        }
      ],
      "outputs": [
        {
          "label": "IMAGE",
          "name": "IMAGE",
          "type": "IMAGE",
          "links": [
            129
          ]
        },
        {
          "label": "MASK",
          "name": "MASK",
          "type": "MASK"
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.27.0",
        "Node name for S&R": "LoadImage",
        "hasSecondTab": false,
        "widget_ue_connectable": {},
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": [
        "ComfyUI_temp_pofoj_00040_.png",
        "image"
      ]
    },
    {
      "id": 55,
      "type": "KSampler",
      "pos": [
        3790,
        -1700
      ],
      "size": [
        315,
        262
      ],
      "flags": {},
      "order": 19,
      "mode": 0,
      "inputs": [
        {
          "label": "model",
          "name": "model",
          "type": "MODEL",
          "link": 124
        },
        {
          "label": "positive",
          "name": "positive",
          "type": "CONDITIONING",
          "link": 102
        },
        {
          "label": "negative",
          "name": "negative",
          "type": "CONDITIONING",
          "link": 103
        },
        {
          "label": "latent_image",
          "name": "latent_image",
          "type": "LATENT",
          "link": 104
        },
        {
          "label": "seed",
          "name": "seed",
          "type": "INT",
          "widget": {
            "name": "seed"
          }
        },
        {
          "label": "steps",
          "name": "steps",
          "type": "INT",
          "widget": {
            "name": "steps"
          }
        },
        {
          "label": "cfg",
          "name": "cfg",
          "type": "FLOAT",
          "widget": {
            "name": "cfg"
          }
        },
        {
          "label": "sampler_name",
          "name": "sampler_name",
          "type": "COMBO",
          "widget": {
            "name": "sampler_name"
          }
        },
        {
          "label": "scheduler",
          "name": "scheduler",
          "type": "COMBO",
          "widget": {
            "name": "scheduler"
          }
        },
        {
          "label": "denoise",
          "name": "denoise",
          "type": "FLOAT",
          "widget": {
            "name": "denoise"
          }
        }
      ],
      "outputs": [
        {
          "label": "LATENT",
          "name": "LATENT",
          "type": "LATENT",
          "links": [
            105
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.27.0",
        "Node name for S&R": "KSampler",
        "hasSecondTab": false,
        "widget_ue_connectable": {},
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": [
        929780795696437,
        "randomize",
        4,
        1,
        "euler",
        "simple",
        1
      ]
    },
    {
      "id": 52,
      "type": "CLIPLoader",
      "pos": [
        3410.6876115544537,
        -1876.1789556189985
      ],
      "size": [
        311.2938537597656,
        111.51929473876953
      ],
      "flags": {},
      "order": 3,
      "mode": 0,
      "inputs": [
        {
          "label": "clip_name",
          "name": "clip_name",
          "type": "COMBO",
          "widget": {
            "name": "clip_name"
          }
        },
        {
          "label": "type",
          "name": "type",
          "type": "COMBO",
          "widget": {
            "name": "type"
          }
        },
        {
          "label": "device",
          "name": "device",
          "shape": 7,
          "type": "COMBO",
          "widget": {
            "name": "device"
          }
        }
      ],
      "outputs": [
        {
          "label": "CLIP",
          "name": "CLIP",
          "type": "CLIP",
          "links": [
            94,
            118
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.27.0",
        "Node name for S&R": "CLIPLoader",
        "hasSecondTab": false,
        "widget_ue_connectable": {},
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "ttNbgOverride": {
          "bgcolor": "#653",
          "groupcolor": "#b58b2a",
          "color": "#432"
        },
        "tabXOffset": 10
      },
      "widgets_values": [
        "qwen_3_8b_fp8mixed.safetensors",
        "flux2",
        "default"
      ]
    },
    {
      "id": 58,
      "type": "UNETLoader",
      "pos": [
        3731.5554433591715,
        -1848.5127566093463
      ],
      "size": [
        316.0461120605469,
        82.74449920654297
      ],
      "flags": {},
      "order": 4,
      "mode": 0,
      "inputs": [
        {
          "label": "unet_name",
          "name": "unet_name",
          "type": "COMBO",
          "widget": {
            "name": "unet_name"
          }
        },
        {
          "label": "weight_dtype",
          "name": "weight_dtype",
          "type": "COMBO",
          "widget": {
            "name": "weight_dtype"
          }
        }
      ],
      "outputs": [
        {
          "label": "MODEL",
          "name": "MODEL",
          "type": "MODEL",
          "links": [
            124
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.27.0",
        "Node name for S&R": "UNETLoader",
        "hasSecondTab": false,
        "widget_ue_connectable": {},
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": [
        "FLUX.2-klein-9b-fp8/flux-2-klein-9b-fp8.safetensors",
        "default"
      ]
    },
    {
      "id": 61,
      "type": "ImageResizeKJv2",
      "pos": [
        3080,
        -1710
      ],
      "size": [
        315,
        336
      ],
      "flags": {},
      "order": 6,
      "mode": 0,
      "inputs": [
        {
          "label": "image",
          "name": "image",
          "type": "IMAGE",
          "link": 113
        },
        {
          "label": "mask",
          "name": "mask",
          "shape": 7,
          "type": "MASK"
        },
        {
          "label": "width",
          "name": "width",
          "type": "INT",
          "widget": {
            "name": "width"
          }
        },
        {
          "label": "height",
          "name": "height",
          "type": "INT",
          "widget": {
            "name": "height"
          }
        },
        {
          "label": "upscale_method",
          "name": "upscale_method",
          "type": "COMBO",
          "widget": {
            "name": "upscale_method"
          }
        },
        {
          "label": "keep_proportion",
          "name": "keep_proportion",
          "type": "COMBO",
          "widget": {
            "name": "keep_proportion"
          }
        },
        {
          "label": "pad_color",
          "name": "pad_color",
          "type": "STRING",
          "widget": {
            "name": "pad_color"
          }
        },
        {
          "label": "crop_position",
          "name": "crop_position",
          "type": "COMBO",
          "widget": {
            "name": "crop_position"
          }
        },
        {
          "label": "divisible_by",
          "name": "divisible_by",
          "type": "INT",
          "widget": {
            "name": "divisible_by"
          }
        },
        {
          "label": "device",
          "name": "device",
          "shape": 7,
          "type": "COMBO",
          "widget": {
            "name": "device"
          }
        }
      ],
      "outputs": [
        {
          "label": "IMAGE",
          "name": "IMAGE",
          "type": "IMAGE",
          "links": [
            99
          ]
        },
        {
          "label": "width",
          "name": "width",
          "type": "INT",
          "links": [
            107
          ]
        },
        {
          "label": "height",
          "name": "height",
          "type": "INT",
          "links": [
            108
          ]
        },
        {
          "label": "mask",
          "name": "mask",
          "type": "MASK"
        }
      ],
      "properties": {
        "Node name for S&R": "ImageResizeKJv2",
        "hasSecondTab": false,
        "widget_ue_connectable": {},
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": [
        1536,
        1536,
        "lanczos",
        "resize",
        "0, 0, 0",
        "center",
        2,
        "cpu"
      ]
    },
    {
      "id": 75,
      "type": "OnnxDetectionModelLoader",
      "pos": [
        3080,
        -1310
      ],
      "size": [
        292.8853454589844,
        106
      ],
      "flags": {},
      "order": 5,
      "mode": 0,
      "inputs": [
        {
          "label": "vitpose_model",
          "name": "vitpose_model",
          "type": "COMBO",
          "widget": {
            "name": "vitpose_model"
          },
          "link": null
        },
        {
          "label": "yolo_model",
          "name": "yolo_model",
          "type": "COMBO",
          "widget": {
            "name": "yolo_model"
          },
          "link": null
        },
        {
          "label": "onnx_device",
          "name": "onnx_device",
          "type": "COMBO",
          "widget": {
            "name": "onnx_device"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "model",
          "name": "model",
          "type": "POSEMODEL",
          "links": [
            128
          ]
        }
      ],
      "properties": {
        "aux_id": "kijai/ComfyUI-WanAnimatePreprocess",
        "Node name for S&R": "OnnxDetectionModelLoader",
        "ver": "e63d6e71ae4c271f3f81211a7ca7f87607b7e50d",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "vitpose-l-wholebody.onnx",
        "yolov10m.onnx",
        "CUDAExecutionProvider"
      ]
    },
    {
      "id": 74,
      "type": "PoseAndFaceDetection",
      "pos": [
        3062.3892602451156,
        -1163.583852086835
      ],
      "size": [
        313.125,
        186
      ],
      "flags": {},
      "order": 9,
      "mode": 0,
      "inputs": [
        {
          "label": "model",
          "name": "model",
          "type": "POSEMODEL",
          "link": 128
        },
        {
          "label": "images",
          "name": "images",
          "type": "IMAGE",
          "link": 129
        },
        {
          "label": "retarget_image",
          "name": "retarget_image",
          "shape": 7,
          "type": "IMAGE",
          "link": null
        },
        {
          "label": "width",
          "name": "width",
          "type": "INT",
          "widget": {
            "name": "width"
          },
          "link": null
        },
        {
          "label": "height",
          "name": "height",
          "type": "INT",
          "widget": {
            "name": "height"
          },
          "link": null
        },
        {
          "label": "face_padding",
          "name": "face_padding",
          "shape": 7,
          "type": "INT",
          "widget": {
            "name": "face_padding"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "pose_data",
          "name": "pose_data",
          "type": "POSEDATA",
          "links": []
        },
        {
          "label": "face_images",
          "name": "face_images",
          "type": "IMAGE",
          "links": [
            130
          ]
        },
        {
          "label": "key_frame_body_points",
          "name": "key_frame_body_points",
          "type": "STRING",
          "links": []
        },
        {
          "label": "bboxes",
          "name": "bboxes",
          "type": "BBOX",
          "links": []
        },
        {
          "label": "face_bboxes",
          "name": "face_bboxes",
          "type": "BBOX,",
          "links": null
        }
      ],
      "properties": {
        "aux_id": "kijai/ComfyUI-WanAnimatePreprocess",
        "Node name for S&R": "PoseAndFaceDetection",
        "ver": "e63d6e71ae4c271f3f81211a7ca7f87607b7e50d",
        "widget_ue_connectable": {
          "width": true,
          "height": true
        }
      },
      "widgets_values": [
        832,
        480,
        0
      ]
    },
    {
      "id": 67,
      "type": "SaveImage",
      "pos": [
        3894.4447586676315,
        -1315.1980527195851
      ],
      "size": [
        543.5309448242188,
        627.2542114257812
      ],
      "flags": {},
      "order": 21,
      "mode": 0,
      "inputs": [
        {
          "label": "images",
          "name": "images",
          "type": "IMAGE",
          "link": 119
        },
        {
          "label": "filename_prefix",
          "name": "filename_prefix",
          "type": "STRING",
          "widget": {
            "name": "filename_prefix"
          }
        }
      ],
      "outputs": [
        {
          "label": "image_urls",
          "name": "images",
          "type": "IMAGE"
        },
        {
          "label": "images",
          "name": "images",
          "type": "IMAGE",
          "links": null
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.27.0",
        "Node name for S&R": "SaveImage",
        "hasSecondTab": false,
        "widget_ue_connectable": {},
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": [
        "ComfyUI"
      ]
    }
  ],
  "links": [
    [
      94,
      52,
      0,
      49,
      0,
      "CLIP"
    ],
    [
      95,
      66,
      0,
      50,
      0,
      "CONDITIONING"
    ],
    [
      96,
      54,
      0,
      50,
      1,
      "LATENT"
    ],
    [
      97,
      49,
      0,
      51,
      0,
      "CONDITIONING"
    ],
    [
      98,
      54,
      0,
      51,
      1,
      "LATENT"
    ],
    [
      99,
      61,
      0,
      54,
      0,
      "IMAGE"
    ],
    [
      100,
      53,
      0,
      54,
      1,
      "VAE"
    ],
    [
      102,
      59,
      0,
      55,
      1,
      "CONDITIONING"
    ],
    [
      103,
      60,
      0,
      55,
      2,
      "CONDITIONING"
    ],
    [
      104,
      57,
      0,
      55,
      3,
      "LATENT"
    ],
    [
      105,
      55,
      0,
      56,
      0,
      "LATENT"
    ],
    [
      106,
      53,
      0,
      56,
      1,
      "VAE"
    ],
    [
      107,
      61,
      1,
      57,
      0,
      "INT"
    ],
    [
      108,
      61,
      2,
      57,
      1,
      "INT"
    ],
    [
      109,
      50,
      0,
      59,
      0,
      "CONDITIONING"
    ],
    [
      110,
      63,
      0,
      59,
      1,
      "LATENT"
    ],
    [
      111,
      51,
      0,
      60,
      0,
      "CONDITIONING"
    ],
    [
      112,
      63,
      0,
      60,
      1,
      "LATENT"
    ],
    [
      113,
      70,
      0,
      61,
      0,
      "IMAGE"
    ],
    [
      115,
      62,
      0,
      63,
      0,
      "IMAGE"
    ],
    [
      116,
      53,
      0,
      63,
      1,
      "VAE"
    ],
    [
      118,
      52,
      0,
      66,
      0,
      "CLIP"
    ],
    [
      119,
      56,
      0,
      67,
      0,
      "IMAGE"
    ],
    [
      124,
      58,
      0,
      55,
      0,
      "MODEL"
    ],
    [
      128,
      75,
      0,
      74,
      0,
      "POSEMODEL"
    ],
    [
      129,
      71,
      0,
      74,
      1,
      "IMAGE"
    ],
    [
      130,
      74,
      1,
      76,
      0,
      "IMAGE"
    ],
    [
      131,
      76,
      0,
      62,
      0,
      "IMAGE"
    ]
  ],
  "groups": [],
  "config": {},
  "extra": {
    "links_added_by_ue": [],
    "VHS_KeepIntermediate": true,
    "ue_links": [],
    "VHS_MetadataImage": true,
    "0246.VERSION": [
      0,
      0,
      4
    ],
    "VHS_latentpreviewrate": 0,
    "frontendVersion": "1.45.20",
    "VHS_latentpreview": false,
    "ds": {
      "scale": 0.7972024500000158,
      "offset": [
        -2352.318907582482,
        2137.6987251848914
      ]
    }
  },
  "version": 0.4
}
```
