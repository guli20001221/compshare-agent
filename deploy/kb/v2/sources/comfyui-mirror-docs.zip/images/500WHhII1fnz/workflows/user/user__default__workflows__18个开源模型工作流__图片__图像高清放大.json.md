# 图像高清放大

- 来源类别：用户工作流
- 镜像内原始路径：`/ComfyUI/user/default/workflows/18个开源模型工作流/图片/图像高清放大.json`
- 节点数量：5
- 连线数量：4

## 节点类型

- `LoadImage` × 1
- `SaveImage` × 1
- `SeedVR2LoadDiTModel` × 1
- `SeedVR2LoadVAEModel` × 1
- `SeedVR2VideoUpscaler` × 1

## 工作流引用的模型或媒体文件

- `eedvr2_ema_3b-Q8_0.gguf`
- `ema_vae_fp16.safetensors`

## 原始工作流 JSON

```json
{
  "id": "91f6bbe2-ed41-4fd6-bac7-71d5b5864ecb",
  "revision": 0,
  "last_node_id": 384,
  "last_link_id": 875,
  "nodes": [
    {
      "id": 349,
      "type": "SeedVR2LoadVAEModel",
      "pos": [
        412.02774537762235,
        737.2343233084448
      ],
      "size": [
        312.8667907714844,
        298
      ],
      "flags": {},
      "order": 0,
      "mode": 0,
      "inputs": [
        {
          "label": "torch_compile_args",
          "name": "torch_compile_args",
          "shape": 7,
          "type": "TORCH_COMPILE_ARGS"
        },
        {
          "label": "model",
          "name": "model",
          "type": "COMBO",
          "widget": {
            "name": "model"
          }
        },
        {
          "label": "device",
          "name": "device",
          "type": "COMBO",
          "widget": {
            "name": "device"
          }
        },
        {
          "label": "encode_tiled",
          "name": "encode_tiled",
          "shape": 7,
          "type": "BOOLEAN",
          "widget": {
            "name": "encode_tiled"
          }
        },
        {
          "label": "encode_tile_size",
          "name": "encode_tile_size",
          "shape": 7,
          "type": "INT",
          "widget": {
            "name": "encode_tile_size"
          }
        },
        {
          "label": "encode_tile_overlap",
          "name": "encode_tile_overlap",
          "shape": 7,
          "type": "INT",
          "widget": {
            "name": "encode_tile_overlap"
          }
        },
        {
          "label": "decode_tiled",
          "name": "decode_tiled",
          "shape": 7,
          "type": "BOOLEAN",
          "widget": {
            "name": "decode_tiled"
          }
        },
        {
          "label": "decode_tile_size",
          "name": "decode_tile_size",
          "shape": 7,
          "type": "INT",
          "widget": {
            "name": "decode_tile_size"
          }
        },
        {
          "label": "decode_tile_overlap",
          "name": "decode_tile_overlap",
          "shape": 7,
          "type": "INT",
          "widget": {
            "name": "decode_tile_overlap"
          }
        },
        {
          "label": "tile_debug",
          "name": "tile_debug",
          "shape": 7,
          "type": "COMBO",
          "widget": {
            "name": "tile_debug"
          }
        },
        {
          "label": "offload_device",
          "name": "offload_device",
          "shape": 7,
          "type": "COMBO",
          "widget": {
            "name": "offload_device"
          }
        },
        {
          "label": "cache_model",
          "name": "cache_model",
          "shape": 7,
          "type": "BOOLEAN",
          "widget": {
            "name": "cache_model"
          }
        }
      ],
      "outputs": [
        {
          "label": "vae",
          "name": "SEEDVR2_VAE",
          "type": "SEEDVR2_VAE",
          "links": [
            820
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "SeedVR2LoadVAEModel",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "ema_vae_fp16.safetensors",
        "cuda:0",
        false,
        1024,
        128,
        false,
        1024,
        128,
        "false",
        "none",
        false
      ]
    },
    {
      "id": 382,
      "type": "LoadImage",
      "pos": [
        452.6943495452169,
        105.86369441429848
      ],
      "size": [
        270,
        314
      ],
      "flags": {},
      "order": 1,
      "mode": 0,
      "inputs": [],
      "outputs": [
        {
          "name": "IMAGE",
          "type": "IMAGE",
          "links": [
            873
          ]
        },
        {
          "name": "MASK",
          "type": "MASK",
          "links": null
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.27.0",
        "Node name for S&R": "LoadImage"
      },
      "widgets_values": [
        "ComfyUI_temp_pofoj_00031_.png",
        "image"
      ]
    },
    {
      "id": 347,
      "type": "SeedVR2VideoUpscaler",
      "pos": [
        802.976596453647,
        106.45826370703051
      ],
      "size": [
        317.5425720214844,
        386
      ],
      "flags": {},
      "order": 3,
      "mode": 0,
      "inputs": [
        {
          "label": "image",
          "name": "image",
          "type": "IMAGE",
          "link": 873
        },
        {
          "label": "dit",
          "name": "dit",
          "type": "SEEDVR2_DIT",
          "link": 875
        },
        {
          "label": "vae",
          "name": "vae",
          "type": "SEEDVR2_VAE",
          "link": 820
        },
        {
          "label": "seed",
          "name": "seed",
          "type": "INT",
          "widget": {
            "name": "seed"
          }
        },
        {
          "label": "resolution",
          "name": "resolution",
          "type": "INT",
          "widget": {
            "name": "resolution"
          }
        },
        {
          "label": "max_resolution",
          "name": "max_resolution",
          "type": "INT",
          "widget": {
            "name": "max_resolution"
          }
        },
        {
          "label": "batch_size",
          "name": "batch_size",
          "type": "INT",
          "widget": {
            "name": "batch_size"
          }
        },
        {
          "label": "uniform_batch_size",
          "name": "uniform_batch_size",
          "type": "BOOLEAN",
          "widget": {
            "name": "uniform_batch_size"
          }
        },
        {
          "label": "color_correction",
          "name": "color_correction",
          "type": "COMBO",
          "widget": {
            "name": "color_correction"
          }
        },
        {
          "label": "temporal_overlap",
          "name": "temporal_overlap",
          "shape": 7,
          "type": "INT",
          "widget": {
            "name": "temporal_overlap"
          }
        },
        {
          "label": "prepend_frames",
          "name": "prepend_frames",
          "shape": 7,
          "type": "INT",
          "widget": {
            "name": "prepend_frames"
          }
        },
        {
          "label": "input_noise_scale",
          "name": "input_noise_scale",
          "shape": 7,
          "type": "FLOAT",
          "widget": {
            "name": "input_noise_scale"
          }
        },
        {
          "label": "latent_noise_scale",
          "name": "latent_noise_scale",
          "shape": 7,
          "type": "FLOAT",
          "widget": {
            "name": "latent_noise_scale"
          }
        },
        {
          "label": "offload_device",
          "name": "offload_device",
          "shape": 7,
          "type": "COMBO",
          "widget": {
            "name": "offload_device"
          }
        },
        {
          "label": "enable_debug",
          "name": "enable_debug",
          "shape": 7,
          "type": "BOOLEAN",
          "widget": {
            "name": "enable_debug"
          }
        }
      ],
      "outputs": [
        {
          "label": "image",
          "name": "IMAGE",
          "type": "IMAGE",
          "links": [
            818,
            859
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "SeedVR2VideoUpscaler",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        328247226,
        "randomize",
        1920,
        0,
        5,
        false,
        "lab",
        0,
        0,
        0,
        0,
        "cpu",
        false
      ]
    },
    {
      "id": 348,
      "type": "SeedVR2LoadDiTModel",
      "pos": [
        418.19808683411844,
        483.06261428124975
      ],
      "size": [
        307.6646423339844,
        202
      ],
      "flags": {},
      "order": 2,
      "mode": 0,
      "inputs": [
        {
          "label": "torch_compile_args",
          "name": "torch_compile_args",
          "shape": 7,
          "type": "TORCH_COMPILE_ARGS"
        },
        {
          "label": "model",
          "name": "model",
          "type": "COMBO",
          "widget": {
            "name": "model"
          }
        },
        {
          "label": "device",
          "name": "device",
          "type": "COMBO",
          "widget": {
            "name": "device"
          }
        },
        {
          "label": "blocks_to_swap",
          "name": "blocks_to_swap",
          "shape": 7,
          "type": "INT",
          "widget": {
            "name": "blocks_to_swap"
          }
        },
        {
          "label": "swap_io_components",
          "name": "swap_io_components",
          "shape": 7,
          "type": "BOOLEAN",
          "widget": {
            "name": "swap_io_components"
          }
        },
        {
          "label": "offload_device",
          "name": "offload_device",
          "shape": 7,
          "type": "COMBO",
          "widget": {
            "name": "offload_device"
          }
        },
        {
          "label": "cache_model",
          "name": "cache_model",
          "shape": 7,
          "type": "BOOLEAN",
          "widget": {
            "name": "cache_model"
          }
        },
        {
          "label": "attention_mode",
          "name": "attention_mode",
          "shape": 7,
          "type": "COMBO",
          "widget": {
            "name": "attention_mode"
          }
        }
      ],
      "outputs": [
        {
          "label": "dit",
          "name": "SEEDVR2_DIT",
          "type": "SEEDVR2_DIT",
          "links": [
            875
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "SeedVR2LoadDiTModel",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "seedvr2_ema_3b-Q8_0.gguf",
        "cuda:0",
        0,
        false,
        "none",
        false,
        "sdpa"
      ]
    },
    {
      "id": 345,
      "type": "SaveImage",
      "pos": [
        1159.894173176429,
        106.00837406007714
      ],
      "size": [
        462.2575988769531,
        531.4813842773438
      ],
      "flags": {},
      "order": 4,
      "mode": 0,
      "inputs": [
        {
          "label": "images",
          "name": "images",
          "type": "IMAGE",
          "link": 818
        },
        {
          "label": "filename_prefix",
          "name": "filename_prefix",
          "type": "STRING",
          "widget": {
            "name": "filename_prefix"
          }
        }
      ],
      "outputs": [
        {
          "label": "image_urls",
          "name": "images",
          "type": "IMAGE",
          "links": null
        },
        {
          "label": "images",
          "name": "images",
          "type": "IMAGE",
          "links": null
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.27.0",
        "Node name for S&R": "SaveImage",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "ComfyUI"
      ]
    }
  ],
  "links": [
    [
      818,
      347,
      0,
      345,
      0,
      "IMAGE"
    ],
    [
      820,
      349,
      0,
      347,
      2,
      "SEEDVR2_VAE"
    ],
    [
      873,
      382,
      0,
      347,
      0,
      "IMAGE"
    ],
    [
      875,
      348,
      0,
      347,
      1,
      "SEEDVR2_DIT"
    ]
  ],
  "groups": [],
  "config": {},
  "extra": {
    "links_added_by_ue": [],
    "VHS_KeepIntermediate": true,
    "ue_links": [],
    "VHS_MetadataImage": true,
    "0246.VERSION": [
      0,
      0,
      4
    ],
    "workflowRendererVersion": "LG",
    "VHS_latentpreviewrate": 0,
    "frontendVersion": "1.45.20",
    "VHS_latentpreview": false,
    "ds": {
      "scale": 0.8769226950000064,
      "offset": [
        165.7107360891265,
        200.5119393093262
      ]
    }
  },
  "version": 0.4
}
```
