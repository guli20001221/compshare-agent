# Image to Video (Wan 2.2)

- 来源类别：内置工作流蓝图
- 镜像内原始路径：`/ComfyUI/blueprints/Image to Video (Wan 2.2).json`
- 节点数量：1
- 连线数量：0

## 节点类型

- `296b573f-1e7d-43df-a2df-925fe5e17063` × 1

## 工作流引用的模型或媒体文件

- `caled.safetensors`
- `e.safetensors`
- `wan_2.1_vae.safetensors`

## 原始工作流 JSON

```json
{
  "id": "ec7da562-7e21-4dac-a0d2-f4441e1efd3b",
  "revision": 0,
  "last_node_id": 119,
  "last_link_id": 231,
  "nodes": [
    {
      "id": 116,
      "type": "296b573f-1e7d-43df-a2df-925fe5e17063",
      "pos": [
        1098.3332694531493,
        -268.3334707134305
      ],
      "size": [
        400,
        470
      ],
      "flags": {
        "collapsed": false
      },
      "order": 0,
      "mode": 0,
      "inputs": [
        {
          "label": "start image",
          "localized_name": "start_image",
          "name": "start_image",
          "type": "IMAGE",
          "link": null
        },
        {
          "label": "prompt",
          "name": "text",
          "type": "STRING",
          "widget": {
            "name": "text"
          },
          "link": null
        },
        {
          "name": "width",
          "type": "INT",
          "widget": {
            "name": "width"
          },
          "link": null
        },
        {
          "name": "height",
          "type": "INT",
          "widget": {
            "name": "height"
          },
          "link": null
        },
        {
          "name": "length",
          "type": "INT",
          "widget": {
            "name": "length"
          },
          "link": null
        },
        {
          "label": "low_noise_unet",
          "name": "unet_name",
          "type": "COMBO",
          "widget": {
            "name": "unet_name"
          },
          "link": null
        },
        {
          "label": "low_noise_lora",
          "name": "lora_name",
          "type": "COMBO",
          "widget": {
            "name": "lora_name"
          },
          "link": null
        },
        {
          "label": "high_noise_unet",
          "name": "unet_name_1",
          "type": "COMBO",
          "widget": {
            "name": "unet_name_1"
          },
          "link": null
        },
        {
          "label": "high_noise_lora",
          "name": "lora_name_1",
          "type": "COMBO",
          "widget": {
            "name": "lora_name_1"
          },
          "link": null
        },
        {
          "name": "clip_name",
          "type": "COMBO",
          "widget": {
            "name": "clip_name"
          },
          "link": null
        },
        {
          "name": "vae_name",
          "type": "COMBO",
          "widget": {
            "name": "vae_name"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "name": "VIDEO",
          "type": "VIDEO",
          "links": null
        }
      ],
      "properties": {
        "proxyWidgets": [
          [
            "-1",
            "text"
          ],
          [
            "-1",
            "width"
          ],
          [
            "-1",
            "height"
          ],
          [
            "-1",
            "length"
          ],
          [
            "86",
            "noise_seed"
          ],
          [
            "86",
            "control_after_generate"
          ],
          [
            "-1",
            "unet_name"
          ],
          [
            "-1",
            "lora_name"
          ],
          [
            "-1",
            "unet_name_1"
          ],
          [
            "-1",
            "lora_name_1"
          ],
          [
            "-1",
            "clip_name"
          ],
          [
            "-1",
            "vae_name"
          ]
        ],
        "cnr_id": "comfy-core",
        "ver": "0.11.0"
      },
      "widgets_values": [
        "",
        640,
        640,
        81,
        null,
        null,
        "wan2.2_i2v_high_noise_14B_fp8_scaled.safetensors",
        "wan2.2_i2v_lightx2v_4steps_lora_v1_high_noise.safetensors",
        "wan2.2_i2v_low_noise_14B_fp8_scaled.safetensors",
        "wan2.2_i2v_lightx2v_4steps_lora_v1_low_noise.safetensors",
        "umt5_xxl_fp8_e4m3fn_scaled.safetensors",
        "wan_2.1_vae.safetensors"
      ]
    }
  ],
  "links": [],
  "groups": [],
  "definitions": {
    "subgraphs": [
      {
        "id": "296b573f-1e7d-43df-a2df-925fe5e17063",
        "version": 1,
        "state": {
          "lastGroupId": 16,
          "lastNodeId": 119,
          "lastLinkId": 231,
          "lastRerouteId": 0
        },
        "revision": 0,
        "config": {},
        "name": "Image to Video (Wan 2.2)",
        "inputNode": {
          "id": -10,
          "bounding": [
            -250,
            570,
            131.435546875,
            260
          ]
        },
        "outputNode": {
          "id": -20,
          "bounding": [
            1723.4786916118696,
            716.3650158766799,
            120,
            60
          ]
        },
        "inputs": [
          {
            "id": "69d8b033-5601-446e-9634-f5cafbd373e2",
            "name": "start_image",
            "type": "IMAGE",
            "linkIds": [
              186
            ],
            "localized_name": "start_image",
            "label": "start image",
            "shape": 7,
            "pos": [
              -138.564453125,
              590
            ]
          },
          {
            "id": "88ae2af6-63c1-41be-90e8-6359f4d5f133",
            "name": "text",
            "type": "STRING",
            "linkIds": [
              222
            ],
            "label": "prompt",
            "pos": [
              -138.564453125,
              610
            ]
          },
          {
            "id": "fad9d346-653e-4be5-9e52-38cef6fa59f3",
            "name": "width",
            "type": "INT",
            "linkIds": [
              223
            ],
            "pos": [
              -138.564453125,
              630
            ]
          },
          {
            "id": "a4f34897-8063-4613-a2eb-6c2503167eb1",
            "name": "height",
            "type": "INT",
            "linkIds": [
              224
            ],
            "pos": [
              -138.564453125,
              650
            ]
          },
          {
            "id": "dc4d4472-cff7-41e0-9a4a-d118fcd4a21a",
            "name": "length",
            "type": "INT",
            "linkIds": [
              225
            ],
            "pos": [
              -138.564453125,
              670
            ]
          },
          {
            "id": "f7317e79-4a52-460b-9d71-89ec450dc333",
            "name": "unet_name",
            "type": "COMBO",
            "linkIds": [
              226
            ],
            "label": "low_noise_unet",
            "pos": [
              -138.564453125,
              690
            ]
          },
          {
            "id": "7a470f86-503a-474f-9571-830c8eb99231",
            "name": "lora_name",
            "type": "COMBO",
            "linkIds": [
              227
            ],
            "label": "low_noise_lora",
            "pos": [
              -138.564453125,
              710
            ]
          },
          {
            "id": "1d88c531-f68e-41b9-95c5-16f944a55b7d",
            "name": "unet_name_1",
            "type": "COMBO",
            "linkIds": [
              228
            ],
            "label": "high_noise_unet",
            "pos": [
              -138.564453125,
              730
            ]
          },
          {
            "id": "67a79742-33e5-4c38-89d8-ecb021d067c8",
            "name": "lora_name_1",
            "type": "COMBO",
            "linkIds": [
              229
            ],
            "label": "high_noise_lora",
            "pos": [
              -138.564453125,
              750
            ]
          },
          {
            "id": "9d184b83-37c6-4891-bbdf-ffcdf5ab2016",
            "name": "clip_name",
            "type": "COMBO",
            "linkIds": [
              230
            ],
            "pos": [
              -138.564453125,
              770
            ]
          },
          {
            "id": "24c568ec-aeb2-4c31-9f87-54ee9099d55f",
            "name": "vae_name",
            "type": "COMBO",
            "linkIds": [
              231
            ],
            "pos": [
              -138.564453125,
              790
            ]
          }
        ],
        "outputs": [
          {
            "id": "994c9c48-5f35-48ed-8c9d-0f2b21990cb6",
            "name": "VIDEO",
            "type": "VIDEO",
            "linkIds": [
              221
            ],
            "pos": [
              1743.4786916118696,
              736.3650158766799
            ]
          }
        ],
        "widgets": [],
        "nodes": [
          {
            "id": 84,
            "type": "CLIPLoader",
            "pos": [
              59.999957705045404,
              29.99977085410412
            ],
            "size": [
              346.38020833333337,
              106
            ],
            "flags": {},
            "order": 0,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "clip_name",
                "name": "clip_name",
                "type": "COMBO",
                "widget": {
                  "name": "clip_name"
                },
                "link": 230
              },
              {
                "localized_name": "type",
                "name": "type",
                "type": "COMBO",
                "widget": {
                  "name": "type"
                },
                "link": null
              },
              {
                "localized_name": "device",
                "name": "device",
                "shape": 7,
                "type": "COMBO",
                "widget": {
                  "name": "device"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "CLIP",
                "name": "CLIP",
                "type": "CLIP",
                "slot_index": 0,
                "links": [
                  178,
                  181
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.3.45",
              "Node name for S&R": "CLIPLoader",
              "models": [
                {
                  "name": "umt5_xxl_fp8_e4m3fn_scaled.safetensors",
                  "url": "https://huggingface.co/Comfy-Org/Wan_2.1_ComfyUI_repackaged/resolve/main/split_files/text_encoders/umt5_xxl_fp8_e4m3fn_scaled.safetensors",
                  "directory": "text_encoders"
                }
              ],
              "ue_properties": {
                "widget_ue_connectable": {},
                "version": "7.1",
                "input_ue_unconnectable": {}
              }
            },
            "widgets_values": [
              "umt5_xxl_fp8_e4m3fn_scaled.safetensors",
              "wan",
              "default"
            ]
          },
          {
            "id": 90,
            "type": "VAELoader",
            "pos": [
              59.999957705045404,
              189.9997708925786
            ],
            "size": [
              344.7265625,
              58
            ],
            "flags": {},
            "order": 1,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "vae_name",
                "name": "vae_name",
                "type": "COMBO",
                "widget": {
                  "name": "vae_name"
                },
                "link": 231
              }
            ],
            "outputs": [
              {
                "localized_name": "VAE",
                "name": "VAE",
                "type": "VAE",
                "slot_index": 0,
                "links": [
                  176,
                  185
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.3.45",
              "Node name for S&R": "VAELoader",
              "models": [
                {
                  "name": "wan_2.1_vae.safetensors",
                  "url": "https://huggingface.co/Comfy-Org/Wan_2.2_ComfyUI_Repackaged/resolve/main/split_files/vae/wan_2.1_vae.safetensors",
                  "directory": "vae"
                }
              ],
              "ue_properties": {
                "widget_ue_connectable": {},
                "version": "7.1",
                "input_ue_unconnectable": {}
              }
            },
            "widgets_values": [
              "wan_2.1_vae.safetensors"
            ]
          },
          {
            "id": 95,
            "type": "UNETLoader",
            "pos": [
              49.99996468306838,
              -230.00013148243067
            ],
            "size": [
              346.7447916666667,
              82
            ],
            "flags": {},
            "order": 2,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "unet_name",
                "name": "unet_name",
                "type": "COMBO",
                "widget": {
                  "name": "unet_name"
                },
                "link": 226
              },
              {
                "localized_name": "weight_dtype",
                "name": "weight_dtype",
                "type": "COMBO",
                "widget": {
                  "name": "weight_dtype"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "MODEL",
                "name": "MODEL",
                "type": "MODEL",
                "slot_index": 0,
                "links": [
                  194
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.3.45",
              "Node name for S&R": "UNETLoader",
              "models": [
                {
                  "name": "wan2.2_i2v_high_noise_14B_fp8_scaled.safetensors",
                  "url": "https://huggingface.co/Comfy-Org/Wan_2.2_ComfyUI_Repackaged/resolve/main/split_files/diffusion_models/wan2.2_i2v_high_noise_14B_fp8_scaled.safetensors",
                  "directory": "diffusion_models"
                }
              ],
              "ue_properties": {
                "widget_ue_connectable": {},
                "version": "7.1",
                "input_ue_unconnectable": {}
              }
            },
            "widgets_values": [
              "wan2.2_i2v_high_noise_14B_fp8_scaled.safetensors",
              "default"
            ]
          },
          {
            "id": 96,
            "type": "UNETLoader",
            "pos": [
              49.99996468306838,
              -100.00008258817711
            ],
            "size": [
              346.7447916666667,
              82
            ],
            "flags": {},
            "order": 3,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "unet_name",
                "name": "unet_name",
                "type": "COMBO",
                "widget": {
                  "name": "unet_name"
                },
                "link": 228
              },
              {
                "localized_name": "weight_dtype",
                "name": "weight_dtype",
                "type": "COMBO",
                "widget": {
                  "name": "weight_dtype"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "MODEL",
                "name": "MODEL",
                "type": "MODEL",
                "slot_index": 0,
                "links": [
                  196
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.3.45",
              "Node name for S&R": "UNETLoader",
              "models": [
                {
                  "name": "wan2.2_i2v_low_noise_14B_fp8_scaled.safetensors",
                  "url": "https://huggingface.co/Comfy-Org/Wan_2.2_ComfyUI_Repackaged/resolve/main/split_files/diffusion_models/wan2.2_i2v_low_noise_14B_fp8_scaled.safetensors",
                  "directory": "diffusion_models"
                }
              ],
              "ue_properties": {
                "widget_ue_connectable": {},
                "version": "7.1",
                "input_ue_unconnectable": {}
              }
            },
            "widgets_values": [
              "wan2.2_i2v_low_noise_14B_fp8_scaled.safetensors",
              "default"
            ]
          },
          {
            "id": 103,
            "type": "ModelSamplingSD3",
            "pos": [
              739.9998741034308,
              -100.00008258817711
            ],
            "size": [
              210,
              58
            ],
            "flags": {
              "collapsed": false
            },
            "order": 12,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "model",
                "name": "model",
                "type": "MODEL",
                "link": 189
              },
              {
                "localized_name": "shift",
                "name": "shift",
                "type": "FLOAT",
                "widget": {
                  "name": "shift"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "MODEL",
                "name": "MODEL",
                "type": "MODEL",
                "slot_index": 0,
                "links": [
                  192
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.3.45",
              "Node name for S&R": "ModelSamplingSD3",
              "ue_properties": {
                "widget_ue_connectable": {},
                "version": "7.1",
                "input_ue_unconnectable": {}
              }
            },
            "widgets_values": [
              5.000000000000001
            ]
          },
          {
            "id": 93,
            "type": "CLIPTextEncode",
            "pos": [
              439.99997175727736,
              89.99984067280784
            ],
            "size": [
              510,
              88
            ],
            "flags": {},
            "order": 16,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "clip",
                "name": "clip",
                "type": "CLIP",
                "link": 181
              },
              {
                "localized_name": "text",
                "name": "text",
                "type": "STRING",
                "widget": {
                  "name": "text"
                },
                "link": 222
              }
            ],
            "outputs": [
              {
                "localized_name": "CONDITIONING",
                "name": "CONDITIONING",
                "type": "CONDITIONING",
                "slot_index": 0,
                "links": [
                  183
                ]
              }
            ],
            "title": "CLIP Text Encode (Positive Prompt)",
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.3.45",
              "Node name for S&R": "CLIPTextEncode",
              "ue_properties": {
                "widget_ue_connectable": {},
                "version": "7.1",
                "input_ue_unconnectable": {}
              }
            },
            "widgets_values": [
              ""
            ],
            "color": "#232",
            "bgcolor": "#353"
          },
          {
            "id": 89,
            "type": "CLIPTextEncode",
            "pos": [
              439.99997175727736,
              289.99986864261126
            ],
            "size": [
              510,
              88
            ],
            "flags": {},
            "order": 8,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "clip",
                "name": "clip",
                "type": "CLIP",
                "link": 178
              },
              {
                "localized_name": "text",
                "name": "text",
                "type": "STRING",
                "widget": {
                  "name": "text"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "CONDITIONING",
                "name": "CONDITIONING",
                "type": "CONDITIONING",
                "slot_index": 0,
                "links": [
                  184
                ]
              }
            ],
            "title": "CLIP Text Encode (Negative Prompt)",
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.3.45",
              "Node name for S&R": "CLIPTextEncode",
              "ue_properties": {
                "widget_ue_connectable": {},
                "version": "7.1",
                "input_ue_unconnectable": {}
              }
            },
            "widgets_values": [
              "色调艳丽，过曝，静态，细节模糊不清，字幕，风格，作品，画作，画面，静止，整体发灰，最差质量，低质量，JPEG压缩残留，丑陋的，残缺的，多余的手指，画得不好的手部，画得不好的脸部，畸形的，毁容的，形态畸形的肢体，手指融合，静止不动的画面，杂乱的背景，三条腿，背景人很多，倒着走"
            ],
            "color": "#322",
            "bgcolor": "#533"
          },
          {
            "id": 101,
            "type": "LoraLoaderModelOnly",
            "pos": [
              449.99996477925447,
              -230.00013148243067
            ],
            "size": [
              280,
              82
            ],
            "flags": {},
            "order": 9,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "model",
                "name": "model",
                "type": "MODEL",
                "link": 194
              },
              {
                "localized_name": "lora_name",
                "name": "lora_name",
                "type": "COMBO",
                "widget": {
                  "name": "lora_name"
                },
                "link": 227
              },
              {
                "localized_name": "strength_model",
                "name": "strength_model",
                "type": "FLOAT",
                "widget": {
                  "name": "strength_model"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "MODEL",
                "name": "MODEL",
                "type": "MODEL",
                "links": [
                  190
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.3.49",
              "Node name for S&R": "LoraLoaderModelOnly",
              "models": [
                {
                  "name": "wan2.2_i2v_lightx2v_4steps_lora_v1_high_noise.safetensors",
                  "url": "https://huggingface.co/Comfy-Org/Wan_2.2_ComfyUI_Repackaged/resolve/main/split_files/loras/wan2.2_i2v_lightx2v_4steps_lora_v1_high_noise.safetensors",
                  "directory": "loras"
                }
              ],
              "ue_properties": {
                "widget_ue_connectable": {},
                "version": "7.1",
                "input_ue_unconnectable": {}
              }
            },
            "widgets_values": [
              "wan2.2_i2v_lightx2v_4steps_lora_v1_high_noise.safetensors",
              1.0000000000000002
            ]
          },
          {
            "id": 102,
            "type": "LoraLoaderModelOnly",
            "pos": [
              449.99996477925447,
              -100.00008258817711
            ],
            "size": [
              280,
              82
            ],
            "flags": {},
            "order": 10,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "model",
                "name": "model",
                "type": "MODEL",
                "link": 196
              },
              {
                "localized_name": "lora_name",
                "name": "lora_name",
                "type": "COMBO",
                "widget": {
                  "name": "lora_name"
                },
                "link": 229
              },
              {
                "localized_name": "strength_model",
                "name": "strength_model",
                "type": "FLOAT",
                "widget": {
                  "name": "strength_model"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "MODEL",
                "name": "MODEL",
                "type": "MODEL",
                "links": [
                  189
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.3.49",
              "Node name for S&R": "LoraLoaderModelOnly",
              "models": [
                {
                  "name": "wan2.2_i2v_lightx2v_4steps_lora_v1_low_noise.safetensors",
                  "url": "https://huggingface.co/Comfy-Org/Wan_2.2_ComfyUI_Repackaged/resolve/main/split_files/loras/wan2.2_i2v_lightx2v_4steps_lora_v1_low_noise.safetensors",
                  "directory": "loras"
                }
              ],
              "ue_properties": {
                "widget_ue_connectable": {},
                "version": "7.1",
                "input_ue_unconnectable": {}
              }
            },
            "widgets_values": [
              "wan2.2_i2v_lightx2v_4steps_lora_v1_low_noise.safetensors",
              1.0000000000000002
            ]
          },
          {
            "id": 104,
            "type": "ModelSamplingSD3",
            "pos": [
              739.9998741034308,
              -230.00013148243067
            ],
            "size": [
              210,
              58
            ],
            "flags": {},
            "order": 11,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "model",
                "name": "model",
                "type": "MODEL",
                "link": 190
              },
              {
                "localized_name": "shift",
                "name": "shift",
                "type": "FLOAT",
                "widget": {
                  "name": "shift"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "MODEL",
                "name": "MODEL",
                "type": "MODEL",
                "slot_index": 0,
                "links": [
                  195
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.3.45",
              "Node name for S&R": "ModelSamplingSD3",
              "ue_properties": {
                "widget_ue_connectable": {},
                "version": "7.1",
                "input_ue_unconnectable": {}
              }
            },
            "widgets_values": [
              5.000000000000001
            ]
          },
          {
            "id": 98,
            "type": "WanImageToVideo",
            "pos": [
              530.0000206419123,
              529.9999245437435
            ],
            "size": [
              342.59114583333337,
              210
            ],
            "flags": {},
            "order": 17,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "positive",
                "name": "positive",
                "type": "CONDITIONING",
                "link": 183
              },
              {
                "localized_name": "negative",
                "name": "negative",
                "type": "CONDITIONING",
                "link": 184
              },
              {
                "localized_name": "vae",
                "name": "vae",
                "type": "VAE",
                "link": 185
              },
              {
                "localized_name": "clip_vision_output",
                "name": "clip_vision_output",
                "shape": 7,
                "type": "CLIP_VISION_OUTPUT",
                "link": null
              },
              {
                "localized_name": "start_image",
                "name": "start_image",
                "shape": 7,
                "type": "IMAGE",
                "link": 186
              },
              {
                "localized_name": "width",
                "name": "width",
                "type": "INT",
                "widget": {
                  "name": "width"
                },
                "link": 223
              },
              {
                "localized_name": "height",
                "name": "height",
                "type": "INT",
                "widget": {
                  "name": "height"
                },
                "link": 224
              },
              {
                "localized_name": "length",
                "name": "length",
                "type": "INT",
                "widget": {
                  "name": "length"
                },
                "link": 225
              },
              {
                "localized_name": "batch_size",
                "name": "batch_size",
                "type": "INT",
                "widget": {
                  "name": "batch_size"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "positive",
                "name": "positive",
                "type": "CONDITIONING",
                "slot_index": 0,
                "links": [
                  168,
                  172
                ]
              },
              {
                "localized_name": "negative",
                "name": "negative",
                "type": "CONDITIONING",
                "slot_index": 1,
                "links": [
                  169,
                  173
                ]
              },
              {
                "localized_name": "latent",
                "name": "latent",
                "type": "LATENT",
                "slot_index": 2,
                "links": [
                  174
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.3.45",
              "Node name for S&R": "WanImageToVideo",
              "ue_properties": {
                "widget_ue_connectable": {},
                "version": "7.1",
                "input_ue_unconnectable": {}
              }
            },
            "widgets_values": [
              640,
              640,
              81,
              1
            ]
          },
          {
            "id": 86,
            "type": "KSamplerAdvanced",
            "pos": [
              989.9999230265402,
              -250.00014544809514
            ],
            "size": [
              304.73958333333337,
              334
            ],
            "flags": {},
            "order": 14,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "model",
                "name": "model",
                "type": "MODEL",
                "link": 195
              },
              {
                "localized_name": "positive",
                "name": "positive",
                "type": "CONDITIONING",
                "link": 172
              },
              {
                "localized_name": "negative",
                "name": "negative",
                "type": "CONDITIONING",
                "link": 173
              },
              {
                "localized_name": "latent_image",
                "name": "latent_image",
                "type": "LATENT",
                "link": 174
              },
              {
                "localized_name": "add_noise",
                "name": "add_noise",
                "type": "COMBO",
                "widget": {
                  "name": "add_noise"
                },
                "link": null
              },
              {
                "localized_name": "noise_seed",
                "name": "noise_seed",
                "type": "INT",
                "widget": {
                  "name": "noise_seed"
                },
                "link": null
              },
              {
                "localized_name": "steps",
                "name": "steps",
                "type": "INT",
                "widget": {
                  "name": "steps"
                },
                "link": null
              },
              {
                "localized_name": "cfg",
                "name": "cfg",
                "type": "FLOAT",
                "widget": {
                  "name": "cfg"
                },
                "link": null
              },
              {
                "localized_name": "sampler_name",
                "name": "sampler_name",
                "type": "COMBO",
                "widget": {
                  "name": "sampler_name"
                },
                "link": null
              },
              {
                "localized_name": "scheduler",
                "name": "scheduler",
                "type": "COMBO",
                "widget": {
                  "name": "scheduler"
                },
                "link": null
              },
              {
                "localized_name": "start_at_step",
                "name": "start_at_step",
                "type": "INT",
                "widget": {
                  "name": "start_at_step"
                },
                "link": null
              },
              {
                "localized_name": "end_at_step",
                "name": "end_at_step",
                "type": "INT",
                "widget": {
                  "name": "end_at_step"
                },
                "link": null
              },
              {
                "localized_name": "return_with_leftover_noise",
                "name": "return_with_leftover_noise",
                "type": "COMBO",
                "widget": {
                  "name": "return_with_leftover_noise"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "LATENT",
                "name": "LATENT",
                "type": "LATENT",
                "links": [
                  170
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.3.45",
              "Node name for S&R": "KSamplerAdvanced",
              "ue_properties": {
                "widget_ue_connectable": {},
                "version": "7.1",
                "input_ue_unconnectable": {}
              }
            },
            "widgets_values": [
              "enable",
              0,
              "randomize",
              4,
              1,
              "euler",
              "simple",
              0,
              2,
              "enable"
            ]
          },
          {
            "id": 85,
            "type": "KSamplerAdvanced",
            "pos": [
              1336.748028098344,
              -250.00014544809514
            ],
            "size": [
              304.73958333333337,
              334
            ],
            "flags": {},
            "order": 13,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "model",
                "name": "model",
                "type": "MODEL",
                "link": 192
              },
              {
                "localized_name": "positive",
                "name": "positive",
                "type": "CONDITIONING",
                "link": 168
              },
              {
                "localized_name": "negative",
                "name": "negative",
                "type": "CONDITIONING",
                "link": 169
              },
              {
                "localized_name": "latent_image",
                "name": "latent_image",
                "type": "LATENT",
                "link": 170
              },
              {
                "localized_name": "add_noise",
                "name": "add_noise",
                "type": "COMBO",
                "widget": {
                  "name": "add_noise"
                },
                "link": null
              },
              {
                "localized_name": "noise_seed",
                "name": "noise_seed",
                "type": "INT",
                "widget": {
                  "name": "noise_seed"
                },
                "link": null
              },
              {
                "localized_name": "steps",
                "name": "steps",
                "type": "INT",
                "widget": {
                  "name": "steps"
                },
                "link": null
              },
              {
                "localized_name": "cfg",
                "name": "cfg",
                "type": "FLOAT",
                "widget": {
                  "name": "cfg"
                },
                "link": null
              },
              {
                "localized_name": "sampler_name",
                "name": "sampler_name",
                "type": "COMBO",
                "widget": {
                  "name": "sampler_name"
                },
                "link": null
              },
              {
                "localized_name": "scheduler",
                "name": "scheduler",
                "type": "COMBO",
                "widget": {
                  "name": "scheduler"
                },
                "link": null
              },
              {
                "localized_name": "start_at_step",
                "name": "start_at_step",
                "type": "INT",
                "widget": {
                  "name": "start_at_step"
                },
                "link": null
              },
              {
                "localized_name": "end_at_step",
                "name": "end_at_step",
                "type": "INT",
                "widget": {
                  "name": "end_at_step"
                },
                "link": null
              },
              {
                "localized_name": "return_with_leftover_noise",
                "name": "return_with_leftover_noise",
                "type": "COMBO",
                "widget": {
                  "name": "return_with_leftover_noise"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "LATENT",
                "name": "LATENT",
                "type": "LATENT",
                "links": [
                  175
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.3.45",
              "Node name for S&R": "KSamplerAdvanced",
              "ue_properties": {
                "widget_ue_connectable": {},
                "version": "7.1",
                "input_ue_unconnectable": {}
              }
            },
            "widgets_values": [
              "disable",
              0,
              "fixed",
              4,
              1,
              "euler",
              "simple",
              2,
              4,
              "disable"
            ]
          },
          {
            "id": 67,
            "type": "Note",
            "pos": [
              510.0000345979581,
              819.9999455547611
            ],
            "size": [
              390,
              88
            ],
            "flags": {},
            "order": 4,
            "mode": 0,
            "inputs": [],
            "outputs": [],
            "title": "Video Size",
            "properties": {
              "ue_properties": {
                "widget_ue_connectable": {},
                "version": "7.1",
                "input_ue_unconnectable": {}
              }
            },
            "widgets_values": [
              "By default, we set the video to a smaller size for users with low VRAM. If you have enough VRAM, you can change the size"
            ],
            "color": "#222",
            "bgcolor": "#000"
          },
          {
            "id": 105,
            "type": "MarkdownNote",
            "pos": [
              -469.9999795985529,
              279.9998197772136
            ],
            "size": [
              480,
              170.65104166666669
            ],
            "flags": {},
            "order": 5,
            "mode": 0,
            "inputs": [],
            "outputs": [],
            "title": "VRAM Usage",
            "properties": {
              "ue_properties": {
                "version": "7.1",
                "widget_ue_connectable": {},
                "input_ue_unconnectable": {}
              }
            },
            "widgets_values": [
              "## GPU:RTX4090D 24GB\n\n| Model            | Size |VRAM Usage | 1st Generation | 2nd Generation |\n|---------------------|-------|-----------|---------------|-----------------|\n| fp8_scaled               |640*640| 84%               | ≈  536s              | ≈ 513s                   |\n| fp8_scaled +  4steps LoRA  | 640*640  | 83%                | ≈ 97s               | ≈ 71s                   |"
            ],
            "color": "#222",
            "bgcolor": "#000"
          },
          {
            "id": 66,
            "type": "MarkdownNote",
            "pos": [
              -469.9999795985529,
              -320.00012452364496
            ],
            "size": [
              480,
              572.1354166666667
            ],
            "flags": {},
            "order": 6,
            "mode": 0,
            "inputs": [],
            "outputs": [],
            "title": "Model Links",
            "properties": {
              "ue_properties": {
                "widget_ue_connectable": {},
                "version": "7.1",
                "input_ue_unconnectable": {}
              }
            },
            "widgets_values": [
              "[Tutorial](https://docs.comfy.org/tutorials/video/wan/wan2_2\n)\n\n**Diffusion Model**\n- [wan2.2_i2v_high_noise_14B_fp8_scaled.safetensors](https://huggingface.co/Comfy-Org/Wan_2.2_ComfyUI_Repackaged/resolve/main/split_files/diffusion_models/wan2.2_i2v_high_noise_14B_fp8_scaled.safetensors)\n- [wan2.2_i2v_low_noise_14B_fp8_scaled.safetensors](https://huggingface.co/Comfy-Org/Wan_2.2_ComfyUI_Repackaged/resolve/main/split_files/diffusion_models/wan2.2_i2v_low_noise_14B_fp8_scaled.safetensors)\n\n**LoRA**\n- [wan2.2_i2v_lightx2v_4steps_lora_v1_low_noise.safetensors](https://huggingface.co/Comfy-Org/Wan_2.2_ComfyUI_Repackaged/resolve/main/split_files/loras/wan2.2_i2v_lightx2v_4steps_lora_v1_low_noise.safetensors)\n- [wan2.2_i2v_lightx2v_4steps_lora_v1_high_noise.safetensors](https://huggingface.co/Comfy-Org/Wan_2.2_ComfyUI_Repackaged/resolve/main/split_files/loras/wan2.2_i2v_lightx2v_4steps_lora_v1_high_noise.safetensors)\n\n**VAE**\n- [wan_2.1_vae.safetensors](https://huggingface.co/Comfy-Org/Wan_2.2_ComfyUI_Repackaged/resolve/main/split_files/vae/wan_2.1_vae.safetensors)\n\n**Text Encoder**   \n- [umt5_xxl_fp8_e4m3fn_scaled.safetensors](https://huggingface.co/Comfy-Org/Wan_2.1_ComfyUI_repackaged/resolve/main/split_files/text_encoders/umt5_xxl_fp8_e4m3fn_scaled.safetensors)\n\n\nFile save location\n\n```\nComfyUI/\n├───📂 models/\n│   ├───📂 diffusion_models/\n│   │   ├─── wan2.2_i2v_low_noise_14B_fp8_scaled.safetensors\n│   │   └─── wan2.2_i2v_high_noise_14B_fp8_scaled.safetensors\n│   ├───📂 loras/\n│   │   ├─── wan2.2_i2v_lightx2v_4steps_lora_v1_low_noise.safetensors\n│   │   └─── wan2.2_i2v_lightx2v_4steps_lora_v1_low_noise.safetensors\n│   ├───📂 text_encoders/\n│   │   └─── umt5_xxl_fp8_e4m3fn_scaled.safetensors \n│   └───📂 vae/\n│       └── wan_2.1_vae.safetensors\n```\n"
            ],
            "color": "#222",
            "bgcolor": "#000"
          },
          {
            "id": 115,
            "type": "Note",
            "pos": [
              29.999978639114225,
              -470.00010361843204
            ],
            "size": [
              360,
              88
            ],
            "flags": {},
            "order": 7,
            "mode": 0,
            "inputs": [],
            "outputs": [],
            "title": "About 4 Steps LoRA",
            "properties": {
              "ue_properties": {
                "widget_ue_connectable": {},
                "version": "7.1",
                "input_ue_unconnectable": {}
              }
            },
            "widgets_values": [
              "Using the Wan2.2 Lighting LoRA will result in the loss of video dynamics, but it will reduce the generation time. This template provides two workflows, and you can enable one as needed."
            ],
            "color": "#222",
            "bgcolor": "#000"
          },
          {
            "id": 117,
            "type": "CreateVideo",
            "pos": [
              1030,
              650
            ],
            "size": [
              270,
              78
            ],
            "flags": {},
            "order": 18,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "images",
                "name": "images",
                "type": "IMAGE",
                "link": 220
              },
              {
                "localized_name": "audio",
                "name": "audio",
                "shape": 7,
                "type": "AUDIO",
                "link": null
              },
              {
                "localized_name": "fps",
                "name": "fps",
                "type": "FLOAT",
                "widget": {
                  "name": "fps"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "VIDEO",
                "name": "VIDEO",
                "type": "VIDEO",
                "links": [
                  221
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.11.0",
              "Node name for S&R": "CreateVideo"
            },
            "widgets_values": [
              16
            ]
          },
          {
            "id": 87,
            "type": "VAEDecode",
            "pos": [
              1020,
              540
            ],
            "size": [
              210,
              46
            ],
            "flags": {},
            "order": 15,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "samples",
                "name": "samples",
                "type": "LATENT",
                "link": 175
              },
              {
                "localized_name": "vae",
                "name": "vae",
                "type": "VAE",
                "link": 176
              }
            ],
            "outputs": [
              {
                "localized_name": "IMAGE",
                "name": "IMAGE",
                "type": "IMAGE",
                "slot_index": 0,
                "links": [
                  220
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.3.45",
              "Node name for S&R": "VAEDecode",
              "ue_properties": {
                "widget_ue_connectable": {},
                "version": "7.1",
                "input_ue_unconnectable": {}
              }
            },
            "widgets_values": []
          }
        ],
        "groups": [
          {
            "id": 15,
            "title": "fp8_scaled +  4steps LoRA",
            "bounding": [
              30,
              -350,
              1630,
              1120
            ],
            "color": "#444",
            "font_size": 24,
            "flags": {}
          },
          {
            "id": 11,
            "title": "Step1 - Load models",
            "bounding": [
              40,
              -310,
              371.0310363769531,
              571.3974609375
            ],
            "color": "#444",
            "font_size": 24,
            "flags": {}
          },
          {
            "id": 13,
            "title": "Step4 -  Prompt",
            "bounding": [
              430,
              20,
              530,
              420
            ],
            "color": "#444",
            "font_size": 24,
            "flags": {}
          },
          {
            "id": 14,
            "title": "Step3 - Video size & length",
            "bounding": [
              430,
              460,
              530,
              290
            ],
            "color": "#444",
            "font_size": 24,
            "flags": {}
          },
          {
            "id": 16,
            "title": "Lightx2v 4steps LoRA",
            "bounding": [
              430,
              -310,
              530,
              310
            ],
            "color": "#444",
            "font_size": 24,
            "flags": {}
          }
        ],
        "links": [
          {
            "id": 189,
            "origin_id": 102,
            "origin_slot": 0,
            "target_id": 103,
            "target_slot": 0,
            "type": "MODEL"
          },
          {
            "id": 181,
            "origin_id": 84,
            "origin_slot": 0,
            "target_id": 93,
            "target_slot": 0,
            "type": "CLIP"
          },
          {
            "id": 178,
            "origin_id": 84,
            "origin_slot": 0,
            "target_id": 89,
            "target_slot": 0,
            "type": "CLIP"
          },
          {
            "id": 194,
            "origin_id": 95,
            "origin_slot": 0,
            "target_id": 101,
            "target_slot": 0,
            "type": "MODEL"
          },
          {
            "id": 196,
            "origin_id": 96,
            "origin_slot": 0,
            "target_id": 102,
            "target_slot": 0,
            "type": "MODEL"
          },
          {
            "id": 190,
            "origin_id": 101,
            "origin_slot": 0,
            "target_id": 104,
            "target_slot": 0,
            "type": "MODEL"
          },
          {
            "id": 183,
            "origin_id": 93,
            "origin_slot": 0,
            "target_id": 98,
            "target_slot": 0,
            "type": "CONDITIONING"
          },
          {
            "id": 184,
            "origin_id": 89,
            "origin_slot": 0,
            "target_id": 98,
            "target_slot": 1,
            "type": "CONDITIONING"
          },
          {
            "id": 185,
            "origin_id": 90,
            "origin_slot": 0,
            "target_id": 98,
            "target_slot": 2,
            "type": "VAE"
          },
          {
            "id": 175,
            "origin_id": 85,
            "origin_slot": 0,
            "target_id": 87,
            "target_slot": 0,
            "type": "LATENT"
          },
          {
            "id": 176,
            "origin_id": 90,
            "origin_slot": 0,
            "target_id": 87,
            "target_slot": 1,
            "type": "VAE"
          },
          {
            "id": 195,
            "origin_id": 104,
            "origin_slot": 0,
            "target_id": 86,
            "target_slot": 0,
            "type": "MODEL"
          },
          {
            "id": 172,
            "origin_id": 98,
            "origin_slot": 0,
            "target_id": 86,
            "target_slot": 1,
            "type": "CONDITIONING"
          },
          {
            "id": 173,
            "origin_id": 98,
            "origin_slot": 1,
            "target_id": 86,
            "target_slot": 2,
            "type": "CONDITIONING"
          },
          {
            "id": 174,
            "origin_id": 98,
            "origin_slot": 2,
            "target_id": 86,
            "target_slot": 3,
            "type": "LATENT"
          },
          {
            "id": 192,
            "origin_id": 103,
            "origin_slot": 0,
            "target_id": 85,
            "target_slot": 0,
            "type": "MODEL"
          },
          {
            "id": 168,
            "origin_id": 98,
            "origin_slot": 0,
            "target_id": 85,
            "target_slot": 1,
            "type": "CONDITIONING"
          },
          {
            "id": 169,
            "origin_id": 98,
            "origin_slot": 1,
            "target_id": 85,
            "target_slot": 2,
            "type": "CONDITIONING"
          },
          {
            "id": 170,
            "origin_id": 86,
            "origin_slot": 0,
            "target_id": 85,
            "target_slot": 3,
            "type": "LATENT"
          },
          {
            "id": 186,
            "origin_id": -10,
            "origin_slot": 0,
            "target_id": 98,
            "target_slot": 4,
            "type": "IMAGE"
          },
          {
            "id": 220,
            "origin_id": 87,
            "origin_slot": 0,
            "target_id": 117,
            "target_slot": 0,
            "type": "IMAGE"
          },
          {
            "id": 221,
            "origin_id": 117,
            "origin_slot": 0,
            "target_id": -20,
            "target_slot": 0,
            "type": "VIDEO"
          },
          {
            "id": 222,
            "origin_id": -10,
            "origin_slot": 1,
            "target_id": 93,
            "target_slot": 1,
            "type": "STRING"
          },
          {
            "id": 223,
            "origin_id": -10,
            "origin_slot": 2,
            "target_id": 98,
            "target_slot": 5,
            "type": "INT"
          },
          {
            "id": 224,
            "origin_id": -10,
            "origin_slot": 3,
            "target_id": 98,
            "target_slot": 6,
            "type": "INT"
          },
          {
            "id": 225,
            "origin_id": -10,
            "origin_slot": 4,
            "target_id": 98,
            "target_slot": 7,
            "type": "INT"
          },
          {
            "id": 226,
            "origin_id": -10,
            "origin_slot": 5,
            "target_id": 95,
            "target_slot": 0,
            "type": "COMBO"
          },
          {
            "id": 227,
            "origin_id": -10,
            "origin_slot": 6,
            "target_id": 101,
            "target_slot": 1,
            "type": "COMBO"
          },
          {
            "id": 228,
            "origin_id": -10,
            "origin_slot": 7,
            "target_id": 96,
            "target_slot": 0,
            "type": "COMBO"
          },
          {
            "id": 229,
            "origin_id": -10,
            "origin_slot": 8,
            "target_id": 102,
            "target_slot": 1,
            "type": "COMBO"
          },
          {
            "id": 230,
            "origin_id": -10,
            "origin_slot": 9,
            "target_id": 84,
            "target_slot": 0,
            "type": "COMBO"
          },
          {
            "id": 231,
            "origin_id": -10,
            "origin_slot": 10,
            "target_id": 90,
            "target_slot": 0,
            "type": "COMBO"
          }
        ],
        "extra": {
          "workflowRendererVersion": "LG"
        },
        "category": "Video generation and editing/Image to video",
        "description": "Image-to-video with Wan 2.2 using a start image plus text prompt to extend motion from the still frame."
      }
    ]
  },
  "config": {},
  "extra": {
    "ds": {
      "scale": 0.7926047855889957,
      "offset": [
        -30.12529469925767,
        690.3829855122884
      ]
    },
    "frontendVersion": "1.37.11",
    "workflowRendererVersion": "LG",
    "VHS_latentpreview": false,
    "VHS_latentpreviewrate": 0,
    "VHS_MetadataImage": true,
    "VHS_KeepIntermediate": true,
    "ue_links": []
  },
  "version": 0.4
}
```
