# 批量视频补帧

- 来源类别：用户工作流
- 镜像内原始路径：`/ComfyUI/user/default/workflows/批量处理/批量视频补帧.json`
- 节点数量：4
- 连线数量：4

## 节点类型

- `BatchVideoLoader` × 1
- `RIFE VFI` × 1
- `VHS_VideoCombine` × 1
- `easy cleanGpuUsed` × 1

## 工作流引用的模型或媒体文件

- `.ap-beijing.myqcloud.com//6026960d747ab2678bc6b02e27205fea/output/补帧_00001_p82_vkqvq_1777362253.mp4`
- `/ComfyUI/output/补帧_00006-audio.mp4`
- `rife49.pth`
- `补帧_00006-audio.mp4`

## 原始工作流 JSON

```json
{
  "id": "48720452-ed20-4002-946f-b57e22b0e35f",
  "revision": 0,
  "last_node_id": 204,
  "last_link_id": 302,
  "nodes": [
    {
      "id": 199,
      "type": "easy cleanGpuUsed",
      "pos": [
        2340.426025390625,
        5573.86572265625
      ],
      "size": [
        157.38925170898438,
        26
      ],
      "flags": {},
      "order": 3,
      "mode": 0,
      "inputs": [
        {
          "label": "输入任何",
          "localized_name": "输入任何",
          "name": "anything",
          "type": "*",
          "link": 295
        }
      ],
      "outputs": [
        {
          "label": "output",
          "localized_name": "output",
          "name": "output",
          "type": "*"
        }
      ],
      "properties": {
        "Node name for S&R": "easy cleanGpuUsed",
        "widget_ue_connectable": {}
      },
      "widgets_values": []
    },
    {
      "id": 191,
      "type": "RIFE VFI",
      "pos": [
        1743.960205078125,
        5410.3681640625
      ],
      "size": [
        289.6578063964844,
        198
      ],
      "flags": {
        "collapsed": false
      },
      "order": 1,
      "mode": 0,
      "inputs": [
        {
          "label": "图像",
          "localized_name": "frames",
          "name": "frames",
          "type": "IMAGE",
          "link": 301
        },
        {
          "label": "插值规则(可选)",
          "localized_name": "optional_interpolation_states",
          "name": "optional_interpolation_states",
          "shape": 7,
          "type": "INTERPOLATION_STATES"
        },
        {
          "localized_name": "ckpt名称",
          "name": "ckpt_name",
          "type": "COMBO",
          "widget": {
            "name": "ckpt_name"
          },
          "link": null
        },
        {
          "label": "clear_cache_after_n_frames",
          "localized_name": "N帧后清除缓存",
          "name": "clear_cache_after_n_frames",
          "type": "INT",
          "widget": {
            "name": "clear_cache_after_n_frames"
          }
        },
        {
          "label": "multiplier",
          "localized_name": "乘数",
          "name": "multiplier",
          "type": "INT",
          "widget": {
            "name": "multiplier"
          }
        },
        {
          "label": "fast_mode",
          "localized_name": "快速模式",
          "name": "fast_mode",
          "type": "BOOLEAN",
          "widget": {
            "name": "fast_mode"
          }
        },
        {
          "label": "ensemble",
          "localized_name": "ensemble",
          "name": "ensemble",
          "type": "BOOLEAN",
          "widget": {
            "name": "ensemble"
          }
        },
        {
          "label": "scale_factor",
          "localized_name": "缩放系数",
          "name": "scale_factor",
          "type": "COMBO",
          "widget": {
            "name": "scale_factor"
          }
        }
      ],
      "outputs": [
        {
          "label": "图像",
          "localized_name": "图像",
          "name": "IMAGE",
          "type": "IMAGE",
          "slot_index": 0,
          "links": [
            293
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "RIFE VFI",
        "cnr_id": "comfyui-frame-interpolation",
        "ver": "1.0.6",
        "ue_properties": {
          "widget_ue_connectable": {
            "ckpt_name": true,
            "fast_mode": true,
            "multiplier": true,
            "clear_cache_after_n_frames": true,
            "ensemble": true,
            "scale_factor": true
          },
          "version": "7.0.1"
        },
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "rife49.pth",
        8,
        2,
        true,
        true,
        1
      ],
      "color": "#323",
      "bgcolor": "#535",
      "shape": 1
    },
    {
      "id": 204,
      "type": "BatchVideoLoader",
      "pos": [
        1405.876220703125,
        5413.341796875
      ],
      "size": [
        212.5390625,
        820
      ],
      "flags": {},
      "order": 0,
      "mode": 0,
      "inputs": [
        {
          "label": "folder_path",
          "localized_name": "folder_path",
          "name": "folder_path",
          "type": "STRING",
          "widget": {
            "name": "folder_path"
          },
          "link": null
        },
        {
          "label": "sort_method",
          "localized_name": "sort_method",
          "name": "sort_method",
          "type": "COMBO",
          "widget": {
            "name": "sort_method"
          },
          "link": null
        },
        {
          "label": "sort_order",
          "localized_name": "sort_order",
          "name": "sort_order",
          "type": "COMBO",
          "widget": {
            "name": "sort_order"
          },
          "link": null
        },
        {
          "label": "force_fps",
          "localized_name": "force_fps",
          "name": "force_fps",
          "type": "FLOAT",
          "widget": {
            "name": "force_fps"
          },
          "link": null
        },
        {
          "label": "force_width",
          "localized_name": "force_width",
          "name": "force_width",
          "type": "INT",
          "widget": {
            "name": "force_width"
          },
          "link": null
        },
        {
          "label": "force_height",
          "localized_name": "force_height",
          "name": "force_height",
          "type": "INT",
          "widget": {
            "name": "force_height"
          },
          "link": null
        },
        {
          "label": "resize_method",
          "localized_name": "resize_method",
          "name": "resize_method",
          "type": "COMBO",
          "widget": {
            "name": "resize_method"
          },
          "link": null
        },
        {
          "label": "auto_queue",
          "localized_name": "auto_queue",
          "name": "auto_queue",
          "type": "COMBO",
          "widget": {
            "name": "auto_queue"
          },
          "link": null
        },
        {
          "label": "start_index",
          "localized_name": "start_index",
          "name": "start_index",
          "shape": 7,
          "type": "INT",
          "widget": {
            "name": "start_index"
          },
          "link": null
        },
        {
          "label": "max_frames",
          "localized_name": "max_frames",
          "name": "max_frames",
          "shape": 7,
          "type": "INT",
          "widget": {
            "name": "max_frames"
          },
          "link": null
        },
        {
          "label": "frame_skip",
          "localized_name": "frame_skip",
          "name": "frame_skip",
          "shape": 7,
          "type": "INT",
          "widget": {
            "name": "frame_skip"
          },
          "link": null
        },
        {
          "label": "custom_extensions",
          "localized_name": "custom_extensions",
          "name": "custom_extensions",
          "shape": 7,
          "type": "STRING",
          "widget": {
            "name": "custom_extensions"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "images",
          "localized_name": "images",
          "name": "images",
          "type": "IMAGE",
          "links": [
            301
          ]
        },
        {
          "label": "audio",
          "localized_name": "audio",
          "name": "audio",
          "type": "AUDIO",
          "links": [
            302
          ]
        },
        {
          "label": "video_path",
          "localized_name": "video_path",
          "name": "video_path",
          "type": "STRING",
          "links": null
        },
        {
          "label": "video_name",
          "localized_name": "video_name",
          "name": "video_name",
          "type": "STRING",
          "links": null
        },
        {
          "label": "filename_prefix",
          "localized_name": "filename_prefix",
          "name": "filename_prefix",
          "type": "STRING",
          "links": null
        },
        {
          "label": "current_index",
          "localized_name": "current_index",
          "name": "current_index",
          "type": "INT",
          "links": null
        },
        {
          "label": "total_count",
          "localized_name": "total_count",
          "name": "total_count",
          "type": "INT",
          "links": null
        },
        {
          "label": "fps",
          "localized_name": "fps",
          "name": "fps",
          "type": "FLOAT",
          "links": null
        },
        {
          "label": "original_fps",
          "localized_name": "original_fps",
          "name": "original_fps",
          "type": "FLOAT",
          "links": null
        },
        {
          "label": "frame_count",
          "localized_name": "frame_count",
          "name": "frame_count",
          "type": "INT",
          "links": null
        },
        {
          "label": "width",
          "localized_name": "width",
          "name": "width",
          "type": "INT",
          "links": null
        },
        {
          "label": "height",
          "localized_name": "height",
          "name": "height",
          "type": "INT",
          "links": null
        }
      ],
      "properties": {
        "Node name for S&R": "BatchVideoLoader"
      },
      "widgets_values": [
        "/ComfyUI/piliang/",
        "filename",
        "ascending",
        15.000000000000004,
        0,
        0,
        "lanczos",
        "enabled",
        0,
        0,
        0,
        ""
      ]
    },
    {
      "id": 198,
      "type": "VHS_VideoCombine",
      "pos": [
        2075.393798828125,
        5405.66064453125
      ],
      "size": [
        476.0711669921875,
        1158.793185763889
      ],
      "flags": {},
      "order": 2,
      "mode": 0,
      "inputs": [
        {
          "label": "图像",
          "localized_name": "images",
          "name": "images",
          "type": "IMAGE",
          "link": 293
        },
        {
          "label": "音频",
          "localized_name": "audio",
          "name": "audio",
          "shape": 7,
          "type": "AUDIO",
          "link": 302
        },
        {
          "label": "批次管理",
          "localized_name": "meta_batch",
          "name": "meta_batch",
          "shape": 7,
          "type": "VHS_BatchManager"
        },
        {
          "label": "vae",
          "localized_name": "vae",
          "name": "vae",
          "shape": 7,
          "type": "VAE"
        },
        {
          "localized_name": "帧率",
          "name": "frame_rate",
          "type": "FLOAT",
          "widget": {
            "name": "frame_rate"
          },
          "link": null
        },
        {
          "label": "loop_count",
          "localized_name": "循环次数",
          "name": "loop_count",
          "type": "INT",
          "widget": {
            "name": "loop_count"
          }
        },
        {
          "label": "filename_prefix",
          "localized_name": "文件名前缀",
          "name": "filename_prefix",
          "type": "STRING",
          "widget": {
            "name": "filename_prefix"
          }
        },
        {
          "label": "format",
          "localized_name": "格式",
          "name": "format",
          "type": "COMBO",
          "widget": {
            "name": "format"
          }
        },
        {
          "label": "pingpong",
          "localized_name": "Ping-Pong",
          "name": "pingpong",
          "type": "BOOLEAN",
          "widget": {
            "name": "pingpong"
          }
        },
        {
          "label": "save_output",
          "localized_name": "保存到输出文件夹",
          "name": "save_output",
          "type": "BOOLEAN",
          "widget": {
            "name": "save_output"
          }
        },
        {
          "name": "pix_fmt",
          "type": [
            "yuv420p",
            "yuv420p10le"
          ],
          "widget": {
            "name": "pix_fmt"
          },
          "link": null
        },
        {
          "name": "crf",
          "type": "INT",
          "widget": {
            "name": "crf"
          },
          "link": null
        },
        {
          "label": "保存元数据",
          "localized_name": "保存元数据",
          "name": "save_metadata",
          "type": "BOOLEAN",
          "widget": {
            "name": "save_metadata"
          },
          "link": null
        },
        {
          "name": "trim_to_audio",
          "type": "BOOLEAN",
          "widget": {
            "name": "trim_to_audio"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "文件名",
          "localized_name": "Filenames",
          "name": "Filenames",
          "type": "VHS_FILENAMES",
          "links": [
            295
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "VHS_VideoCombine",
        "cnr_id": "comfyui-videohelpersuite",
        "ver": "0a75c7958fe320efcb052f1d9f8451fd20c730a8",
        "widget_ue_connectable": {}
      },
      "widgets_values": {
        "frame_rate": 30,
        "loop_count": 0,
        "filename_prefix": "补帧",
        "format": "video/h264-mp4",
        "pix_fmt": "yuv420p",
        "crf": 16,
        "save_metadata": true,
        "trim_to_audio": false,
        "pingpong": false,
        "save_output": true,
        "videopreview": {
          "paused": false,
          "hidden": false,
          "params": {
            "score": "0",
            "filename": "补帧_00006-audio.mp4",
            "cos_url": "https://rh-images-1252422369.cos.ap-beijing.myqcloud.com//6026960d747ab2678bc6b02e27205fea/output/补帧_00001_p82_vkqvq_1777362253.mp4",
            "workflow": "补帧_00006.png",
            "fullpath": "/ComfyUI/output/补帧_00006-audio.mp4",
            "format": "video/h264-mp4",
            "subfolder": "",
            "label": "Normal",
            "type": "output",
            "frame_rate": 30
          }
        }
      },
      "color": "#323",
      "bgcolor": "#535"
    }
  ],
  "links": [
    [
      293,
      191,
      0,
      198,
      0,
      "IMAGE"
    ],
    [
      295,
      198,
      0,
      199,
      0,
      "*"
    ],
    [
      301,
      204,
      0,
      191,
      0,
      "IMAGE"
    ],
    [
      302,
      204,
      1,
      198,
      1,
      "AUDIO"
    ]
  ],
  "groups": [
    {
      "id": 41,
      "title": "补充功能：补帧",
      "bounding": [
        1367.2286376953125,
        5313.8095703125,
        1213.053466796875,
        1050.6544189453125
      ],
      "color": "#3f789e",
      "flags": {}
    }
  ],
  "config": {},
  "extra": {
    "ds": {
      "scale": 1.0610764609500025,
      "offset": [
        -762.5743881661724,
        -5345.294922942806
      ]
    },
    "frontendVersion": "1.23.4",
    "links_added_by_ue": [],
    "VHS_KeepIntermediate": true,
    "ue_links": [],
    "VHS_MetadataImage": true,
    "0246.VERSION": [
      0,
      0,
      4
    ],
    "VHS_latentpreviewrate": 0,
    "VHS_latentpreview": false
  },
  "version": 0.4
}
```
