# 反推提示词

- 来源类别：用户工作流
- 镜像内原始路径：`/ComfyUI/user/default/workflows/18个开源模型工作流/图片/反推提示词.json`
- 节点数量：6
- 连线数量：4

## 节点类型

- `GetNode` × 1
- `LayerUtility: JoyCaptionBeta1` × 1
- `LayerUtility: JoyCaptionBeta1ExtraOptions` × 1
- `LayerUtility: LoadJoyCaptionBeta1Model` × 1
- `LoadImage` × 1
- `PreviewAny` × 1

## 原始工作流 JSON

```json
{
  "id": "918d356a-e238-4168-a6d3-5c2bb5607db9",
  "revision": 0,
  "last_node_id": 47,
  "last_link_id": 44,
  "nodes": [
    {
      "id": 31,
      "type": "GetNode",
      "pos": [
        1121.6845703125,
        -182.2011260986328
      ],
      "size": [
        210,
        34
      ],
      "flags": {
        "collapsed": true
      },
      "order": 0,
      "mode": 0,
      "inputs": [],
      "outputs": [
        {
          "label": "IMAGE",
          "name": "IMAGE",
          "type": "IMAGE",
          "links": []
        }
      ],
      "properties": {
        "Node name for S&R": "GetNode",
        "aux_id": "GetNode",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "图像反推"
      ],
      "color": "#2a363b",
      "bgcolor": "#3f5159"
    },
    {
      "id": 29,
      "type": "LayerUtility: JoyCaptionBeta1",
      "pos": [
        479.12921996191244,
        104.9659641053042
      ],
      "size": [
        394.17501192535906,
        390.55608109879955
      ],
      "flags": {},
      "order": 4,
      "mode": 0,
      "inputs": [
        {
          "label": "image",
          "name": "image",
          "type": "IMAGE",
          "link": 43
        },
        {
          "label": "joycaption_beta1_model",
          "name": "joycaption_beta1_model",
          "type": "JOYCAPTIONBETA1_MODEL",
          "link": 31
        },
        {
          "label": "extra_options",
          "name": "extra_options",
          "shape": 7,
          "type": "JoyCaption2ExtraOption",
          "link": 44
        },
        {
          "label": "caption_type",
          "name": "caption_type",
          "type": "COMBO",
          "widget": {
            "name": "caption_type"
          }
        },
        {
          "label": "caption_length",
          "name": "caption_length",
          "type": "COMBO",
          "widget": {
            "name": "caption_length"
          }
        },
        {
          "label": "max_new_tokens",
          "name": "max_new_tokens",
          "type": "INT",
          "widget": {
            "name": "max_new_tokens"
          }
        },
        {
          "label": "top_p",
          "name": "top_p",
          "type": "FLOAT",
          "widget": {
            "name": "top_p"
          }
        },
        {
          "label": "top_k",
          "name": "top_k",
          "type": "INT",
          "widget": {
            "name": "top_k"
          }
        },
        {
          "label": "temperature",
          "name": "temperature",
          "type": "FLOAT",
          "widget": {
            "name": "temperature"
          }
        },
        {
          "label": "user_prompt",
          "name": "user_prompt",
          "type": "STRING",
          "widget": {
            "name": "user_prompt"
          }
        }
      ],
      "outputs": [
        {
          "label": "text",
          "name": "text",
          "shape": 6,
          "type": "STRING",
          "links": [
            28
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "LayerUtility: JoyCaptionBeta1",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "MidJourney",
        "long",
        1024,
        0.9,
        0,
        0.6,
        "Analyze the main content of the image meticulously. Describe the physical elements in the scene comprehensively and in extreme detail. Start directly with the core subject. Do not include any introductory or preamble sentences. Strictly avoid redundant or referential terms such as \"The image shows,\" \"This picture is,\" \"It is visible,\" \"The scene contains,\" or \"The main subject.\" Use short, concise sentences. Avoid overly long single sentences. Do not add any numbers at the beginning of the sentences. Maintain a purely objective and realistic tone. Describe only the physical appearance, clothing, posture, facial expressions, surrounding objects, background environment, and color characteristics. Absolutely no mention of creator names, film/TV IPs, or specific character names. However, you MUST accurately describe the art style, creative medium, painting genre, and rendering techniques used in the image. Strictly prohibit any aesthetic evaluations or image quality ratings. Adopt a Chinese-English bilingual comparison format. Present the complete Chinese description first. Follow it immediately below with the corresponding English description."
      ],
      "color": "rgba(38, 73, 116, 0.7)"
    },
    {
      "id": 38,
      "type": "LayerUtility: LoadJoyCaptionBeta1Model",
      "pos": [
        40.565736964922095,
        387.91156436545475
      ],
      "size": [
        416.792578125,
        106
      ],
      "flags": {},
      "order": 1,
      "mode": 0,
      "inputs": [
        {
          "label": "model",
          "name": "model",
          "type": "COMBO",
          "widget": {
            "name": "model"
          }
        },
        {
          "label": "quantization_mode",
          "name": "quantization_mode",
          "type": "COMBO",
          "widget": {
            "name": "quantization_mode"
          }
        },
        {
          "label": "device",
          "name": "device",
          "type": "COMBO",
          "widget": {
            "name": "device"
          }
        }
      ],
      "outputs": [
        {
          "label": "joycaption_beta1_model",
          "name": "joycaption_beta1_model",
          "type": "JOYCAPTIONBETA1_MODEL",
          "links": [
            31
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "LayerUtility: LoadJoyCaptionBeta1Model",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "fancyfeast/llama-joycaption-beta-one-hf-llava",
        "bf16",
        "cuda"
      ],
      "color": "rgba(38, 73, 116, 0.7)"
    },
    {
      "id": 45,
      "type": "LoadImage",
      "pos": [
        176.42766085846006,
        20.68216597090613
      ],
      "size": [
        270,
        314
      ],
      "flags": {},
      "order": 2,
      "mode": 0,
      "inputs": [],
      "outputs": [
        {
          "name": "IMAGE",
          "type": "IMAGE",
          "links": [
            43
          ]
        },
        {
          "name": "MASK",
          "type": "MASK",
          "links": null
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.27.0",
        "Node name for S&R": "LoadImage"
      },
      "widgets_values": [
        "100fa7cc9db09b2e81ab214b98a152ed27b81fa0ea88dfcf3ba125b2bac939a8.png",
        "image"
      ]
    },
    {
      "id": 26,
      "type": "PreviewAny",
      "pos": [
        888.6685670461978,
        105.23188856412212
      ],
      "size": [
        431.2911071777344,
        534.8238525390625
      ],
      "flags": {},
      "order": 5,
      "mode": 0,
      "inputs": [
        {
          "label": "source",
          "name": "source",
          "type": "*",
          "link": 28
        }
      ],
      "outputs": [
        {
          "label": "STRING",
          "name": "STRING",
          "type": "STRING"
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.27.0",
        "Node name for S&R": "PreviewAny",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        null,
        null,
        null
      ]
    },
    {
      "id": 47,
      "type": "LayerUtility: JoyCaptionBeta1ExtraOptions",
      "pos": [
        -23.879980491404208,
        551.0731931489532
      ],
      "size": [
        484.1548828125,
        706
      ],
      "flags": {},
      "order": 3,
      "mode": 0,
      "inputs": [],
      "outputs": [
        {
          "name": "extra_option",
          "type": "JoyCaption2ExtraOption",
          "links": [
            44
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "LayerUtility: JoyCaptionBeta1ExtraOptions"
      },
      "widgets_values": [
        false,
        false,
        true,
        true,
        false,
        false,
        false,
        false,
        true,
        true,
        true,
        false,
        true,
        true,
        false,
        false,
        false,
        false,
        false,
        false,
        false,
        true,
        true,
        false,
        false,
        false,
        false,
        ""
      ],
      "color": "rgba(38, 73, 116, 0.7)"
    }
  ],
  "links": [
    [
      28,
      29,
      0,
      26,
      0,
      "*"
    ],
    [
      31,
      38,
      0,
      29,
      1,
      "JOYCAPTIONBETA1_MODEL"
    ],
    [
      43,
      45,
      0,
      29,
      0,
      "IMAGE"
    ],
    [
      44,
      47,
      0,
      29,
      2,
      "JoyCaption2ExtraOption"
    ]
  ],
  "groups": [
    {
      "id": 6,
      "title": "反推提示词",
      "bounding": [
        845.41259765625,
        -1072.4615478515625,
        494.0649108886719,
        136
      ],
      "color": "#b58b2a",
      "flags": {}
    },
    {
      "id": 7,
      "title": "JoyCaption急速 + RH Captioner去风格化+Qwen3 VQA 标签转短句",
      "bounding": [
        -24.025941848754883,
        -922.9819946289062,
        2297.880859375,
        111.51930236816406
      ],
      "color": "#b58b2a",
      "flags": {}
    }
  ],
  "config": {},
  "extra": {
    "links_added_by_ue": [],
    "ue_links": [],
    "0246.VERSION": [
      0,
      0,
      4
    ],
    "ds": {
      "scale": 1.061076460950003,
      "offset": [
        380.91858817129145,
        236.34602297405516
      ]
    },
    "frontendVersion": "1.45.20",
    "VHS_latentpreview": false,
    "VHS_latentpreviewrate": 0,
    "VHS_MetadataImage": true,
    "VHS_KeepIntermediate": true
  },
  "version": 0.4
}
```
