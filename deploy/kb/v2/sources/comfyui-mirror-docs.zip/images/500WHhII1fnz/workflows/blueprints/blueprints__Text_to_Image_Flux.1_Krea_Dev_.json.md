# Text to Image (Flux.1 Krea Dev)

- 来源类别：内置工作流蓝图
- 镜像内原始路径：`/ComfyUI/blueprints/Text to Image (Flux.1 Krea Dev).json`
- 节点数量：1
- 连线数量：0

## 节点类型

- `aa0a207e-bf0e-477c-a87f-f58fcf5f7749` × 1

## 原始工作流 JSON

```json
{
  "revision": 0,
  "last_node_id": 196,
  "last_link_id": 0,
  "nodes": [
    {
      "id": 196,
      "type": "aa0a207e-bf0e-477c-a87f-f58fcf5f7749",
      "pos": [
        1010,
        130
      ],
      "size": [
        410,
        460
      ],
      "flags": {},
      "order": 0,
      "mode": 0,
      "inputs": [
        {
          "name": "text",
          "type": "STRING",
          "widget": {
            "name": "text"
          },
          "link": null
        },
        {
          "name": "width",
          "type": "INT",
          "widget": {
            "name": "width"
          },
          "link": null
        },
        {
          "name": "height",
          "type": "INT",
          "widget": {
            "name": "height"
          },
          "link": null
        },
        {
          "name": "seed",
          "type": "INT",
          "widget": {
            "name": "seed"
          },
          "link": null
        },
        {
          "name": "unet_name",
          "type": "COMBO",
          "widget": {
            "name": "unet_name"
          },
          "link": null
        },
        {
          "name": "clip_name1",
          "type": "COMBO",
          "widget": {
            "name": "clip_name1"
          },
          "link": null
        },
        {
          "name": "clip_name2",
          "type": "COMBO",
          "widget": {
            "name": "clip_name2"
          },
          "link": null
        },
        {
          "name": "vae_name",
          "type": "COMBO",
          "widget": {
            "name": "vae_name"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "localized_name": "IMAGE",
          "name": "IMAGE",
          "type": "IMAGE",
          "links": []
        }
      ],
      "properties": {
        "proxyWidgets": [
          [
            "195",
            "text"
          ],
          [
            "27",
            "width"
          ],
          [
            "27",
            "height"
          ],
          [
            "31",
            "seed"
          ],
          [
            "38",
            "unet_name"
          ],
          [
            "40",
            "clip_name1"
          ],
          [
            "40",
            "clip_name2"
          ],
          [
            "39",
            "vae_name"
          ]
        ],
        "ue_properties": {
          "widget_ue_connectable": {},
          "input_ue_unconnectable": {}
        },
        "cnr_id": "comfy-core",
        "ver": "0.18.1"
      },
      "widgets_values": [],
      "title": "Text to Image (Flux.1 Krea Dev)"
    }
  ],
  "links": [],
  "version": 0.4,
  "definitions": {
    "subgraphs": [
      {
        "id": "aa0a207e-bf0e-477c-a87f-f58fcf5f7749",
        "version": 1,
        "state": {
          "lastGroupId": 8,
          "lastNodeId": 196,
          "lastLinkId": 395,
          "lastRerouteId": 0
        },
        "revision": 0,
        "config": {},
        "name": "Text to Image (Flux.1 Krea Dev)",
        "inputNode": {
          "id": -10,
          "bounding": [
            -1050,
            426,
            120,
            200
          ]
        },
        "outputNode": {
          "id": -20,
          "bounding": [
            620,
            140,
            120,
            60
          ]
        },
        "inputs": [
          {
            "id": "c2515318-6e10-4ad9-9466-e6aa855bc849",
            "name": "text",
            "type": "STRING",
            "linkIds": [
              71
            ],
            "pos": [
              -950,
              446
            ]
          },
          {
            "id": "09f20672-c8a3-4180-823a-5a6af0113e4f",
            "name": "width",
            "type": "INT",
            "linkIds": [
              72
            ],
            "pos": [
              -950,
              466
            ]
          },
          {
            "id": "7f54c952-896e-4356-bfb2-970e1c8f2eb7",
            "name": "height",
            "type": "INT",
            "linkIds": [
              73
            ],
            "pos": [
              -950,
              486
            ]
          },
          {
            "id": "e2dc1c86-2fb4-4b80-b560-f30560af1897",
            "name": "seed",
            "type": "INT",
            "linkIds": [
              391
            ],
            "pos": [
              -950,
              506
            ]
          },
          {
            "id": "34b172e7-85b2-444a-9a4d-1221f272c46e",
            "name": "unet_name",
            "type": "COMBO",
            "linkIds": [
              392
            ],
            "pos": [
              -950,
              526
            ]
          },
          {
            "id": "073b7440-d943-4a2f-a3a1-fbdb8fcda9f9",
            "name": "clip_name1",
            "type": "COMBO",
            "linkIds": [
              393
            ],
            "pos": [
              -950,
              546
            ]
          },
          {
            "id": "55c1286a-4aca-41fc-b967-ae3d3fa7bc85",
            "name": "clip_name2",
            "type": "COMBO",
            "linkIds": [
              394
            ],
            "pos": [
              -950,
              566
            ]
          },
          {
            "id": "2241e4fc-9219-4be7-bf6d-3493b579ab5a",
            "name": "vae_name",
            "type": "COMBO",
            "linkIds": [
              395
            ],
            "pos": [
              -950,
              586
            ]
          }
        ],
        "outputs": [
          {
            "id": "5310184a-f0a2-405f-9917-dd2a352a4fac",
            "name": "IMAGE",
            "type": "IMAGE",
            "linkIds": [
              9
            ],
            "localized_name": "IMAGE",
            "pos": [
              640,
              160
            ]
          }
        ],
        "widgets": [],
        "nodes": [
          {
            "id": 40,
            "type": "DualCLIPLoader",
            "pos": [
              -780,
              360
            ],
            "size": [
              270,
              180
            ],
            "flags": {},
            "order": 5,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "clip_name1",
                "name": "clip_name1",
                "type": "COMBO",
                "widget": {
                  "name": "clip_name1"
                },
                "link": 393
              },
              {
                "localized_name": "clip_name2",
                "name": "clip_name2",
                "type": "COMBO",
                "widget": {
                  "name": "clip_name2"
                },
                "link": 394
              },
              {
                "localized_name": "type",
                "name": "type",
                "type": "COMBO",
                "widget": {
                  "name": "type"
                },
                "link": null
              },
              {
                "localized_name": "device",
                "name": "device",
                "shape": 7,
                "type": "COMBO",
                "widget": {
                  "name": "device"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "CLIP",
                "name": "CLIP",
                "type": "CLIP",
                "links": [
                  64
                ]
              }
            ],
            "properties": {
              "ue_properties": {
                "widget_ue_connectable": {},
                "input_ue_unconnectable": {}
              },
              "cnr_id": "comfy-core",
              "ver": "0.3.40",
              "Node name for S&R": "DualCLIPLoader",
              "models": [
                {
                  "name": "clip_l.safetensors",
                  "url": "https://huggingface.co/comfyanonymous/flux_text_encoders/resolve/main/clip_l.safetensors",
                  "directory": "text_encoders"
                },
                {
                  "name": "t5xxl_fp16.safetensors",
                  "url": "https://huggingface.co/comfyanonymous/flux_text_encoders/resolve/main/t5xxl_fp16.safetensors",
                  "directory": "text_encoders"
                }
              ]
            },
            "widgets_values": [
              "clip_l.safetensors",
              "t5xxl_fp16.safetensors",
              "flux",
              "default"
            ]
          },
          {
            "id": 39,
            "type": "VAELoader",
            "pos": [
              -770,
              630
            ],
            "size": [
              240,
              110
            ],
            "flags": {},
            "order": 4,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "vae_name",
                "name": "vae_name",
                "type": "COMBO",
                "widget": {
                  "name": "vae_name"
                },
                "link": 395
              }
            ],
            "outputs": [
              {
                "localized_name": "VAE",
                "name": "VAE",
                "type": "VAE",
                "links": [
                  58
                ]
              }
            ],
            "properties": {
              "ue_properties": {
                "widget_ue_connectable": {},
                "input_ue_unconnectable": {}
              },
              "cnr_id": "comfy-core",
              "ver": "0.3.40",
              "Node name for S&R": "VAELoader",
              "models": [
                {
                  "name": "ae.safetensors",
                  "url": "https://huggingface.co/Comfy-Org/Lumina_Image_2.0_Repackaged/resolve/main/split_files/vae/ae.safetensors",
                  "directory": "vae"
                }
              ]
            },
            "widgets_values": [
              "ae.safetensors"
            ]
          },
          {
            "id": 38,
            "type": "UNETLoader",
            "pos": [
              -780,
              170
            ],
            "size": [
              270,
              110
            ],
            "flags": {},
            "order": 3,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "unet_name",
                "name": "unet_name",
                "type": "COMBO",
                "widget": {
                  "name": "unet_name"
                },
                "link": 392
              },
              {
                "localized_name": "weight_dtype",
                "name": "weight_dtype",
                "type": "COMBO",
                "widget": {
                  "name": "weight_dtype"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "MODEL",
                "name": "MODEL",
                "type": "MODEL",
                "links": [
                  61
                ]
              }
            ],
            "properties": {
              "ue_properties": {
                "widget_ue_connectable": {},
                "input_ue_unconnectable": {}
              },
              "cnr_id": "comfy-core",
              "ver": "0.3.40",
              "Node name for S&R": "UNETLoader",
              "models": [
                {
                  "name": "flux1-krea-dev_fp8_scaled.safetensors",
                  "url": "https://huggingface.co/Comfy-Org/FLUX.1-Krea-dev_ComfyUI/resolve/main/split_files/diffusion_models/flux1-krea-dev_fp8_scaled.safetensors",
                  "directory": "diffusion_models"
                }
              ]
            },
            "widgets_values": [
              "flux1-krea-dev_fp8_scaled.safetensors",
              "default"
            ]
          },
          {
            "id": 195,
            "type": "CLIPTextEncode",
            "pos": [
              -440,
              180
            ],
            "size": [
              330,
              210
            ],
            "flags": {},
            "order": 7,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "clip",
                "name": "clip",
                "type": "CLIP",
                "link": 64
              },
              {
                "localized_name": "text",
                "name": "text",
                "type": "STRING",
                "widget": {
                  "name": "text"
                },
                "link": 71
              }
            ],
            "outputs": [
              {
                "localized_name": "CONDITIONING",
                "name": "CONDITIONING",
                "type": "CONDITIONING",
                "links": [
                  65,
                  66
                ]
              }
            ],
            "properties": {
              "ue_properties": {
                "widget_ue_connectable": {},
                "input_ue_unconnectable": {}
              },
              "cnr_id": "comfy-core",
              "ver": "0.3.47",
              "Node name for S&R": "CLIPTextEncode"
            },
            "widgets_values": [
              ""
            ]
          },
          {
            "id": 27,
            "type": "EmptySD3LatentImage",
            "pos": [
              -390,
              650
            ],
            "size": [
              270,
              170
            ],
            "flags": {},
            "order": 1,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "width",
                "name": "width",
                "type": "INT",
                "widget": {
                  "name": "width"
                },
                "link": 72
              },
              {
                "localized_name": "height",
                "name": "height",
                "type": "INT",
                "widget": {
                  "name": "height"
                },
                "link": 73
              },
              {
                "localized_name": "batch_size",
                "name": "batch_size",
                "type": "INT",
                "widget": {
                  "name": "batch_size"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "LATENT",
                "name": "LATENT",
                "type": "LATENT",
                "slot_index": 0,
                "links": [
                  51
                ]
              }
            ],
            "properties": {
              "ue_properties": {
                "widget_ue_connectable": {},
                "input_ue_unconnectable": {}
              },
              "cnr_id": "comfy-core",
              "ver": "0.3.40",
              "Node name for S&R": "EmptySD3LatentImage"
            },
            "widgets_values": [
              1024,
              1024,
              1
            ]
          },
          {
            "id": 31,
            "type": "KSampler",
            "pos": [
              0,
              130
            ],
            "size": [
              320,
              350
            ],
            "flags": {},
            "order": 2,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "model",
                "name": "model",
                "type": "MODEL",
                "link": 61
              },
              {
                "localized_name": "positive",
                "name": "positive",
                "type": "CONDITIONING",
                "link": 65
              },
              {
                "localized_name": "negative",
                "name": "negative",
                "type": "CONDITIONING",
                "link": 63
              },
              {
                "localized_name": "latent_image",
                "name": "latent_image",
                "type": "LATENT",
                "link": 51
              },
              {
                "localized_name": "seed",
                "name": "seed",
                "type": "INT",
                "widget": {
                  "name": "seed"
                },
                "link": 391
              },
              {
                "localized_name": "steps",
                "name": "steps",
                "type": "INT",
                "widget": {
                  "name": "steps"
                },
                "link": null
              },
              {
                "localized_name": "cfg",
                "name": "cfg",
                "type": "FLOAT",
                "widget": {
                  "name": "cfg"
                },
                "link": null
              },
              {
                "localized_name": "sampler_name",
                "name": "sampler_name",
                "type": "COMBO",
                "widget": {
                  "name": "sampler_name"
                },
                "link": null
              },
              {
                "localized_name": "scheduler",
                "name": "scheduler",
                "type": "COMBO",
                "widget": {
                  "name": "scheduler"
                },
                "link": null
              },
              {
                "localized_name": "denoise",
                "name": "denoise",
                "type": "FLOAT",
                "widget": {
                  "name": "denoise"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "LATENT",
                "name": "LATENT",
                "type": "LATENT",
                "slot_index": 0,
                "links": [
                  52
                ]
              }
            ],
            "properties": {
              "ue_properties": {
                "widget_ue_connectable": {},
                "input_ue_unconnectable": {}
              },
              "cnr_id": "comfy-core",
              "ver": "0.3.40",
              "Node name for S&R": "KSampler"
            },
            "widgets_values": [
              0,
              "randomize",
              20,
              1,
              "euler",
              "simple",
              1
            ]
          },
          {
            "id": 8,
            "type": "VAEDecode",
            "pos": [
              340,
              140
            ],
            "size": [
              230,
              100
            ],
            "flags": {
              "collapsed": false
            },
            "order": 0,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "samples",
                "name": "samples",
                "type": "LATENT",
                "link": 52
              },
              {
                "localized_name": "vae",
                "name": "vae",
                "type": "VAE",
                "link": 58
              }
            ],
            "outputs": [
              {
                "localized_name": "IMAGE",
                "name": "IMAGE",
                "type": "IMAGE",
                "slot_index": 0,
                "links": [
                  9
                ]
              }
            ],
            "properties": {
              "ue_properties": {
                "widget_ue_connectable": {},
                "input_ue_unconnectable": {}
              },
              "cnr_id": "comfy-core",
              "ver": "0.3.40",
              "Node name for S&R": "VAEDecode"
            }
          },
          {
            "id": 42,
            "type": "ConditioningZeroOut",
            "pos": [
              -340,
              430
            ],
            "size": [
              230,
              80
            ],
            "flags": {
              "collapsed": false
            },
            "order": 6,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "conditioning",
                "name": "conditioning",
                "type": "CONDITIONING",
                "link": 66
              }
            ],
            "outputs": [
              {
                "localized_name": "CONDITIONING",
                "name": "CONDITIONING",
                "type": "CONDITIONING",
                "links": [
                  63
                ]
              }
            ],
            "properties": {
              "ue_properties": {
                "widget_ue_connectable": {},
                "input_ue_unconnectable": {}
              },
              "cnr_id": "comfy-core",
              "ver": "0.3.40",
              "Node name for S&R": "ConditioningZeroOut"
            }
          }
        ],
        "groups": [
          {
            "id": 1,
            "title": "Model",
            "bounding": [
              -800,
              90,
              310,
              750
            ],
            "color": "#3f789e",
            "font_size": 24,
            "flags": {}
          },
          {
            "id": 2,
            "title": "Image Size",
            "bounding": [
              -460,
              560,
              400,
              280
            ],
            "color": "#3f789e",
            "font_size": 24,
            "flags": {}
          },
          {
            "id": 3,
            "title": "Prompt",
            "bounding": [
              -460,
              90,
              400,
              440
            ],
            "color": "#3f789e",
            "font_size": 24,
            "flags": {}
          }
        ],
        "links": [
          {
            "id": 66,
            "origin_id": 195,
            "origin_slot": 0,
            "target_id": 42,
            "target_slot": 0,
            "type": "CONDITIONING"
          },
          {
            "id": 52,
            "origin_id": 31,
            "origin_slot": 0,
            "target_id": 8,
            "target_slot": 0,
            "type": "LATENT"
          },
          {
            "id": 58,
            "origin_id": 39,
            "origin_slot": 0,
            "target_id": 8,
            "target_slot": 1,
            "type": "VAE"
          },
          {
            "id": 61,
            "origin_id": 38,
            "origin_slot": 0,
            "target_id": 31,
            "target_slot": 0,
            "type": "MODEL"
          },
          {
            "id": 65,
            "origin_id": 195,
            "origin_slot": 0,
            "target_id": 31,
            "target_slot": 1,
            "type": "CONDITIONING"
          },
          {
            "id": 63,
            "origin_id": 42,
            "origin_slot": 0,
            "target_id": 31,
            "target_slot": 2,
            "type": "CONDITIONING"
          },
          {
            "id": 51,
            "origin_id": 27,
            "origin_slot": 0,
            "target_id": 31,
            "target_slot": 3,
            "type": "LATENT"
          },
          {
            "id": 64,
            "origin_id": 40,
            "origin_slot": 0,
            "target_id": 195,
            "target_slot": 0,
            "type": "CLIP"
          },
          {
            "id": 9,
            "origin_id": 8,
            "origin_slot": 0,
            "target_id": -20,
            "target_slot": 0,
            "type": "IMAGE"
          },
          {
            "id": 71,
            "origin_id": -10,
            "origin_slot": 0,
            "target_id": 195,
            "target_slot": 1,
            "type": "STRING"
          },
          {
            "id": 72,
            "origin_id": -10,
            "origin_slot": 1,
            "target_id": 27,
            "target_slot": 0,
            "type": "INT"
          },
          {
            "id": 73,
            "origin_id": -10,
            "origin_slot": 2,
            "target_id": 27,
            "target_slot": 1,
            "type": "INT"
          },
          {
            "id": 391,
            "origin_id": -10,
            "origin_slot": 3,
            "target_id": 31,
            "target_slot": 4,
            "type": "INT"
          },
          {
            "id": 392,
            "origin_id": -10,
            "origin_slot": 4,
            "target_id": 38,
            "target_slot": 0,
            "type": "COMBO"
          },
          {
            "id": 393,
            "origin_id": -10,
            "origin_slot": 5,
            "target_id": 40,
            "target_slot": 0,
            "type": "COMBO"
          },
          {
            "id": 394,
            "origin_id": -10,
            "origin_slot": 6,
            "target_id": 40,
            "target_slot": 1,
            "type": "COMBO"
          },
          {
            "id": 395,
            "origin_id": -10,
            "origin_slot": 7,
            "target_id": 39,
            "target_slot": 0,
            "type": "COMBO"
          }
        ],
        "extra": {
          "workflowRendererVersion": "LG"
        },
        "category": "Image generation and editing/Text to image",
        "description": "FLUX.1 Krea [dev] (Black Forest Labs × Krea): open-weight 12B rectified-flow text-to-image drop-in alongside FLUX.1 [dev], tuned away from overcooked saturation toward more natural diversity in people, realism, and style while keeping ecosystem compatibility."
      }
    ]
  },
  "extra": {
    "ds": {
      "scale": 0.735584459955559,
      "offset": [
        1936.5815687336737,
        303.78330847702625
      ]
    },
    "ue_links": []
  }
}
```
