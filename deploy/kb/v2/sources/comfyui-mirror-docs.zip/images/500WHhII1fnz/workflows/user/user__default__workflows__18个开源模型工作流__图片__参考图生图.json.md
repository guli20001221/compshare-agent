# 参考图生图

- 来源类别：用户工作流
- 镜像内原始路径：`/ComfyUI/user/default/workflows/18个开源模型工作流/图片/参考图生图.json`
- 节点数量：21
- 连线数量：22

## 节点类型

- `LoadImage` × 3
- `FluxKontextMultiReferenceLatentMethod` × 2
- `SaveImage` × 2
- `CLIPLoader` × 1
- `ConditioningZeroOut` × 1
- `EmptyLatentImage` × 1
- `KSampler` × 1
- `LayerUtility: PurgeVRAM V2` × 1
- `LayerUtility: TextBox` × 1
- `LoraLoaderModelOnly` × 1
- `SeedVR2LoadDiTModel` × 1
- `SeedVR2LoadVAEModel` × 1
- `SeedVR2VideoUpscaler` × 1
- `TextEncodeQwenImageEditPlus` × 1
- `UNETLoader` × 1
- `VAEDecode` × 1
- `VAELoader` × 1

## 工作流引用的模型或媒体文件

- `-V1.0-fp32-1c18194f7240.safetensors`
- `eedvr2_ema_3b-Q8_0.gguf`
- `ema_vae_fp16.safetensors`
- `qwen_2.5_vl_7b.safetensors`
- `qwen_image_edit_2511_bf16.safetensors`
- `qwen_image_vae.safetensors`

## 原始工作流 JSON

```json
{
  "id": "91f6bbe2-ed41-4fd6-bac7-71d5b5864ecb",
  "revision": 0,
  "last_node_id": 390,
  "last_link_id": 878,
  "nodes": [
    {
      "id": 351,
      "type": "LoadImage",
      "pos": [
        -1720.931884765625,
        -52.0556755065918
      ],
      "size": [
        210,
        326
      ],
      "flags": {},
      "order": 0,
      "mode": 0,
      "inputs": [
        {
          "label": "image",
          "name": "image",
          "type": "COMBO",
          "widget": {
            "name": "image"
          }
        },
        {
          "label": "upload",
          "name": "upload",
          "type": "IMAGEUPLOAD",
          "widget": {
            "name": "upload"
          }
        }
      ],
      "outputs": [
        {
          "label": "IMAGE",
          "name": "IMAGE",
          "type": "IMAGE",
          "links": [
            839
          ]
        },
        {
          "label": "MASK",
          "name": "MASK",
          "type": "MASK"
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.75",
        "Node name for S&R": "LoadImage",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "20191228131551_h3rrK.jpeg",
        "image"
      ]
    },
    {
      "id": 353,
      "type": "LoadImage",
      "pos": [
        -1721.210205078125,
        373.7670593261719
      ],
      "size": [
        210,
        326
      ],
      "flags": {},
      "order": 1,
      "mode": 0,
      "inputs": [
        {
          "label": "image",
          "name": "image",
          "type": "COMBO",
          "widget": {
            "name": "image"
          }
        },
        {
          "label": "upload",
          "name": "upload",
          "type": "IMAGEUPLOAD",
          "widget": {
            "name": "upload"
          }
        }
      ],
      "outputs": [
        {
          "label": "IMAGE",
          "name": "IMAGE",
          "type": "IMAGE",
          "links": [
            841
          ]
        },
        {
          "label": "MASK",
          "name": "MASK",
          "type": "MASK"
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.75",
        "Node name for S&R": "LoadImage",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "ComfyUI_temp_pofoj_00006_.png",
        "image"
      ]
    },
    {
      "id": 356,
      "type": "EmptyLatentImage",
      "pos": [
        -1478.1347088623036,
        586.3148010253904
      ],
      "size": [
        380.62859252929684,
        112.91429626464844
      ],
      "flags": {},
      "order": 2,
      "mode": 0,
      "inputs": [
        {
          "label": "width",
          "name": "width",
          "type": "INT",
          "widget": {
            "name": "width"
          }
        },
        {
          "label": "height",
          "name": "height",
          "type": "INT",
          "widget": {
            "name": "height"
          }
        },
        {
          "label": "batch_size",
          "name": "batch_size",
          "type": "INT",
          "widget": {
            "name": "batch_size"
          }
        }
      ],
      "outputs": [
        {
          "label": "LATENT",
          "name": "LATENT",
          "type": "LATENT",
          "links": [
            852
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.75",
        "Node name for S&R": "EmptyLatentImage",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        720,
        1280,
        1
      ]
    },
    {
      "id": 122,
      "type": "LoraLoaderModelOnly",
      "pos": [
        -479.4347783868962,
        -74.54424077814276
      ],
      "size": [
        375.68957963715843,
        82
      ],
      "flags": {},
      "order": 10,
      "mode": 0,
      "inputs": [
        {
          "label": "model",
          "name": "model",
          "type": "MODEL",
          "link": 799
        },
        {
          "label": "lora_name",
          "name": "lora_name",
          "type": "COMBO",
          "widget": {
            "name": "lora_name"
          }
        },
        {
          "label": "strength_model",
          "name": "strength_model",
          "type": "FLOAT",
          "widget": {
            "name": "strength_model"
          }
        }
      ],
      "outputs": [
        {
          "label": "MODEL",
          "name": "MODEL",
          "type": "MODEL",
          "links": [
            747
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.50",
        "Node name for S&R": "LoraLoaderModelOnly",
        "ue_properties": {
          "widget_ue_connectable": {
            "lora_name": true,
            "strength_model": true
          },
          "input_ue_unconnectable": {},
          "version": "7.5.2"
        },
        "widget_ue_connectable": {
          "lora_name": true,
          "strength_model": true
        }
      },
      "widgets_values": [
        "Qwen-Image-Edit-2511-Lightning-4steps-V1.0-fp32-1c18194f7240.safetensors",
        1
      ]
    },
    {
      "id": 339,
      "type": "UNETLoader",
      "pos": [
        -874.4782215465198,
        -80.77796103737572
      ],
      "size": [
        380.60768821022725,
        95.85281649502838
      ],
      "flags": {},
      "order": 3,
      "mode": 0,
      "inputs": [
        {
          "label": "unet_name",
          "name": "unet_name",
          "type": "COMBO",
          "widget": {
            "name": "unet_name"
          }
        },
        {
          "label": "weight_dtype",
          "name": "weight_dtype",
          "type": "COMBO",
          "widget": {
            "name": "weight_dtype"
          }
        }
      ],
      "outputs": [
        {
          "label": "MODEL",
          "name": "MODEL",
          "type": "MODEL",
          "links": [
            799
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.27.0",
        "Node name for S&R": "UNETLoader",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "qwen_image_edit_2511_bf16.safetensors",
        "default"
      ]
    },
    {
      "id": 38,
      "type": "CLIPLoader",
      "pos": [
        -868.4928755326705,
        64.70933810147372
      ],
      "size": [
        372.54228349165487,
        106
      ],
      "flags": {},
      "order": 4,
      "mode": 0,
      "inputs": [
        {
          "label": "clip_name",
          "name": "clip_name",
          "type": "COMBO",
          "widget": {
            "name": "clip_name"
          }
        },
        {
          "label": "type",
          "name": "type",
          "type": "COMBO",
          "widget": {
            "name": "type"
          }
        },
        {
          "label": "device",
          "name": "device",
          "shape": 7,
          "type": "COMBO",
          "widget": {
            "name": "device"
          }
        }
      ],
      "outputs": [
        {
          "label": "CLIP",
          "name": "CLIP",
          "type": "CLIP",
          "slot_index": 0,
          "links": [
            847
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.49",
        "Node name for S&R": "CLIPLoader",
        "ue_properties": {
          "widget_ue_connectable": {
            "clip_name": true,
            "type": true,
            "device": true
          },
          "input_ue_unconnectable": {},
          "version": "7.5.2"
        },
        "widget_ue_connectable": {
          "clip_name": true,
          "type": true,
          "device": true
        }
      },
      "widgets_values": [
        "qwen_2.5_vl_7b.safetensors",
        "qwen_image",
        "default"
      ],
      "color": "#223",
      "bgcolor": "#335"
    },
    {
      "id": 380,
      "type": "VAELoader",
      "pos": [
        -865.5741743607954,
        217.83556851473716
      ],
      "size": [
        367.8355823863636,
        58.86575594815338
      ],
      "flags": {},
      "order": 5,
      "mode": 0,
      "inputs": [
        {
          "label": "vae_name",
          "name": "vae_name",
          "type": "COMBO",
          "widget": {
            "name": "vae_name"
          }
        }
      ],
      "outputs": [
        {
          "label": "VAE",
          "name": "VAE",
          "type": "VAE",
          "links": [
            860,
            862
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.27.0",
        "Node name for S&R": "VAELoader",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "qwen_image_vae.safetensors"
      ]
    },
    {
      "id": 375,
      "type": "TextEncodeQwenImageEditPlus",
      "pos": [
        -474.6290865811432,
        72.71897610751066
      ],
      "size": [
        376.623202237216,
        200
      ],
      "flags": {},
      "order": 11,
      "mode": 0,
      "inputs": [
        {
          "label": "clip",
          "name": "clip",
          "type": "CLIP",
          "link": 847
        },
        {
          "label": "vae",
          "name": "vae",
          "shape": 7,
          "type": "VAE",
          "link": 862
        },
        {
          "label": "image1",
          "name": "image1",
          "shape": 7,
          "type": "IMAGE",
          "link": 839
        },
        {
          "label": "image2",
          "name": "image2",
          "shape": 7,
          "type": "IMAGE",
          "link": 840
        },
        {
          "label": "image3",
          "name": "image3",
          "shape": 7,
          "type": "IMAGE",
          "link": 841
        },
        {
          "label": "prompt",
          "name": "prompt",
          "type": "STRING",
          "widget": {
            "name": "prompt"
          },
          "link": 870
        }
      ],
      "outputs": [
        {
          "label": "CONDITIONING",
          "name": "CONDITIONING",
          "type": "CONDITIONING",
          "links": [
            850,
            866
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.27.0",
        "Node name for S&R": "TextEncodeQwenImageEditPlus",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        ""
      ]
    },
    {
      "id": 381,
      "type": "ConditioningZeroOut",
      "pos": [
        -90.34862726384938,
        73.2169022993608
      ],
      "size": [
        261.9910583496094,
        26
      ],
      "flags": {},
      "order": 13,
      "mode": 0,
      "inputs": [
        {
          "label": "conditioning",
          "name": "conditioning",
          "type": "CONDITIONING",
          "link": 866
        }
      ],
      "outputs": [
        {
          "label": "CONDITIONING",
          "name": "CONDITIONING",
          "type": "CONDITIONING",
          "links": [
            865
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.50",
        "Node name for S&R": "ConditioningZeroOut",
        "ue_properties": {
          "widget_ue_connectable": {},
          "input_ue_unconnectable": {},
          "version": "7.5.2"
        },
        "widget_ue_connectable": {}
      },
      "widgets_values": []
    },
    {
      "id": 330,
      "type": "FluxKontextMultiReferenceLatentMethod",
      "pos": [
        -85.81272194602272,
        -50.35848860307169
      ],
      "size": [
        251.1640625,
        66.2393569946289
      ],
      "flags": {
        "collapsed": false
      },
      "order": 12,
      "mode": 0,
      "inputs": [
        {
          "label": "conditioning",
          "name": "conditioning",
          "type": "CONDITIONING",
          "link": 850
        },
        {
          "label": "reference_latents_method",
          "name": "reference_latents_method",
          "type": "COMBO",
          "widget": {
            "name": "reference_latents_method"
          }
        }
      ],
      "outputs": [
        {
          "label": "CONDITIONING",
          "name": "CONDITIONING",
          "type": "CONDITIONING",
          "links": [
            785
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.6.0",
        "Node name for S&R": "FluxKontextMultiReferenceLatentMethod",
        "ue_properties": {
          "widget_ue_connectable": {},
          "input_ue_unconnectable": {},
          "version": "7.5.2"
        },
        "widget_ue_connectable": {
          "reference_latents_method": true
        }
      },
      "widgets_values": [
        "index_timestep_zero"
      ]
    },
    {
      "id": 331,
      "type": "FluxKontextMultiReferenceLatentMethod",
      "pos": [
        -80.23518232865771,
        154.87420654296866
      ],
      "size": [
        251.1640625,
        64.78557586669922
      ],
      "flags": {
        "collapsed": false
      },
      "order": 14,
      "mode": 0,
      "inputs": [
        {
          "label": "conditioning",
          "name": "conditioning",
          "type": "CONDITIONING",
          "link": 865
        },
        {
          "label": "reference_latents_method",
          "name": "reference_latents_method",
          "type": "COMBO",
          "widget": {
            "name": "reference_latents_method"
          }
        }
      ],
      "outputs": [
        {
          "label": "CONDITIONING",
          "name": "CONDITIONING",
          "type": "CONDITIONING",
          "links": [
            787
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.6.0",
        "Node name for S&R": "FluxKontextMultiReferenceLatentMethod",
        "ue_properties": {
          "widget_ue_connectable": {},
          "input_ue_unconnectable": {},
          "version": "7.5.2"
        },
        "widget_ue_connectable": {
          "reference_latents_method": true
        }
      },
      "widgets_values": [
        "index_timestep_zero"
      ]
    },
    {
      "id": 302,
      "type": "KSampler",
      "pos": [
        182.94189453124991,
        -54.42724054509944
      ],
      "size": [
        315,
        474.0000305175781
      ],
      "flags": {},
      "order": 15,
      "mode": 0,
      "inputs": [
        {
          "label": "model",
          "name": "model",
          "type": "MODEL",
          "link": 747
        },
        {
          "label": "positive",
          "name": "positive",
          "type": "CONDITIONING",
          "link": 785
        },
        {
          "label": "negative",
          "name": "negative",
          "type": "CONDITIONING",
          "link": 787
        },
        {
          "label": "latent_image",
          "name": "latent_image",
          "type": "LATENT",
          "link": 852
        },
        {
          "label": "seed",
          "name": "seed",
          "type": "INT",
          "widget": {
            "name": "seed"
          }
        },
        {
          "label": "steps",
          "name": "steps",
          "type": "INT",
          "widget": {
            "name": "steps"
          }
        },
        {
          "label": "cfg",
          "name": "cfg",
          "type": "FLOAT",
          "widget": {
            "name": "cfg"
          }
        },
        {
          "label": "sampler_name",
          "name": "sampler_name",
          "type": "COMBO",
          "widget": {
            "name": "sampler_name"
          }
        },
        {
          "label": "scheduler",
          "name": "scheduler",
          "type": "COMBO",
          "widget": {
            "name": "scheduler"
          }
        },
        {
          "label": "denoise",
          "name": "denoise",
          "type": "FLOAT",
          "widget": {
            "name": "denoise"
          }
        }
      ],
      "outputs": [
        {
          "label": "LATENT",
          "name": "LATENT",
          "type": "LATENT",
          "slot_index": 0,
          "links": [
            720
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.49",
        "Node name for S&R": "KSampler",
        "ue_properties": {
          "widget_ue_connectable": {
            "scheduler": true,
            "denoise": true,
            "seed": true,
            "cfg": true,
            "sampler_name": true,
            "steps": true
          },
          "input_ue_unconnectable": {},
          "version": "7.5.2"
        },
        "widget_ue_connectable": {
          "scheduler": true,
          "denoise": true,
          "seed": true,
          "cfg": true,
          "sampler_name": true,
          "steps": true
        }
      },
      "widgets_values": [
        109315871065499,
        "randomize",
        4,
        1,
        "euler",
        "simple",
        1
      ]
    },
    {
      "id": 385,
      "type": "SeedVR2LoadVAEModel",
      "pos": [
        -828.8940583348286,
        919.8471919031912
      ],
      "size": [
        312.8667907714844,
        298
      ],
      "flags": {},
      "order": 6,
      "mode": 0,
      "inputs": [
        {
          "label": "torch_compile_args",
          "name": "torch_compile_args",
          "shape": 7,
          "type": "TORCH_COMPILE_ARGS",
          "link": null
        },
        {
          "label": "model",
          "name": "model",
          "type": "COMBO",
          "widget": {
            "name": "model"
          },
          "link": null
        },
        {
          "label": "device",
          "name": "device",
          "type": "COMBO",
          "widget": {
            "name": "device"
          },
          "link": null
        },
        {
          "label": "encode_tiled",
          "name": "encode_tiled",
          "shape": 7,
          "type": "BOOLEAN",
          "widget": {
            "name": "encode_tiled"
          },
          "link": null
        },
        {
          "label": "encode_tile_size",
          "name": "encode_tile_size",
          "shape": 7,
          "type": "INT",
          "widget": {
            "name": "encode_tile_size"
          },
          "link": null
        },
        {
          "label": "encode_tile_overlap",
          "name": "encode_tile_overlap",
          "shape": 7,
          "type": "INT",
          "widget": {
            "name": "encode_tile_overlap"
          },
          "link": null
        },
        {
          "label": "decode_tiled",
          "name": "decode_tiled",
          "shape": 7,
          "type": "BOOLEAN",
          "widget": {
            "name": "decode_tiled"
          },
          "link": null
        },
        {
          "label": "decode_tile_size",
          "name": "decode_tile_size",
          "shape": 7,
          "type": "INT",
          "widget": {
            "name": "decode_tile_size"
          },
          "link": null
        },
        {
          "label": "decode_tile_overlap",
          "name": "decode_tile_overlap",
          "shape": 7,
          "type": "INT",
          "widget": {
            "name": "decode_tile_overlap"
          },
          "link": null
        },
        {
          "label": "tile_debug",
          "name": "tile_debug",
          "shape": 7,
          "type": "COMBO",
          "widget": {
            "name": "tile_debug"
          },
          "link": null
        },
        {
          "label": "offload_device",
          "name": "offload_device",
          "shape": 7,
          "type": "COMBO",
          "widget": {
            "name": "offload_device"
          },
          "link": null
        },
        {
          "label": "cache_model",
          "name": "cache_model",
          "shape": 7,
          "type": "BOOLEAN",
          "widget": {
            "name": "cache_model"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "vae",
          "name": "SEEDVR2_VAE",
          "type": "SEEDVR2_VAE",
          "links": [
            875
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "SeedVR2LoadVAEModel",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "ema_vae_fp16.safetensors",
        "cuda:0",
        false,
        1024,
        128,
        false,
        1024,
        128,
        "false",
        "none",
        false
      ]
    },
    {
      "id": 345,
      "type": "SaveImage",
      "pos": [
        525.5458035345893,
        -45.25588275539195
      ],
      "size": [
        462.2575988769531,
        531.4813842773438
      ],
      "flags": {},
      "order": 17,
      "mode": 0,
      "inputs": [
        {
          "label": "images",
          "name": "images",
          "type": "IMAGE",
          "link": 871
        },
        {
          "label": "filename_prefix",
          "name": "filename_prefix",
          "type": "STRING",
          "widget": {
            "name": "filename_prefix"
          }
        }
      ],
      "outputs": [
        {
          "label": "image_urls",
          "name": "images",
          "type": "IMAGE",
          "links": null
        },
        {
          "label": "images",
          "name": "images",
          "type": "IMAGE",
          "links": null
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.27.0",
        "Node name for S&R": "SaveImage",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "ComfyUI"
      ]
    },
    {
      "id": 388,
      "type": "SeedVR2LoadDiTModel",
      "pos": [
        -822.7237168783325,
        665.6754828759958
      ],
      "size": [
        307.6646423339844,
        202
      ],
      "flags": {},
      "order": 7,
      "mode": 0,
      "inputs": [
        {
          "label": "torch_compile_args",
          "name": "torch_compile_args",
          "shape": 7,
          "type": "TORCH_COMPILE_ARGS",
          "link": null
        },
        {
          "label": "model",
          "name": "model",
          "type": "COMBO",
          "widget": {
            "name": "model"
          },
          "link": null
        },
        {
          "label": "device",
          "name": "device",
          "type": "COMBO",
          "widget": {
            "name": "device"
          },
          "link": null
        },
        {
          "label": "blocks_to_swap",
          "name": "blocks_to_swap",
          "shape": 7,
          "type": "INT",
          "widget": {
            "name": "blocks_to_swap"
          },
          "link": null
        },
        {
          "label": "swap_io_components",
          "name": "swap_io_components",
          "shape": 7,
          "type": "BOOLEAN",
          "widget": {
            "name": "swap_io_components"
          },
          "link": null
        },
        {
          "label": "offload_device",
          "name": "offload_device",
          "shape": 7,
          "type": "COMBO",
          "widget": {
            "name": "offload_device"
          },
          "link": null
        },
        {
          "label": "cache_model",
          "name": "cache_model",
          "shape": 7,
          "type": "BOOLEAN",
          "widget": {
            "name": "cache_model"
          },
          "link": null
        },
        {
          "label": "attention_mode",
          "name": "attention_mode",
          "shape": 7,
          "type": "COMBO",
          "widget": {
            "name": "attention_mode"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "dit",
          "name": "SEEDVR2_DIT",
          "type": "SEEDVR2_DIT",
          "links": [
            874
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "SeedVR2LoadDiTModel",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "seedvr2_ema_3b-Q8_0.gguf",
        "cuda:0",
        0,
        false,
        "none",
        false,
        "sdpa"
      ]
    },
    {
      "id": 389,
      "type": "SaveImage",
      "pos": [
        -117.83934384901116,
        662.8730387845841
      ],
      "size": [
        462.2575988769531,
        531.4813842773438
      ],
      "flags": {},
      "order": 20,
      "mode": 0,
      "inputs": [
        {
          "label": "images",
          "name": "images",
          "type": "IMAGE",
          "link": 876
        },
        {
          "label": "filename_prefix",
          "name": "filename_prefix",
          "type": "STRING",
          "widget": {
            "name": "filename_prefix"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "image_urls",
          "name": "images",
          "type": "IMAGE",
          "links": null
        },
        {
          "label": "images",
          "name": "images",
          "type": "IMAGE",
          "links": null
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.27.0",
        "Node name for S&R": "SaveImage",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "ComfyUI"
      ]
    },
    {
      "id": 387,
      "type": "SeedVR2VideoUpscaler",
      "pos": [
        -474.7569205717931,
        663.3229284315374
      ],
      "size": [
        317.5425720214844,
        386
      ],
      "flags": {},
      "order": 18,
      "mode": 0,
      "inputs": [
        {
          "label": "image",
          "name": "image",
          "type": "IMAGE",
          "link": 877
        },
        {
          "label": "dit",
          "name": "dit",
          "type": "SEEDVR2_DIT",
          "link": 874
        },
        {
          "label": "vae",
          "name": "vae",
          "type": "SEEDVR2_VAE",
          "link": 875
        },
        {
          "label": "seed",
          "name": "seed",
          "type": "INT",
          "widget": {
            "name": "seed"
          },
          "link": null
        },
        {
          "label": "resolution",
          "name": "resolution",
          "type": "INT",
          "widget": {
            "name": "resolution"
          },
          "link": null
        },
        {
          "label": "max_resolution",
          "name": "max_resolution",
          "type": "INT",
          "widget": {
            "name": "max_resolution"
          },
          "link": null
        },
        {
          "label": "batch_size",
          "name": "batch_size",
          "type": "INT",
          "widget": {
            "name": "batch_size"
          },
          "link": null
        },
        {
          "label": "uniform_batch_size",
          "name": "uniform_batch_size",
          "type": "BOOLEAN",
          "widget": {
            "name": "uniform_batch_size"
          },
          "link": null
        },
        {
          "label": "color_correction",
          "name": "color_correction",
          "type": "COMBO",
          "widget": {
            "name": "color_correction"
          },
          "link": null
        },
        {
          "label": "temporal_overlap",
          "name": "temporal_overlap",
          "shape": 7,
          "type": "INT",
          "widget": {
            "name": "temporal_overlap"
          },
          "link": null
        },
        {
          "label": "prepend_frames",
          "name": "prepend_frames",
          "shape": 7,
          "type": "INT",
          "widget": {
            "name": "prepend_frames"
          },
          "link": null
        },
        {
          "label": "input_noise_scale",
          "name": "input_noise_scale",
          "shape": 7,
          "type": "FLOAT",
          "widget": {
            "name": "input_noise_scale"
          },
          "link": null
        },
        {
          "label": "latent_noise_scale",
          "name": "latent_noise_scale",
          "shape": 7,
          "type": "FLOAT",
          "widget": {
            "name": "latent_noise_scale"
          },
          "link": null
        },
        {
          "label": "offload_device",
          "name": "offload_device",
          "shape": 7,
          "type": "COMBO",
          "widget": {
            "name": "offload_device"
          },
          "link": null
        },
        {
          "label": "enable_debug",
          "name": "enable_debug",
          "shape": 7,
          "type": "BOOLEAN",
          "widget": {
            "name": "enable_debug"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "image",
          "name": "IMAGE",
          "type": "IMAGE",
          "links": [
            876
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "SeedVR2VideoUpscaler",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        951021485,
        "randomize",
        1920,
        0,
        5,
        false,
        "lab",
        0,
        0,
        0,
        0,
        "cpu",
        false
      ]
    },
    {
      "id": 303,
      "type": "VAEDecode",
      "pos": [
        -80.9497117442387,
        266.5040163137502
      ],
      "size": [
        244.8595025329589,
        46
      ],
      "flags": {},
      "order": 16,
      "mode": 0,
      "inputs": [
        {
          "label": "samples",
          "name": "samples",
          "type": "LATENT",
          "link": 720
        },
        {
          "label": "vae",
          "name": "vae",
          "type": "VAE",
          "link": 860
        }
      ],
      "outputs": [
        {
          "label": "IMAGE",
          "name": "IMAGE",
          "type": "IMAGE",
          "slot_index": 0,
          "links": [
            871,
            877,
            878
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.49",
        "Node name for S&R": "VAEDecode",
        "ue_properties": {
          "widget_ue_connectable": {},
          "input_ue_unconnectable": {},
          "version": "7.5.2"
        },
        "widget_ue_connectable": {}
      },
      "widgets_values": []
    },
    {
      "id": 390,
      "type": "LayerUtility: PurgeVRAM V2",
      "pos": [
        -112.96844190843758,
        364.7713779675405
      ],
      "size": [
        270,
        82
      ],
      "flags": {},
      "order": 19,
      "mode": 0,
      "inputs": [
        {
          "name": "anything",
          "type": "*",
          "link": 878
        }
      ],
      "outputs": [
        {
          "name": "any",
          "type": "*",
          "links": null
        }
      ],
      "properties": {
        "Node name for S&R": "LayerUtility: PurgeVRAM V2"
      },
      "widgets_values": [
        true,
        true
      ],
      "color": "rgba(38, 73, 116, 0.7)"
    },
    {
      "id": 352,
      "type": "LoadImage",
      "pos": [
        -1474.922119140625,
        -53.4723014831543
      ],
      "size": [
        210,
        326
      ],
      "flags": {},
      "order": 8,
      "mode": 0,
      "inputs": [
        {
          "label": "image",
          "name": "image",
          "type": "COMBO",
          "widget": {
            "name": "image"
          }
        },
        {
          "label": "upload",
          "name": "upload",
          "type": "IMAGEUPLOAD",
          "widget": {
            "name": "upload"
          }
        }
      ],
      "outputs": [
        {
          "label": "IMAGE",
          "name": "IMAGE",
          "type": "IMAGE",
          "links": [
            840
          ]
        },
        {
          "label": "MASK",
          "name": "MASK",
          "type": "MASK"
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.75",
        "Node name for S&R": "LoadImage",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "downloaded-image.jpg",
        "image"
      ]
    },
    {
      "id": 384,
      "type": "LayerUtility: TextBox",
      "pos": [
        -1484.9763378317184,
        341.08164059851356
      ],
      "size": [
        400,
        200
      ],
      "flags": {},
      "order": 9,
      "mode": 0,
      "inputs": [],
      "outputs": [
        {
          "name": "text",
          "type": "STRING",
          "links": [
            870
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "LayerUtility: TextBox"
      },
      "widgets_values": [
        "图像1中的人物 拿着图像2中的产品，在图像3的背景下做产品展示"
      ],
      "color": "rgba(38, 73, 116, 0.7)"
    }
  ],
  "links": [
    [
      720,
      302,
      0,
      303,
      0,
      "LATENT"
    ],
    [
      747,
      122,
      0,
      302,
      0,
      "MODEL"
    ],
    [
      785,
      330,
      0,
      302,
      1,
      "CONDITIONING"
    ],
    [
      787,
      331,
      0,
      302,
      2,
      "CONDITIONING"
    ],
    [
      799,
      339,
      0,
      122,
      0,
      "MODEL"
    ],
    [
      839,
      351,
      0,
      375,
      2,
      "IMAGE"
    ],
    [
      840,
      352,
      0,
      375,
      3,
      "IMAGE"
    ],
    [
      841,
      353,
      0,
      375,
      4,
      "IMAGE"
    ],
    [
      847,
      38,
      0,
      375,
      0,
      "CLIP"
    ],
    [
      850,
      375,
      0,
      330,
      0,
      "CONDITIONING"
    ],
    [
      852,
      356,
      0,
      302,
      3,
      "LATENT"
    ],
    [
      860,
      380,
      0,
      303,
      1,
      "VAE"
    ],
    [
      862,
      380,
      0,
      375,
      1,
      "VAE"
    ],
    [
      865,
      381,
      0,
      331,
      0,
      "CONDITIONING"
    ],
    [
      866,
      375,
      0,
      381,
      0,
      "CONDITIONING"
    ],
    [
      870,
      384,
      0,
      375,
      5,
      "STRING"
    ],
    [
      871,
      303,
      0,
      345,
      0,
      "IMAGE"
    ],
    [
      874,
      388,
      0,
      387,
      1,
      "SEEDVR2_DIT"
    ],
    [
      875,
      385,
      0,
      387,
      2,
      "SEEDVR2_VAE"
    ],
    [
      876,
      387,
      0,
      389,
      0,
      "IMAGE"
    ],
    [
      877,
      303,
      0,
      387,
      0,
      "IMAGE"
    ],
    [
      878,
      303,
      0,
      390,
      0,
      "IMAGE"
    ]
  ],
  "groups": [
    {
      "id": 3,
      "title": "生成区",
      "bounding": [
        -890.9369506835938,
        -164.87380981445312,
        1905.3444405517575,
        693.8198753479003
      ],
      "color": "#3f789e",
      "flags": {}
    },
    {
      "id": 6,
      "title": "自定义区域",
      "bounding": [
        -1741.210205078125,
        -169.2556610107422,
        809.818359375,
        889.0225830078125
      ],
      "color": "#3f789e",
      "flags": {}
    },
    {
      "id": 7,
      "title": "图像1",
      "bounding": [
        -1730.931884765625,
        -125.65568542480469,
        230,
        409.6000061035156
      ],
      "color": "#3f789e",
      "flags": {}
    },
    {
      "id": 8,
      "title": "图像2",
      "bounding": [
        -1484.922119140625,
        -125.18742370605469,
        230,
        409.6000061035156
      ],
      "color": "#8A8",
      "flags": {}
    },
    {
      "id": 9,
      "title": "图像3",
      "bounding": [
        -1731.210205078125,
        300.1670227050781,
        230,
        409.6000061035156
      ],
      "color": "#8A8",
      "flags": {}
    },
    {
      "id": 10,
      "title": "高清放大区",
      "bounding": [
        -878.6671136631983,
        559.1189152380485,
        1278.0937660992436,
        774.8199583587648
      ],
      "color": "#3f789e",
      "flags": {}
    }
  ],
  "config": {},
  "extra": {
    "links_added_by_ue": [],
    "VHS_KeepIntermediate": true,
    "ue_links": [],
    "VHS_MetadataImage": true,
    "0246.VERSION": [
      0,
      0,
      4
    ],
    "workflowRendererVersion": "LG",
    "VHS_latentpreviewrate": 0,
    "frontendVersion": "1.45.20",
    "VHS_latentpreview": false,
    "ds": {
      "scale": 0.5644739300537773,
      "offset": [
        2096.118585114809,
        574.1518340299459
      ]
    }
  },
  "version": 0.4
}
```
