# 超级文生图

- 来源类别：用户工作流
- 镜像内原始路径：`/ComfyUI/user/default/workflows/18个开源模型工作流/图片/超级文生图.json`
- 节点数量：21
- 连线数量：26

## 节点类型

- `CLIPTextEncode` × 2
- `ConditioningZeroOut` × 2
- `KSamplerAdvanced` × 2
- `ModelSamplingAuraFlow` × 2
- `SaveImage` × 2
- `VAEDecode` × 2
- `CLIPLoader` × 1
- `CheckpointLoaderSimple` × 1
- `EmptyLatentImage` × 1
- `LayerUtility: ImageScaleByAspectRatio V2` × 1
- `LayerUtility: TextBox` × 1
- `UNETLoader` × 1
- `VAEEncode` × 1
- `VAELoader` × 1
- `easy cleanGpuUsed` × 1

## 工作流引用的模型或媒体文件

- `Krea-2-Turbo/turbo.safetensors`
- `caled.safetensors`
- `qwen_image_vae.safetensors`
- `z-image-turbo-bf16-aio.safetensors`

## 原始工作流 JSON

```json
{
  "id": "dbf65f09-743e-4e2b-97ac-a4d42d6c239e",
  "revision": 0,
  "last_node_id": 291,
  "last_link_id": 3107,
  "nodes": [
    {
      "id": 223,
      "type": "UNETLoader",
      "pos": [
        637.2693458211496,
        711.2474521005965
      ],
      "size": [
        348.870849609375,
        90.9964599609375
      ],
      "flags": {},
      "order": 0,
      "mode": 0,
      "inputs": [
        {
          "label": "unet_name",
          "name": "unet_name",
          "type": "COMBO",
          "widget": {
            "name": "unet_name"
          }
        },
        {
          "label": "weight_dtype",
          "name": "weight_dtype",
          "type": "COMBO",
          "widget": {
            "name": "weight_dtype"
          }
        }
      ],
      "outputs": [
        {
          "label": "模型",
          "name": "MODEL",
          "type": "MODEL",
          "links": [
            2135
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.73",
        "Node name for S&R": "UNETLoader",
        "hasSecondTab": false,
        "models": [
          {
            "name": "z_image_bf16.safetensors",
            "directory": "diffusion_models",
            "url": "https://huggingface.co/Comfy-Org/z_image/resolve/main/split_files/diffusion_models/z_image_bf16.safetensors"
          }
        ],
        "ue_properties": {
          "widget_ue_connectable": {},
          "input_ue_unconnectable": {},
          "version": "7.5.2"
        },
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "widget_ue_connectable": {
          "weight_dtype": true,
          "unet_name": true
        },
        "secondTabText": "Send Back",
        "enableTabs": false,
        "tabXOffset": 10
      },
      "widgets_values": [
        "Krea-2-Turbo/turbo.safetensors",
        "default"
      ],
      "color": "#223",
      "bgcolor": "#335"
    },
    {
      "id": 291,
      "type": "CLIPLoader",
      "pos": [
        633.8765508179192,
        858.589453884792
      ],
      "size": [
        356.61515487330246,
        106
      ],
      "flags": {},
      "order": 1,
      "mode": 0,
      "inputs": [
        {
          "label": "clip_name",
          "name": "clip_name",
          "type": "COMBO",
          "widget": {
            "name": "clip_name"
          },
          "link": null
        },
        {
          "label": "type",
          "name": "type",
          "type": "COMBO",
          "widget": {
            "name": "type"
          },
          "link": null
        },
        {
          "label": "device",
          "name": "device",
          "shape": 7,
          "type": "COMBO",
          "widget": {
            "name": "device"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "CLIP",
          "name": "CLIP",
          "type": "CLIP",
          "links": [
            3107
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.26.0",
        "Node name for S&R": "CLIPLoader",
        "ue_properties": {
          "widget_ue_connectable": {},
          "input_ue_unconnectable": {},
          "version": "7.8"
        },
        "widget_ue_connectable": {
          "clip_name": true,
          "type": true,
          "device": true
        }
      },
      "widgets_values": [
        "qwen3vl_4b_fp8_scaled.safetensors",
        "krea2",
        "default"
      ],
      "color": "#223",
      "bgcolor": "#335"
    },
    {
      "id": 237,
      "type": "CLIPTextEncode",
      "pos": [
        1014.1319728271338,
        862.8770724081031
      ],
      "size": [
        259.7905932922408,
        102.03007809346286
      ],
      "flags": {
        "collapsed": false
      },
      "order": 8,
      "mode": 0,
      "inputs": [
        {
          "label": "CLIP",
          "name": "clip",
          "type": "CLIP",
          "link": 3107
        },
        {
          "name": "text",
          "type": "STRING",
          "widget": {
            "name": "text"
          },
          "link": 3096
        }
      ],
      "outputs": [
        {
          "label": "条件",
          "name": "CONDITIONING",
          "type": "CONDITIONING",
          "links": [
            1098,
            1124
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.73",
        "Node name for S&R": "CLIPTextEncode",
        "hasSecondTab": false,
        "ue_properties": {
          "widget_ue_connectable": {},
          "input_ue_unconnectable": {},
          "version": "7.5.2"
        },
        "widget_ue_connectable": {
          "text": true
        },
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": [
        ""
      ],
      "color": "#223",
      "bgcolor": "#335"
    },
    {
      "id": 236,
      "type": "ModelSamplingAuraFlow",
      "pos": [
        1025.543368971145,
        715.5906433345718
      ],
      "size": [
        248.10941676127027,
        79.02591124623882
      ],
      "flags": {},
      "order": 6,
      "mode": 0,
      "inputs": [
        {
          "label": "模型",
          "name": "model",
          "type": "MODEL",
          "link": 2135
        },
        {
          "label": "shift",
          "name": "shift",
          "type": "FLOAT",
          "widget": {
            "name": "shift"
          }
        }
      ],
      "outputs": [
        {
          "label": "模型",
          "name": "MODEL",
          "type": "MODEL",
          "slot_index": 0,
          "links": [
            1125
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.64",
        "Node name for S&R": "ModelSamplingAuraFlow",
        "hasSecondTab": false,
        "ue_properties": {
          "widget_ue_connectable": {},
          "input_ue_unconnectable": {},
          "version": "7.5.2"
        },
        "widget_ue_connectable": {
          "shift": true
        },
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": [
        3.0000000000000004
      ],
      "color": "#223",
      "bgcolor": "#335"
    },
    {
      "id": 231,
      "type": "ConditioningZeroOut",
      "pos": [
        1283.4620747003999,
        832.7272633662944
      ],
      "size": [
        204.134765625,
        26
      ],
      "flags": {
        "collapsed": true
      },
      "order": 10,
      "mode": 0,
      "inputs": [
        {
          "label": "条件",
          "name": "conditioning",
          "type": "CONDITIONING",
          "link": 1098
        }
      ],
      "outputs": [
        {
          "label": "条件",
          "name": "CONDITIONING",
          "type": "CONDITIONING",
          "links": [
            1123
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.11.0",
        "Node name for S&R": "ConditioningZeroOut",
        "ue_properties": {
          "widget_ue_connectable": {},
          "input_ue_unconnectable": {},
          "version": "7.5.2"
        },
        "widget_ue_connectable": {}
      },
      "widgets_values": [],
      "color": "#223",
      "bgcolor": "#335"
    },
    {
      "id": 229,
      "type": "VAELoader",
      "pos": [
        633.5194480970576,
        1012.0035700931154
      ],
      "size": [
        643.2519794889929,
        62.21820569670285
      ],
      "flags": {},
      "order": 2,
      "mode": 0,
      "inputs": [
        {
          "label": "vae_name",
          "name": "vae_name",
          "type": "COMBO",
          "widget": {
            "name": "vae_name"
          }
        }
      ],
      "outputs": [
        {
          "label": "VAE",
          "name": "VAE",
          "type": "VAE",
          "links": [
            1131
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.73",
        "Node name for S&R": "VAELoader",
        "hasSecondTab": false,
        "models": [
          {
            "name": "ae.safetensors",
            "directory": "vae",
            "url": "https://huggingface.co/Comfy-Org/z_image_turbo/resolve/main/split_files/vae/ae.safetensors"
          }
        ],
        "ue_properties": {
          "widget_ue_connectable": {},
          "input_ue_unconnectable": {},
          "version": "7.5.2"
        },
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "widget_ue_connectable": {
          "vae_name": true
        },
        "secondTabText": "Send Back",
        "enableTabs": false,
        "tabXOffset": 10
      },
      "widgets_values": [
        "qwen_image_vae.safetensors"
      ],
      "color": "#223",
      "bgcolor": "#335"
    },
    {
      "id": 242,
      "type": "CheckpointLoaderSimple",
      "pos": [
        634.3149441908674,
        1121.15217342263
      ],
      "size": [
        642.823225238275,
        103.7533512353607
      ],
      "flags": {},
      "order": 3,
      "mode": 0,
      "inputs": [
        {
          "label": "ckpt_name",
          "name": "ckpt_name",
          "type": "COMBO",
          "widget": {
            "name": "ckpt_name"
          }
        }
      ],
      "outputs": [
        {
          "label": "模型",
          "name": "MODEL",
          "type": "MODEL",
          "links": [
            1105
          ]
        },
        {
          "label": "CLIP",
          "name": "CLIP",
          "type": "CLIP",
          "links": [
            1100
          ]
        },
        {
          "label": "VAE",
          "name": "VAE",
          "type": "VAE",
          "links": [
            1132,
            1137
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.26.0",
        "Node name for S&R": "CheckpointLoaderSimple",
        "ue_properties": {
          "widget_ue_connectable": {},
          "input_ue_unconnectable": {},
          "version": "7.8"
        },
        "widget_ue_connectable": {
          "ckpt_name": true
        }
      },
      "widgets_values": [
        "z-image-turbo-bf16-aio.safetensors"
      ],
      "color": "#233",
      "bgcolor": "#355"
    },
    {
      "id": 238,
      "type": "KSamplerAdvanced",
      "pos": [
        1432.2741545621163,
        731.1739307328423
      ],
      "size": [
        270,
        546
      ],
      "flags": {},
      "order": 12,
      "mode": 0,
      "inputs": [
        {
          "label": "模型",
          "name": "model",
          "type": "MODEL",
          "link": 1125
        },
        {
          "label": "正面条件",
          "name": "positive",
          "type": "CONDITIONING",
          "link": 1124
        },
        {
          "label": "负面条件",
          "name": "negative",
          "type": "CONDITIONING",
          "link": 1123
        },
        {
          "label": "Latent",
          "name": "latent_image",
          "type": "LATENT",
          "link": 3100
        },
        {
          "label": "add_noise",
          "name": "add_noise",
          "type": "COMBO",
          "widget": {
            "name": "add_noise"
          }
        },
        {
          "label": "noise_seed",
          "name": "noise_seed",
          "type": "INT",
          "widget": {
            "name": "noise_seed"
          }
        },
        {
          "label": "steps",
          "name": "steps",
          "type": "INT",
          "widget": {
            "name": "steps"
          }
        },
        {
          "label": "cfg",
          "name": "cfg",
          "type": "FLOAT",
          "widget": {
            "name": "cfg"
          }
        },
        {
          "label": "sampler_name",
          "name": "sampler_name",
          "type": "COMBO",
          "widget": {
            "name": "sampler_name"
          }
        },
        {
          "label": "scheduler",
          "name": "scheduler",
          "type": "COMBO",
          "widget": {
            "name": "scheduler"
          }
        },
        {
          "label": "start_at_step",
          "name": "start_at_step",
          "type": "INT",
          "widget": {
            "name": "start_at_step"
          }
        },
        {
          "label": "end_at_step",
          "name": "end_at_step",
          "type": "INT",
          "widget": {
            "name": "end_at_step"
          }
        },
        {
          "label": "return_with_leftover_noise",
          "name": "return_with_leftover_noise",
          "type": "COMBO",
          "widget": {
            "name": "return_with_leftover_noise"
          }
        }
      ],
      "outputs": [
        {
          "label": "Latent",
          "name": "LATENT",
          "type": "LATENT",
          "links": [
            1116
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.11.0",
        "Node name for S&R": "KSamplerAdvanced",
        "ue_properties": {
          "widget_ue_connectable": {},
          "input_ue_unconnectable": {},
          "version": "7.5.2"
        },
        "widget_ue_connectable": {
          "scheduler": true,
          "start_at_step": true,
          "cfg": true,
          "return_with_leftover_noise": true,
          "sampler_name": true,
          "end_at_step": true,
          "noise_seed": true,
          "add_noise": true,
          "steps": true
        }
      },
      "widgets_values": [
        "enable",
        448549214391942,
        "randomize",
        8,
        1,
        "euler",
        "simple",
        0,
        10000,
        "disable"
      ],
      "color": "#223",
      "bgcolor": "#335"
    },
    {
      "id": 240,
      "type": "VAEDecode",
      "pos": [
        1560.651390240189,
        635.9784479388859
      ],
      "size": [
        140,
        46.760257720947266
      ],
      "flags": {},
      "order": 13,
      "mode": 0,
      "inputs": [
        {
          "label": "Latent",
          "name": "samples",
          "type": "LATENT",
          "link": 1116
        },
        {
          "label": "VAE",
          "name": "vae",
          "type": "VAE",
          "link": 1131
        }
      ],
      "outputs": [
        {
          "label": "图像",
          "name": "IMAGE",
          "type": "IMAGE",
          "slot_index": 0,
          "links": [
            1092,
            2486
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.64",
        "Node name for S&R": "VAEDecode",
        "hasSecondTab": false,
        "ue_properties": {
          "widget_ue_connectable": {},
          "input_ue_unconnectable": {},
          "version": "7.5.2"
        },
        "widget_ue_connectable": {},
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": [],
      "color": "#223",
      "bgcolor": "#335"
    },
    {
      "id": 225,
      "type": "LayerUtility: ImageScaleByAspectRatio V2",
      "pos": [
        1723.0281325779374,
        738.2811561013192
      ],
      "size": [
        303.6851501464844,
        330
      ],
      "flags": {
        "collapsed": false
      },
      "order": 14,
      "mode": 0,
      "inputs": [
        {
          "label": "图像",
          "name": "image",
          "shape": 7,
          "type": "IMAGE",
          "link": 1092
        },
        {
          "label": "遮罩",
          "name": "mask",
          "shape": 7,
          "type": "MASK"
        },
        {
          "label": "aspect_ratio",
          "name": "aspect_ratio",
          "type": "COMBO",
          "widget": {
            "name": "aspect_ratio"
          }
        },
        {
          "label": "proportional_width",
          "name": "proportional_width",
          "type": "INT",
          "widget": {
            "name": "proportional_width"
          }
        },
        {
          "label": "proportional_height",
          "name": "proportional_height",
          "type": "INT",
          "widget": {
            "name": "proportional_height"
          }
        },
        {
          "label": "fit",
          "name": "fit",
          "type": "COMBO",
          "widget": {
            "name": "fit"
          }
        },
        {
          "label": "method",
          "name": "method",
          "type": "COMBO",
          "widget": {
            "name": "method"
          }
        },
        {
          "label": "round_to_multiple",
          "name": "round_to_multiple",
          "type": "COMBO",
          "widget": {
            "name": "round_to_multiple"
          }
        },
        {
          "label": "scale_to_side",
          "name": "scale_to_side",
          "type": "COMBO",
          "widget": {
            "name": "scale_to_side"
          }
        },
        {
          "label": "scale_to_length",
          "name": "scale_to_length",
          "type": "INT",
          "widget": {
            "name": "scale_to_length"
          },
          "link": null
        },
        {
          "label": "background_color",
          "name": "background_color",
          "type": "STRING",
          "widget": {
            "name": "background_color"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "图像",
          "name": "image",
          "type": "IMAGE",
          "links": [
            1096
          ]
        },
        {
          "label": "遮罩",
          "name": "mask",
          "type": "MASK"
        },
        {
          "label": "原始大小",
          "name": "original_size",
          "type": "BOX"
        },
        {
          "label": "width",
          "name": "width",
          "type": "INT"
        },
        {
          "label": "height",
          "name": "height",
          "type": "INT"
        }
      ],
      "properties": {
        "Node name for S&R": "LayerUtility: ImageScaleByAspectRatio V2",
        "cnr_id": "comfyui_layerstyle",
        "ver": "d94bef1ee5ed3656f5ff1bb2830a4ffd94f40935",
        "ue_properties": {
          "widget_ue_connectable": {},
          "input_ue_unconnectable": {},
          "version": "7.8"
        },
        "widget_ue_connectable": {
          "fit": true,
          "aspect_ratio": true,
          "method": true,
          "background_color": true,
          "round_to_multiple": true,
          "scale_to_side": true,
          "proportional_height": true,
          "proportional_width": true,
          "scale_to_length": true
        }
      },
      "widgets_values": [
        "original",
        1,
        1,
        "crop",
        "bicubic",
        "16",
        "longest",
        2048,
        "#000000"
      ],
      "color": "#233",
      "bgcolor": "#355"
    },
    {
      "id": 274,
      "type": "SaveImage",
      "pos": [
        1431.8070053880283,
        1325.6347457655847
      ],
      "size": [
        311.3383530880519,
        569.854654499535
      ],
      "flags": {},
      "order": 15,
      "mode": 0,
      "inputs": [
        {
          "label": "图像",
          "name": "images",
          "type": "IMAGE",
          "link": 2486
        },
        {
          "label": "filename_prefix",
          "name": "filename_prefix",
          "type": "STRING",
          "widget": {
            "name": "filename_prefix"
          }
        }
      ],
      "outputs": [
        {
          "label": "image_urls",
          "name": "images",
          "type": "IMAGE"
        },
        {
          "label": "images",
          "name": "images",
          "type": "IMAGE"
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.27.0",
        "Node name for S&R": "SaveImage",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "ComfyUI"
      ]
    },
    {
      "id": 239,
      "type": "KSamplerAdvanced",
      "pos": [
        2064.96582628431,
        748.3286708960756
      ],
      "size": [
        284.9140625,
        549.3391723632812
      ],
      "flags": {},
      "order": 17,
      "mode": 0,
      "inputs": [
        {
          "label": "模型",
          "name": "model",
          "type": "MODEL",
          "link": 1120
        },
        {
          "label": "正面条件",
          "name": "positive",
          "type": "CONDITIONING",
          "link": 1121
        },
        {
          "label": "负面条件",
          "name": "negative",
          "type": "CONDITIONING",
          "link": 1122
        },
        {
          "label": "Latent",
          "name": "latent_image",
          "type": "LATENT",
          "link": 1115
        },
        {
          "label": "add_noise",
          "name": "add_noise",
          "type": "COMBO",
          "widget": {
            "name": "add_noise"
          }
        },
        {
          "label": "noise_seed",
          "name": "noise_seed",
          "type": "INT",
          "widget": {
            "name": "noise_seed"
          }
        },
        {
          "label": "steps",
          "name": "steps",
          "type": "INT",
          "widget": {
            "name": "steps"
          }
        },
        {
          "label": "cfg",
          "name": "cfg",
          "type": "FLOAT",
          "widget": {
            "name": "cfg"
          }
        },
        {
          "label": "sampler_name",
          "name": "sampler_name",
          "type": "COMBO",
          "widget": {
            "name": "sampler_name"
          }
        },
        {
          "label": "scheduler",
          "name": "scheduler",
          "type": "COMBO",
          "widget": {
            "name": "scheduler"
          }
        },
        {
          "label": "start_at_step",
          "name": "start_at_step",
          "type": "INT",
          "widget": {
            "name": "start_at_step"
          }
        },
        {
          "label": "end_at_step",
          "name": "end_at_step",
          "type": "INT",
          "widget": {
            "name": "end_at_step"
          }
        },
        {
          "label": "return_with_leftover_noise",
          "name": "return_with_leftover_noise",
          "type": "COMBO",
          "widget": {
            "name": "return_with_leftover_noise"
          }
        }
      ],
      "outputs": [
        {
          "label": "Latent",
          "name": "LATENT",
          "type": "LATENT",
          "links": [
            1093
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.11.0",
        "Node name for S&R": "KSamplerAdvanced",
        "ue_properties": {
          "widget_ue_connectable": {},
          "input_ue_unconnectable": {},
          "version": "7.5.2"
        },
        "widget_ue_connectable": {
          "scheduler": true,
          "start_at_step": true,
          "cfg": true,
          "return_with_leftover_noise": true,
          "sampler_name": true,
          "end_at_step": true,
          "noise_seed": true,
          "add_noise": true,
          "steps": true
        }
      },
      "widgets_values": [
        "enable",
        94985825786821,
        "randomize",
        10,
        1,
        "euler",
        "simple",
        6,
        10000,
        "disable"
      ],
      "color": "#233",
      "bgcolor": "#355"
    },
    {
      "id": 235,
      "type": "ModelSamplingAuraFlow",
      "pos": [
        1737.923598548288,
        1120.6370788671015
      ],
      "size": [
        210,
        58
      ],
      "flags": {},
      "order": 7,
      "mode": 0,
      "inputs": [
        {
          "label": "模型",
          "name": "model",
          "type": "MODEL",
          "link": 1105
        },
        {
          "label": "shift",
          "name": "shift",
          "type": "FLOAT",
          "widget": {
            "name": "shift"
          }
        }
      ],
      "outputs": [
        {
          "label": "模型",
          "name": "MODEL",
          "type": "MODEL",
          "slot_index": 0,
          "links": [
            1120
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.64",
        "Node name for S&R": "ModelSamplingAuraFlow",
        "hasSecondTab": false,
        "ue_properties": {
          "widget_ue_connectable": {},
          "input_ue_unconnectable": {},
          "version": "7.5.2"
        },
        "widget_ue_connectable": {
          "shift": true
        },
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": [
        5
      ],
      "color": "#233",
      "bgcolor": "#355"
    },
    {
      "id": 228,
      "type": "VAEEncode",
      "pos": [
        1873.167013431813,
        653.1958332888855
      ],
      "size": [
        140,
        46
      ],
      "flags": {
        "collapsed": false
      },
      "order": 16,
      "mode": 0,
      "inputs": [
        {
          "label": "图像",
          "name": "pixels",
          "type": "IMAGE",
          "link": 1096
        },
        {
          "label": "VAE",
          "name": "vae",
          "type": "VAE",
          "link": 1132
        }
      ],
      "outputs": [
        {
          "label": "Latent",
          "name": "LATENT",
          "type": "LATENT",
          "links": [
            1115
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.26.0",
        "Node name for S&R": "VAEEncode",
        "ue_properties": {
          "widget_ue_connectable": {},
          "input_ue_unconnectable": {},
          "version": "7.8"
        },
        "widget_ue_connectable": {}
      },
      "widgets_values": [],
      "color": "#233",
      "bgcolor": "#355"
    },
    {
      "id": 233,
      "type": "CLIPTextEncode",
      "pos": [
        1742.9017180479118,
        1231.0889590178638
      ],
      "size": [
        210.29940795898438,
        88
      ],
      "flags": {
        "collapsed": false
      },
      "order": 9,
      "mode": 0,
      "inputs": [
        {
          "label": "CLIP",
          "name": "clip",
          "type": "CLIP",
          "link": 1100
        },
        {
          "name": "text",
          "type": "STRING",
          "widget": {
            "name": "text"
          },
          "link": 3099
        }
      ],
      "outputs": [
        {
          "label": "条件",
          "name": "CONDITIONING",
          "type": "CONDITIONING",
          "links": [
            1099,
            1121
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.73",
        "Node name for S&R": "CLIPTextEncode",
        "hasSecondTab": false,
        "ue_properties": {
          "widget_ue_connectable": {},
          "input_ue_unconnectable": {},
          "version": "7.5.2"
        },
        "widget_ue_connectable": {
          "text": true
        },
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": [
        ""
      ],
      "color": "#233",
      "bgcolor": "#355"
    },
    {
      "id": 226,
      "type": "VAEDecode",
      "pos": [
        2204.858630884928,
        656.0840215179463
      ],
      "size": [
        140,
        46.760257720947266
      ],
      "flags": {},
      "order": 18,
      "mode": 0,
      "inputs": [
        {
          "label": "Latent",
          "name": "samples",
          "type": "LATENT",
          "link": 1093
        },
        {
          "label": "VAE",
          "name": "vae",
          "type": "VAE",
          "link": 1137
        }
      ],
      "outputs": [
        {
          "label": "图像",
          "name": "IMAGE",
          "type": "IMAGE",
          "slot_index": 0,
          "links": [
            1095,
            1356
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.64",
        "Node name for S&R": "VAEDecode",
        "hasSecondTab": false,
        "ue_properties": {
          "widget_ue_connectable": {},
          "input_ue_unconnectable": {},
          "version": "7.5.2"
        },
        "widget_ue_connectable": {},
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": [],
      "color": "#233",
      "bgcolor": "#355"
    },
    {
      "id": 268,
      "type": "SaveImage",
      "pos": [
        2377.686844736001,
        766.1107004241943
      ],
      "size": [
        736.9895629882812,
        798.7257080078125
      ],
      "flags": {},
      "order": 20,
      "mode": 0,
      "inputs": [
        {
          "label": "图像",
          "name": "images",
          "type": "IMAGE",
          "link": 1356
        },
        {
          "label": "filename_prefix",
          "name": "filename_prefix",
          "type": "STRING",
          "widget": {
            "name": "filename_prefix"
          }
        }
      ],
      "outputs": [
        {
          "label": "image_urls",
          "name": "images",
          "type": "IMAGE"
        },
        {
          "label": "images",
          "name": "images",
          "type": "IMAGE"
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.27.0",
        "Node name for S&R": "SaveImage",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "ComfyUI"
      ]
    },
    {
      "id": 227,
      "type": "easy cleanGpuUsed",
      "pos": [
        2381.5559778121915,
        667.241209799608
      ],
      "size": [
        157.38925170898438,
        26
      ],
      "flags": {},
      "order": 19,
      "mode": 0,
      "inputs": [
        {
          "label": "输入任何",
          "name": "anything",
          "type": "*",
          "link": 1095
        }
      ],
      "outputs": [
        {
          "label": "output",
          "name": "output",
          "type": "*"
        }
      ],
      "properties": {
        "Node name for S&R": "easy cleanGpuUsed",
        "cnr_id": "comfyui-easy-use",
        "ver": "5ec3b5ef861fe45c4e9966d17c4546e943417723",
        "ue_properties": {
          "widget_ue_connectable": {},
          "input_ue_unconnectable": {},
          "version": "7.5.2"
        },
        "widget_ue_connectable": {}
      },
      "widgets_values": [],
      "color": "#233",
      "bgcolor": "#355"
    },
    {
      "id": 232,
      "type": "ConditioningZeroOut",
      "pos": [
        1952.6812193850953,
        1205.0426880044017
      ],
      "size": [
        352.4189453125,
        77.83026885986328
      ],
      "flags": {
        "collapsed": true
      },
      "order": 11,
      "mode": 0,
      "inputs": [
        {
          "label": "条件",
          "name": "conditioning",
          "type": "CONDITIONING",
          "link": 1099
        }
      ],
      "outputs": [
        {
          "label": "条件",
          "name": "CONDITIONING",
          "type": "CONDITIONING",
          "links": [
            1122
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.11.0",
        "Node name for S&R": "ConditioningZeroOut",
        "ue_properties": {
          "widget_ue_connectable": {},
          "input_ue_unconnectable": {},
          "version": "7.5.2"
        },
        "widget_ue_connectable": {}
      },
      "widgets_values": [],
      "color": "#233",
      "bgcolor": "#355"
    },
    {
      "id": 288,
      "type": "EmptyLatentImage",
      "pos": [
        654.4868439507179,
        1553.439362226535
      ],
      "size": [
        607.386960013231,
        133.8985909705143
      ],
      "flags": {},
      "order": 4,
      "mode": 0,
      "inputs": [],
      "outputs": [
        {
          "label": "Latent",
          "name": "LATENT",
          "type": "LATENT",
          "links": [
            3100
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.27.0",
        "Node name for S&R": "EmptyLatentImage"
      },
      "widgets_values": [
        720,
        1280,
        1
      ]
    },
    {
      "id": 287,
      "type": "LayerUtility: TextBox",
      "pos": [
        643.8007894801456,
        1294.8628521076137
      ],
      "size": [
        624.0572798680787,
        195.66335369567219
      ],
      "flags": {},
      "order": 5,
      "mode": 0,
      "inputs": [
        {
          "label": "text",
          "name": "text",
          "type": "STRING",
          "widget": {
            "name": "text"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "text",
          "name": "text",
          "type": "STRING",
          "links": [
            3096,
            3099
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "LayerUtility: TextBox"
      },
      "widgets_values": [
        "A stunning cinematic portrait of a young East Asian woman with flawless skin texture and natural pores. She is wearing a delicate silk qipao, standing in a dimly lit vintage room. Soft rim lighting highlighting her facial contours and stray hairs. Shot on a 35mm lens, f/1.8 aperture, shallow depth of field, photorealistic, highly detailed, natural color grading."
      ],
      "color": "rgba(38, 73, 116, 0.7)"
    }
  ],
  "links": [
    [
      1092,
      240,
      0,
      225,
      0,
      "IMAGE"
    ],
    [
      1093,
      239,
      0,
      226,
      0,
      "LATENT"
    ],
    [
      1095,
      226,
      0,
      227,
      0,
      "IMAGE"
    ],
    [
      1096,
      225,
      0,
      228,
      0,
      "IMAGE"
    ],
    [
      1098,
      237,
      0,
      231,
      0,
      "CONDITIONING"
    ],
    [
      1099,
      233,
      0,
      232,
      0,
      "CONDITIONING"
    ],
    [
      1100,
      242,
      1,
      233,
      0,
      "CLIP"
    ],
    [
      1105,
      242,
      0,
      235,
      0,
      "MODEL"
    ],
    [
      1115,
      228,
      0,
      239,
      3,
      "LATENT"
    ],
    [
      1116,
      238,
      0,
      240,
      0,
      "LATENT"
    ],
    [
      1120,
      235,
      0,
      239,
      0,
      "MODEL"
    ],
    [
      1121,
      233,
      0,
      239,
      1,
      "CONDITIONING"
    ],
    [
      1122,
      232,
      0,
      239,
      2,
      "CONDITIONING"
    ],
    [
      1123,
      231,
      0,
      238,
      2,
      "CONDITIONING"
    ],
    [
      1124,
      237,
      0,
      238,
      1,
      "CONDITIONING"
    ],
    [
      1125,
      236,
      0,
      238,
      0,
      "MODEL"
    ],
    [
      1131,
      229,
      0,
      240,
      1,
      "VAE"
    ],
    [
      1132,
      242,
      2,
      228,
      1,
      "VAE"
    ],
    [
      1137,
      242,
      2,
      226,
      1,
      "VAE"
    ],
    [
      1356,
      226,
      0,
      268,
      0,
      "IMAGE"
    ],
    [
      2135,
      223,
      0,
      236,
      0,
      "MODEL"
    ],
    [
      2486,
      240,
      0,
      274,
      0,
      "IMAGE"
    ],
    [
      3096,
      287,
      0,
      237,
      1,
      "STRING"
    ],
    [
      3099,
      287,
      0,
      233,
      1,
      "STRING"
    ],
    [
      3100,
      288,
      0,
      238,
      3,
      "LATENT"
    ],
    [
      3107,
      291,
      0,
      237,
      0,
      "CLIP"
    ]
  ],
  "groups": [],
  "config": {},
  "extra": {
    "links_added_by_ue": [
      3092,
      3093,
      3094
    ],
    "ue_links": [
      {
        "downstream": 233,
        "downstream_slot": 1,
        "upstream": "258",
        "upstream_slot": 0,
        "controller": 252,
        "type": "STRING"
      },
      {
        "downstream": 237,
        "downstream_slot": 1,
        "upstream": "258",
        "upstream_slot": 0,
        "controller": 252,
        "type": "STRING"
      },
      {
        "downstream": 238,
        "downstream_slot": 3,
        "upstream": "263",
        "upstream_slot": 0,
        "controller": 254,
        "type": "LATENT"
      }
    ],
    "0246.VERSION": [
      0,
      0,
      4
    ],
    "groupNodes": {},
    "ds": {
      "scale": 0.658845000000014,
      "offset": [
        -97.1117533918267,
        -386.7356926311566
      ]
    },
    "frontendVersion": "1.45.20",
    "VHS_latentpreview": false,
    "VHS_latentpreviewrate": 0,
    "VHS_MetadataImage": true,
    "VHS_KeepIntermediate": true
  },
  "version": 0.4
}
```
