# Image to Layers(Qwen-Image-Layered)

- 来源类别：内置工作流蓝图
- 镜像内原始路径：`/ComfyUI/blueprints/Image to Layers(Qwen-Image-Layered).json`
- 节点数量：1
- 连线数量：0

## 节点类型

- `2d2e3c8e-53b3-4618-be52-6d1d99382f0e` × 1

## 原始工作流 JSON

```json
{
  "revision": 0,
  "last_node_id": 176,
  "last_link_id": 0,
  "nodes": [
    {
      "id": 176,
      "type": "2d2e3c8e-53b3-4618-be52-6d1d99382f0e",
      "pos": [
        -1150,
        200
      ],
      "size": [
        400,
        550
      ],
      "flags": {},
      "order": 0,
      "mode": 0,
      "inputs": [
        {
          "localized_name": "image",
          "name": "image",
          "type": "IMAGE",
          "link": null
        },
        {
          "name": "text",
          "type": "STRING",
          "widget": {
            "name": "text"
          },
          "link": null
        },
        {
          "name": "steps",
          "type": "INT",
          "widget": {
            "name": "steps"
          },
          "link": null
        },
        {
          "name": "cfg",
          "type": "FLOAT",
          "widget": {
            "name": "cfg"
          },
          "link": null
        },
        {
          "name": "layers",
          "type": "INT",
          "widget": {
            "name": "layers"
          },
          "link": null
        },
        {
          "name": "seed",
          "type": "INT",
          "widget": {
            "name": "seed"
          },
          "link": null
        },
        {
          "name": "unet_name",
          "type": "COMBO",
          "widget": {
            "name": "unet_name"
          },
          "link": null
        },
        {
          "name": "clip_name",
          "type": "COMBO",
          "widget": {
            "name": "clip_name"
          },
          "link": null
        },
        {
          "name": "vae_name",
          "type": "COMBO",
          "widget": {
            "name": "vae_name"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "localized_name": "IMAGE",
          "name": "IMAGE",
          "type": "IMAGE",
          "links": []
        }
      ],
      "title": "Image to Layers (Qwen-Image-Layered)",
      "properties": {
        "proxyWidgets": [
          [
            "6",
            "text"
          ],
          [
            "3",
            "steps"
          ],
          [
            "3",
            "cfg"
          ],
          [
            "83",
            "layers"
          ],
          [
            "3",
            "seed"
          ],
          [
            "37",
            "unet_name"
          ],
          [
            "38",
            "clip_name"
          ],
          [
            "39",
            "vae_name"
          ],
          [
            "3",
            "control_after_generate"
          ]
        ],
        "cnr_id": "comfy-core",
        "ver": "0.5.1",
        "ue_properties": {
          "widget_ue_connectable": {},
          "input_ue_unconnectable": {},
          "version": "7.7"
        },
        "enableTabs": false,
        "tabWidth": 65,
        "tabXOffset": 10,
        "hasSecondTab": false,
        "secondTabText": "Send Back",
        "secondTabOffset": 80,
        "secondTabWidth": 65
      },
      "widgets_values": []
    }
  ],
  "links": [],
  "version": 0.4,
  "definitions": {
    "subgraphs": [
      {
        "id": "2d2e3c8e-53b3-4618-be52-6d1d99382f0e",
        "version": 1,
        "state": {
          "lastGroupId": 8,
          "lastNodeId": 176,
          "lastLinkId": 380,
          "lastRerouteId": 0
        },
        "revision": 0,
        "config": {},
        "name": "Image to Layers (Qwen-Image-Layered)",
        "inputNode": {
          "id": -10,
          "bounding": [
            -720,
            720,
            120,
            220
          ]
        },
        "outputNode": {
          "id": -20,
          "bounding": [
            1160,
            523,
            120,
            60
          ]
        },
        "inputs": [
          {
            "id": "6c36b5bc-c9a5-4b07-8b52-6fe0df434cce",
            "name": "image",
            "type": "IMAGE",
            "linkIds": [
              148,
              149
            ],
            "localized_name": "image",
            "pos": [
              -620,
              740
            ]
          },
          {
            "id": "8497fe33-124d-4e3e-9ab6-fc4a56a98dde",
            "name": "text",
            "type": "STRING",
            "linkIds": [
              150
            ],
            "pos": [
              -620,
              760
            ]
          },
          {
            "id": "509ab2c1-e6da-47ba-8714-023100ab92bd",
            "name": "steps",
            "type": "INT",
            "linkIds": [
              153
            ],
            "pos": [
              -620,
              780
            ]
          },
          {
            "id": "dd81894e-5def-4c75-9b17-d8f89fe095d6",
            "name": "cfg",
            "type": "FLOAT",
            "linkIds": [
              154
            ],
            "pos": [
              -620,
              800
            ]
          },
          {
            "id": "66da7c8a-3369-4a3f-92f2-3073afc55e7d",
            "name": "layers",
            "type": "INT",
            "linkIds": [
              159
            ],
            "pos": [
              -620,
              820
            ]
          },
          {
            "id": "9f76338b-f4ca-4bb3-b61a-57b3f233061e",
            "name": "seed",
            "type": "INT",
            "linkIds": [
              377
            ],
            "pos": [
              -620,
              840
            ]
          },
          {
            "id": "8d0422d5-5eee-4f7e-9817-dc613cc62eca",
            "name": "unet_name",
            "type": "COMBO",
            "linkIds": [
              378
            ],
            "pos": [
              -620,
              860
            ]
          },
          {
            "id": "552eece2-a735-4d00-ae78-ded454622bc1",
            "name": "clip_name",
            "type": "COMBO",
            "linkIds": [
              379
            ],
            "pos": [
              -620,
              880
            ]
          },
          {
            "id": "1e6d141c-d0f9-4a2b-895c-b6780e57cfa0",
            "name": "vae_name",
            "type": "COMBO",
            "linkIds": [
              380
            ],
            "pos": [
              -620,
              900
            ]
          }
        ],
        "outputs": [
          {
            "id": "7df75921-6729-4aad-bfc1-fcc536c2d298",
            "name": "IMAGE",
            "type": "IMAGE",
            "linkIds": [
              110
            ],
            "localized_name": "IMAGE",
            "pos": [
              1180,
              543
            ]
          }
        ],
        "widgets": [],
        "nodes": [
          {
            "id": 38,
            "type": "CLIPLoader",
            "pos": [
              -320,
              360
            ],
            "size": [
              350,
              150
            ],
            "flags": {},
            "order": 5,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "clip_name",
                "name": "clip_name",
                "type": "COMBO",
                "widget": {
                  "name": "clip_name"
                },
                "link": 379
              },
              {
                "localized_name": "type",
                "name": "type",
                "type": "COMBO",
                "widget": {
                  "name": "type"
                },
                "link": null
              },
              {
                "localized_name": "device",
                "name": "device",
                "shape": 7,
                "type": "COMBO",
                "widget": {
                  "name": "device"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "CLIP",
                "name": "CLIP",
                "type": "CLIP",
                "slot_index": 0,
                "links": [
                  74,
                  75
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.5.1",
              "ue_properties": {
                "widget_ue_connectable": {},
                "input_ue_unconnectable": {},
                "version": "7.7"
              },
              "Node name for S&R": "CLIPLoader",
              "models": [
                {
                  "name": "qwen_2.5_vl_7b_fp8_scaled.safetensors",
                  "url": "https://huggingface.co/Comfy-Org/HunyuanVideo_1.5_repackaged/resolve/main/split_files/text_encoders/qwen_2.5_vl_7b_fp8_scaled.safetensors",
                  "directory": "text_encoders"
                }
              ],
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            },
            "widgets_values": [
              "qwen_2.5_vl_7b_fp8_scaled.safetensors",
              "qwen_image",
              "default"
            ]
          },
          {
            "id": 39,
            "type": "VAELoader",
            "pos": [
              -320,
              580
            ],
            "size": [
              350,
              110
            ],
            "flags": {},
            "order": 6,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "vae_name",
                "name": "vae_name",
                "type": "COMBO",
                "widget": {
                  "name": "vae_name"
                },
                "link": 380
              }
            ],
            "outputs": [
              {
                "localized_name": "VAE",
                "name": "VAE",
                "type": "VAE",
                "slot_index": 0,
                "links": [
                  76,
                  139
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.5.1",
              "ue_properties": {
                "widget_ue_connectable": {},
                "input_ue_unconnectable": {},
                "version": "7.7"
              },
              "Node name for S&R": "VAELoader",
              "models": [
                {
                  "name": "qwen_image_layered_vae.safetensors",
                  "url": "https://huggingface.co/Comfy-Org/Qwen-Image-Layered_ComfyUI/resolve/main/split_files/vae/qwen_image_layered_vae.safetensors",
                  "directory": "vae"
                }
              ],
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            },
            "widgets_values": [
              "qwen_image_layered_vae.safetensors"
            ]
          },
          {
            "id": 7,
            "type": "CLIPTextEncode",
            "pos": [
              70,
              420
            ],
            "size": [
              430,
              190
            ],
            "flags": {},
            "order": 2,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "clip",
                "name": "clip",
                "type": "CLIP",
                "link": 75
              },
              {
                "localized_name": "text",
                "name": "text",
                "type": "STRING",
                "widget": {
                  "name": "text"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "CONDITIONING",
                "name": "CONDITIONING",
                "type": "CONDITIONING",
                "slot_index": 0,
                "links": [
                  131
                ]
              }
            ],
            "title": "CLIP Text Encode (Negative Prompt)",
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.5.1",
              "ue_properties": {
                "widget_ue_connectable": {},
                "input_ue_unconnectable": {},
                "version": "7.7"
              },
              "Node name for S&R": "CLIPTextEncode",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            },
            "widgets_values": [
              ""
            ],
            "color": "#322",
            "bgcolor": "#533"
          },
          {
            "id": 70,
            "type": "ReferenceLatent",
            "pos": [
              140,
              700
            ],
            "size": [
              210,
              50
            ],
            "flags": {
              "collapsed": true
            },
            "order": 9,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "conditioning",
                "name": "conditioning",
                "type": "CONDITIONING",
                "link": 131
              },
              {
                "localized_name": "latent",
                "name": "latent",
                "shape": 7,
                "type": "LATENT",
                "link": 134
              }
            ],
            "outputs": [
              {
                "localized_name": "CONDITIONING",
                "name": "CONDITIONING",
                "type": "CONDITIONING",
                "links": [
                  132
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.5.1",
              "ue_properties": {
                "widget_ue_connectable": {},
                "input_ue_unconnectable": {},
                "version": "7.7"
              },
              "Node name for S&R": "ReferenceLatent",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            }
          },
          {
            "id": 69,
            "type": "ReferenceLatent",
            "pos": [
              160,
              820
            ],
            "size": [
              210,
              50
            ],
            "flags": {
              "collapsed": true
            },
            "order": 8,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "conditioning",
                "name": "conditioning",
                "type": "CONDITIONING",
                "link": 129
              },
              {
                "localized_name": "latent",
                "name": "latent",
                "shape": 7,
                "type": "LATENT",
                "link": 133
              }
            ],
            "outputs": [
              {
                "localized_name": "CONDITIONING",
                "name": "CONDITIONING",
                "type": "CONDITIONING",
                "links": [
                  130
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.5.1",
              "ue_properties": {
                "widget_ue_connectable": {},
                "input_ue_unconnectable": {},
                "version": "7.7"
              },
              "Node name for S&R": "ReferenceLatent",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            }
          },
          {
            "id": 66,
            "type": "ModelSamplingAuraFlow",
            "pos": [
              530,
              150
            ],
            "size": [
              270,
              110
            ],
            "flags": {},
            "order": 7,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "model",
                "name": "model",
                "type": "MODEL",
                "link": 126
              },
              {
                "localized_name": "shift",
                "name": "shift",
                "type": "FLOAT",
                "widget": {
                  "name": "shift"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "MODEL",
                "name": "MODEL",
                "type": "MODEL",
                "links": [
                  125
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.5.1",
              "ue_properties": {
                "widget_ue_connectable": {},
                "input_ue_unconnectable": {},
                "version": "7.7"
              },
              "Node name for S&R": "ModelSamplingAuraFlow",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            },
            "widgets_values": [
              1
            ]
          },
          {
            "id": 76,
            "type": "LatentCutToBatch",
            "pos": [
              830,
              140
            ],
            "size": [
              270,
              140
            ],
            "flags": {},
            "order": 11,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "samples",
                "name": "samples",
                "type": "LATENT",
                "link": 142
              },
              {
                "localized_name": "dim",
                "name": "dim",
                "type": "COMBO",
                "widget": {
                  "name": "dim"
                },
                "link": null
              },
              {
                "localized_name": "slice_size",
                "name": "slice_size",
                "type": "INT",
                "widget": {
                  "name": "slice_size"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "LATENT",
                "name": "LATENT",
                "type": "LATENT",
                "links": [
                  143
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.5.1",
              "ue_properties": {
                "widget_ue_connectable": {},
                "input_ue_unconnectable": {},
                "version": "7.7"
              },
              "Node name for S&R": "LatentCutToBatch",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            },
            "widgets_values": [
              "t",
              1
            ]
          },
          {
            "id": 71,
            "type": "VAEEncode",
            "pos": [
              -280,
              780
            ],
            "size": [
              230,
              100
            ],
            "flags": {
              "collapsed": false
            },
            "order": 10,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "pixels",
                "name": "pixels",
                "type": "IMAGE",
                "link": 149
              },
              {
                "localized_name": "vae",
                "name": "vae",
                "type": "VAE",
                "link": 139
              }
            ],
            "outputs": [
              {
                "localized_name": "LATENT",
                "name": "LATENT",
                "type": "LATENT",
                "links": [
                  133,
                  134
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.5.1",
              "ue_properties": {
                "widget_ue_connectable": {},
                "input_ue_unconnectable": {},
                "version": "7.7"
              },
              "Node name for S&R": "VAEEncode",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            }
          },
          {
            "id": 8,
            "type": "VAEDecode",
            "pos": [
              850,
              370
            ],
            "size": [
              210,
              50
            ],
            "flags": {
              "collapsed": true
            },
            "order": 3,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "samples",
                "name": "samples",
                "type": "LATENT",
                "link": 143
              },
              {
                "localized_name": "vae",
                "name": "vae",
                "type": "VAE",
                "link": 76
              }
            ],
            "outputs": [
              {
                "localized_name": "IMAGE",
                "name": "IMAGE",
                "type": "IMAGE",
                "slot_index": 0,
                "links": [
                  110
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.5.1",
              "ue_properties": {
                "widget_ue_connectable": {},
                "input_ue_unconnectable": {},
                "version": "7.7"
              },
              "Node name for S&R": "VAEDecode",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            }
          },
          {
            "id": 6,
            "type": "CLIPTextEncode",
            "pos": [
              70,
              180
            ],
            "size": [
              430,
              170
            ],
            "flags": {},
            "order": 1,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "clip",
                "name": "clip",
                "type": "CLIP",
                "link": 74
              },
              {
                "localized_name": "text",
                "name": "text",
                "type": "STRING",
                "widget": {
                  "name": "text"
                },
                "link": 150
              }
            ],
            "outputs": [
              {
                "localized_name": "CONDITIONING",
                "name": "CONDITIONING",
                "type": "CONDITIONING",
                "slot_index": 0,
                "links": [
                  129
                ]
              }
            ],
            "title": "CLIP Text Encode (Positive Prompt)",
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.5.1",
              "ue_properties": {
                "widget_ue_connectable": {},
                "input_ue_unconnectable": {},
                "version": "7.7"
              },
              "Node name for S&R": "CLIPTextEncode",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            },
            "widgets_values": [
              ""
            ],
            "color": "#232",
            "bgcolor": "#353"
          },
          {
            "id": 3,
            "type": "KSampler",
            "pos": [
              530,
              340
            ],
            "size": [
              270,
              400
            ],
            "flags": {},
            "order": 0,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "model",
                "name": "model",
                "type": "MODEL",
                "link": 125
              },
              {
                "localized_name": "positive",
                "name": "positive",
                "type": "CONDITIONING",
                "link": 130
              },
              {
                "localized_name": "negative",
                "name": "negative",
                "type": "CONDITIONING",
                "link": 132
              },
              {
                "localized_name": "latent_image",
                "name": "latent_image",
                "type": "LATENT",
                "link": 157
              },
              {
                "localized_name": "seed",
                "name": "seed",
                "type": "INT",
                "widget": {
                  "name": "seed"
                },
                "link": 377
              },
              {
                "localized_name": "steps",
                "name": "steps",
                "type": "INT",
                "widget": {
                  "name": "steps"
                },
                "link": 153
              },
              {
                "localized_name": "cfg",
                "name": "cfg",
                "type": "FLOAT",
                "widget": {
                  "name": "cfg"
                },
                "link": 154
              },
              {
                "localized_name": "sampler_name",
                "name": "sampler_name",
                "type": "COMBO",
                "widget": {
                  "name": "sampler_name"
                },
                "link": null
              },
              {
                "localized_name": "scheduler",
                "name": "scheduler",
                "type": "COMBO",
                "widget": {
                  "name": "scheduler"
                },
                "link": null
              },
              {
                "localized_name": "denoise",
                "name": "denoise",
                "type": "FLOAT",
                "widget": {
                  "name": "denoise"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "LATENT",
                "name": "LATENT",
                "type": "LATENT",
                "slot_index": 0,
                "links": [
                  142
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.5.1",
              "ue_properties": {
                "widget_ue_connectable": {},
                "input_ue_unconnectable": {},
                "version": "7.7"
              },
              "Node name for S&R": "KSampler",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            },
            "widgets_values": [
              0,
              "randomize",
              20,
              2.5,
              "euler",
              "simple",
              1
            ]
          },
          {
            "id": 78,
            "type": "GetImageSize",
            "pos": [
              -280,
              930
            ],
            "size": [
              230,
              140
            ],
            "flags": {},
            "order": 12,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "image",
                "name": "image",
                "type": "IMAGE",
                "link": 148
              }
            ],
            "outputs": [
              {
                "localized_name": "width",
                "name": "width",
                "type": "INT",
                "links": [
                  155
                ]
              },
              {
                "localized_name": "height",
                "name": "height",
                "type": "INT",
                "links": [
                  156
                ]
              },
              {
                "localized_name": "batch_size",
                "name": "batch_size",
                "type": "INT",
                "links": null
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.5.1",
              "ue_properties": {
                "widget_ue_connectable": {},
                "input_ue_unconnectable": {},
                "version": "7.7"
              },
              "Node name for S&R": "GetImageSize",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            }
          },
          {
            "id": 83,
            "type": "EmptyQwenImageLayeredLatentImage",
            "pos": [
              -280,
              1120
            ],
            "size": [
              340,
              200
            ],
            "flags": {},
            "order": 13,
            "mode": 0,
            "showAdvanced": true,
            "inputs": [
              {
                "localized_name": "width",
                "name": "width",
                "type": "INT",
                "widget": {
                  "name": "width"
                },
                "link": 155
              },
              {
                "localized_name": "height",
                "name": "height",
                "type": "INT",
                "widget": {
                  "name": "height"
                },
                "link": 156
              },
              {
                "localized_name": "layers",
                "name": "layers",
                "type": "INT",
                "widget": {
                  "name": "layers"
                },
                "link": 159
              },
              {
                "localized_name": "batch_size",
                "name": "batch_size",
                "type": "INT",
                "widget": {
                  "name": "batch_size"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "LATENT",
                "name": "LATENT",
                "type": "LATENT",
                "links": [
                  157
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.5.1",
              "ue_properties": {
                "widget_ue_connectable": {},
                "input_ue_unconnectable": {},
                "version": "7.7"
              },
              "Node name for S&R": "EmptyQwenImageLayeredLatentImage",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            },
            "widgets_values": [
              640,
              640,
              2,
              1
            ]
          },
          {
            "id": 37,
            "type": "UNETLoader",
            "pos": [
              -320,
              180
            ],
            "size": [
              350,
              110
            ],
            "flags": {},
            "order": 4,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "unet_name",
                "name": "unet_name",
                "type": "COMBO",
                "widget": {
                  "name": "unet_name"
                },
                "link": 378
              },
              {
                "localized_name": "weight_dtype",
                "name": "weight_dtype",
                "type": "COMBO",
                "widget": {
                  "name": "weight_dtype"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "MODEL",
                "name": "MODEL",
                "type": "MODEL",
                "slot_index": 0,
                "links": [
                  126
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.5.1",
              "ue_properties": {
                "widget_ue_connectable": {},
                "input_ue_unconnectable": {},
                "version": "7.7"
              },
              "Node name for S&R": "UNETLoader",
              "models": [
                {
                  "name": "qwen_image_layered_bf16.safetensors",
                  "url": "https://huggingface.co/Comfy-Org/Qwen-Image-Layered_ComfyUI/resolve/main/split_files/diffusion_models/qwen_image_layered_bf16.safetensors",
                  "directory": "diffusion_models"
                }
              ],
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            },
            "widgets_values": [
              "qwen_image_layered_bf16.safetensors",
              "default"
            ]
          }
        ],
        "groups": [
          {
            "id": 1,
            "title": "Prompt(Optional)",
            "bounding": [
              60,
              110,
              450,
              510
            ],
            "color": "#3f789e",
            "font_size": 24,
            "flags": {}
          },
          {
            "id": 2,
            "title": "Load Models",
            "bounding": [
              -330,
              110,
              370,
              610
            ],
            "color": "#3f789e",
            "font_size": 24,
            "flags": {}
          }
        ],
        "links": [
          {
            "id": 75,
            "origin_id": 38,
            "origin_slot": 0,
            "target_id": 7,
            "target_slot": 0,
            "type": "CLIP"
          },
          {
            "id": 131,
            "origin_id": 7,
            "origin_slot": 0,
            "target_id": 70,
            "target_slot": 0,
            "type": "CONDITIONING"
          },
          {
            "id": 134,
            "origin_id": 71,
            "origin_slot": 0,
            "target_id": 70,
            "target_slot": 1,
            "type": "LATENT"
          },
          {
            "id": 129,
            "origin_id": 6,
            "origin_slot": 0,
            "target_id": 69,
            "target_slot": 0,
            "type": "CONDITIONING"
          },
          {
            "id": 133,
            "origin_id": 71,
            "origin_slot": 0,
            "target_id": 69,
            "target_slot": 1,
            "type": "LATENT"
          },
          {
            "id": 126,
            "origin_id": 37,
            "origin_slot": 0,
            "target_id": 66,
            "target_slot": 0,
            "type": "MODEL"
          },
          {
            "id": 125,
            "origin_id": 66,
            "origin_slot": 0,
            "target_id": 3,
            "target_slot": 0,
            "type": "MODEL"
          },
          {
            "id": 130,
            "origin_id": 69,
            "origin_slot": 0,
            "target_id": 3,
            "target_slot": 1,
            "type": "CONDITIONING"
          },
          {
            "id": 132,
            "origin_id": 70,
            "origin_slot": 0,
            "target_id": 3,
            "target_slot": 2,
            "type": "CONDITIONING"
          },
          {
            "id": 142,
            "origin_id": 3,
            "origin_slot": 0,
            "target_id": 76,
            "target_slot": 0,
            "type": "LATENT"
          },
          {
            "id": 74,
            "origin_id": 38,
            "origin_slot": 0,
            "target_id": 6,
            "target_slot": 0,
            "type": "CLIP"
          },
          {
            "id": 139,
            "origin_id": 39,
            "origin_slot": 0,
            "target_id": 71,
            "target_slot": 1,
            "type": "VAE"
          },
          {
            "id": 143,
            "origin_id": 76,
            "origin_slot": 0,
            "target_id": 8,
            "target_slot": 0,
            "type": "LATENT"
          },
          {
            "id": 76,
            "origin_id": 39,
            "origin_slot": 0,
            "target_id": 8,
            "target_slot": 1,
            "type": "VAE"
          },
          {
            "id": 148,
            "origin_id": -10,
            "origin_slot": 0,
            "target_id": 78,
            "target_slot": 0,
            "type": "IMAGE"
          },
          {
            "id": 149,
            "origin_id": -10,
            "origin_slot": 0,
            "target_id": 71,
            "target_slot": 0,
            "type": "IMAGE"
          },
          {
            "id": 110,
            "origin_id": 8,
            "origin_slot": 0,
            "target_id": -20,
            "target_slot": 0,
            "type": "IMAGE"
          },
          {
            "id": 150,
            "origin_id": -10,
            "origin_slot": 1,
            "target_id": 6,
            "target_slot": 1,
            "type": "STRING"
          },
          {
            "id": 153,
            "origin_id": -10,
            "origin_slot": 2,
            "target_id": 3,
            "target_slot": 5,
            "type": "INT"
          },
          {
            "id": 154,
            "origin_id": -10,
            "origin_slot": 3,
            "target_id": 3,
            "target_slot": 6,
            "type": "FLOAT"
          },
          {
            "id": 155,
            "origin_id": 78,
            "origin_slot": 0,
            "target_id": 83,
            "target_slot": 0,
            "type": "INT"
          },
          {
            "id": 156,
            "origin_id": 78,
            "origin_slot": 1,
            "target_id": 83,
            "target_slot": 1,
            "type": "INT"
          },
          {
            "id": 157,
            "origin_id": 83,
            "origin_slot": 0,
            "target_id": 3,
            "target_slot": 3,
            "type": "LATENT"
          },
          {
            "id": 159,
            "origin_id": -10,
            "origin_slot": 4,
            "target_id": 83,
            "target_slot": 2,
            "type": "INT"
          },
          {
            "id": 377,
            "origin_id": -10,
            "origin_slot": 5,
            "target_id": 3,
            "target_slot": 4,
            "type": "INT"
          },
          {
            "id": 378,
            "origin_id": -10,
            "origin_slot": 6,
            "target_id": 37,
            "target_slot": 0,
            "type": "COMBO"
          },
          {
            "id": 379,
            "origin_id": -10,
            "origin_slot": 7,
            "target_id": 38,
            "target_slot": 0,
            "type": "COMBO"
          },
          {
            "id": 380,
            "origin_id": -10,
            "origin_slot": 8,
            "target_id": 39,
            "target_slot": 0,
            "type": "COMBO"
          }
        ],
        "extra": {
          "workflowRendererVersion": "LG"
        },
        "category": "Image generation and editing/Image to layers",
        "description": "Decomposes an image into variable-resolution RGBA layers for independent editing using Qwen-Image-Layered."
      }
    ]
  },
  "extra": {
    "ds": {
      "scale": 1.14,
      "offset": [
        695.5933739308316,
        6.855893974423647
      ]
    },
    "ue_links": []
  }
}
```
