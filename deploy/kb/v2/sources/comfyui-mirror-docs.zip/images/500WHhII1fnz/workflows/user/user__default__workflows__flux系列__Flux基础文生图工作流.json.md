# Flux基础文生图工作流

- 来源类别：用户工作流
- 镜像内原始路径：`/ComfyUI/user/default/workflows/flux系列/Flux基础文生图工作流.json`
- 节点数量：13
- 连线数量：13

## 节点类型

- `BasicGuider` × 1
- `BasicScheduler` × 1
- `CLIPTextEncodeFlux` × 1
- `DualCLIPLoader` × 1
- `EmptyLatentImage` × 1
- `KSamplerSelect` × 1
- `LoraLoaderModelOnly` × 1
- `RandomNoise` × 1
- `SamplerCustomAdvanced` × 1
- `SaveImage` × 1
- `UNETLoader` × 1
- `VAEDecode` × 1
- `VAELoader` × 1

## 工作流引用的模型或媒体文件

- `clip_l.safetensors`
- `t5xxl_fp8_e4m3fn.safetensors`
- `w.safetensors`

## 原始工作流 JSON

```json
{
  "id": "213dac81-4a01-4641-8a63-e8c823869c33",
  "revision": 0,
  "last_node_id": 58,
  "last_link_id": 93,
  "nodes": [
    {
      "id": 5,
      "type": "EmptyLatentImage",
      "pos": [
        1162.21142578125,
        862.5962524414062
      ],
      "size": [
        210,
        106
      ],
      "flags": {},
      "order": 0,
      "mode": 0,
      "inputs": [
        {
          "localized_name": "宽度",
          "name": "width",
          "type": "INT",
          "widget": {
            "name": "width"
          },
          "link": null
        },
        {
          "localized_name": "高度",
          "name": "height",
          "type": "INT",
          "widget": {
            "name": "height"
          },
          "link": null
        },
        {
          "localized_name": "批次大小",
          "name": "batch_size",
          "type": "INT",
          "widget": {
            "name": "batch_size"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "Latent",
          "localized_name": "Latent",
          "name": "LATENT",
          "type": "LATENT",
          "slot_index": 0,
          "links": [
            92
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.47",
        "Node name for S&R": "EmptyLatentImage"
      },
      "widgets_values": [
        768,
        512,
        1
      ],
      "color": "#432",
      "bgcolor": "#653"
    },
    {
      "id": 25,
      "type": "RandomNoise",
      "pos": [
        1162.21142578125,
        1002.5962524414062
      ],
      "size": [
        210,
        82
      ],
      "flags": {},
      "order": 1,
      "mode": 0,
      "inputs": [
        {
          "localized_name": "随机种",
          "name": "noise_seed",
          "type": "INT",
          "widget": {
            "name": "noise_seed"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "噪波生成",
          "localized_name": "噪波",
          "name": "NOISE",
          "type": "NOISE",
          "links": [
            88
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.47",
        "Node name for S&R": "RandomNoise"
      },
      "widgets_values": [
        1002554197557571,
        "randomize"
      ],
      "color": "#432",
      "bgcolor": "#653"
    },
    {
      "id": 8,
      "type": "VAEDecode",
      "pos": [
        740,
        630
      ],
      "size": [
        170,
        60
      ],
      "flags": {},
      "order": 11,
      "mode": 0,
      "inputs": [
        {
          "label": "Latent",
          "localized_name": "Latent",
          "name": "samples",
          "type": "LATENT",
          "link": 93
        },
        {
          "label": "VAE",
          "localized_name": "vae",
          "name": "vae",
          "type": "VAE",
          "link": 57
        }
      ],
      "outputs": [
        {
          "label": "图像",
          "localized_name": "图像",
          "name": "IMAGE",
          "type": "IMAGE",
          "slot_index": 0,
          "links": [
            87
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.47",
        "Node name for S&R": "VAEDecode"
      },
      "widgets_values": [],
      "color": "#2a363b",
      "bgcolor": "#3f5159"
    },
    {
      "id": 22,
      "type": "BasicGuider",
      "pos": [
        920,
        630
      ],
      "size": [
        170,
        60
      ],
      "flags": {},
      "order": 9,
      "mode": 0,
      "inputs": [
        {
          "label": "模型",
          "localized_name": "模型",
          "name": "model",
          "type": "MODEL",
          "link": 63
        },
        {
          "label": "条件",
          "localized_name": "条件",
          "name": "conditioning",
          "type": "CONDITIONING",
          "link": 86
        }
      ],
      "outputs": [
        {
          "label": "引导",
          "localized_name": "引导器",
          "name": "GUIDER",
          "type": "GUIDER",
          "slot_index": 0,
          "links": [
            89
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.47",
        "Node name for S&R": "BasicGuider"
      },
      "widgets_values": [],
      "color": "#432",
      "bgcolor": "#653"
    },
    {
      "id": 57,
      "type": "SamplerCustomAdvanced",
      "pos": [
        1400,
        640
      ],
      "size": [
        270,
        440
      ],
      "flags": {},
      "order": 10,
      "mode": 0,
      "inputs": [
        {
          "label": "噪波生成",
          "localized_name": "噪波",
          "name": "noise",
          "type": "NOISE",
          "link": 88
        },
        {
          "label": "引导",
          "localized_name": "引导器",
          "name": "guider",
          "type": "GUIDER",
          "link": 89
        },
        {
          "label": "采样器",
          "localized_name": "采样器",
          "name": "sampler",
          "type": "SAMPLER",
          "link": 90
        },
        {
          "label": "Sigmas",
          "localized_name": "西格玛",
          "name": "sigmas",
          "type": "SIGMAS",
          "link": 91
        },
        {
          "label": "Latent",
          "localized_name": "Latent图像",
          "name": "latent_image",
          "type": "LATENT",
          "link": 92
        }
      ],
      "outputs": [
        {
          "label": "输出",
          "localized_name": "Latent",
          "name": "output",
          "type": "LATENT",
          "links": [
            93
          ]
        },
        {
          "label": "降噪输出",
          "localized_name": "降噪Latent",
          "name": "denoised_output",
          "type": "LATENT",
          "links": null
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.47",
        "Node name for S&R": "SamplerCustomAdvanced"
      },
      "widgets_values": [],
      "color": "#223",
      "bgcolor": "#335"
    },
    {
      "id": 56,
      "type": "SaveImage",
      "pos": [
        1680,
        640
      ],
      "size": [
        330,
        440
      ],
      "flags": {},
      "order": 12,
      "mode": 0,
      "inputs": [
        {
          "label": "图像",
          "localized_name": "图片",
          "name": "images",
          "type": "IMAGE",
          "link": 87
        },
        {
          "localized_name": "文件名前缀",
          "name": "filename_prefix",
          "type": "STRING",
          "widget": {
            "name": "filename_prefix"
          },
          "link": null
        }
      ],
      "outputs": [],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.47",
        "Node name for S&R": "SaveImage"
      },
      "widgets_values": [
        "ComfyUI"
      ],
      "color": "#233",
      "bgcolor": "#355"
    },
    {
      "id": 43,
      "type": "LoraLoaderModelOnly",
      "pos": [
        400,
        760
      ],
      "size": [
        315,
        82
      ],
      "flags": {},
      "order": 7,
      "mode": 4,
      "inputs": [
        {
          "label": "模型",
          "localized_name": "模型",
          "name": "model",
          "type": "MODEL",
          "link": 61
        },
        {
          "localized_name": "LoRA名称",
          "name": "lora_name",
          "type": "COMBO",
          "widget": {
            "name": "lora_name"
          },
          "link": null
        },
        {
          "localized_name": "模型强度",
          "name": "strength_model",
          "type": "FLOAT",
          "widget": {
            "name": "strength_model"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "模型",
          "localized_name": "模型",
          "name": "MODEL",
          "type": "MODEL",
          "slot_index": 0,
          "links": [
            62,
            63
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.47",
        "Node name for S&R": "LoraLoaderModelOnly"
      },
      "widgets_values": [
        "CGDivineSwordsw.safetensors",
        0.8
      ]
    },
    {
      "id": 52,
      "type": "CLIPTextEncodeFlux",
      "pos": [
        730,
        730
      ],
      "size": [
        420,
        300
      ],
      "flags": {},
      "order": 6,
      "mode": 0,
      "inputs": [
        {
          "label": "CLIP",
          "localized_name": "clip",
          "name": "clip",
          "type": "CLIP",
          "link": 85
        },
        {
          "localized_name": "CLIP_L",
          "name": "clip_l",
          "type": "STRING",
          "widget": {
            "name": "clip_l"
          },
          "link": null
        },
        {
          "localized_name": "T5XXL",
          "name": "t5xxl",
          "type": "STRING",
          "widget": {
            "name": "t5xxl"
          },
          "link": null
        },
        {
          "localized_name": "引导",
          "name": "guidance",
          "type": "FLOAT",
          "widget": {
            "name": "guidance"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "条件",
          "localized_name": "条件",
          "name": "CONDITIONING",
          "type": "CONDITIONING",
          "slot_index": 0,
          "links": [
            86
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.47",
        "Node name for S&R": "CLIPTextEncodeFlux"
      },
      "widgets_values": [
        "a young woman smiling while speaking onstage from segmind, white background with corporate logos blurred out, tech conference",
        "a young woman smiling while speaking onstage from segmind, white background with corporate logos blurred out, tech conference",
        3.5
      ],
      "color": "#232",
      "bgcolor": "#353"
    },
    {
      "id": 16,
      "type": "KSamplerSelect",
      "pos": [
        1160,
        630
      ],
      "size": [
        210,
        58
      ],
      "flags": {},
      "order": 2,
      "mode": 0,
      "inputs": [
        {
          "localized_name": "采样器",
          "name": "sampler_name",
          "type": "COMBO",
          "widget": {
            "name": "sampler_name"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "采样器",
          "localized_name": "采样器",
          "name": "SAMPLER",
          "type": "SAMPLER",
          "links": [
            90
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.47",
        "Node name for S&R": "KSamplerSelect"
      },
      "widgets_values": [
        "euler"
      ],
      "color": "#432",
      "bgcolor": "#653"
    },
    {
      "id": 17,
      "type": "BasicScheduler",
      "pos": [
        1162.21142578125,
        722.5962524414062
      ],
      "size": [
        210,
        106
      ],
      "flags": {},
      "order": 8,
      "mode": 0,
      "inputs": [
        {
          "label": "模型",
          "localized_name": "模型",
          "name": "model",
          "type": "MODEL",
          "link": 62
        },
        {
          "localized_name": "调度器",
          "name": "scheduler",
          "type": "COMBO",
          "widget": {
            "name": "scheduler"
          },
          "link": null
        },
        {
          "localized_name": "步数",
          "name": "steps",
          "type": "INT",
          "widget": {
            "name": "steps"
          },
          "link": null
        },
        {
          "localized_name": "降噪",
          "name": "denoise",
          "type": "FLOAT",
          "widget": {
            "name": "denoise"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "Sigmas",
          "localized_name": "Sigmas",
          "name": "SIGMAS",
          "type": "SIGMAS",
          "links": [
            91
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.47",
        "Node name for S&R": "BasicScheduler"
      },
      "widgets_values": [
        "simple",
        20,
        1
      ],
      "color": "#432",
      "bgcolor": "#653"
    },
    {
      "id": 42,
      "type": "DualCLIPLoader",
      "pos": [
        397.3959045410156,
        890.0322875976562
      ],
      "size": [
        315,
        130
      ],
      "flags": {},
      "order": 3,
      "mode": 0,
      "inputs": [
        {
          "localized_name": "CLIP1",
          "name": "clip_name1",
          "type": "COMBO",
          "widget": {
            "name": "clip_name1"
          },
          "link": null
        },
        {
          "localized_name": "CLIP2",
          "name": "clip_name2",
          "type": "COMBO",
          "widget": {
            "name": "clip_name2"
          },
          "link": null
        },
        {
          "localized_name": "类型",
          "name": "type",
          "type": "COMBO",
          "widget": {
            "name": "type"
          },
          "link": null
        },
        {
          "localized_name": "设备",
          "name": "device",
          "shape": 7,
          "type": "COMBO",
          "widget": {
            "name": "device"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "CLIP",
          "localized_name": "CLIP",
          "name": "CLIP",
          "type": "CLIP",
          "slot_index": 0,
          "links": [
            85
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.47",
        "Node name for S&R": "DualCLIPLoader"
      },
      "widgets_values": [
        "t5xxl_fp8_e4m3fn.safetensors",
        "clip_l.safetensors",
        "flux",
        "default"
      ]
    },
    {
      "id": 41,
      "type": "UNETLoader",
      "pos": [
        397.3959045410156,
        630.032470703125
      ],
      "size": [
        315,
        82
      ],
      "flags": {},
      "order": 5,
      "mode": 0,
      "inputs": [
        {
          "localized_name": "UNET名称",
          "name": "unet_name",
          "type": "COMBO",
          "widget": {
            "name": "unet_name"
          },
          "link": null
        },
        {
          "localized_name": "剪枝类型",
          "name": "weight_dtype",
          "type": "COMBO",
          "widget": {
            "name": "weight_dtype"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "模型",
          "localized_name": "模型",
          "name": "MODEL",
          "type": "MODEL",
          "slot_index": 0,
          "links": [
            61
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.47",
        "Node name for S&R": "UNETLoader"
      },
      "widgets_values": [
        "flux1-dev.sft",
        "fp8_e4m3fn"
      ]
    },
    {
      "id": 40,
      "type": "VAELoader",
      "pos": [
        395.1706237792969,
        1064.896484375
      ],
      "size": [
        315,
        58
      ],
      "flags": {},
      "order": 4,
      "mode": 0,
      "inputs": [
        {
          "localized_name": "vae名称",
          "name": "vae_name",
          "type": "COMBO",
          "widget": {
            "name": "vae_name"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "localized_name": "VAE",
          "name": "VAE",
          "type": "VAE",
          "slot_index": 0,
          "links": [
            57
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.47",
        "Node name for S&R": "VAELoader"
      },
      "widgets_values": [
        "ae.sft"
      ]
    }
  ],
  "links": [
    [
      57,
      40,
      0,
      8,
      1,
      "VAE"
    ],
    [
      61,
      41,
      0,
      43,
      0,
      "MODEL"
    ],
    [
      62,
      43,
      0,
      17,
      0,
      "MODEL"
    ],
    [
      63,
      43,
      0,
      22,
      0,
      "MODEL"
    ],
    [
      85,
      42,
      0,
      52,
      0,
      "CLIP"
    ],
    [
      86,
      52,
      0,
      22,
      1,
      "CONDITIONING"
    ],
    [
      87,
      8,
      0,
      56,
      0,
      "IMAGE"
    ],
    [
      88,
      25,
      0,
      57,
      0,
      "NOISE"
    ],
    [
      89,
      22,
      0,
      57,
      1,
      "GUIDER"
    ],
    [
      90,
      16,
      0,
      57,
      2,
      "SAMPLER"
    ],
    [
      91,
      17,
      0,
      57,
      3,
      "SIGMAS"
    ],
    [
      92,
      5,
      0,
      57,
      4,
      "LATENT"
    ],
    [
      93,
      57,
      0,
      8,
      0,
      "LATENT"
    ]
  ],
  "groups": [
    {
      "id": 1,
      "title": "Flux:Dev+Schnell 可用",
      "bounding": [
        382,
        555,
        1664.7969970703125,
        600.4927368164062
      ],
      "color": "#3f789e",
      "font_size": 24,
      "flags": {}
    }
  ],
  "config": {},
  "extra": {
    "ds": {
      "scale": 0.9646149645000037,
      "offset": [
        190.00019461132786,
        -125.62633430668124
      ]
    },
    "workspace_info": {
      "id": "cF14JHNEa0QU8y_o2bgEY",
      "saveLock": false,
      "cloudID": null,
      "coverMediaPath": null
    },
    "0246.VERSION": [
      0,
      0,
      4
    ]
  },
  "version": 0.4
}
```
