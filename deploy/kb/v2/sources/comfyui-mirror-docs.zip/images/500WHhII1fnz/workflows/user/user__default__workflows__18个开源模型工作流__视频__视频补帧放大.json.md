# 视频补帧放大

- 来源类别：用户工作流
- 镜像内原始路径：`/ComfyUI/user/default/workflows/18个开源模型工作流/视频/视频补帧放大.json`
- 节点数量：11
- 连线数量：15

## 节点类型

- `VHS_VideoCombine` × 2
- `INTConstant` × 1
- `ImageScaleToTotalPixels` × 1
- `RIFE VFI` × 1
- `SeedVR2LoadDiTModel` × 1
- `SeedVR2LoadVAEModel` × 1
- `SeedVR2VideoUpscaler` × 1
- `SimpleMath+` × 1
- `VHS_LoadVideo` × 1
- `VHS_VideoInfoSource` × 1

## 工作流引用的模型或媒体文件

- `.xiaoyaoyou.com//dcafcc86c1342e8e5aa6861d6518f930/output/AnimateDiff_00001_p10021-audio_lifna_1782445574.mp4`
- `.xiaoyaoyou.com//f3257c885c1aaa9dddfcc32ac04c6ba1/output/AnimateDiff_00001_p81-audio_aqryj_1782451841.mp4`
- `/ComfyUI/output/AnimateDiff_00003-audio.mp4`
- `/ComfyUI/output/AnimateDiff_00004-audio.mp4`
- `AnimateDiff_00003-audio.mp4`
- `AnimateDiff_00004-audio.mp4`
- `CAIL_00001-audio.mp4`
- `eedvr2_ema_3b-Q8_0.gguf`
- `ema_vae_fp16.safetensors`
- `rife49.pth`

## 原始工作流 JSON

```json
{
  "id": "c6c8579c-3da4-4948-a3d8-5e1958be612d",
  "revision": 0,
  "last_node_id": 86,
  "last_link_id": 78,
  "nodes": [
    {
      "id": 16,
      "type": "VHS_LoadVideo",
      "pos": [
        -308.33697660347013,
        2609.021012341127
      ],
      "size": [
        376.9829553303641,
        942.7704559059646
      ],
      "flags": {},
      "order": 0,
      "mode": 0,
      "inputs": [
        {
          "label": "meta_batch",
          "name": "meta_batch",
          "shape": 7,
          "type": "VHS_BatchManager"
        },
        {
          "label": "vae",
          "name": "vae",
          "shape": 7,
          "type": "VAE"
        },
        {
          "label": "video",
          "name": "video",
          "type": "COMBO",
          "widget": {
            "name": "video"
          }
        },
        {
          "label": "force_rate",
          "name": "force_rate",
          "type": "FLOAT",
          "widget": {
            "name": "force_rate"
          }
        },
        {
          "label": "custom_width",
          "name": "custom_width",
          "type": "INT",
          "widget": {
            "name": "custom_width"
          }
        },
        {
          "label": "custom_height",
          "name": "custom_height",
          "type": "INT",
          "widget": {
            "name": "custom_height"
          }
        },
        {
          "label": "frame_load_cap",
          "name": "frame_load_cap",
          "type": "INT",
          "widget": {
            "name": "frame_load_cap"
          }
        },
        {
          "label": "skip_first_frames",
          "name": "skip_first_frames",
          "type": "INT",
          "widget": {
            "name": "skip_first_frames"
          }
        },
        {
          "label": "select_every_nth",
          "name": "select_every_nth",
          "type": "INT",
          "widget": {
            "name": "select_every_nth"
          }
        },
        {
          "label": "format",
          "name": "format",
          "shape": 7,
          "type": "COMBO",
          "widget": {
            "name": "format"
          }
        }
      ],
      "outputs": [
        {
          "label": "IMAGE",
          "name": "IMAGE",
          "type": "IMAGE",
          "links": [
            52
          ]
        },
        {
          "label": "frame_count",
          "name": "frame_count",
          "type": "INT"
        },
        {
          "label": "audio",
          "name": "audio",
          "type": "AUDIO",
          "links": [
            56,
            64
          ]
        },
        {
          "label": "video_info",
          "name": "video_info",
          "type": "VHS_VIDEOINFO",
          "links": [
            8
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "VHS_LoadVideo",
        "widget_ue_connectable": {}
      },
      "widgets_values": {
        "video": "WanVideo_SCAIL_00001-audio.mp4",
        "force_rate": 0,
        "custom_width": 0,
        "custom_height": 0,
        "frame_load_cap": 0,
        "skip_first_frames": 0,
        "select_every_nth": 1,
        "format": "AnimateDiff",
        "videopreview": {
          "paused": false,
          "hidden": false,
          "params": {
            "custom_height": 0,
            "force_rate": 0,
            "filename": "WanVideo_SCAIL_00001-audio.mp4",
            "custom_width": 0,
            "select_every_nth": 1,
            "frame_load_cap": 0,
            "format": "video/mp4",
            "skip_first_frames": 0,
            "type": "input"
          }
        }
      }
    },
    {
      "id": 68,
      "type": "ImageScaleToTotalPixels",
      "pos": [
        137.64796447753906,
        2805.537552196851
      ],
      "size": [
        295.2969055175781,
        106
      ],
      "flags": {},
      "order": 4,
      "mode": 0,
      "inputs": [
        {
          "label": "image",
          "name": "image",
          "type": "IMAGE",
          "link": 52
        },
        {
          "label": "upscale_method",
          "name": "upscale_method",
          "type": "COMBO",
          "widget": {
            "name": "upscale_method"
          }
        },
        {
          "label": "megapixels",
          "name": "megapixels",
          "type": "FLOAT",
          "widget": {
            "name": "megapixels"
          }
        },
        {
          "label": "resolution_steps",
          "name": "resolution_steps",
          "type": "INT",
          "widget": {
            "name": "resolution_steps"
          }
        }
      ],
      "outputs": [
        {
          "label": "IMAGE",
          "name": "IMAGE",
          "type": "IMAGE",
          "links": [
            72
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.27.0",
        "Node name for S&R": "ImageScaleToTotalPixels",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "lanczos",
        0.30000000000000004,
        1
      ]
    },
    {
      "id": 83,
      "type": "SeedVR2LoadVAEModel",
      "pos": [
        451.7860893460536,
        2903.41306030414
      ],
      "size": [
        310.78899517082834,
        307.557347227169
      ],
      "flags": {},
      "order": 1,
      "mode": 0,
      "inputs": [
        {
          "name": "torch_compile_args",
          "shape": 7,
          "type": "TORCH_COMPILE_ARGS",
          "link": null
        }
      ],
      "outputs": [
        {
          "name": "SEEDVR2_VAE",
          "type": "SEEDVR2_VAE",
          "links": [
            71
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "SeedVR2LoadVAEModel"
      },
      "widgets_values": [
        "ema_vae_fp16.safetensors",
        "cuda:0",
        false,
        1024,
        128,
        false,
        1024,
        128,
        "false",
        "none",
        false
      ]
    },
    {
      "id": 72,
      "type": "VHS_VideoCombine",
      "pos": [
        1164.4877782009669,
        2656.9054803943072
      ],
      "size": [
        507.0968933105469,
        1191.8439137633418
      ],
      "flags": {},
      "order": 8,
      "mode": 0,
      "inputs": [
        {
          "label": "images",
          "name": "images",
          "type": "IMAGE",
          "link": 70
        },
        {
          "label": "audio",
          "name": "audio",
          "shape": 7,
          "type": "AUDIO",
          "link": 56
        },
        {
          "label": "meta_batch",
          "name": "meta_batch",
          "shape": 7,
          "type": "VHS_BatchManager"
        },
        {
          "label": "vae",
          "name": "vae",
          "shape": 7,
          "type": "VAE"
        },
        {
          "label": "frame_rate",
          "name": "frame_rate",
          "type": "FLOAT",
          "widget": {
            "name": "frame_rate"
          },
          "link": 57
        },
        {
          "label": "loop_count",
          "name": "loop_count",
          "type": "INT",
          "widget": {
            "name": "loop_count"
          }
        },
        {
          "label": "filename_prefix",
          "name": "filename_prefix",
          "type": "STRING",
          "widget": {
            "name": "filename_prefix"
          }
        },
        {
          "label": "format",
          "name": "format",
          "type": "COMBO",
          "widget": {
            "name": "format"
          }
        },
        {
          "label": "pingpong",
          "name": "pingpong",
          "type": "BOOLEAN",
          "widget": {
            "name": "pingpong"
          }
        },
        {
          "label": "save_output",
          "name": "save_output",
          "type": "BOOLEAN",
          "widget": {
            "name": "save_output"
          }
        }
      ],
      "outputs": [
        {
          "label": "Filenames",
          "name": "Filenames",
          "type": "VHS_FILENAMES"
        }
      ],
      "properties": {
        "Node name for S&R": "VHS_VideoCombine",
        "widget_ue_connectable": {}
      },
      "widgets_values": {
        "frame_rate": 8,
        "loop_count": 0,
        "filename_prefix": "AnimateDiff",
        "format": "video/h264-mp4",
        "pix_fmt": "yuv420p",
        "crf": 19,
        "save_metadata": true,
        "trim_to_audio": false,
        "pingpong": false,
        "save_output": true,
        "videopreview": {
          "paused": false,
          "hidden": false,
          "params": {
            "score": "0",
            "filename": "AnimateDiff_00003-audio.mp4",
            "cos_url": "https://rh-images.xiaoyaoyou.com//f3257c885c1aaa9dddfcc32ac04c6ba1/output/AnimateDiff_00001_p81-audio_aqryj_1782451841.mp4",
            "workflow": "AnimateDiff_00003.png",
            "fullpath": "/ComfyUI/output/AnimateDiff_00003-audio.mp4",
            "format": "video/h264-mp4",
            "subfolder": "",
            "label": "Normal",
            "type": "output",
            "frame_rate": 16
          }
        }
      }
    },
    {
      "id": 12,
      "type": "VHS_VideoInfoSource",
      "pos": [
        138.08656311035156,
        2653.2275390625
      ],
      "size": [
        297.0849609375,
        106
      ],
      "flags": {},
      "order": 5,
      "mode": 0,
      "inputs": [
        {
          "label": "video_info",
          "name": "video_info",
          "type": "VHS_VIDEOINFO",
          "link": 8
        }
      ],
      "outputs": [
        {
          "label": "fps🟨",
          "name": "fps🟨",
          "type": "FLOAT",
          "links": [
            57,
            77
          ]
        },
        {
          "label": "frame_count🟨",
          "name": "frame_count🟨",
          "type": "INT",
          "links": []
        },
        {
          "label": "duration🟨",
          "name": "duration🟨",
          "type": "FLOAT",
          "links": []
        },
        {
          "label": "width🟨",
          "name": "width🟨",
          "type": "INT"
        },
        {
          "label": "height🟨",
          "name": "height🟨",
          "type": "INT"
        }
      ],
      "properties": {
        "Node name for S&R": "VHS_VideoInfoSource",
        "widget_ue_connectable": {}
      },
      "widgets_values": {}
    },
    {
      "id": 84,
      "type": "SeedVR2LoadDiTModel",
      "pos": [
        454.26697683731936,
        2649.3040459574527
      ],
      "size": [
        317.5630859375,
        202
      ],
      "flags": {},
      "order": 2,
      "mode": 0,
      "inputs": [
        {
          "name": "torch_compile_args",
          "shape": 7,
          "type": "TORCH_COMPILE_ARGS",
          "link": null
        }
      ],
      "outputs": [
        {
          "name": "SEEDVR2_DIT",
          "type": "SEEDVR2_DIT",
          "links": [
            73
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "SeedVR2LoadDiTModel"
      },
      "widgets_values": [
        "seedvr2_ema_3b-Q8_0.gguf",
        "cuda:0",
        0,
        false,
        "none",
        false,
        "sdpa"
      ]
    },
    {
      "id": 20,
      "type": "RIFE VFI",
      "pos": [
        786.3447822406065,
        3084.8763627040107
      ],
      "size": [
        352.9299423563559,
        209.96067909546218
      ],
      "flags": {},
      "order": 9,
      "mode": 0,
      "inputs": [
        {
          "label": "frames",
          "name": "frames",
          "type": "IMAGE",
          "link": 74
        },
        {
          "label": "optional_interpolation_states",
          "name": "optional_interpolation_states",
          "shape": 7,
          "type": "INTERPOLATION_STATES"
        },
        {
          "label": "clear_cache_after_n_frames",
          "name": "clear_cache_after_n_frames",
          "type": "INT",
          "widget": {
            "name": "clear_cache_after_n_frames"
          }
        },
        {
          "label": "multiplier",
          "name": "multiplier",
          "type": "INT",
          "widget": {
            "name": "multiplier"
          },
          "link": 75
        },
        {
          "label": "fast_mode",
          "name": "fast_mode",
          "type": "BOOLEAN",
          "widget": {
            "name": "fast_mode"
          }
        },
        {
          "label": "ensemble",
          "name": "ensemble",
          "type": "BOOLEAN",
          "widget": {
            "name": "ensemble"
          }
        },
        {
          "label": "scale_factor",
          "name": "scale_factor",
          "type": "COMBO",
          "widget": {
            "name": "scale_factor"
          }
        }
      ],
      "outputs": [
        {
          "label": "IMAGE",
          "name": "IMAGE",
          "type": "IMAGE",
          "links": [
            62
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "RIFE VFI",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "rife49.pth",
        10,
        2,
        true,
        true,
        1
      ]
    },
    {
      "id": 85,
      "type": "INTConstant",
      "pos": [
        137.47120404833524,
        2955.4364265405816
      ],
      "size": [
        303.1830636014256,
        58
      ],
      "flags": {
        "collapsed": false
      },
      "order": 3,
      "mode": 0,
      "inputs": [],
      "outputs": [
        {
          "name": "value",
          "type": "INT",
          "links": [
            75,
            76
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "INTConstant"
      },
      "widgets_values": [
        2
      ],
      "color": "#1b4669",
      "bgcolor": "#29699c"
    },
    {
      "id": 77,
      "type": "VHS_VideoCombine",
      "pos": [
        1696.3283353851434,
        2676.292771080454
      ],
      "size": [
        446.09693257955905,
        1086.167925454729
      ],
      "flags": {},
      "order": 10,
      "mode": 0,
      "inputs": [
        {
          "label": "images",
          "name": "images",
          "type": "IMAGE",
          "link": 62
        },
        {
          "label": "audio",
          "name": "audio",
          "shape": 7,
          "type": "AUDIO",
          "link": 64
        },
        {
          "label": "meta_batch",
          "name": "meta_batch",
          "shape": 7,
          "type": "VHS_BatchManager"
        },
        {
          "label": "vae",
          "name": "vae",
          "shape": 7,
          "type": "VAE"
        },
        {
          "label": "frame_rate",
          "name": "frame_rate",
          "type": "FLOAT",
          "widget": {
            "name": "frame_rate"
          },
          "link": 78
        },
        {
          "label": "loop_count",
          "name": "loop_count",
          "type": "INT",
          "widget": {
            "name": "loop_count"
          }
        },
        {
          "label": "filename_prefix",
          "name": "filename_prefix",
          "type": "STRING",
          "widget": {
            "name": "filename_prefix"
          }
        },
        {
          "label": "format",
          "name": "format",
          "type": "COMBO",
          "widget": {
            "name": "format"
          }
        },
        {
          "label": "pingpong",
          "name": "pingpong",
          "type": "BOOLEAN",
          "widget": {
            "name": "pingpong"
          }
        },
        {
          "label": "save_output",
          "name": "save_output",
          "type": "BOOLEAN",
          "widget": {
            "name": "save_output"
          }
        }
      ],
      "outputs": [
        {
          "label": "Filenames",
          "name": "Filenames",
          "type": "VHS_FILENAMES"
        }
      ],
      "properties": {
        "Node name for S&R": "VHS_VideoCombine",
        "widget_ue_connectable": {}
      },
      "widgets_values": {
        "frame_rate": 8,
        "loop_count": 0,
        "filename_prefix": "AnimateDiff",
        "format": "video/h264-mp4",
        "pix_fmt": "yuv420p",
        "crf": 19,
        "save_metadata": true,
        "trim_to_audio": false,
        "pingpong": false,
        "save_output": true,
        "videopreview": {
          "paused": false,
          "hidden": false,
          "params": {
            "score": "0",
            "filename": "AnimateDiff_00004-audio.mp4",
            "cos_url": "https://rh-images.xiaoyaoyou.com//dcafcc86c1342e8e5aa6861d6518f930/output/AnimateDiff_00001_p10021-audio_lifna_1782445574.mp4",
            "workflow": "AnimateDiff_00004.png",
            "fullpath": "/ComfyUI/output/AnimateDiff_00004-audio.mp4",
            "format": "video/h264-mp4",
            "subfolder": "",
            "label": "Normal",
            "type": "output",
            "frame_rate": 32
          }
        }
      }
    },
    {
      "id": 86,
      "type": "SimpleMath+",
      "pos": [
        143.25656380031958,
        3059.0870086975387
      ],
      "size": [
        289.11446476930837,
        98
      ],
      "flags": {
        "collapsed": false
      },
      "order": 7,
      "mode": 0,
      "inputs": [
        {
          "label": "a",
          "name": "a",
          "shape": 7,
          "type": "*",
          "link": 77
        },
        {
          "label": "b",
          "name": "b",
          "shape": 7,
          "type": "*",
          "link": 76
        },
        {
          "label": "c",
          "name": "c",
          "shape": 7,
          "type": "*",
          "link": null
        },
        {
          "label": "value",
          "name": "value",
          "type": "STRING",
          "widget": {
            "name": "value"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "INT",
          "name": "INT",
          "type": "INT",
          "links": []
        },
        {
          "label": "FLOAT",
          "name": "FLOAT",
          "type": "FLOAT",
          "links": [
            78
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "SimpleMath+",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "a*b"
      ]
    },
    {
      "id": 82,
      "type": "SeedVR2VideoUpscaler",
      "pos": [
        780.9408927652859,
        2657.9083910856366
      ],
      "size": [
        362.2120750232822,
        386
      ],
      "flags": {},
      "order": 6,
      "mode": 0,
      "inputs": [
        {
          "name": "image",
          "type": "IMAGE",
          "link": 72
        },
        {
          "name": "dit",
          "type": "SEEDVR2_DIT",
          "link": 73
        },
        {
          "name": "vae",
          "type": "SEEDVR2_VAE",
          "link": 71
        }
      ],
      "outputs": [
        {
          "name": "IMAGE",
          "type": "IMAGE",
          "links": [
            70,
            74
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "SeedVR2VideoUpscaler"
      },
      "widgets_values": [
        1386437563,
        "randomize",
        1080,
        0,
        5,
        false,
        "lab",
        0,
        0,
        0,
        0,
        "cpu",
        false
      ]
    }
  ],
  "links": [
    [
      8,
      16,
      3,
      12,
      0,
      "VHS_VIDEOINFO"
    ],
    [
      52,
      16,
      0,
      68,
      0,
      "IMAGE"
    ],
    [
      56,
      16,
      2,
      72,
      1,
      "AUDIO"
    ],
    [
      57,
      12,
      0,
      72,
      4,
      "FLOAT"
    ],
    [
      62,
      20,
      0,
      77,
      0,
      "IMAGE"
    ],
    [
      64,
      16,
      2,
      77,
      1,
      "AUDIO"
    ],
    [
      70,
      82,
      0,
      72,
      0,
      "IMAGE"
    ],
    [
      71,
      83,
      0,
      82,
      2,
      "SEEDVR2_VAE"
    ],
    [
      72,
      68,
      0,
      82,
      0,
      "IMAGE"
    ],
    [
      73,
      84,
      0,
      82,
      1,
      "SEEDVR2_DIT"
    ],
    [
      74,
      82,
      0,
      20,
      0,
      "IMAGE"
    ],
    [
      75,
      85,
      0,
      20,
      3,
      "INT"
    ],
    [
      76,
      85,
      0,
      86,
      1,
      "INT"
    ],
    [
      77,
      12,
      0,
      86,
      0,
      "FLOAT"
    ],
    [
      78,
      86,
      1,
      77,
      4,
      "FLOAT"
    ]
  ],
  "groups": [
    {
      "id": 7,
      "title": "模型采样工作区",
      "bounding": [
        125.6823959350586,
        2564.19091796875,
        1026.6702601945908,
        754.9348920569978
      ],
      "color": "#3f789e",
      "flags": {}
    }
  ],
  "config": {},
  "extra": {
    "links_added_by_ue": [],
    "VHS_KeepIntermediate": true,
    "ue_links": [],
    "VHS_MetadataImage": true,
    "0246.VERSION": [
      0,
      0,
      4
    ],
    "VHS_latentpreviewrate": 0,
    "frontendVersion": "1.45.20",
    "VHS_latentpreview": false,
    "ds": {
      "scale": 0.7247295000000022,
      "offset": [
        837.4567890406636,
        -2355.406915308896
      ]
    }
  },
  "version": 0.4
}
```
