# Depth to Video (ltx 2.0)

- 来源类别：内置工作流蓝图
- 镜像内原始路径：`/ComfyUI/blueprints/Depth to Video (ltx 2.0).json`
- 节点数量：1
- 连线数量：0

## 节点类型

- `68857357-cbc2-4c3a-a786-c3a58d43f9b1` × 1

## 工作流引用的模型或媒体文件

- `-depth-d-v1-1.safetensors`
- `caler-x2-1.0.safetensors`
- `e-840000-ema-pruned.safetensors`
- `gemma_3_12B_it_fp4_mixed.safetensors`
- `ltx-2-19b-dev-fp8.safetensors`
- `ltx-2-19b-ic-lora-depth-control.safetensors`
- `tilled-lora-384.safetensors`

## 原始工作流 JSON

```json
{
  "id": "ec176c82-4db5-4ab9-b5a0-8aa8e5684a81",
  "revision": 0,
  "last_node_id": 191,
  "last_link_id": 433,
  "nodes": [
    {
      "id": 143,
      "type": "68857357-cbc2-4c3a-a786-c3a58d43f9b1",
      "pos": [
        289.99998661973035,
        3960.0002084505168
      ],
      "size": [
        400,
        500
      ],
      "flags": {
        "collapsed": false
      },
      "order": 0,
      "mode": 0,
      "inputs": [
        {
          "label": "prompt",
          "name": "text",
          "type": "STRING",
          "widget": {
            "name": "text"
          },
          "link": null
        },
        {
          "label": "image_strength",
          "name": "strength",
          "type": "FLOAT",
          "widget": {
            "name": "strength"
          },
          "link": null
        },
        {
          "label": "disable_first_frame",
          "name": "bypass",
          "type": "BOOLEAN",
          "widget": {
            "name": "bypass"
          },
          "link": null
        },
        {
          "label": "depth reference video",
          "name": "video",
          "type": "VIDEO",
          "link": null
        },
        {
          "label": "first frame",
          "name": "image_2",
          "type": "IMAGE",
          "link": null
        },
        {
          "label": "width",
          "name": "resize_type.width",
          "type": "INT",
          "widget": {
            "name": "resize_type.width"
          },
          "link": null
        },
        {
          "label": "height",
          "name": "resize_type.height",
          "type": "INT",
          "widget": {
            "name": "resize_type.height"
          },
          "link": null
        },
        {
          "name": "length",
          "type": "INT",
          "widget": {
            "name": "length"
          },
          "link": null
        },
        {
          "name": "ckpt_name",
          "type": "COMBO",
          "widget": {
            "name": "ckpt_name"
          },
          "link": null
        },
        {
          "name": "lora_name",
          "type": "COMBO",
          "widget": {
            "name": "lora_name"
          },
          "link": null
        },
        {
          "name": "text_encoder",
          "type": "COMBO",
          "widget": {
            "name": "text_encoder"
          },
          "link": null
        },
        {
          "label": "distill_lora",
          "name": "lora_name_1",
          "type": "COMBO",
          "widget": {
            "name": "lora_name_1"
          },
          "link": null
        },
        {
          "name": "model_name",
          "type": "COMBO",
          "widget": {
            "name": "model_name"
          },
          "link": null
        },
        {
          "label": "lotus_depth_model",
          "name": "unet_name",
          "type": "COMBO",
          "widget": {
            "name": "unet_name"
          },
          "link": null
        },
        {
          "label": "sd15_vae",
          "name": "vae_name",
          "type": "COMBO",
          "widget": {
            "name": "vae_name"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "localized_name": "VIDEO",
          "name": "VIDEO",
          "type": "VIDEO",
          "links": []
        }
      ],
      "properties": {
        "proxyWidgets": [
          [
            "-1",
            "text"
          ],
          [
            "-1",
            "bypass"
          ],
          [
            "-1",
            "strength"
          ],
          [
            "-1",
            "resize_type.width"
          ],
          [
            "-1",
            "resize_type.height"
          ],
          [
            "-1",
            "length"
          ],
          [
            "126",
            "noise_seed"
          ],
          [
            "143",
            "control_after_generate"
          ],
          [
            "-1",
            "ckpt_name"
          ],
          [
            "-1",
            "lora_name"
          ],
          [
            "-1",
            "text_encoder"
          ],
          [
            "-1",
            "lora_name_1"
          ],
          [
            "-1",
            "model_name"
          ],
          [
            "-1",
            "unet_name"
          ],
          [
            "-1",
            "vae_name"
          ]
        ],
        "cnr_id": "comfy-core",
        "ver": "0.7.0",
        "enableTabs": false,
        "tabWidth": 65,
        "tabXOffset": 10,
        "hasSecondTab": false,
        "secondTabText": "Send Back",
        "secondTabOffset": 80,
        "secondTabWidth": 65
      },
      "widgets_values": [
        "",
        false,
        1,
        1280,
        720,
        121,
        null,
        null,
        "ltx-2-19b-dev-fp8.safetensors",
        "ltx-2-19b-ic-lora-depth-control.safetensors",
        "gemma_3_12B_it_fp4_mixed.safetensors",
        "ltx-2-19b-distilled-lora-384.safetensors",
        "ltx-2-spatial-upscaler-x2-1.0.safetensors",
        "lotus-depth-d-v1-1.safetensors",
        "vae-ft-mse-840000-ema-pruned.safetensors"
      ]
    }
  ],
  "links": [],
  "groups": [],
  "definitions": {
    "subgraphs": [
      {
        "id": "68857357-cbc2-4c3a-a786-c3a58d43f9b1",
        "version": 1,
        "state": {
          "lastGroupId": 16,
          "lastNodeId": 191,
          "lastLinkId": 433,
          "lastRerouteId": 0
        },
        "revision": 0,
        "config": {},
        "name": "Depth to Video (LTX 2.0)",
        "inputNode": {
          "id": -10,
          "bounding": [
            -2730,
            4020,
            165.30859375,
            340
          ]
        },
        "outputNode": {
          "id": -20,
          "bounding": [
            1750,
            4090,
            120,
            60
          ]
        },
        "inputs": [
          {
            "id": "0f1d2f96-933a-4a7b-8f1a-7b49fc4ade09",
            "name": "text",
            "type": "STRING",
            "linkIds": [
              345
            ],
            "label": "prompt",
            "pos": [
              -2584.69140625,
              4040
            ]
          },
          {
            "id": "59430efe-1090-4e36-8afe-b21ce7f4268b",
            "name": "strength",
            "type": "FLOAT",
            "linkIds": [
              370,
              371
            ],
            "label": "image_strength",
            "pos": [
              -2584.69140625,
              4060
            ]
          },
          {
            "id": "6145a9b9-68ed-4956-89f7-7a5ebdd5c99e",
            "name": "bypass",
            "type": "BOOLEAN",
            "linkIds": [
              363,
              368
            ],
            "label": "disable_first_frame",
            "pos": [
              -2584.69140625,
              4080
            ]
          },
          {
            "id": "de434962-832a-485c-a016-869b3f2176ca",
            "name": "video",
            "type": "VIDEO",
            "linkIds": [
              419
            ],
            "label": "depth reference video",
            "pos": [
              -2584.69140625,
              4100
            ]
          },
          {
            "id": "a1189d3d-bbff-4933-875d-cffa58dd4cb0",
            "name": "image_2",
            "type": "IMAGE",
            "linkIds": [
              410
            ],
            "label": "first frame",
            "pos": [
              -2584.69140625,
              4120
            ]
          },
          {
            "id": "577dae4c-447b-4c84-9973-56381fdbc6a9",
            "name": "resize_type.width",
            "type": "INT",
            "linkIds": [
              420
            ],
            "label": "width",
            "pos": [
              -2584.69140625,
              4140
            ]
          },
          {
            "id": "fb30c570-128c-46b8-a140-054aff294edc",
            "name": "resize_type.height",
            "type": "INT",
            "linkIds": [
              421
            ],
            "label": "height",
            "pos": [
              -2584.69140625,
              4160
            ]
          },
          {
            "id": "33d5f598-00ae-4e2d-8eb2-2da23ae5ba46",
            "name": "length",
            "type": "INT",
            "linkIds": [
              422
            ],
            "pos": [
              -2584.69140625,
              4180
            ]
          },
          {
            "id": "68cc58b0-2013-4c3a-81ff-3d1e86232d76",
            "name": "ckpt_name",
            "type": "COMBO",
            "linkIds": [
              425,
              433
            ],
            "pos": [
              -2584.69140625,
              4200
            ]
          },
          {
            "id": "0c65a06b-e12a-4298-8d81-69e57a123188",
            "name": "lora_name",
            "type": "COMBO",
            "linkIds": [
              426
            ],
            "pos": [
              -2584.69140625,
              4220
            ]
          },
          {
            "id": "eba96545-b8c6-4fba-b086-ddeeb4a9130d",
            "name": "text_encoder",
            "type": "COMBO",
            "linkIds": [
              427
            ],
            "pos": [
              -2584.69140625,
              4240
            ]
          },
          {
            "id": "848f9d82-3fde-4b95-b226-4b0db7082112",
            "name": "lora_name_1",
            "type": "COMBO",
            "linkIds": [
              429
            ],
            "label": "distill_lora",
            "pos": [
              -2584.69140625,
              4260
            ]
          },
          {
            "id": "32ace7dd-4da8-416b-b1e3-00652b3e6838",
            "name": "model_name",
            "type": "COMBO",
            "linkIds": [
              430
            ],
            "pos": [
              -2584.69140625,
              4280
            ]
          },
          {
            "id": "d6ad1978-71b6-425b-be13-c8f1e1d798d9",
            "name": "unet_name",
            "type": "COMBO",
            "linkIds": [
              431
            ],
            "label": "lotus_depth_model",
            "pos": [
              -2584.69140625,
              4300
            ]
          },
          {
            "id": "b0545a5d-65e8-4baa-a7be-d5f3d2b8b6e3",
            "name": "vae_name",
            "type": "COMBO",
            "linkIds": [
              432
            ],
            "label": "sd15_vae",
            "pos": [
              -2584.69140625,
              4320
            ]
          }
        ],
        "outputs": [
          {
            "id": "4e837941-de2d-4df8-8f94-686e24036897",
            "name": "VIDEO",
            "type": "VIDEO",
            "linkIds": [
              304
            ],
            "localized_name": "VIDEO",
            "pos": [
              1770,
              4110
            ]
          }
        ],
        "widgets": [],
        "nodes": [
          {
            "id": 93,
            "type": "CFGGuider",
            "pos": [
              -697.9999467324425,
              3670.0001318308678
            ],
            "size": [
              270,
              106.66666666666667
            ],
            "flags": {},
            "order": 8,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "model",
                "name": "model",
                "type": "MODEL",
                "link": 326
              },
              {
                "localized_name": "positive",
                "name": "positive",
                "type": "CONDITIONING",
                "link": 309
              },
              {
                "localized_name": "negative",
                "name": "negative",
                "type": "CONDITIONING",
                "link": 311
              },
              {
                "localized_name": "cfg",
                "name": "cfg",
                "type": "FLOAT",
                "widget": {
                  "name": "cfg"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "GUIDER",
                "name": "GUIDER",
                "type": "GUIDER",
                "links": [
                  261
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.3.64",
              "Node name for S&R": "CFGGuider",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            },
            "widgets_values": [
              3
            ]
          },
          {
            "id": 94,
            "type": "KSamplerSelect",
            "pos": [
              -697.9999467324425,
              3840.0000630985346
            ],
            "size": [
              270,
              68.88020833333334
            ],
            "flags": {},
            "order": 0,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "sampler_name",
                "name": "sampler_name",
                "type": "COMBO",
                "widget": {
                  "name": "sampler_name"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "SAMPLER",
                "name": "SAMPLER",
                "type": "SAMPLER",
                "links": [
                  262
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.3.56",
              "Node name for S&R": "KSamplerSelect",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            },
            "widgets_values": [
              "euler"
            ]
          },
          {
            "id": 99,
            "type": "ManualSigmas",
            "pos": [
              409.9999946478922,
              3850.0001667604133
            ],
            "size": [
              270,
              70
            ],
            "flags": {},
            "order": 1,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "sigmas",
                "name": "sigmas",
                "type": "STRING",
                "widget": {
                  "name": "sigmas"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "SIGMAS",
                "name": "SIGMAS",
                "type": "SIGMAS",
                "links": [
                  278
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.5.1",
              "Node name for S&R": "ManualSigmas",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            },
            "widgets_values": [
              "0.909375, 0.725, 0.421875, 0.0"
            ]
          },
          {
            "id": 101,
            "type": "LTXVConcatAVLatent",
            "pos": [
              409.9999946478922,
              4100.000194929402
            ],
            "size": [
              270,
              110
            ],
            "flags": {},
            "order": 13,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "video_latent",
                "name": "video_latent",
                "type": "LATENT",
                "link": 365
              },
              {
                "localized_name": "audio_latent",
                "name": "audio_latent",
                "type": "LATENT",
                "link": 266
              }
            ],
            "outputs": [
              {
                "localized_name": "latent",
                "name": "latent",
                "type": "LATENT",
                "links": [
                  279
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.5.1",
              "Node name for S&R": "LTXVConcatAVLatent",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            },
            "widgets_values": []
          },
          {
            "id": 108,
            "type": "CFGGuider",
            "pos": [
              409.9999946478922,
              3700.00007661965
            ],
            "size": [
              270,
              106.66666666666667
            ],
            "flags": {},
            "order": 19,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "model",
                "name": "model",
                "type": "MODEL",
                "link": 280
              },
              {
                "localized_name": "positive",
                "name": "positive",
                "type": "CONDITIONING",
                "link": 281
              },
              {
                "localized_name": "negative",
                "name": "negative",
                "type": "CONDITIONING",
                "link": 282
              },
              {
                "localized_name": "cfg",
                "name": "cfg",
                "type": "FLOAT",
                "widget": {
                  "name": "cfg"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "GUIDER",
                "name": "GUIDER",
                "type": "GUIDER",
                "links": [
                  276
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.3.71",
              "Node name for S&R": "CFGGuider",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            },
            "widgets_values": [
              1
            ]
          },
          {
            "id": 111,
            "type": "LTXVEmptyLatentAudio",
            "pos": [
              -1100.000003380279,
              4810.000230985708
            ],
            "size": [
              270,
              120
            ],
            "flags": {},
            "order": 21,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "audio_vae",
                "name": "audio_vae",
                "type": "VAE",
                "link": 285
              },
              {
                "localized_name": "frames_number",
                "name": "frames_number",
                "type": "INT",
                "widget": {
                  "name": "frames_number"
                },
                "link": 329
              },
              {
                "localized_name": "frame_rate",
                "name": "frame_rate",
                "type": "INT",
                "widget": {
                  "name": "frame_rate"
                },
                "link": 354
              },
              {
                "localized_name": "batch_size",
                "name": "batch_size",
                "type": "INT",
                "widget": {
                  "name": "batch_size"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "Latent",
                "name": "Latent",
                "type": "LATENT",
                "links": [
                  300
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.3.68",
              "Node name for S&R": "LTXVEmptyLatentAudio",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            },
            "widgets_values": [
              97,
              25,
              1
            ]
          },
          {
            "id": 123,
            "type": "SamplerCustomAdvanced",
            "pos": [
              -387.99998321128277,
              3520.0000416901034
            ],
            "size": [
              213.125,
              120
            ],
            "flags": {},
            "order": 30,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "noise",
                "name": "noise",
                "type": "NOISE",
                "link": 260
              },
              {
                "localized_name": "guider",
                "name": "guider",
                "type": "GUIDER",
                "link": 261
              },
              {
                "localized_name": "sampler",
                "name": "sampler",
                "type": "SAMPLER",
                "link": 262
              },
              {
                "localized_name": "sigmas",
                "name": "sigmas",
                "type": "SIGMAS",
                "link": 263
              },
              {
                "localized_name": "latent_image",
                "name": "latent_image",
                "type": "LATENT",
                "link": 323
              }
            ],
            "outputs": [
              {
                "localized_name": "output",
                "name": "output",
                "type": "LATENT",
                "links": [
                  272
                ]
              },
              {
                "localized_name": "denoised_output",
                "name": "denoised_output",
                "type": "LATENT",
                "links": []
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.3.60",
              "Node name for S&R": "SamplerCustomAdvanced",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            },
            "widgets_values": []
          },
          {
            "id": 114,
            "type": "LTXVConditioning",
            "pos": [
              -1134.000099492868,
              4140.000243380063
            ],
            "size": [
              270,
              86.66666666666667
            ],
            "flags": {},
            "order": 24,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "positive",
                "name": "positive",
                "type": "CONDITIONING",
                "link": 292
              },
              {
                "localized_name": "negative",
                "name": "negative",
                "type": "CONDITIONING",
                "link": 293
              },
              {
                "localized_name": "frame_rate",
                "name": "frame_rate",
                "type": "FLOAT",
                "widget": {
                  "name": "frame_rate"
                },
                "link": 355
              }
            ],
            "outputs": [
              {
                "localized_name": "positive",
                "name": "positive",
                "type": "CONDITIONING",
                "links": [
                  313
                ]
              },
              {
                "localized_name": "negative",
                "name": "negative",
                "type": "CONDITIONING",
                "links": [
                  314
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.3.56",
              "Node name for S&R": "LTXVConditioning",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            },
            "widgets_values": [
              25
            ]
          },
          {
            "id": 119,
            "type": "CLIPTextEncode",
            "pos": [
              -1164.0000442816504,
              3880.0001115491955
            ],
            "size": [
              400,
              200
            ],
            "flags": {},
            "order": 28,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "clip",
                "name": "clip",
                "type": "CLIP",
                "link": 294
              },
              {
                "localized_name": "text",
                "name": "text",
                "type": "STRING",
                "widget": {
                  "name": "text"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "CONDITIONING",
                "name": "CONDITIONING",
                "type": "CONDITIONING",
                "links": [
                  293
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.3.56",
              "Node name for S&R": "CLIPTextEncode",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            },
            "widgets_values": [
              "blurry, low quality, still frame, frames, watermark, overlay, titles, has blurbox, has subtitles"
            ],
            "color": "#323",
            "bgcolor": "#535"
          },
          {
            "id": 116,
            "type": "LTXVConcatAVLatent",
            "pos": [
              -519.9999874648,
              4700.000189295605
            ],
            "size": [
              187.5,
              60
            ],
            "flags": {},
            "order": 26,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "video_latent",
                "name": "video_latent",
                "type": "LATENT",
                "link": 324
              },
              {
                "localized_name": "audio_latent",
                "name": "audio_latent",
                "type": "LATENT",
                "link": 300
              }
            ],
            "outputs": [
              {
                "localized_name": "latent",
                "name": "latent",
                "type": "LATENT",
                "links": [
                  322,
                  323
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.7.0",
              "Node name for S&R": "LTXVConcatAVLatent",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            },
            "widgets_values": []
          },
          {
            "id": 122,
            "type": "LTXVSeparateAVLatent",
            "pos": [
              -393.9999813239605,
              3800.0000146478747
            ],
            "size": [
              240,
              60
            ],
            "flags": {},
            "order": 29,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "av_latent",
                "name": "av_latent",
                "type": "LATENT",
                "link": 272
              }
            ],
            "outputs": [
              {
                "localized_name": "video_latent",
                "name": "video_latent",
                "type": "LATENT",
                "links": [
                  270
                ]
              },
              {
                "localized_name": "audio_latent",
                "name": "audio_latent",
                "type": "LATENT",
                "links": [
                  266
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.5.1",
              "Node name for S&R": "LTXVSeparateAVLatent",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            },
            "widgets_values": []
          },
          {
            "id": 124,
            "type": "CLIPTextEncode",
            "pos": [
              -1174.9999569014471,
              3514.0002724504593
            ],
            "size": [
              410,
              320
            ],
            "flags": {},
            "order": 31,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "clip",
                "name": "clip",
                "type": "CLIP",
                "link": 295
              },
              {
                "localized_name": "text",
                "name": "text",
                "type": "STRING",
                "widget": {
                  "name": "text"
                },
                "link": 345
              }
            ],
            "outputs": [
              {
                "localized_name": "CONDITIONING",
                "name": "CONDITIONING",
                "type": "CONDITIONING",
                "links": [
                  292
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.3.56",
              "Node name for S&R": "CLIPTextEncode",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            },
            "widgets_values": [
              ""
            ],
            "color": "#232",
            "bgcolor": "#353"
          },
          {
            "id": 98,
            "type": "KSamplerSelect",
            "pos": [
              409.9999946478922,
              3980.00004957742
            ],
            "size": [
              270,
              68.88020833333334
            ],
            "flags": {},
            "order": 2,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "sampler_name",
                "name": "sampler_name",
                "type": "COMBO",
                "widget": {
                  "name": "sampler_name"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "SAMPLER",
                "name": "SAMPLER",
                "type": "SAMPLER",
                "links": [
                  277
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.3.75",
              "Node name for S&R": "KSamplerSelect",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            },
            "widgets_values": [
              "gradient_estimation"
            ]
          },
          {
            "id": 95,
            "type": "LTXVScheduler",
            "pos": [
              -699.9999766197394,
              3980.00004957742
            ],
            "size": [
              270,
              170
            ],
            "flags": {},
            "order": 9,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "latent",
                "name": "latent",
                "shape": 7,
                "type": "LATENT",
                "link": 322
              },
              {
                "localized_name": "steps",
                "name": "steps",
                "type": "INT",
                "widget": {
                  "name": "steps"
                },
                "link": null
              },
              {
                "localized_name": "max_shift",
                "name": "max_shift",
                "type": "FLOAT",
                "widget": {
                  "name": "max_shift"
                },
                "link": null
              },
              {
                "localized_name": "base_shift",
                "name": "base_shift",
                "type": "FLOAT",
                "widget": {
                  "name": "base_shift"
                },
                "link": null
              },
              {
                "localized_name": "stretch",
                "name": "stretch",
                "type": "BOOLEAN",
                "widget": {
                  "name": "stretch"
                },
                "link": null
              },
              {
                "localized_name": "terminal",
                "name": "terminal",
                "type": "FLOAT",
                "widget": {
                  "name": "terminal"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "SIGMAS",
                "name": "SIGMAS",
                "type": "SIGMAS",
                "links": [
                  263
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.3.56",
              "Node name for S&R": "LTXVScheduler",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            },
            "widgets_values": [
              20,
              2.05,
              0.95,
              true,
              0.1
            ]
          },
          {
            "id": 126,
            "type": "RandomNoise",
            "pos": [
              -697.9999467324425,
              3520.0000416901034
            ],
            "size": [
              270,
              82
            ],
            "flags": {},
            "order": 3,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "noise_seed",
                "name": "noise_seed",
                "type": "INT",
                "widget": {
                  "name": "noise_seed"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "NOISE",
                "name": "NOISE",
                "type": "NOISE",
                "links": [
                  260
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.3.56",
              "Node name for S&R": "RandomNoise",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            },
            "widgets_values": [
              0,
              "fixed"
            ]
          },
          {
            "id": 107,
            "type": "SamplerCustomAdvanced",
            "pos": [
              709.9999918309934,
              3570.000193802643
            ],
            "size": [
              212.3828125,
              120
            ],
            "flags": {},
            "order": 18,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "noise",
                "name": "noise",
                "type": "NOISE",
                "link": 347
              },
              {
                "localized_name": "guider",
                "name": "guider",
                "type": "GUIDER",
                "link": 276
              },
              {
                "localized_name": "sampler",
                "name": "sampler",
                "type": "SAMPLER",
                "link": 277
              },
              {
                "localized_name": "sigmas",
                "name": "sigmas",
                "type": "SIGMAS",
                "link": 278
              },
              {
                "localized_name": "latent_image",
                "name": "latent_image",
                "type": "LATENT",
                "link": 279
              }
            ],
            "outputs": [
              {
                "localized_name": "output",
                "name": "output",
                "type": "LATENT",
                "links": []
              },
              {
                "localized_name": "denoised_output",
                "name": "denoised_output",
                "type": "LATENT",
                "links": [
                  336
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.3.75",
              "Node name for S&R": "SamplerCustomAdvanced",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            },
            "widgets_values": []
          },
          {
            "id": 143,
            "type": "RandomNoise",
            "pos": [
              409.9999946478922,
              3570.000193802643
            ],
            "size": [
              270,
              82
            ],
            "flags": {},
            "order": 4,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "noise_seed",
                "name": "noise_seed",
                "type": "INT",
                "widget": {
                  "name": "noise_seed"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "NOISE",
                "name": "NOISE",
                "type": "NOISE",
                "links": [
                  347
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.3.56",
              "Node name for S&R": "RandomNoise",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            },
            "widgets_values": [
              0,
              "randomize"
            ]
          },
          {
            "id": 139,
            "type": "LTXVAudioVAEDecode",
            "pos": [
              1129.9999512676497,
              3840.0000630985346
            ],
            "size": [
              240,
              60
            ],
            "flags": {},
            "order": 35,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "samples",
                "name": "samples",
                "type": "LATENT",
                "link": 338
              },
              {
                "label": "Audio VAE",
                "localized_name": "audio_vae",
                "name": "audio_vae",
                "type": "VAE",
                "link": 340
              }
            ],
            "outputs": [
              {
                "localized_name": "Audio",
                "name": "Audio",
                "type": "AUDIO",
                "links": [
                  339
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.7.0",
              "Node name for S&R": "LTXVAudioVAEDecode",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            },
            "widgets_values": []
          },
          {
            "id": 134,
            "type": "LoraLoaderModelOnly",
            "pos": [
              -1650.0000287323687,
              3760.0003323940673
            ],
            "size": [
              420,
              95.546875
            ],
            "flags": {},
            "order": 33,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "model",
                "name": "model",
                "type": "MODEL",
                "link": 325
              },
              {
                "localized_name": "lora_name",
                "name": "lora_name",
                "type": "COMBO",
                "widget": {
                  "name": "lora_name"
                },
                "link": 426
              },
              {
                "localized_name": "strength_model",
                "name": "strength_model",
                "type": "FLOAT",
                "widget": {
                  "name": "strength_model"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "MODEL",
                "name": "MODEL",
                "type": "MODEL",
                "links": [
                  326,
                  327
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.7.0",
              "Node name for S&R": "LoraLoaderModelOnly",
              "models": [
                {
                  "name": "ltx-2-19b-ic-lora-depth-control.safetensors",
                  "url": "https://huggingface.co/Lightricks/LTX-2-19b-IC-LoRA-Depth-Control/resolve/main/ltx-2-19b-ic-lora-depth-control.safetensors",
                  "directory": "loras"
                }
              ],
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            },
            "widgets_values": [
              "ltx-2-19b-ic-lora-depth-control.safetensors",
              1
            ],
            "color": "#322",
            "bgcolor": "#533"
          },
          {
            "id": 138,
            "type": "LTXVSeparateAVLatent",
            "pos": [
              730.0000160563236,
              3730.0000214084316
            ],
            "size": [
              193.2916015625,
              60
            ],
            "flags": {},
            "order": 34,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "av_latent",
                "name": "av_latent",
                "type": "LATENT",
                "link": 336
              }
            ],
            "outputs": [
              {
                "localized_name": "video_latent",
                "name": "video_latent",
                "type": "LATENT",
                "links": [
                  337,
                  351
                ]
              },
              {
                "localized_name": "audio_latent",
                "name": "audio_latent",
                "type": "LATENT",
                "links": [
                  338
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.5.1",
              "Node name for S&R": "LTXVSeparateAVLatent",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            },
            "widgets_values": []
          },
          {
            "id": 144,
            "type": "VAEDecodeTiled",
            "pos": [
              1119.9999391549845,
              3640.000187042085
            ],
            "size": [
              270,
              150
            ],
            "flags": {},
            "order": 36,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "samples",
                "name": "samples",
                "type": "LATENT",
                "link": 351
              },
              {
                "localized_name": "vae",
                "name": "vae",
                "type": "VAE",
                "link": 353
              },
              {
                "localized_name": "tile_size",
                "name": "tile_size",
                "type": "INT",
                "widget": {
                  "name": "tile_size"
                },
                "link": null
              },
              {
                "localized_name": "overlap",
                "name": "overlap",
                "type": "INT",
                "widget": {
                  "name": "overlap"
                },
                "link": null
              },
              {
                "localized_name": "temporal_size",
                "name": "temporal_size",
                "type": "INT",
                "widget": {
                  "name": "temporal_size"
                },
                "link": null
              },
              {
                "localized_name": "temporal_overlap",
                "name": "temporal_overlap",
                "type": "INT",
                "widget": {
                  "name": "temporal_overlap"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "IMAGE",
                "name": "IMAGE",
                "type": "IMAGE",
                "links": [
                  352
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.7.0",
              "Node name for S&R": "VAEDecodeTiled",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            },
            "widgets_values": [
              512,
              64,
              4096,
              8
            ]
          },
          {
            "id": 113,
            "type": "VAEDecode",
            "pos": [
              1129.9999512676497,
              3530.000145351982
            ],
            "size": [
              240,
              60
            ],
            "flags": {},
            "order": 23,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "samples",
                "name": "samples",
                "type": "LATENT",
                "link": 337
              },
              {
                "localized_name": "vae",
                "name": "vae",
                "type": "VAE",
                "link": 291
              }
            ],
            "outputs": [
              {
                "localized_name": "IMAGE",
                "name": "IMAGE",
                "type": "IMAGE",
                "links": []
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.3.75",
              "Node name for S&R": "VAEDecode",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            },
            "widgets_values": []
          },
          {
            "id": 145,
            "type": "PrimitiveInt",
            "pos": [
              -1630.0000045070383,
              4620.0000923942835
            ],
            "size": [
              270,
              82
            ],
            "flags": {},
            "order": 5,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "value",
                "name": "value",
                "type": "INT",
                "widget": {
                  "name": "value"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "INT",
                "name": "INT",
                "type": "INT",
                "links": [
                  354
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.7.0",
              "Node name for S&R": "PrimitiveInt",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            },
            "widgets_values": [
              24,
              "fixed"
            ]
          },
          {
            "id": 148,
            "type": "PrimitiveFloat",
            "pos": [
              -1630.0000045070383,
              4749.99997521129
            ],
            "size": [
              270,
              66.66666666666667
            ],
            "flags": {},
            "order": 6,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "value",
                "name": "value",
                "type": "FLOAT",
                "widget": {
                  "name": "value"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "FLOAT",
                "name": "FLOAT",
                "type": "FLOAT",
                "links": [
                  355,
                  356
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.7.0",
              "Node name for S&R": "PrimitiveFloat",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            },
            "widgets_values": [
              24
            ]
          },
          {
            "id": 115,
            "type": "EmptyLTXVLatentVideo",
            "pos": [
              -1100.000003380279,
              4609.999988732406
            ],
            "size": [
              270,
              146.66666666666669
            ],
            "flags": {},
            "order": 25,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "width",
                "name": "width",
                "type": "INT",
                "widget": {
                  "name": "width"
                },
                "link": 296
              },
              {
                "localized_name": "height",
                "name": "height",
                "type": "INT",
                "widget": {
                  "name": "height"
                },
                "link": 297
              },
              {
                "localized_name": "length",
                "name": "length",
                "type": "INT",
                "widget": {
                  "name": "length"
                },
                "link": 330
              },
              {
                "localized_name": "batch_size",
                "name": "batch_size",
                "type": "INT",
                "widget": {
                  "name": "batch_size"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "LATENT",
                "name": "LATENT",
                "type": "LATENT",
                "links": [
                  360
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.3.60",
              "Node name for S&R": "EmptyLTXVLatentVideo",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            },
            "widgets_values": [
              768,
              512,
              97,
              1
            ]
          },
          {
            "id": 149,
            "type": "LTXVImgToVideoInplace",
            "pos": [
              -1089.9999912676137,
              4400.000009014077
            ],
            "size": [
              270,
              151.9921875
            ],
            "flags": {},
            "order": 37,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "vae",
                "name": "vae",
                "type": "VAE",
                "link": 359
              },
              {
                "localized_name": "image",
                "name": "image",
                "type": "IMAGE",
                "link": 417
              },
              {
                "localized_name": "latent",
                "name": "latent",
                "type": "LATENT",
                "link": 360
              },
              {
                "localized_name": "strength",
                "name": "strength",
                "type": "FLOAT",
                "widget": {
                  "name": "strength"
                },
                "link": 370
              },
              {
                "localized_name": "bypass",
                "name": "bypass",
                "type": "BOOLEAN",
                "widget": {
                  "name": "bypass"
                },
                "link": 363
              }
            ],
            "outputs": [
              {
                "localized_name": "latent",
                "name": "latent",
                "type": "LATENT",
                "links": [
                  357
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.7.0",
              "Node name for S&R": "LTXVImgToVideoInplace",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            },
            "widgets_values": [
              1,
              false
            ]
          },
          {
            "id": 118,
            "type": "Reroute",
            "pos": [
              -229.99999095071237,
              4210.000236619506
            ],
            "size": [
              75,
              26
            ],
            "flags": {},
            "order": 27,
            "mode": 0,
            "inputs": [
              {
                "name": "",
                "type": "*",
                "link": 303
              }
            ],
            "outputs": [
              {
                "name": "",
                "type": "VAE",
                "links": [
                  289,
                  291,
                  367
                ]
              }
            ],
            "properties": {
              "showOutputText": false,
              "horizontal": false
            }
          },
          {
            "id": 151,
            "type": "LTXVImgToVideoInplace",
            "pos": [
              -19.999999788732577,
              4070.0002501406198
            ],
            "size": [
              270,
              181.9921875
            ],
            "flags": {},
            "order": 38,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "vae",
                "name": "vae",
                "type": "VAE",
                "link": 367
              },
              {
                "localized_name": "image",
                "name": "image",
                "type": "IMAGE",
                "link": 410
              },
              {
                "localized_name": "latent",
                "name": "latent",
                "type": "LATENT",
                "link": 366
              },
              {
                "localized_name": "strength",
                "name": "strength",
                "type": "FLOAT",
                "widget": {
                  "name": "strength"
                },
                "link": 371
              },
              {
                "localized_name": "bypass",
                "name": "bypass",
                "type": "BOOLEAN",
                "widget": {
                  "name": "bypass"
                },
                "link": 368
              }
            ],
            "outputs": [
              {
                "localized_name": "latent",
                "name": "latent",
                "type": "LATENT",
                "links": [
                  365
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.7.0",
              "Node name for S&R": "LTXVImgToVideoInplace",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            },
            "widgets_values": [
              1,
              false
            ]
          },
          {
            "id": 104,
            "type": "LTXVCropGuides",
            "pos": [
              -9.999999119719098,
              3840.0000630985346
            ],
            "size": [
              240,
              80
            ],
            "flags": {},
            "order": 15,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "positive",
                "name": "positive",
                "type": "CONDITIONING",
                "link": 310
              },
              {
                "localized_name": "negative",
                "name": "negative",
                "type": "CONDITIONING",
                "link": 312
              },
              {
                "localized_name": "latent",
                "name": "latent",
                "type": "LATENT",
                "link": 270
              }
            ],
            "outputs": [
              {
                "localized_name": "positive",
                "name": "positive",
                "type": "CONDITIONING",
                "links": [
                  281
                ]
              },
              {
                "localized_name": "negative",
                "name": "negative",
                "type": "CONDITIONING",
                "links": [
                  282
                ]
              },
              {
                "localized_name": "latent",
                "name": "latent",
                "type": "LATENT",
                "slot_index": 2,
                "links": [
                  287
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.3.68",
              "Node name for S&R": "LTXVCropGuides",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            },
            "widgets_values": []
          },
          {
            "id": 112,
            "type": "LTXVLatentUpsampler",
            "pos": [
              -9.999999119719098,
              3960.0002084505168
            ],
            "size": [
              260,
              80
            ],
            "flags": {},
            "order": 22,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "samples",
                "name": "samples",
                "type": "LATENT",
                "link": 287
              },
              {
                "localized_name": "upscale_model",
                "name": "upscale_model",
                "type": "LATENT_UPSCALE_MODEL",
                "link": 288
              },
              {
                "localized_name": "vae",
                "name": "vae",
                "type": "VAE",
                "link": 289
              }
            ],
            "outputs": [
              {
                "localized_name": "LATENT",
                "name": "LATENT",
                "type": "LATENT",
                "links": [
                  366
                ]
              }
            ],
            "title": "spatial",
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.7.0",
              "Node name for S&R": "LTXVLatentUpsampler",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            },
            "widgets_values": []
          },
          {
            "id": 132,
            "type": "LTXVAddGuide",
            "pos": [
              -599.9999928169079,
              4420.000216337834
            ],
            "size": [
              270,
              209.16666666666669
            ],
            "flags": {},
            "order": 32,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "positive",
                "name": "positive",
                "type": "CONDITIONING",
                "link": 313
              },
              {
                "localized_name": "negative",
                "name": "negative",
                "type": "CONDITIONING",
                "link": 314
              },
              {
                "localized_name": "vae",
                "name": "vae",
                "type": "VAE",
                "link": 328
              },
              {
                "localized_name": "latent",
                "name": "latent",
                "type": "LATENT",
                "link": 357
              },
              {
                "localized_name": "image",
                "name": "image",
                "type": "IMAGE",
                "link": 418
              },
              {
                "localized_name": "frame_idx",
                "name": "frame_idx",
                "type": "INT",
                "widget": {
                  "name": "frame_idx"
                },
                "link": null
              },
              {
                "localized_name": "strength",
                "name": "strength",
                "type": "FLOAT",
                "widget": {
                  "name": "strength"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "positive",
                "name": "positive",
                "type": "CONDITIONING",
                "links": [
                  309,
                  310
                ]
              },
              {
                "localized_name": "negative",
                "name": "negative",
                "type": "CONDITIONING",
                "links": [
                  311,
                  312
                ]
              },
              {
                "localized_name": "latent",
                "name": "latent",
                "type": "LATENT",
                "links": [
                  324
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.3.75",
              "Node name for S&R": "LTXVAddGuide",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            },
            "widgets_values": [
              0,
              1
            ]
          },
          {
            "id": 96,
            "type": "LTXVAudioVAELoader",
            "pos": [
              -1650.0000287323687,
              3910.000056337978
            ],
            "size": [
              420,
              68.88020833333334
            ],
            "flags": {},
            "order": 10,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "ckpt_name",
                "name": "ckpt_name",
                "type": "COMBO",
                "widget": {
                  "name": "ckpt_name"
                },
                "link": 377
              }
            ],
            "outputs": [
              {
                "localized_name": "Audio VAE",
                "name": "Audio VAE",
                "type": "VAE",
                "links": [
                  285,
                  340
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.3.68",
              "Node name for S&R": "LTXVAudioVAELoader",
              "models": [
                {
                  "name": "ltx-2-19b-dev-fp8.safetensors",
                  "url": "https://huggingface.co/Lightricks/LTX-2/resolve/main/ltx-2-19b-dev-fp8.safetensors",
                  "directory": "checkpoints"
                }
              ],
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            },
            "widgets_values": [
              "ltx-2-19b-dev-fp8.safetensors"
            ]
          },
          {
            "id": 103,
            "type": "CheckpointLoaderSimple",
            "pos": [
              -1650.0000287323687,
              3590.0000349295465
            ],
            "size": [
              420,
              108.88020833333334
            ],
            "flags": {},
            "order": 14,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "ckpt_name",
                "name": "ckpt_name",
                "type": "COMBO",
                "widget": {
                  "name": "ckpt_name"
                },
                "link": 425
              }
            ],
            "outputs": [
              {
                "localized_name": "MODEL",
                "name": "MODEL",
                "type": "MODEL",
                "links": [
                  325
                ]
              },
              {
                "localized_name": "CLIP",
                "name": "CLIP",
                "type": "CLIP",
                "links": []
              },
              {
                "localized_name": "VAE",
                "name": "VAE",
                "type": "VAE",
                "links": [
                  303,
                  328,
                  353,
                  359
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.3.56",
              "Node name for S&R": "CheckpointLoaderSimple",
              "models": [
                {
                  "name": "ltx-2-19b-dev-fp8.safetensors",
                  "url": "https://huggingface.co/Lightricks/LTX-2/resolve/main/ltx-2-19b-dev-fp8.safetensors",
                  "directory": "checkpoints"
                }
              ],
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            },
            "widgets_values": [
              "ltx-2-19b-dev-fp8.safetensors"
            ]
          },
          {
            "id": 105,
            "type": "LoraLoaderModelOnly",
            "pos": [
              -69.99999741197416,
              3570.000193802643
            ],
            "size": [
              390,
              95.546875
            ],
            "flags": {},
            "order": 16,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "model",
                "name": "model",
                "type": "MODEL",
                "link": 327
              },
              {
                "localized_name": "lora_name",
                "name": "lora_name",
                "type": "COMBO",
                "widget": {
                  "name": "lora_name"
                },
                "link": 429
              },
              {
                "localized_name": "strength_model",
                "name": "strength_model",
                "type": "FLOAT",
                "widget": {
                  "name": "strength_model"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "MODEL",
                "name": "MODEL",
                "type": "MODEL",
                "links": [
                  280
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.3.75",
              "Node name for S&R": "LoraLoaderModelOnly",
              "models": [
                {
                  "name": "ltx-2-19b-distilled-lora-384.safetensors",
                  "url": "https://huggingface.co/Lightricks/LTX-2/resolve/main/ltx-2-19b-distilled-lora-384.safetensors",
                  "directory": "loras"
                }
              ],
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            },
            "widgets_values": [
              "ltx-2-19b-distilled-lora-384.safetensors",
              1
            ]
          },
          {
            "id": 100,
            "type": "LatentUpscaleModelLoader",
            "pos": [
              -69.99999741197416,
              3700.00007661965
            ],
            "size": [
              390,
              68.88020833333334
            ],
            "flags": {},
            "order": 12,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "model_name",
                "name": "model_name",
                "type": "COMBO",
                "widget": {
                  "name": "model_name"
                },
                "link": 430
              }
            ],
            "outputs": [
              {
                "localized_name": "LATENT_UPSCALE_MODEL",
                "name": "LATENT_UPSCALE_MODEL",
                "type": "LATENT_UPSCALE_MODEL",
                "links": [
                  288
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.7.0",
              "Node name for S&R": "LatentUpscaleModelLoader",
              "models": [
                {
                  "name": "ltx-2-spatial-upscaler-x2-1.0.safetensors",
                  "url": "https://huggingface.co/Lightricks/LTX-2/resolve/main/ltx-2-spatial-upscaler-x2-1.0.safetensors",
                  "directory": "latent_upscale_models"
                }
              ],
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            },
            "widgets_values": [
              "ltx-2-spatial-upscaler-x2-1.0.safetensors"
            ]
          },
          {
            "id": 110,
            "type": "GetImageSize",
            "pos": [
              -1630.0000045070383,
              4450.000161126616
            ],
            "size": [
              260,
              80
            ],
            "flags": {},
            "order": 20,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "image",
                "name": "image",
                "type": "IMAGE",
                "link": 416
              }
            ],
            "outputs": [
              {
                "localized_name": "width",
                "name": "width",
                "type": "INT",
                "links": [
                  296
                ]
              },
              {
                "localized_name": "height",
                "name": "height",
                "type": "INT",
                "links": [
                  297
                ]
              },
              {
                "localized_name": "batch_size",
                "name": "batch_size",
                "type": "INT",
                "links": [
                  329,
                  330
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.7.0",
              "Node name for S&R": "GetImageSize",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            },
            "widgets_values": []
          },
          {
            "id": 106,
            "type": "CreateVideo",
            "pos": [
              1419.9999363380857,
              3760.0003323940673
            ],
            "size": [
              270,
              86.66666666666667
            ],
            "flags": {},
            "order": 17,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "images",
                "name": "images",
                "type": "IMAGE",
                "link": 352
              },
              {
                "localized_name": "audio",
                "name": "audio",
                "shape": 7,
                "type": "AUDIO",
                "link": 339
              },
              {
                "localized_name": "fps",
                "name": "fps",
                "type": "FLOAT",
                "widget": {
                  "name": "fps"
                },
                "link": 356
              }
            ],
            "outputs": [
              {
                "localized_name": "VIDEO",
                "name": "VIDEO",
                "type": "VIDEO",
                "links": [
                  304
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.5.1",
              "Node name for S&R": "CreateVideo",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            },
            "widgets_values": [
              25
            ]
          },
          {
            "id": 187,
            "type": "ImageFromBatch",
            "pos": [
              -2310.000095774562,
              3689.999972957771
            ],
            "size": [
              260,
              93.33333333333334
            ],
            "flags": {},
            "order": 39,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "image",
                "name": "image",
                "type": "IMAGE",
                "link": 412
              },
              {
                "localized_name": "batch_index",
                "name": "batch_index",
                "type": "INT",
                "widget": {
                  "name": "batch_index"
                },
                "link": null
              },
              {
                "localized_name": "length",
                "name": "length",
                "type": "INT",
                "widget": {
                  "name": "length"
                },
                "link": 422
              }
            ],
            "outputs": [
              {
                "localized_name": "IMAGE",
                "name": "IMAGE",
                "type": "IMAGE",
                "links": [
                  415
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.7.0",
              "Node name for S&R": "ImageFromBatch",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            },
            "widgets_values": [
              0,
              121
            ]
          },
          {
            "id": 191,
            "type": "ResizeImageMaskNode",
            "pos": [
              -2320.0000163380137,
              3850.0001667604133
            ],
            "size": [
              284.375,
              154
            ],
            "flags": {},
            "order": 43,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "input",
                "name": "input",
                "type": "IMAGE,MASK",
                "link": 415
              },
              {
                "localized_name": "resize_type",
                "name": "resize_type",
                "type": "COMFY_DYNAMICCOMBO_V3",
                "widget": {
                  "name": "resize_type"
                },
                "link": null
              },
              {
                "localized_name": "width",
                "name": "resize_type.width",
                "type": "INT",
                "widget": {
                  "name": "resize_type.width"
                },
                "link": 420
              },
              {
                "localized_name": "height",
                "name": "resize_type.height",
                "type": "INT",
                "widget": {
                  "name": "resize_type.height"
                },
                "link": 421
              },
              {
                "localized_name": "crop",
                "name": "resize_type.crop",
                "type": "COMBO",
                "widget": {
                  "name": "resize_type.crop"
                },
                "link": null
              },
              {
                "localized_name": "scale_method",
                "name": "scale_method",
                "type": "COMBO",
                "widget": {
                  "name": "scale_method"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "resized",
                "name": "resized",
                "type": "IMAGE",
                "links": [
                  413
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.7.0",
              "Node name for S&R": "ResizeImageMaskNode",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            },
            "widgets_values": [
              "scale dimensions",
              1280,
              720,
              "center",
              "lanczos"
            ]
          },
          {
            "id": 188,
            "type": "GetVideoComponents",
            "pos": [
              -2320.0000163380137,
              3520.0000416901034
            ],
            "size": [
              280,
              80
            ],
            "flags": {
              "collapsed": false
            },
            "order": 40,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "video",
                "name": "video",
                "type": "VIDEO",
                "link": 419
              }
            ],
            "outputs": [
              {
                "localized_name": "images",
                "name": "images",
                "type": "IMAGE",
                "links": [
                  412
                ]
              },
              {
                "localized_name": "audio",
                "name": "audio",
                "type": "AUDIO",
                "links": []
              },
              {
                "localized_name": "fps",
                "name": "fps",
                "type": "FLOAT",
                "links": []
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.5.1",
              "Node name for S&R": "GetVideoComponents",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            },
            "widgets_values": []
          },
          {
            "id": 189,
            "type": "ImageScaleBy",
            "pos": [
              -1990.0000743661303,
              3670.0001318308678
            ],
            "size": [
              280,
              125.546875
            ],
            "flags": {},
            "order": 41,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "image",
                "name": "image",
                "type": "IMAGE",
                "link": 413
              },
              {
                "localized_name": "upscale_method",
                "name": "upscale_method",
                "type": "COMBO",
                "widget": {
                  "name": "upscale_method"
                },
                "link": null
              },
              {
                "localized_name": "scale_by",
                "name": "scale_by",
                "type": "FLOAT",
                "widget": {
                  "name": "scale_by"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "IMAGE",
                "name": "IMAGE",
                "type": "IMAGE",
                "links": [
                  414
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.5.1",
              "Node name for S&R": "ImageScaleBy",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            },
            "widgets_values": [
              "lanczos",
              0.5
            ]
          },
          {
            "id": 154,
            "type": "MarkdownNote",
            "pos": [
              -1659.9999492958204,
              4870.000120563272
            ],
            "size": [
              350,
              170
            ],
            "flags": {
              "collapsed": false
            },
            "order": 7,
            "mode": 0,
            "inputs": [],
            "outputs": [],
            "title": "Frame Rate Note",
            "properties": {},
            "widgets_values": [
              "Please make sure the frame rate value is the same in both boxes"
            ],
            "color": "#222",
            "bgcolor": "#000"
          },
          {
            "id": 190,
            "type": "38b60539-50a7-42f9-a5fe-bdeca26272e2",
            "pos": [
              -1999.9999949295823,
              3910.000056337978
            ],
            "size": [
              310,
              106
            ],
            "flags": {},
            "order": 42,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "pixels",
                "name": "pixels",
                "type": "IMAGE",
                "link": 414
              },
              {
                "label": "depth_intensity",
                "name": "sigma",
                "type": "FLOAT",
                "widget": {
                  "name": "sigma"
                },
                "link": null
              },
              {
                "name": "unet_name",
                "type": "COMBO",
                "widget": {
                  "name": "unet_name"
                },
                "link": 431
              },
              {
                "name": "vae_name",
                "type": "COMBO",
                "widget": {
                  "name": "vae_name"
                },
                "link": 432
              }
            ],
            "outputs": [
              {
                "localized_name": "IMAGE",
                "name": "IMAGE",
                "type": "IMAGE",
                "links": [
                  416,
                  417,
                  418
                ]
              }
            ],
            "properties": {
              "proxyWidgets": [
                [
                  "-1",
                  "sigma"
                ],
                [
                  "-1",
                  "unet_name"
                ],
                [
                  "-1",
                  "vae_name"
                ]
              ],
              "cnr_id": "comfy-core",
              "ver": "0.5.1",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            },
            "widgets_values": [
              999.0000000000002,
              "lotus-depth-d-v1-1.safetensors",
              "vae-ft-mse-840000-ema-pruned.safetensors"
            ],
            "color": "#322",
            "bgcolor": "#533"
          },
          {
            "id": 97,
            "type": "LTXAVTextEncoderLoader",
            "pos": [
              -1650.0000287323687,
              4040.0003053518376
            ],
            "size": [
              420,
              124.44010416666667
            ],
            "flags": {},
            "order": 11,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "text_encoder",
                "name": "text_encoder",
                "type": "COMBO",
                "widget": {
                  "name": "text_encoder"
                },
                "link": 427
              },
              {
                "localized_name": "ckpt_name",
                "name": "ckpt_name",
                "type": "COMBO",
                "widget": {
                  "name": "ckpt_name"
                },
                "link": 433
              },
              {
                "localized_name": "device",
                "name": "device",
                "type": "COMBO",
                "widget": {
                  "name": "device"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "CLIP",
                "name": "CLIP",
                "type": "CLIP",
                "links": [
                  294,
                  295
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.7.0",
              "Node name for S&R": "LTXAVTextEncoderLoader",
              "models": [
                {
                  "name": "ltx-2-19b-dev-fp8.safetensors",
                  "url": "https://huggingface.co/Lightricks/LTX-2/resolve/main/ltx-2-19b-dev-fp8.safetensors",
                  "directory": "checkpoints"
                },
                {
                  "name": "gemma_3_12B_it_fp4_mixed.safetensors",
                  "url": "https://huggingface.co/Comfy-Org/ltx-2/resolve/main/split_files/text_encoders/gemma_3_12B_it_fp4_mixed.safetensors",
                  "directory": "text_encoders"
                }
              ],
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            },
            "widgets_values": [
              "gemma_3_12B_it_fp4_mixed.safetensors",
              "ltx-2-19b-dev-fp8.safetensors",
              "default"
            ]
          }
        ],
        "groups": [
          {
            "id": 1,
            "title": "Model",
            "bounding": [
              -1660,
              3440,
              440,
              820
            ],
            "color": "#3f789e",
            "font_size": 24,
            "flags": {}
          },
          {
            "id": 2,
            "title": "Basic Sampling",
            "bounding": [
              -700,
              3440,
              570,
              820
            ],
            "color": "#3f789e",
            "font_size": 24,
            "flags": {}
          },
          {
            "id": 3,
            "title": "Prompt",
            "bounding": [
              -1180,
              3440,
              440,
              820
            ],
            "color": "#3f789e",
            "font_size": 24,
            "flags": {}
          },
          {
            "id": 5,
            "title": "Latent",
            "bounding": [
              -1180,
              4290,
              1050,
              680
            ],
            "color": "#3f789e",
            "font_size": 24,
            "flags": {}
          },
          {
            "id": 9,
            "title": "Upscale Sampling(2x)",
            "bounding": [
              -100,
              3440,
              1090,
              820
            ],
            "color": "#3f789e",
            "font_size": 24,
            "flags": {}
          },
          {
            "id": 6,
            "title": "Sampler",
            "bounding": [
              350,
              3480,
              620,
              750
            ],
            "color": "#3f789e",
            "font_size": 24,
            "flags": {}
          },
          {
            "id": 7,
            "title": "Model",
            "bounding": [
              -90,
              3480,
              430,
              310
            ],
            "color": "#3f789e",
            "font_size": 24,
            "flags": {}
          },
          {
            "id": 11,
            "title": "Frame rate",
            "bounding": [
              -1640,
              4550,
              290,
              271.6
            ],
            "color": "#3f789e",
            "font_size": 24,
            "flags": {}
          },
          {
            "id": 16,
            "title": "Video Preprocess",
            "bounding": [
              -2330,
              3450,
              650,
              567.6
            ],
            "color": "#3f789e",
            "font_size": 24,
            "flags": {}
          },
          {
            "id": 15,
            "title": "video length",
            "bounding": [
              -2320,
              3620,
              290,
              180
            ],
            "color": "#3f789e",
            "font_size": 24,
            "flags": {}
          }
        ],
        "links": [
          {
            "id": 326,
            "origin_id": 134,
            "origin_slot": 0,
            "target_id": 93,
            "target_slot": 0,
            "type": "MODEL"
          },
          {
            "id": 309,
            "origin_id": 132,
            "origin_slot": 0,
            "target_id": 93,
            "target_slot": 1,
            "type": "CONDITIONING"
          },
          {
            "id": 311,
            "origin_id": 132,
            "origin_slot": 1,
            "target_id": 93,
            "target_slot": 2,
            "type": "CONDITIONING"
          },
          {
            "id": 266,
            "origin_id": 122,
            "origin_slot": 1,
            "target_id": 101,
            "target_slot": 1,
            "type": "LATENT"
          },
          {
            "id": 280,
            "origin_id": 105,
            "origin_slot": 0,
            "target_id": 108,
            "target_slot": 0,
            "type": "MODEL"
          },
          {
            "id": 281,
            "origin_id": 104,
            "origin_slot": 0,
            "target_id": 108,
            "target_slot": 1,
            "type": "CONDITIONING"
          },
          {
            "id": 282,
            "origin_id": 104,
            "origin_slot": 1,
            "target_id": 108,
            "target_slot": 2,
            "type": "CONDITIONING"
          },
          {
            "id": 285,
            "origin_id": 96,
            "origin_slot": 0,
            "target_id": 111,
            "target_slot": 0,
            "type": "VAE"
          },
          {
            "id": 329,
            "origin_id": 110,
            "origin_slot": 2,
            "target_id": 111,
            "target_slot": 1,
            "type": "INT"
          },
          {
            "id": 260,
            "origin_id": 126,
            "origin_slot": 0,
            "target_id": 123,
            "target_slot": 0,
            "type": "NOISE"
          },
          {
            "id": 261,
            "origin_id": 93,
            "origin_slot": 0,
            "target_id": 123,
            "target_slot": 1,
            "type": "GUIDER"
          },
          {
            "id": 262,
            "origin_id": 94,
            "origin_slot": 0,
            "target_id": 123,
            "target_slot": 2,
            "type": "SAMPLER"
          },
          {
            "id": 263,
            "origin_id": 95,
            "origin_slot": 0,
            "target_id": 123,
            "target_slot": 3,
            "type": "SIGMAS"
          },
          {
            "id": 323,
            "origin_id": 116,
            "origin_slot": 0,
            "target_id": 123,
            "target_slot": 4,
            "type": "LATENT"
          },
          {
            "id": 296,
            "origin_id": 110,
            "origin_slot": 0,
            "target_id": 115,
            "target_slot": 0,
            "type": "INT"
          },
          {
            "id": 297,
            "origin_id": 110,
            "origin_slot": 1,
            "target_id": 115,
            "target_slot": 1,
            "type": "INT"
          },
          {
            "id": 330,
            "origin_id": 110,
            "origin_slot": 2,
            "target_id": 115,
            "target_slot": 2,
            "type": "INT"
          },
          {
            "id": 325,
            "origin_id": 103,
            "origin_slot": 0,
            "target_id": 134,
            "target_slot": 0,
            "type": "MODEL"
          },
          {
            "id": 292,
            "origin_id": 124,
            "origin_slot": 0,
            "target_id": 114,
            "target_slot": 0,
            "type": "CONDITIONING"
          },
          {
            "id": 293,
            "origin_id": 119,
            "origin_slot": 0,
            "target_id": 114,
            "target_slot": 1,
            "type": "CONDITIONING"
          },
          {
            "id": 294,
            "origin_id": 97,
            "origin_slot": 0,
            "target_id": 119,
            "target_slot": 0,
            "type": "CLIP"
          },
          {
            "id": 324,
            "origin_id": 132,
            "origin_slot": 2,
            "target_id": 116,
            "target_slot": 0,
            "type": "LATENT"
          },
          {
            "id": 300,
            "origin_id": 111,
            "origin_slot": 0,
            "target_id": 116,
            "target_slot": 1,
            "type": "LATENT"
          },
          {
            "id": 313,
            "origin_id": 114,
            "origin_slot": 0,
            "target_id": 132,
            "target_slot": 0,
            "type": "CONDITIONING"
          },
          {
            "id": 314,
            "origin_id": 114,
            "origin_slot": 1,
            "target_id": 132,
            "target_slot": 1,
            "type": "CONDITIONING"
          },
          {
            "id": 328,
            "origin_id": 103,
            "origin_slot": 2,
            "target_id": 132,
            "target_slot": 2,
            "type": "VAE"
          },
          {
            "id": 272,
            "origin_id": 123,
            "origin_slot": 0,
            "target_id": 122,
            "target_slot": 0,
            "type": "LATENT"
          },
          {
            "id": 336,
            "origin_id": 107,
            "origin_slot": 1,
            "target_id": 138,
            "target_slot": 0,
            "type": "LATENT"
          },
          {
            "id": 339,
            "origin_id": 139,
            "origin_slot": 0,
            "target_id": 106,
            "target_slot": 1,
            "type": "AUDIO"
          },
          {
            "id": 295,
            "origin_id": 97,
            "origin_slot": 0,
            "target_id": 124,
            "target_slot": 0,
            "type": "CLIP"
          },
          {
            "id": 303,
            "origin_id": 103,
            "origin_slot": 2,
            "target_id": 118,
            "target_slot": 0,
            "type": "VAE"
          },
          {
            "id": 338,
            "origin_id": 138,
            "origin_slot": 1,
            "target_id": 139,
            "target_slot": 0,
            "type": "LATENT"
          },
          {
            "id": 340,
            "origin_id": 96,
            "origin_slot": 0,
            "target_id": 139,
            "target_slot": 1,
            "type": "VAE"
          },
          {
            "id": 337,
            "origin_id": 138,
            "origin_slot": 0,
            "target_id": 113,
            "target_slot": 0,
            "type": "LATENT"
          },
          {
            "id": 291,
            "origin_id": 118,
            "origin_slot": 0,
            "target_id": 113,
            "target_slot": 1,
            "type": "VAE"
          },
          {
            "id": 276,
            "origin_id": 108,
            "origin_slot": 0,
            "target_id": 107,
            "target_slot": 1,
            "type": "GUIDER"
          },
          {
            "id": 277,
            "origin_id": 98,
            "origin_slot": 0,
            "target_id": 107,
            "target_slot": 2,
            "type": "SAMPLER"
          },
          {
            "id": 278,
            "origin_id": 99,
            "origin_slot": 0,
            "target_id": 107,
            "target_slot": 3,
            "type": "SIGMAS"
          },
          {
            "id": 279,
            "origin_id": 101,
            "origin_slot": 0,
            "target_id": 107,
            "target_slot": 4,
            "type": "LATENT"
          },
          {
            "id": 327,
            "origin_id": 134,
            "origin_slot": 0,
            "target_id": 105,
            "target_slot": 0,
            "type": "MODEL"
          },
          {
            "id": 310,
            "origin_id": 132,
            "origin_slot": 0,
            "target_id": 104,
            "target_slot": 0,
            "type": "CONDITIONING"
          },
          {
            "id": 312,
            "origin_id": 132,
            "origin_slot": 1,
            "target_id": 104,
            "target_slot": 1,
            "type": "CONDITIONING"
          },
          {
            "id": 270,
            "origin_id": 122,
            "origin_slot": 0,
            "target_id": 104,
            "target_slot": 2,
            "type": "LATENT"
          },
          {
            "id": 287,
            "origin_id": 104,
            "origin_slot": 2,
            "target_id": 112,
            "target_slot": 0,
            "type": "LATENT"
          },
          {
            "id": 288,
            "origin_id": 100,
            "origin_slot": 0,
            "target_id": 112,
            "target_slot": 1,
            "type": "LATENT_UPSCALE_MODEL"
          },
          {
            "id": 289,
            "origin_id": 118,
            "origin_slot": 0,
            "target_id": 112,
            "target_slot": 2,
            "type": "VAE"
          },
          {
            "id": 322,
            "origin_id": 116,
            "origin_slot": 0,
            "target_id": 95,
            "target_slot": 0,
            "type": "LATENT"
          },
          {
            "id": 304,
            "origin_id": 106,
            "origin_slot": 0,
            "target_id": -20,
            "target_slot": 0,
            "type": "VIDEO"
          },
          {
            "id": 345,
            "origin_id": -10,
            "origin_slot": 0,
            "target_id": 124,
            "target_slot": 1,
            "type": "STRING"
          },
          {
            "id": 347,
            "origin_id": 143,
            "origin_slot": 0,
            "target_id": 107,
            "target_slot": 0,
            "type": "NOISE"
          },
          {
            "id": 351,
            "origin_id": 138,
            "origin_slot": 0,
            "target_id": 144,
            "target_slot": 0,
            "type": "LATENT"
          },
          {
            "id": 352,
            "origin_id": 144,
            "origin_slot": 0,
            "target_id": 106,
            "target_slot": 0,
            "type": "IMAGE"
          },
          {
            "id": 353,
            "origin_id": 103,
            "origin_slot": 2,
            "target_id": 144,
            "target_slot": 1,
            "type": "VAE"
          },
          {
            "id": 354,
            "origin_id": 145,
            "origin_slot": 0,
            "target_id": 111,
            "target_slot": 2,
            "type": "INT"
          },
          {
            "id": 355,
            "origin_id": 148,
            "origin_slot": 0,
            "target_id": 114,
            "target_slot": 2,
            "type": "FLOAT"
          },
          {
            "id": 356,
            "origin_id": 148,
            "origin_slot": 0,
            "target_id": 106,
            "target_slot": 2,
            "type": "FLOAT"
          },
          {
            "id": 357,
            "origin_id": 149,
            "origin_slot": 0,
            "target_id": 132,
            "target_slot": 3,
            "type": "LATENT"
          },
          {
            "id": 359,
            "origin_id": 103,
            "origin_slot": 2,
            "target_id": 149,
            "target_slot": 0,
            "type": "VAE"
          },
          {
            "id": 360,
            "origin_id": 115,
            "origin_slot": 0,
            "target_id": 149,
            "target_slot": 2,
            "type": "LATENT"
          },
          {
            "id": 363,
            "origin_id": -10,
            "origin_slot": 2,
            "target_id": 149,
            "target_slot": 4,
            "type": "BOOLEAN"
          },
          {
            "id": 365,
            "origin_id": 151,
            "origin_slot": 0,
            "target_id": 101,
            "target_slot": 0,
            "type": "LATENT"
          },
          {
            "id": 366,
            "origin_id": 112,
            "origin_slot": 0,
            "target_id": 151,
            "target_slot": 2,
            "type": "LATENT"
          },
          {
            "id": 367,
            "origin_id": 118,
            "origin_slot": 0,
            "target_id": 151,
            "target_slot": 0,
            "type": "VAE"
          },
          {
            "id": 368,
            "origin_id": -10,
            "origin_slot": 2,
            "target_id": 151,
            "target_slot": 4,
            "type": "BOOLEAN"
          },
          {
            "id": 370,
            "origin_id": -10,
            "origin_slot": 1,
            "target_id": 149,
            "target_slot": 3,
            "type": "FLOAT"
          },
          {
            "id": 371,
            "origin_id": -10,
            "origin_slot": 1,
            "target_id": 151,
            "target_slot": 3,
            "type": "FLOAT"
          },
          {
            "id": 377,
            "origin_id": -10,
            "origin_slot": 6,
            "target_id": 96,
            "target_slot": 0,
            "type": "COMBO"
          },
          {
            "id": 410,
            "origin_id": -10,
            "origin_slot": 4,
            "target_id": 151,
            "target_slot": 1,
            "type": "IMAGE"
          },
          {
            "id": 412,
            "origin_id": 188,
            "origin_slot": 0,
            "target_id": 187,
            "target_slot": 0,
            "type": "IMAGE"
          },
          {
            "id": 413,
            "origin_id": 191,
            "origin_slot": 0,
            "target_id": 189,
            "target_slot": 0,
            "type": "IMAGE"
          },
          {
            "id": 414,
            "origin_id": 189,
            "origin_slot": 0,
            "target_id": 190,
            "target_slot": 0,
            "type": "IMAGE"
          },
          {
            "id": 415,
            "origin_id": 187,
            "origin_slot": 0,
            "target_id": 191,
            "target_slot": 0,
            "type": "IMAGE"
          },
          {
            "id": 416,
            "origin_id": 190,
            "origin_slot": 0,
            "target_id": 110,
            "target_slot": 0,
            "type": "IMAGE"
          },
          {
            "id": 417,
            "origin_id": 190,
            "origin_slot": 0,
            "target_id": 149,
            "target_slot": 1,
            "type": "IMAGE"
          },
          {
            "id": 418,
            "origin_id": 190,
            "origin_slot": 0,
            "target_id": 132,
            "target_slot": 4,
            "type": "IMAGE"
          },
          {
            "id": 419,
            "origin_id": -10,
            "origin_slot": 3,
            "target_id": 188,
            "target_slot": 0,
            "type": "VIDEO"
          },
          {
            "id": 420,
            "origin_id": -10,
            "origin_slot": 5,
            "target_id": 191,
            "target_slot": 2,
            "type": "INT"
          },
          {
            "id": 421,
            "origin_id": -10,
            "origin_slot": 6,
            "target_id": 191,
            "target_slot": 3,
            "type": "INT"
          },
          {
            "id": 422,
            "origin_id": -10,
            "origin_slot": 7,
            "target_id": 187,
            "target_slot": 2,
            "type": "INT"
          },
          {
            "id": 425,
            "origin_id": -10,
            "origin_slot": 8,
            "target_id": 103,
            "target_slot": 0,
            "type": "COMBO"
          },
          {
            "id": 426,
            "origin_id": -10,
            "origin_slot": 9,
            "target_id": 134,
            "target_slot": 1,
            "type": "COMBO"
          },
          {
            "id": 427,
            "origin_id": -10,
            "origin_slot": 10,
            "target_id": 97,
            "target_slot": 0,
            "type": "COMBO"
          },
          {
            "id": 429,
            "origin_id": -10,
            "origin_slot": 11,
            "target_id": 105,
            "target_slot": 1,
            "type": "COMBO"
          },
          {
            "id": 430,
            "origin_id": -10,
            "origin_slot": 12,
            "target_id": 100,
            "target_slot": 0,
            "type": "COMBO"
          },
          {
            "id": 431,
            "origin_id": -10,
            "origin_slot": 13,
            "target_id": 190,
            "target_slot": 2,
            "type": "COMBO"
          },
          {
            "id": 432,
            "origin_id": -10,
            "origin_slot": 14,
            "target_id": 190,
            "target_slot": 3,
            "type": "COMBO"
          },
          {
            "id": 433,
            "origin_id": -10,
            "origin_slot": 8,
            "target_id": 97,
            "target_slot": 1,
            "type": "COMBO"
          }
        ],
        "extra": {
          "workflowRendererVersion": "LG"
        },
        "category": "Video generation and editing/Conditioned",
        "description": "Generates depth-controlled video with LTX-2: motion and structure follow a depth-reference video alongside text prompting, optional first-frame image conditioning, with optional synchronized audio."
      },
      {
        "id": "38b60539-50a7-42f9-a5fe-bdeca26272e2",
        "version": 1,
        "state": {
          "lastGroupId": 16,
          "lastNodeId": 191,
          "lastLinkId": 433,
          "lastRerouteId": 0
        },
        "revision": 0,
        "config": {},
        "name": "Image to Depth Map (Lotus)",
        "inputNode": {
          "id": -10,
          "bounding": [
            -60,
            -172.61268043518066,
            126.625,
            120
          ]
        },
        "outputNode": {
          "id": -20,
          "bounding": [
            1650,
            -172.61268043518066,
            120,
            60
          ]
        },
        "inputs": [
          {
            "id": "3bdd30c3-4ec9-485a-814b-e7d39fb6b5cc",
            "name": "pixels",
            "type": "IMAGE",
            "linkIds": [
              37
            ],
            "localized_name": "pixels",
            "pos": [
              46.625,
              -152.61268043518066
            ]
          },
          {
            "id": "f9a1017c-f4b9-43b4-94c2-41c088b3a492",
            "name": "sigma",
            "type": "FLOAT",
            "linkIds": [
              243
            ],
            "label": "depth_intensity",
            "pos": [
              46.625,
              -132.61268043518066
            ]
          },
          {
            "id": "374bfecc-34bb-47f9-82b6-cbe9383f8756",
            "name": "unet_name",
            "type": "COMBO",
            "linkIds": [
              423
            ],
            "pos": [
              46.625,
              -112.61268043518066
            ]
          },
          {
            "id": "bb8707a1-46c3-44be-a15a-0adc908d871d",
            "name": "vae_name",
            "type": "COMBO",
            "linkIds": [
              424
            ],
            "pos": [
              46.625,
              -92.61268043518066
            ]
          }
        ],
        "outputs": [
          {
            "id": "2ec278bd-0b66-4b30-9c5b-994d5f638214",
            "name": "IMAGE",
            "type": "IMAGE",
            "linkIds": [
              242
            ],
            "localized_name": "IMAGE",
            "pos": [
              1670,
              -152.61268043518066
            ]
          }
        ],
        "widgets": [],
        "nodes": [
          {
            "id": 8,
            "type": "VAEDecode",
            "pos": [
              1380,
              -240
            ],
            "size": [
              210,
              46
            ],
            "flags": {},
            "order": 3,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "samples",
                "name": "samples",
                "type": "LATENT",
                "link": 232
              },
              {
                "localized_name": "vae",
                "name": "vae",
                "type": "VAE",
                "link": 240
              }
            ],
            "outputs": [
              {
                "localized_name": "IMAGE",
                "name": "IMAGE",
                "type": "IMAGE",
                "slot_index": 0,
                "links": [
                  35
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.3.34",
              "Node name for S&R": "VAEDecode",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65,
              "widget_ue_connectable": {}
            },
            "widgets_values": []
          },
          {
            "id": 10,
            "type": "UNETLoader",
            "pos": [
              135.34181213378906,
              -290.1947937011719
            ],
            "size": [
              305.93701171875,
              82
            ],
            "flags": {},
            "order": 4,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "unet_name",
                "name": "unet_name",
                "type": "COMBO",
                "widget": {
                  "name": "unet_name"
                },
                "link": 423
              },
              {
                "localized_name": "weight_dtype",
                "name": "weight_dtype",
                "type": "COMBO",
                "widget": {
                  "name": "weight_dtype"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "MODEL",
                "name": "MODEL",
                "type": "MODEL",
                "slot_index": 0,
                "links": [
                  31,
                  241
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.3.34",
              "Node name for S&R": "UNETLoader",
              "models": [
                {
                  "name": "lotus-depth-d-v1-1.safetensors",
                  "url": "https://huggingface.co/Comfy-Org/lotus/resolve/main/lotus-depth-d-v1-1.safetensors",
                  "directory": "diffusion_models"
                }
              ],
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65,
              "widget_ue_connectable": {}
            },
            "widgets_values": [
              "lotus-depth-d-v1-1.safetensors",
              "default"
            ]
          },
          {
            "id": 14,
            "type": "VAELoader",
            "pos": [
              134.531494140625,
              -165.18197631835938
            ],
            "size": [
              305.93701171875,
              58
            ],
            "flags": {},
            "order": 5,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "vae_name",
                "name": "vae_name",
                "type": "COMBO",
                "widget": {
                  "name": "vae_name"
                },
                "link": 424
              }
            ],
            "outputs": [
              {
                "localized_name": "VAE",
                "name": "VAE",
                "type": "VAE",
                "slot_index": 0,
                "links": [
                  38,
                  240
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.3.34",
              "Node name for S&R": "VAELoader",
              "models": [
                {
                  "name": "vae-ft-mse-840000-ema-pruned.safetensors",
                  "url": "https://huggingface.co/stabilityai/sd-vae-ft-mse-original/resolve/main/vae-ft-mse-840000-ema-pruned.safetensors",
                  "directory": "vae"
                }
              ],
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65,
              "widget_ue_connectable": {}
            },
            "widgets_values": [
              "vae-ft-mse-840000-ema-pruned.safetensors"
            ]
          },
          {
            "id": 16,
            "type": "SamplerCustomAdvanced",
            "pos": [
              990.6585693359375,
              -319.9144287109375
            ],
            "size": [
              355.20001220703125,
              326
            ],
            "flags": {},
            "order": 6,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "noise",
                "name": "noise",
                "type": "NOISE",
                "link": 237
              },
              {
                "localized_name": "guider",
                "name": "guider",
                "type": "GUIDER",
                "link": 27
              },
              {
                "localized_name": "sampler",
                "name": "sampler",
                "type": "SAMPLER",
                "link": 33
              },
              {
                "localized_name": "sigmas",
                "name": "sigmas",
                "type": "SIGMAS",
                "link": 194
              },
              {
                "localized_name": "latent_image",
                "name": "latent_image",
                "type": "LATENT",
                "link": 201
              }
            ],
            "outputs": [
              {
                "localized_name": "output",
                "name": "output",
                "type": "LATENT",
                "slot_index": 0,
                "links": [
                  232
                ]
              },
              {
                "localized_name": "denoised_output",
                "name": "denoised_output",
                "type": "LATENT",
                "slot_index": 1,
                "links": []
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.3.34",
              "Node name for S&R": "SamplerCustomAdvanced",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65,
              "widget_ue_connectable": {}
            },
            "widgets_values": []
          },
          {
            "id": 18,
            "type": "DisableNoise",
            "pos": [
              730.47705078125,
              -320
            ],
            "size": [
              210,
              26
            ],
            "flags": {},
            "order": 0,
            "mode": 0,
            "inputs": [],
            "outputs": [
              {
                "localized_name": "NOISE",
                "name": "NOISE",
                "type": "NOISE",
                "slot_index": 0,
                "links": [
                  237
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.3.34",
              "Node name for S&R": "DisableNoise",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65,
              "widget_ue_connectable": {}
            },
            "widgets_values": []
          },
          {
            "id": 19,
            "type": "BasicGuider",
            "pos": [
              730.2631225585938,
              -251.22537231445312
            ],
            "size": [
              210,
              46
            ],
            "flags": {},
            "order": 7,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "model",
                "name": "model",
                "type": "MODEL",
                "link": 241
              },
              {
                "localized_name": "conditioning",
                "name": "conditioning",
                "type": "CONDITIONING",
                "link": 238
              }
            ],
            "outputs": [
              {
                "localized_name": "GUIDER",
                "name": "GUIDER",
                "type": "GUIDER",
                "slot_index": 0,
                "links": [
                  27
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.3.34",
              "Node name for S&R": "BasicGuider",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65,
              "widget_ue_connectable": {}
            },
            "widgets_values": []
          },
          {
            "id": 20,
            "type": "BasicScheduler",
            "pos": [
              488.64459228515625,
              -147.67201232910156
            ],
            "size": [
              210,
              106
            ],
            "flags": {},
            "order": 8,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "model",
                "name": "model",
                "type": "MODEL",
                "link": 31
              },
              {
                "localized_name": "scheduler",
                "name": "scheduler",
                "type": "COMBO",
                "widget": {
                  "name": "scheduler"
                },
                "link": null
              },
              {
                "localized_name": "steps",
                "name": "steps",
                "type": "INT",
                "widget": {
                  "name": "steps"
                },
                "link": null
              },
              {
                "localized_name": "denoise",
                "name": "denoise",
                "type": "FLOAT",
                "widget": {
                  "name": "denoise"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "SIGMAS",
                "name": "SIGMAS",
                "type": "SIGMAS",
                "slot_index": 0,
                "links": [
                  66
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.3.34",
              "Node name for S&R": "BasicScheduler",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65,
              "widget_ue_connectable": {}
            },
            "widgets_values": [
              "normal",
              1,
              1
            ]
          },
          {
            "id": 21,
            "type": "KSamplerSelect",
            "pos": [
              730.2631225585938,
              -161.22537231445312
            ],
            "size": [
              210,
              58
            ],
            "flags": {},
            "order": 1,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "sampler_name",
                "name": "sampler_name",
                "type": "COMBO",
                "widget": {
                  "name": "sampler_name"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "SAMPLER",
                "name": "SAMPLER",
                "type": "SAMPLER",
                "slot_index": 0,
                "links": [
                  33
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.3.34",
              "Node name for S&R": "KSamplerSelect",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65,
              "widget_ue_connectable": {}
            },
            "widgets_values": [
              "euler"
            ]
          },
          {
            "id": 22,
            "type": "ImageInvert",
            "pos": [
              1380,
              -310
            ],
            "size": [
              210,
              26
            ],
            "flags": {},
            "order": 9,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "image",
                "name": "image",
                "type": "IMAGE",
                "link": 35
              }
            ],
            "outputs": [
              {
                "localized_name": "IMAGE",
                "name": "IMAGE",
                "type": "IMAGE",
                "slot_index": 0,
                "links": [
                  242
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.3.34",
              "Node name for S&R": "ImageInvert",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65,
              "widget_ue_connectable": {}
            },
            "widgets_values": []
          },
          {
            "id": 23,
            "type": "VAEEncode",
            "pos": [
              730.2631225585938,
              38.77463912963867
            ],
            "size": [
              210,
              46
            ],
            "flags": {},
            "order": 10,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "pixels",
                "name": "pixels",
                "type": "IMAGE",
                "link": 37
              },
              {
                "localized_name": "vae",
                "name": "vae",
                "type": "VAE",
                "link": 38
              }
            ],
            "outputs": [
              {
                "localized_name": "LATENT",
                "name": "LATENT",
                "type": "LATENT",
                "slot_index": 0,
                "links": [
                  201
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.3.34",
              "Node name for S&R": "VAEEncode",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65,
              "widget_ue_connectable": {}
            },
            "widgets_values": []
          },
          {
            "id": 28,
            "type": "SetFirstSigma",
            "pos": [
              730.2631225585938,
              -61.22536087036133
            ],
            "size": [
              210,
              58
            ],
            "flags": {},
            "order": 11,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "sigmas",
                "name": "sigmas",
                "type": "SIGMAS",
                "link": 66
              },
              {
                "localized_name": "sigma",
                "name": "sigma",
                "type": "FLOAT",
                "widget": {
                  "name": "sigma"
                },
                "link": 243
              }
            ],
            "outputs": [
              {
                "localized_name": "SIGMAS",
                "name": "SIGMAS",
                "type": "SIGMAS",
                "slot_index": 0,
                "links": [
                  194
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.3.34",
              "Node name for S&R": "SetFirstSigma",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65,
              "widget_ue_connectable": {}
            },
            "widgets_values": [
              999.0000000000002
            ]
          },
          {
            "id": 68,
            "type": "LotusConditioning",
            "pos": [
              490,
              -230
            ],
            "size": [
              210,
              26
            ],
            "flags": {},
            "order": 2,
            "mode": 0,
            "inputs": [],
            "outputs": [
              {
                "localized_name": "conditioning",
                "name": "conditioning",
                "type": "CONDITIONING",
                "slot_index": 0,
                "links": [
                  238
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.3.34",
              "Node name for S&R": "LotusConditioning",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65,
              "widget_ue_connectable": {}
            },
            "widgets_values": []
          }
        ],
        "groups": [
          {
            "id": 1,
            "title": "Load Models",
            "bounding": [
              120,
              -370,
              335,
              281.6000061035156
            ],
            "color": "#3f789e",
            "font_size": 24,
            "flags": {}
          }
        ],
        "links": [
          {
            "id": 232,
            "origin_id": 16,
            "origin_slot": 0,
            "target_id": 8,
            "target_slot": 0,
            "type": "LATENT"
          },
          {
            "id": 240,
            "origin_id": 14,
            "origin_slot": 0,
            "target_id": 8,
            "target_slot": 1,
            "type": "VAE"
          },
          {
            "id": 237,
            "origin_id": 18,
            "origin_slot": 0,
            "target_id": 16,
            "target_slot": 0,
            "type": "NOISE"
          },
          {
            "id": 27,
            "origin_id": 19,
            "origin_slot": 0,
            "target_id": 16,
            "target_slot": 1,
            "type": "GUIDER"
          },
          {
            "id": 33,
            "origin_id": 21,
            "origin_slot": 0,
            "target_id": 16,
            "target_slot": 2,
            "type": "SAMPLER"
          },
          {
            "id": 194,
            "origin_id": 28,
            "origin_slot": 0,
            "target_id": 16,
            "target_slot": 3,
            "type": "SIGMAS"
          },
          {
            "id": 201,
            "origin_id": 23,
            "origin_slot": 0,
            "target_id": 16,
            "target_slot": 4,
            "type": "LATENT"
          },
          {
            "id": 241,
            "origin_id": 10,
            "origin_slot": 0,
            "target_id": 19,
            "target_slot": 0,
            "type": "MODEL"
          },
          {
            "id": 238,
            "origin_id": 68,
            "origin_slot": 0,
            "target_id": 19,
            "target_slot": 1,
            "type": "CONDITIONING"
          },
          {
            "id": 31,
            "origin_id": 10,
            "origin_slot": 0,
            "target_id": 20,
            "target_slot": 0,
            "type": "MODEL"
          },
          {
            "id": 35,
            "origin_id": 8,
            "origin_slot": 0,
            "target_id": 22,
            "target_slot": 0,
            "type": "IMAGE"
          },
          {
            "id": 38,
            "origin_id": 14,
            "origin_slot": 0,
            "target_id": 23,
            "target_slot": 1,
            "type": "VAE"
          },
          {
            "id": 66,
            "origin_id": 20,
            "origin_slot": 0,
            "target_id": 28,
            "target_slot": 0,
            "type": "SIGMAS"
          },
          {
            "id": 37,
            "origin_id": -10,
            "origin_slot": 0,
            "target_id": 23,
            "target_slot": 0,
            "type": "IMAGE"
          },
          {
            "id": 242,
            "origin_id": 22,
            "origin_slot": 0,
            "target_id": -20,
            "target_slot": 0,
            "type": "IMAGE"
          },
          {
            "id": 243,
            "origin_id": -10,
            "origin_slot": 1,
            "target_id": 28,
            "target_slot": 1,
            "type": "FLOAT"
          },
          {
            "id": 423,
            "origin_id": -10,
            "origin_slot": 2,
            "target_id": 10,
            "target_slot": 0,
            "type": "COMBO"
          },
          {
            "id": 424,
            "origin_id": -10,
            "origin_slot": 3,
            "target_id": 14,
            "target_slot": 0,
            "type": "COMBO"
          }
        ],
        "extra": {
          "workflowRendererVersion": "LG"
        },
        "description": "Estimates a monocular depth map from an input image using the Lotus depth estimation model."
      }
    ]
  },
  "config": {},
  "extra": {
    "ds": {
      "scale": 1.313181818181818,
      "offset": [
        271.9196871428176,
        -3845.0123774536323
      ]
    },
    "workflowRendererVersion": "LG"
  },
  "version": 0.4
}
```
