# Prompt Enhance

- 来源类别：内置工作流蓝图
- 镜像内原始路径：`/ComfyUI/blueprints/Prompt Enhance.json`
- 节点数量：1
- 连线数量：0

## 节点类型

- `24d8bbfd-39d4-4774-bff0-3de40cc7a471` × 1

## 原始工作流 JSON

```json
{
  "revision": 0,
  "last_node_id": 15,
  "last_link_id": 0,
  "nodes": [
    {
      "id": 15,
      "type": "24d8bbfd-39d4-4774-bff0-3de40cc7a471",
      "pos": [
        -1490,
        2040
      ],
      "size": [
        400,
        260
      ],
      "flags": {},
      "order": 0,
      "mode": 0,
      "inputs": [
        {
          "name": "prompt",
          "type": "STRING",
          "widget": {
            "name": "prompt"
          },
          "link": null
        },
        {
          "label": "reference images",
          "name": "images",
          "type": "IMAGE",
          "link": null
        }
      ],
      "outputs": [
        {
          "name": "STRING",
          "type": "STRING",
          "links": null
        }
      ],
      "title": "Prompt Enhance",
      "properties": {
        "proxyWidgets": [
          [
            "-1",
            "prompt"
          ]
        ],
        "cnr_id": "comfy-core",
        "ver": "0.14.1"
      },
      "widgets_values": [
        ""
      ]
    }
  ],
  "links": [],
  "version": 0.4,
  "definitions": {
    "subgraphs": [
      {
        "id": "24d8bbfd-39d4-4774-bff0-3de40cc7a471",
        "version": 1,
        "state": {
          "lastGroupId": 0,
          "lastNodeId": 15,
          "lastLinkId": 14,
          "lastRerouteId": 0
        },
        "revision": 0,
        "config": {},
        "name": "Prompt Enhance",
        "inputNode": {
          "id": -10,
          "bounding": [
            -2170,
            2110,
            138.876953125,
            80
          ]
        },
        "outputNode": {
          "id": -20,
          "bounding": [
            -640,
            2110,
            120,
            60
          ]
        },
        "inputs": [
          {
            "id": "aeab7216-00e0-4528-a09b-bba50845c5a6",
            "name": "prompt",
            "type": "STRING",
            "linkIds": [
              11
            ],
            "pos": [
              -2051.123046875,
              2130
            ]
          },
          {
            "id": "7b73fd36-aa31-4771-9066-f6c83879994b",
            "name": "images",
            "type": "IMAGE",
            "linkIds": [
              14
            ],
            "label": "reference images",
            "pos": [
              -2051.123046875,
              2150
            ]
          }
        ],
        "outputs": [
          {
            "id": "c7b0d930-68a1-48d1-b496-0519e5837064",
            "name": "STRING",
            "type": "STRING",
            "linkIds": [
              13
            ],
            "pos": [
              -620,
              2130
            ]
          }
        ],
        "widgets": [],
        "nodes": [
          {
            "id": 11,
            "type": "GeminiNode",
            "pos": [
              -1560,
              1990
            ],
            "size": [
              470,
              470
            ],
            "flags": {},
            "order": 0,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "images",
                "name": "images",
                "shape": 7,
                "type": "IMAGE",
                "link": 14
              },
              {
                "localized_name": "audio",
                "name": "audio",
                "shape": 7,
                "type": "AUDIO",
                "link": null
              },
              {
                "localized_name": "video",
                "name": "video",
                "shape": 7,
                "type": "VIDEO",
                "link": null
              },
              {
                "localized_name": "files",
                "name": "files",
                "shape": 7,
                "type": "GEMINI_INPUT_FILES",
                "link": null
              },
              {
                "localized_name": "prompt",
                "name": "prompt",
                "type": "STRING",
                "widget": {
                  "name": "prompt"
                },
                "link": 11
              },
              {
                "localized_name": "model",
                "name": "model",
                "type": "COMBO",
                "widget": {
                  "name": "model"
                },
                "link": null
              },
              {
                "localized_name": "seed",
                "name": "seed",
                "type": "INT",
                "widget": {
                  "name": "seed"
                },
                "link": null
              },
              {
                "localized_name": "system_prompt",
                "name": "system_prompt",
                "shape": 7,
                "type": "STRING",
                "widget": {
                  "name": "system_prompt"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "STRING",
                "name": "STRING",
                "type": "STRING",
                "links": [
                  13
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.14.1",
              "Node name for S&R": "GeminiNode"
            },
            "widgets_values": [
              "",
              "gemini-3-pro-preview",
              42,
              "randomize",
              "You are an expert in prompt writing.\nBased on the input, rewrite the user's input into a detailed prompt.\nincluding camera settings, lighting, composition, and style.\nReturn the prompt only"
            ],
            "color": "#432",
            "bgcolor": "#653"
          }
        ],
        "groups": [],
        "links": [
          {
            "id": 11,
            "origin_id": -10,
            "origin_slot": 0,
            "target_id": 11,
            "target_slot": 4,
            "type": "STRING"
          },
          {
            "id": 13,
            "origin_id": 11,
            "origin_slot": 0,
            "target_id": -20,
            "target_slot": 0,
            "type": "STRING"
          },
          {
            "id": 14,
            "origin_id": -10,
            "origin_slot": 1,
            "target_id": 11,
            "target_slot": 0,
            "type": "IMAGE"
          }
        ],
        "extra": {
          "workflowRendererVersion": "LG"
        },
        "category": "Text Tools",
        "description": "Expands short text prompts into detailed descriptions using a text generation model for better generation quality."
      }
    ]
  },
  "extra": {}
}
```
