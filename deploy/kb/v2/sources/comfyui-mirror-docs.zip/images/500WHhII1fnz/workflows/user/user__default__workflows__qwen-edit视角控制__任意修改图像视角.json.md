# 任意修改图像视角

- 来源类别：用户工作流
- 镜像内原始路径：`/ComfyUI/user/default/workflows/qwen-edit视角控制/任意修改图像视角.json`
- 节点数量：22
- 连线数量：28

## 节点类型

- `FluxKontextMultiReferenceLatentMethod` × 2
- `LoraLoaderModelOnly` × 2
- `ShowText|pysssss` × 2
- `TextEncodeQwenImageEditPlus` × 2
- `CFGNorm` × 1
- `CLIPLoader` × 1
- `FluxKontextImageScale` × 1
- `KSampler` × 1
- `LoadImage` × 1
- `ModelSamplingAuraFlow` × 1
- `PreviewImage` × 1
- `QwenMultiangleCameraNode` × 1
- `String` × 1
- `StringConcatenate` × 1
- `UNETLoader` × 1
- `VAEDecodeTiled` × 1
- `VAEEncode` × 1
- `VAELoader` × 1

## 工作流引用的模型或媒体文件

- `-V1.0-fp32-1c18194f7240.safetensors`
- `-lora.safetensors`
- `caled.safetensors`
- `qwen_image_edit_2511_bf16.safetensors`
- `qwen_image_vae.safetensors`

## 原始工作流 JSON

```json
{
  "id": "f5e46589-dd2b-416e-9ee5-2a338ce6dec0",
  "revision": 0,
  "last_node_id": 145,
  "last_link_id": 301,
  "nodes": [
    {
      "id": 123,
      "type": "CFGNorm",
      "pos": [
        -850.111083984375,
        363.2242736816406
      ],
      "size": [
        270,
        68.33333587646484
      ],
      "flags": {},
      "order": 17,
      "mode": 0,
      "inputs": [
        {
          "label": "model",
          "name": "model",
          "type": "MODEL",
          "link": 270
        }
      ],
      "outputs": [
        {
          "label": "patched_model",
          "name": "patched_model",
          "type": "MODEL",
          "links": [
            281
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.5.1",
        "Node name for S&R": "CFGNorm",
        "enableTabs": false,
        "tabWidth": 65,
        "tabXOffset": 10,
        "hasSecondTab": false,
        "secondTabText": "Send Back",
        "secondTabOffset": 80,
        "secondTabWidth": 65
      },
      "widgets_values": [
        1
      ]
    },
    {
      "id": 131,
      "type": "FluxKontextMultiReferenceLatentMethod",
      "pos": [
        -869.14599609375,
        476.2448425292969
      ],
      "size": [
        309.6734313964844,
        70
      ],
      "flags": {},
      "order": 18,
      "mode": 0,
      "inputs": [
        {
          "label": "conditioning",
          "name": "conditioning",
          "type": "CONDITIONING",
          "link": 285
        }
      ],
      "outputs": [
        {
          "label": "CONDITIONING",
          "name": "CONDITIONING",
          "type": "CONDITIONING",
          "links": [
            282
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.5.1",
        "Node name for S&R": "FluxKontextMultiReferenceLatentMethod",
        "enableTabs": false,
        "tabWidth": 65,
        "tabXOffset": 10,
        "hasSecondTab": false,
        "secondTabText": "Send Back",
        "secondTabOffset": 80,
        "secondTabWidth": 65
      },
      "widgets_values": [
        "index_timestep_zero"
      ],
      "color": "#222",
      "bgcolor": "#000"
    },
    {
      "id": 132,
      "type": "FluxKontextMultiReferenceLatentMethod",
      "pos": [
        -869.6133422851562,
        605.5435180664062
      ],
      "size": [
        309.6734313964844,
        70
      ],
      "flags": {},
      "order": 14,
      "mode": 0,
      "inputs": [
        {
          "label": "conditioning",
          "name": "conditioning",
          "type": "CONDITIONING",
          "link": 286
        }
      ],
      "outputs": [
        {
          "label": "CONDITIONING",
          "name": "CONDITIONING",
          "type": "CONDITIONING",
          "links": [
            283
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.5.1",
        "Node name for S&R": "FluxKontextMultiReferenceLatentMethod",
        "enableTabs": false,
        "tabWidth": 65,
        "tabXOffset": 10,
        "hasSecondTab": false,
        "secondTabText": "Send Back",
        "secondTabOffset": 80,
        "secondTabWidth": 65
      },
      "widgets_values": [
        "index_timestep_zero"
      ],
      "color": "#222",
      "bgcolor": "#000"
    },
    {
      "id": 136,
      "type": "VAEDecodeTiled",
      "pos": [
        -554.8404541015625,
        256.4501037597656
      ],
      "size": [
        270,
        150
      ],
      "flags": {},
      "order": 20,
      "mode": 0,
      "inputs": [
        {
          "label": "Latent",
          "name": "samples",
          "type": "LATENT",
          "link": 288
        },
        {
          "label": "VAE",
          "name": "vae",
          "type": "VAE",
          "link": 290
        }
      ],
      "outputs": [
        {
          "label": "图像",
          "name": "IMAGE",
          "type": "IMAGE",
          "links": [
            289
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.7.0",
        "Node name for S&R": "VAEDecodeTiled"
      },
      "widgets_values": [
        512,
        64,
        64,
        8
      ]
    },
    {
      "id": 135,
      "type": "KSampler",
      "pos": [
        -557.3901977539062,
        460.98870849609375
      ],
      "size": [
        280,
        449.3333435058594
      ],
      "flags": {},
      "order": 19,
      "mode": 0,
      "inputs": [
        {
          "label": "模型",
          "name": "model",
          "type": "MODEL",
          "link": 281
        },
        {
          "label": "正面条件",
          "name": "positive",
          "type": "CONDITIONING",
          "link": 282
        },
        {
          "label": "负面条件",
          "name": "negative",
          "type": "CONDITIONING",
          "link": 283
        },
        {
          "label": "Latent",
          "name": "latent_image",
          "type": "LATENT",
          "link": 284
        }
      ],
      "outputs": [
        {
          "label": "Latent",
          "name": "LATENT",
          "type": "LATENT",
          "links": [
            288
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.5.1",
        "Node name for S&R": "KSampler",
        "enableTabs": false,
        "tabWidth": 65,
        "tabXOffset": 10,
        "hasSecondTab": false,
        "secondTabText": "Send Back",
        "secondTabOffset": 80,
        "secondTabWidth": 65
      },
      "widgets_values": [
        719299786752363,
        "randomize",
        4,
        1,
        "euler",
        "simple",
        1
      ]
    },
    {
      "id": 126,
      "type": "UNETLoader",
      "pos": [
        -1848.4886474609375,
        230.572998046875
      ],
      "size": [
        396.1328125,
        96.66666412353516
      ],
      "flags": {},
      "order": 0,
      "mode": 0,
      "inputs": [],
      "outputs": [
        {
          "label": "模型",
          "name": "MODEL",
          "type": "MODEL",
          "slot_index": 0,
          "links": [
            275
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.5.1",
        "Node name for S&R": "UNETLoader",
        "models": [
          {
            "name": "qwen_image_edit_2511_bf16.safetensors",
            "url": "https://huggingface.co/Comfy-Org/Qwen-Image-Edit_ComfyUI/resolve/main/split_files/diffusion_models/qwen_image_edit_2511_bf16.safetensors",
            "directory": "diffusion_models"
          }
        ],
        "enableTabs": false,
        "tabWidth": 65,
        "tabXOffset": 10,
        "hasSecondTab": false,
        "secondTabText": "Send Back",
        "secondTabOffset": 80,
        "secondTabWidth": 65
      },
      "widgets_values": [
        "qwen_image_edit_2511_bf16.safetensors",
        "default"
      ]
    },
    {
      "id": 127,
      "type": "LoraLoaderModelOnly",
      "pos": [
        -1840.6754150390625,
        384.2402648925781
      ],
      "size": [
        372.09375,
        82
      ],
      "flags": {},
      "order": 5,
      "mode": 0,
      "inputs": [
        {
          "label": "模型",
          "name": "model",
          "type": "MODEL",
          "link": 275
        }
      ],
      "outputs": [
        {
          "label": "模型",
          "name": "MODEL",
          "type": "MODEL",
          "links": [
            294
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.5.1",
        "Node name for S&R": "LoraLoaderModelOnly",
        "models": [
          {
            "name": "Qwen-Image-Edit-2511-Lightning-4steps-V1.0-bf16.safetensors",
            "url": "https://huggingface.co/lightx2v/Qwen-Image-Edit-2511-Lightning/resolve/main/Qwen-Image-Edit-2511-Lightning-4steps-V1.0-bf16.safetensors",
            "directory": "loras"
          }
        ],
        "enableTabs": false,
        "tabWidth": 65,
        "tabXOffset": 10,
        "hasSecondTab": false,
        "secondTabText": "Send Back",
        "secondTabOffset": 80,
        "secondTabWidth": 65
      },
      "widgets_values": [
        "Qwen-Image-Edit-2511-Lightning-4steps-V1.0-fp32-1c18194f7240.safetensors",
        1
      ]
    },
    {
      "id": 41,
      "type": "LoadImage",
      "pos": [
        -1846.890625,
        -454.70556640625
      ],
      "size": [
        383.0877380371094,
        528.8095703125
      ],
      "flags": {},
      "order": 1,
      "mode": 0,
      "inputs": [],
      "outputs": [
        {
          "label": "图像",
          "name": "IMAGE",
          "type": "IMAGE",
          "links": [
            287,
            291
          ]
        },
        {
          "label": "遮罩",
          "name": "MASK",
          "type": "MASK",
          "links": null
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.5.1",
        "Node name for S&R": "LoadImage",
        "enableTabs": false,
        "tabWidth": 65,
        "tabXOffset": 10,
        "hasSecondTab": false,
        "secondTabText": "Send Back",
        "secondTabOffset": 80,
        "secondTabWidth": 65
      },
      "widgets_values": [
        "_Image 141.png",
        "image"
      ]
    },
    {
      "id": 137,
      "type": "VAELoader",
      "pos": [
        -1848.428955078125,
        858.796630859375
      ],
      "size": [
        396.1328125,
        68.33333587646484
      ],
      "flags": {},
      "order": 2,
      "mode": 0,
      "inputs": [],
      "outputs": [
        {
          "name": "VAE",
          "type": "VAE",
          "slot_index": 0,
          "links": [
            272,
            277,
            280,
            290
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.5.1",
        "Node name for S&R": "VAELoader",
        "models": [
          {
            "name": "qwen_image_vae.safetensors",
            "url": "https://huggingface.co/Comfy-Org/Qwen-Image_ComfyUI/resolve/main/split_files/vae/qwen_image_vae.safetensors",
            "directory": "vae"
          }
        ],
        "enableTabs": false,
        "tabWidth": 65,
        "tabXOffset": 10,
        "hasSecondTab": false,
        "secondTabText": "Send Back",
        "secondTabOffset": 80,
        "secondTabWidth": 65
      },
      "widgets_values": [
        "qwen_image_vae.safetensors"
      ]
    },
    {
      "id": 128,
      "type": "CLIPLoader",
      "pos": [
        -1849.6236572265625,
        686.7700805664062
      ],
      "size": [
        396.1328125,
        125
      ],
      "flags": {},
      "order": 3,
      "mode": 0,
      "inputs": [],
      "outputs": [
        {
          "label": "CLIP",
          "name": "CLIP",
          "type": "CLIP",
          "links": [
            271,
            276
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.5.1",
        "Node name for S&R": "CLIPLoader",
        "models": [
          {
            "name": "qwen_2.5_vl_7b_fp8_scaled.safetensors",
            "url": "https://huggingface.co/Comfy-Org/HunyuanVideo_1.5_repackaged/resolve/main/split_files/text_encoders/qwen_2.5_vl_7b_fp8_scaled.safetensors",
            "directory": "text_encoders"
          }
        ],
        "enableTabs": false,
        "tabWidth": 65,
        "tabXOffset": 10,
        "hasSecondTab": false,
        "secondTabText": "Send Back",
        "secondTabOffset": 80,
        "secondTabWidth": 65
      },
      "widgets_values": [
        "qwen_2.5_vl_7b_fp8_scaled.safetensors",
        "qwen_image",
        "default"
      ]
    },
    {
      "id": 140,
      "type": "LoraLoaderModelOnly",
      "pos": [
        -1837.1844482421875,
        528.216552734375
      ],
      "size": [
        374.62908935546875,
        96.66666412353516
      ],
      "flags": {},
      "order": 8,
      "mode": 0,
      "inputs": [
        {
          "label": "模型",
          "name": "model",
          "type": "MODEL",
          "link": 294
        }
      ],
      "outputs": [
        {
          "label": "模型",
          "name": "MODEL",
          "type": "MODEL",
          "links": [
            295
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.5.1",
        "Node name for S&R": "LoraLoaderModelOnly",
        "models": [
          {
            "name": "Qwen-Image-Edit-2511-Lightning-4steps-V1.0-bf16.safetensors",
            "url": "https://huggingface.co/lightx2v/Qwen-Image-Edit-2511-Lightning/resolve/main/Qwen-Image-Edit-2511-Lightning-4steps-V1.0-bf16.safetensors",
            "directory": "loras"
          }
        ],
        "enableTabs": false,
        "tabWidth": 65,
        "tabXOffset": 10,
        "hasSecondTab": false,
        "secondTabText": "Send Back",
        "secondTabOffset": 80,
        "secondTabWidth": 65
      },
      "widgets_values": [
        "qwen-image-edit-2511-multiple-angles-lora.safetensors",
        1
      ]
    },
    {
      "id": 124,
      "type": "TextEncodeQwenImageEditPlus",
      "pos": [
        -1383.475341796875,
        553.2937622070312
      ],
      "size": [
        420,
        220
      ],
      "flags": {
        "collapsed": false
      },
      "order": 9,
      "mode": 0,
      "inputs": [
        {
          "label": "clip",
          "name": "clip",
          "type": "CLIP",
          "link": 271
        },
        {
          "label": "vae",
          "name": "vae",
          "shape": 7,
          "type": "VAE",
          "link": 272
        },
        {
          "label": "image1",
          "name": "image1",
          "shape": 7,
          "type": "IMAGE",
          "link": 273
        },
        {
          "label": "image2",
          "name": "image2",
          "shape": 7,
          "type": "IMAGE",
          "link": null
        },
        {
          "label": "image3",
          "name": "image3",
          "shape": 7,
          "type": "IMAGE",
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "CONDITIONING",
          "name": "CONDITIONING",
          "type": "CONDITIONING",
          "links": [
            286
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.5.1",
        "Node name for S&R": "TextEncodeQwenImageEditPlus",
        "enableTabs": false,
        "tabWidth": 65,
        "tabXOffset": 10,
        "hasSecondTab": false,
        "secondTabText": "Send Back",
        "secondTabOffset": 80,
        "secondTabWidth": 65
      },
      "widgets_values": [
        ""
      ],
      "color": "#322",
      "bgcolor": "#533"
    },
    {
      "id": 134,
      "type": "FluxKontextImageScale",
      "pos": [
        -1372.8980712890625,
        823.4761352539062
      ],
      "size": [
        194.94589233398438,
        26
      ],
      "flags": {},
      "order": 6,
      "mode": 0,
      "inputs": [
        {
          "label": "image",
          "name": "image",
          "type": "IMAGE",
          "link": 287
        }
      ],
      "outputs": [
        {
          "label": "IMAGE",
          "name": "IMAGE",
          "type": "IMAGE",
          "links": [
            273,
            278,
            279
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.5.1",
        "Node name for S&R": "FluxKontextImageScale",
        "enableTabs": false,
        "tabWidth": 65,
        "tabXOffset": 10,
        "hasSecondTab": false,
        "secondTabText": "Send Back",
        "secondTabOffset": 80,
        "secondTabWidth": 65
      },
      "widgets_values": []
    },
    {
      "id": 130,
      "type": "VAEEncode",
      "pos": [
        -868.4888916015625,
        718.8446655273438
      ],
      "size": [
        303.0985107421875,
        46
      ],
      "flags": {},
      "order": 10,
      "mode": 0,
      "inputs": [
        {
          "label": "图像",
          "name": "pixels",
          "type": "IMAGE",
          "link": 279
        },
        {
          "label": "VAE",
          "name": "vae",
          "type": "VAE",
          "link": 280
        }
      ],
      "outputs": [
        {
          "label": "Latent",
          "name": "LATENT",
          "type": "LATENT",
          "links": [
            284
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.5.1",
        "Node name for S&R": "VAEEncode",
        "enableTabs": false,
        "tabWidth": 65,
        "tabXOffset": 10,
        "hasSecondTab": false,
        "secondTabText": "Send Back",
        "secondTabOffset": 80,
        "secondTabWidth": 65
      },
      "widgets_values": []
    },
    {
      "id": 141,
      "type": "ShowText|pysssss",
      "pos": [
        -1074.4454345703125,
        -413.5637512207031
      ],
      "size": [
        276.6572265625,
        96.53398895263672
      ],
      "flags": {
        "collapsed": true
      },
      "order": 11,
      "mode": 0,
      "inputs": [
        {
          "name": "text",
          "type": "STRING",
          "link": 296
        }
      ],
      "outputs": [
        {
          "label": "字符串",
          "name": "STRING",
          "shape": 6,
          "type": "STRING",
          "links": null
        }
      ],
      "properties": {
        "Node name for S&R": "ShowText|pysssss",
        "cnr_id": "comfyui-custom-scripts",
        "ver": "f2838ed5e59de4d73cde5c98354b87a8d3200190"
      },
      "widgets_values": [
        "<sks> back view high-angle shot wide shot"
      ]
    },
    {
      "id": 145,
      "type": "ShowText|pysssss",
      "pos": [
        -1071.5316162109375,
        -225.6351318359375
      ],
      "size": [
        306.8334045410156,
        122.41230010986328
      ],
      "flags": {
        "collapsed": true
      },
      "order": 15,
      "mode": 0,
      "inputs": [
        {
          "name": "text",
          "type": "STRING",
          "link": 300
        }
      ],
      "outputs": [
        {
          "label": "字符串",
          "name": "STRING",
          "shape": 6,
          "type": "STRING",
          "links": null
        }
      ],
      "properties": {
        "Node name for S&R": "ShowText|pysssss",
        "cnr_id": "comfyui-custom-scripts",
        "ver": "f2838ed5e59de4d73cde5c98354b87a8d3200190"
      },
      "widgets_values": [
        "<sks> back view high-angle shot wide shot,Girl, look up"
      ]
    },
    {
      "id": 144,
      "type": "StringConcatenate",
      "pos": [
        -1066.518310546875,
        -339.791748046875
      ],
      "size": [
        400,
        200
      ],
      "flags": {
        "collapsed": true
      },
      "order": 12,
      "mode": 0,
      "inputs": [
        {
          "name": "string_a",
          "type": "STRING",
          "widget": {
            "name": "string_a"
          },
          "link": 297
        },
        {
          "name": "string_b",
          "type": "STRING",
          "widget": {
            "name": "string_b"
          },
          "link": 298
        }
      ],
      "outputs": [
        {
          "label": "字符串",
          "name": "STRING",
          "type": "STRING",
          "links": [
            300,
            301
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.9.2",
        "Node name for S&R": "StringConcatenate"
      },
      "widgets_values": [
        "",
        "",
        ","
      ]
    },
    {
      "id": 129,
      "type": "TextEncodeQwenImageEditPlus",
      "pos": [
        -1380.5616455078125,
        239.9062957763672
      ],
      "size": [
        426.6275939941406,
        265.5599060058594
      ],
      "flags": {},
      "order": 16,
      "mode": 0,
      "inputs": [
        {
          "label": "clip",
          "name": "clip",
          "type": "CLIP",
          "link": 276
        },
        {
          "label": "vae",
          "name": "vae",
          "shape": 7,
          "type": "VAE",
          "link": 277
        },
        {
          "label": "image1",
          "name": "image1",
          "shape": 7,
          "type": "IMAGE",
          "link": 278
        },
        {
          "label": "image2",
          "name": "image2",
          "shape": 7,
          "type": "IMAGE",
          "link": null
        },
        {
          "label": "image3",
          "name": "image3",
          "shape": 7,
          "type": "IMAGE",
          "link": null
        },
        {
          "label": "prompt",
          "name": "prompt",
          "type": "STRING",
          "widget": {
            "name": "prompt"
          },
          "link": 301
        }
      ],
      "outputs": [
        {
          "label": "CONDITIONING",
          "name": "CONDITIONING",
          "type": "CONDITIONING",
          "links": [
            285
          ]
        }
      ],
      "title": "TextEncodeQwenImageEditPlus (Positive)",
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.5.1",
        "Node name for S&R": "TextEncodeQwenImageEditPlus",
        "enableTabs": false,
        "tabWidth": 65,
        "tabXOffset": 10,
        "hasSecondTab": false,
        "secondTabText": "Send Back",
        "secondTabOffset": 80,
        "secondTabWidth": 65
      },
      "widgets_values": [
        ""
      ],
      "color": "#232",
      "bgcolor": "#353"
    },
    {
      "id": 125,
      "type": "ModelSamplingAuraFlow",
      "pos": [
        -852.9093627929688,
        250.42568969726562
      ],
      "size": [
        270,
        68.33333587646484
      ],
      "flags": {},
      "order": 13,
      "mode": 0,
      "inputs": [
        {
          "label": "模型",
          "name": "model",
          "type": "MODEL",
          "link": 295
        }
      ],
      "outputs": [
        {
          "label": "模型",
          "name": "MODEL",
          "type": "MODEL",
          "links": [
            270
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.5.1",
        "Node name for S&R": "ModelSamplingAuraFlow",
        "enableTabs": false,
        "tabWidth": 65,
        "tabXOffset": 10,
        "hasSecondTab": false,
        "secondTabText": "Send Back",
        "secondTabOffset": 80,
        "secondTabWidth": 65
      },
      "widgets_values": [
        3.1
      ]
    },
    {
      "id": 109,
      "type": "PreviewImage",
      "pos": [
        -256.1676940917969,
        256.7432556152344
      ],
      "size": [
        544.807861328125,
        642.7154541015625
      ],
      "flags": {},
      "order": 21,
      "mode": 0,
      "inputs": [
        {
          "label": "图像",
          "name": "images",
          "type": "IMAGE",
          "link": 289
        }
      ],
      "outputs": [],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.7.0",
        "Node name for S&R": "PreviewImage"
      },
      "widgets_values": []
    },
    {
      "id": 142,
      "type": "String",
      "pos": [
        -1079.4713134765625,
        -150.7189483642578
      ],
      "size": [
        210,
        221.50376892089844
      ],
      "flags": {},
      "order": 4,
      "mode": 0,
      "inputs": [],
      "outputs": [
        {
          "label": "字符串",
          "name": "STRING",
          "type": "STRING",
          "links": [
            298
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "String",
        "cnr_id": "ComfyLiterals",
        "ver": "bdddb08ca82d90d75d97b1d437a652e0284a32ac"
      },
      "widgets_values": [
        "Girl, look up"
      ],
      "color": "#322",
      "bgcolor": "#533"
    },
    {
      "id": 138,
      "type": "QwenMultiangleCameraNode",
      "pos": [
        -1446.134521484375,
        -448.976806640625
      ],
      "size": [
        350,
        528
      ],
      "flags": {},
      "order": 7,
      "mode": 0,
      "inputs": [
        {
          "label": "image",
          "name": "image",
          "shape": 7,
          "type": "IMAGE",
          "link": 291
        }
      ],
      "outputs": [
        {
          "label": "prompt",
          "name": "prompt",
          "type": "STRING",
          "links": [
            296,
            297
          ]
        }
      ],
      "properties": {
        "aux_id": "jtydhr88/ComfyUI-qwenmultiangle",
        "Node name for S&R": "QwenMultiangleCameraNode",
        "cnr_id": "comfyui-qwenmultiangle",
        "ver": "1488866c3608712c415fcc6c0bf7e9f74b744c70"
      },
      "widgets_values": [
        180,
        60,
        1.2,
        false,
        "",
        ""
      ]
    }
  ],
  "links": [
    [
      270,
      125,
      0,
      123,
      0,
      "MODEL"
    ],
    [
      271,
      128,
      0,
      124,
      0,
      "CLIP"
    ],
    [
      272,
      137,
      0,
      124,
      1,
      "VAE"
    ],
    [
      273,
      134,
      0,
      124,
      2,
      "IMAGE"
    ],
    [
      275,
      126,
      0,
      127,
      0,
      "MODEL"
    ],
    [
      276,
      128,
      0,
      129,
      0,
      "CLIP"
    ],
    [
      277,
      137,
      0,
      129,
      1,
      "VAE"
    ],
    [
      278,
      134,
      0,
      129,
      2,
      "IMAGE"
    ],
    [
      279,
      134,
      0,
      130,
      0,
      "IMAGE"
    ],
    [
      280,
      137,
      0,
      130,
      1,
      "VAE"
    ],
    [
      281,
      123,
      0,
      135,
      0,
      "MODEL"
    ],
    [
      282,
      131,
      0,
      135,
      1,
      "CONDITIONING"
    ],
    [
      283,
      132,
      0,
      135,
      2,
      "CONDITIONING"
    ],
    [
      284,
      130,
      0,
      135,
      3,
      "LATENT"
    ],
    [
      285,
      129,
      0,
      131,
      0,
      "CONDITIONING"
    ],
    [
      286,
      124,
      0,
      132,
      0,
      "CONDITIONING"
    ],
    [
      287,
      41,
      0,
      134,
      0,
      "IMAGE"
    ],
    [
      288,
      135,
      0,
      136,
      0,
      "LATENT"
    ],
    [
      289,
      136,
      0,
      109,
      0,
      "IMAGE"
    ],
    [
      290,
      137,
      0,
      136,
      1,
      "VAE"
    ],
    [
      291,
      41,
      0,
      138,
      0,
      "IMAGE"
    ],
    [
      294,
      127,
      0,
      140,
      0,
      "MODEL"
    ],
    [
      295,
      140,
      0,
      125,
      0,
      "MODEL"
    ],
    [
      296,
      138,
      0,
      141,
      0,
      "STRING"
    ],
    [
      297,
      138,
      0,
      144,
      0,
      "STRING"
    ],
    [
      298,
      142,
      0,
      144,
      1,
      "STRING"
    ],
    [
      300,
      144,
      0,
      145,
      0,
      "STRING"
    ],
    [
      301,
      144,
      0,
      129,
      5,
      "STRING"
    ]
  ],
  "groups": [
    {
      "id": 1,
      "title": "Models",
      "bounding": [
        -1861.234619140625,
        160.84214782714844,
        423.3099365234375,
        781.7508544921875
      ],
      "color": "#3f789e",
      "font_size": 24,
      "flags": {}
    },
    {
      "id": 2,
      "title": "Prompt",
      "bounding": [
        -1410.8585205078125,
        154.22207641601562,
        510,
        780.5263671875
      ],
      "color": "#3f789e",
      "font_size": 24,
      "flags": {}
    },
    {
      "id": 3,
      "title": "角度设置",
      "bounding": [
        -1867.642578125,
        -546.9776000976562,
        1017.2698364257812,
        683.4647216796875
      ],
      "color": "#3f789e",
      "font_size": 24,
      "flags": {}
    },
    {
      "id": 4,
      "title": "Group",
      "bounding": [
        -870.0181884765625,
        163.88560485839844,
        1202.0494384765625,
        755.849365234375
      ],
      "color": "#3f789e",
      "font_size": 24,
      "flags": {}
    }
  ],
  "config": {},
  "extra": {
    "ds": {
      "scale": 0.7247295000000026,
      "offset": [
        2308.1389046439717,
        429.27140599478093
      ]
    },
    "frontendVersion": "1.23.4",
    "workflowRendererVersion": "LG",
    "groupNodes": {},
    "VHS_latentpreview": false,
    "VHS_latentpreviewrate": 0,
    "VHS_MetadataImage": true,
    "VHS_KeepIntermediate": true
  },
  "version": 0.4
}
```
