# 图生视频

- 来源类别：用户工作流
- 镜像内原始路径：`/ComfyUI/user/default/workflows/18个开源模型工作流/视频/图生视频.json`
- 节点数量：40
- 连线数量：60

## 节点类型

- `CLIPTextEncode` × 2
- `GetImageSize` × 2
- `LTXVConcatAVLatent` × 2
- `LTXVImgToVideoInplace` × 2
- `LTXVSeparateAVLatent` × 2
- `CFGGuider` × 1
- `CheckpointLoaderSimple` × 1
- `CreateVideo` × 1
- `DualCLIPLoader` × 1
- `EmptyImage` × 1
- `EmptyLTXVLatentVideo` × 1
- `ImageScaleBy` × 1
- `KSampler` × 1
- `KSamplerSelect` × 1
- `LTXAVTextEncoderLoader` × 1
- `LTXVAudioVAEDecode` × 1
- `LTXVAudioVAELoader` × 1
- `LTXVConditioning` × 1
- `LTXVCropGuides` × 1
- `LTXVEmptyLatentAudio` × 1
- `LTXVLatentUpsampler` × 1
- `LTXVPreprocess` × 1
- `LTXVScheduler` × 1
- `LatentUpscaleModelLoader` × 1
- `LoadImage` × 1
- `LoraLoaderModelOnly` × 1
- `PreviewAny` × 1
- `PrimitiveInt` × 1
- `RandomNoise` × 1
- `ResizeImageMaskNode` × 1
- `ResizeImagesByLongerEdge` × 1
- `SamplerCustomAdvanced` × 1
- `SaveVideo` × 1
- `TextGenerateLTX2Prompt` × 1
- `VAEDecode` × 1

## 工作流引用的模型或媒体文件

- `_connector_dev_bf16.safetensors`
- `caled.safetensors`
- `caler-x2-1.0.safetensors`
- `ltx-2.3-22b-dev.safetensors`
- `tilled-lora-384.safetensors`

## 原始工作流 JSON

```json
{
  "id": "07824bbb-6672-4bb0-ac36-4313a519e35b",
  "revision": 0,
  "last_node_id": 221,
  "last_link_id": 501,
  "nodes": [
    {
      "id": 197,
      "type": "ResizeImagesByLongerEdge",
      "pos": [
        -296.9228515625,
        2997.27783203125
      ],
      "size": [
        344.6499938964844,
        60.50877380371094
      ],
      "flags": {
        "collapsed": false
      },
      "order": 14,
      "mode": 0,
      "inputs": [
        {
          "label": "images",
          "name": "images",
          "type": "IMAGE",
          "link": 466
        },
        {
          "label": "longer_edge",
          "name": "longer_edge",
          "type": "INT",
          "widget": {
            "name": "longer_edge"
          }
        }
      ],
      "outputs": [
        {
          "label": "images",
          "name": "images",
          "type": "IMAGE",
          "links": [
            448
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.5.1",
        "Node name for S&R": "ResizeImagesByLongerEdge",
        "hasSecondTab": false,
        "ue_properties": {
          "widget_ue_connectable": {},
          "input_ue_unconnectable": {},
          "version": "7.5.2"
        },
        "widget_ue_connectable": {},
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": [
        1536
      ]
    },
    {
      "id": 202,
      "type": "PreviewAny",
      "pos": [
        -279.53900146484375,
        2631.098388671875
      ],
      "size": [
        420.21099853515625,
        226.83871459960938
      ],
      "flags": {},
      "order": 18,
      "mode": 0,
      "inputs": [
        {
          "label": "source",
          "name": "source",
          "type": "*",
          "link": 469
        }
      ],
      "outputs": [
        {
          "label": "STRING",
          "name": "STRING",
          "type": "STRING"
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.15.1",
        "Node name for S&R": "PreviewAny",
        "hasSecondTab": false,
        "ue_properties": {
          "widget_ue_connectable": {},
          "input_ue_unconnectable": {},
          "version": "7.5.2"
        },
        "widget_ue_connectable": {},
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": [
        null,
        null,
        null
      ]
    },
    {
      "id": 207,
      "type": "CLIPTextEncode",
      "pos": [
        189.7581787109375,
        2336.055419921875
      ],
      "size": [
        449.0799255371094,
        238.82943725585938
      ],
      "flags": {
        "collapsed": false
      },
      "order": 19,
      "mode": 0,
      "inputs": [
        {
          "label": "clip",
          "name": "clip",
          "type": "CLIP",
          "link": 473
        },
        {
          "label": "text",
          "name": "text",
          "type": "STRING",
          "widget": {
            "name": "text"
          },
          "link": 499
        }
      ],
      "outputs": [
        {
          "label": "CONDITIONING",
          "name": "CONDITIONING",
          "type": "CONDITIONING",
          "links": [
            470
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.56",
        "Node name for S&R": "CLIPTextEncode",
        "hasSecondTab": false,
        "ue_properties": {
          "widget_ue_connectable": {},
          "input_ue_unconnectable": {},
          "version": "7.5.2"
        },
        "widget_ue_connectable": {
          "text": true
        },
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": [
        ""
      ]
    },
    {
      "id": 206,
      "type": "CLIPTextEncode",
      "pos": [
        183.71835327148438,
        2636.215087890625
      ],
      "size": [
        464.25726318359375,
        204.5696563720703
      ],
      "flags": {
        "collapsed": false
      },
      "order": 11,
      "mode": 0,
      "inputs": [
        {
          "label": "clip",
          "name": "clip",
          "type": "CLIP",
          "link": 472
        },
        {
          "label": "text",
          "name": "text",
          "type": "STRING",
          "widget": {
            "name": "text"
          }
        }
      ],
      "outputs": [
        {
          "label": "CONDITIONING",
          "name": "CONDITIONING",
          "type": "CONDITIONING",
          "links": [
            471
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.56",
        "Node name for S&R": "CLIPTextEncode",
        "hasSecondTab": false,
        "ue_properties": {
          "widget_ue_connectable": {},
          "input_ue_unconnectable": {},
          "version": "7.5.2"
        },
        "widget_ue_connectable": {},
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": [
        "blurry, low quality, still frame, frames, watermark, overlay, titles, has blurbox, has subtitles"
      ]
    },
    {
      "id": 204,
      "type": "LTXVConditioning",
      "pos": [
        692.3759155273438,
        2350.986328125
      ],
      "size": [
        376.2465515136719,
        170.14608764648438
      ],
      "flags": {},
      "order": 21,
      "mode": 0,
      "inputs": [
        {
          "label": "positive",
          "name": "positive",
          "type": "CONDITIONING",
          "link": 470
        },
        {
          "label": "negative",
          "name": "negative",
          "type": "CONDITIONING",
          "link": 471
        },
        {
          "label": "frame_rate",
          "name": "frame_rate",
          "type": "FLOAT",
          "widget": {
            "name": "frame_rate"
          }
        }
      ],
      "outputs": [
        {
          "label": "positive",
          "name": "positive",
          "type": "CONDITIONING",
          "links": [
            418,
            461
          ]
        },
        {
          "label": "negative",
          "name": "negative",
          "type": "CONDITIONING",
          "links": [
            419,
            462
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.56",
        "Node name for S&R": "LTXVConditioning",
        "hasSecondTab": false,
        "ue_properties": {
          "widget_ue_connectable": {},
          "input_ue_unconnectable": {},
          "version": "7.5.2"
        },
        "widget_ue_connectable": {},
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": [
        25
      ]
    },
    {
      "id": 195,
      "type": "LatentUpscaleModelLoader",
      "pos": [
        697.180908203125,
        2583.863037109375
      ],
      "size": [
        368.8395690917969,
        62.3160400390625
      ],
      "flags": {},
      "order": 0,
      "mode": 0,
      "inputs": [
        {
          "label": "model_name",
          "name": "model_name",
          "type": "COMBO",
          "widget": {
            "name": "model_name"
          }
        }
      ],
      "outputs": [
        {
          "label": "LATENT_UPSCALE_MODEL",
          "name": "LATENT_UPSCALE_MODEL",
          "type": "LATENT_UPSCALE_MODEL",
          "links": [
            443
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.7.0",
        "Node name for S&R": "LatentUpscaleModelLoader",
        "hasSecondTab": false,
        "models": [
          {
            "directory_invalid": true,
            "name": "ltx-2.3-spatial-upscaler-x2-1.0.safetensors",
            "directory": "latent_upscale_models",
            "url": "https://huggingface.co/Lightricks/LTX-2.3/resolve/main/ltx-2.3-spatial-upscaler-x2-1.0.safetensors"
          }
        ],
        "ue_properties": {
          "widget_ue_connectable": {},
          "input_ue_unconnectable": {},
          "version": "7.5.2"
        },
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "widget_ue_connectable": {},
        "secondTabText": "Send Back",
        "enableTabs": false,
        "tabXOffset": 10
      },
      "widgets_values": [
        "ltx-2.3-spatial-upscaler-x2-1.0.safetensors"
      ]
    },
    {
      "id": 201,
      "type": "RandomNoise",
      "pos": [
        694.2959594726562,
        2713.808837890625
      ],
      "size": [
        376.2465515136719,
        109.32054138183594
      ],
      "flags": {},
      "order": 1,
      "mode": 0,
      "inputs": [
        {
          "label": "noise_seed",
          "name": "noise_seed",
          "type": "INT",
          "widget": {
            "name": "noise_seed"
          }
        }
      ],
      "outputs": [
        {
          "label": "NOISE",
          "name": "NOISE",
          "type": "NOISE",
          "links": [
            426
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.56",
        "Node name for S&R": "RandomNoise",
        "hasSecondTab": false,
        "ue_properties": {
          "widget_ue_connectable": {},
          "input_ue_unconnectable": {},
          "version": "7.5.2"
        },
        "widget_ue_connectable": {},
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": [
        15,
        "fixed"
      ]
    },
    {
      "id": 193,
      "type": "CFGGuider",
      "pos": [
        1100.4251708984375,
        2349.030029296875
      ],
      "size": [
        288.1258850097656,
        236.4352264404297
      ],
      "flags": {},
      "order": 23,
      "mode": 0,
      "inputs": [
        {
          "label": "model",
          "name": "model",
          "type": "MODEL",
          "link": 460
        },
        {
          "label": "positive",
          "name": "positive",
          "type": "CONDITIONING",
          "link": 461
        },
        {
          "label": "negative",
          "name": "negative",
          "type": "CONDITIONING",
          "link": 462
        },
        {
          "label": "cfg",
          "name": "cfg",
          "type": "FLOAT",
          "widget": {
            "name": "cfg"
          }
        }
      ],
      "outputs": [
        {
          "label": "GUIDER",
          "name": "GUIDER",
          "type": "GUIDER",
          "links": [
            427
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.64",
        "Node name for S&R": "CFGGuider",
        "hasSecondTab": false,
        "ue_properties": {
          "widget_ue_connectable": {},
          "input_ue_unconnectable": {},
          "version": "7.5.2"
        },
        "widget_ue_connectable": {},
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": [
        4
      ]
    },
    {
      "id": 168,
      "type": "KSamplerSelect",
      "pos": [
        1107.1046142578125,
        2647.1435546875
      ],
      "size": [
        282.1424560546875,
        164.50209045410156
      ],
      "flags": {},
      "order": 2,
      "mode": 0,
      "inputs": [
        {
          "label": "sampler_name",
          "name": "sampler_name",
          "type": "COMBO",
          "widget": {
            "name": "sampler_name"
          }
        }
      ],
      "outputs": [
        {
          "label": "SAMPLER",
          "name": "SAMPLER",
          "type": "SAMPLER",
          "links": [
            428
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.56",
        "Node name for S&R": "KSamplerSelect",
        "hasSecondTab": false,
        "ue_properties": {
          "widget_ue_connectable": {},
          "input_ue_unconnectable": {},
          "version": "7.5.2"
        },
        "widget_ue_connectable": {},
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": [
        "euler"
      ]
    },
    {
      "id": 181,
      "type": "LTXVAudioVAELoader",
      "pos": [
        -766.1490997874241,
        2992.367976407384
      ],
      "size": [
        431.9773254394531,
        65.93659973144531
      ],
      "flags": {},
      "order": 3,
      "mode": 0,
      "inputs": [
        {
          "label": "ckpt_name",
          "name": "ckpt_name",
          "type": "COMBO",
          "widget": {
            "name": "ckpt_name"
          }
        }
      ],
      "outputs": [
        {
          "label": "Audio VAE",
          "name": "Audio VAE",
          "type": "VAE",
          "links": [
            424,
            439
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.68",
        "Node name for S&R": "LTXVAudioVAELoader",
        "hasSecondTab": false,
        "models": [
          {
            "name": "ltx-2.3-20b-dev.safetensors",
            "directory": "checkpoints",
            "url": "https://huggingface.co/Lightricks/LTX-2.3/resolve/main/ltx-2.3-20b-dev.safetensors"
          }
        ],
        "ue_properties": {
          "widget_ue_connectable": {},
          "input_ue_unconnectable": {},
          "version": "7.5.2"
        },
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "widget_ue_connectable": {},
        "secondTabText": "Send Back",
        "enableTabs": false,
        "tabXOffset": 10
      },
      "widgets_values": [
        "ltx-2.3-22b-dev.safetensors"
      ]
    },
    {
      "id": 184,
      "type": "ImageScaleBy",
      "pos": [
        -296.73138058664324,
        3102.772553015668
      ],
      "size": [
        341.33697509765625,
        82
      ],
      "flags": {},
      "order": 20,
      "mode": 0,
      "inputs": [
        {
          "label": "image",
          "name": "image",
          "type": "IMAGE",
          "link": 445
        },
        {
          "label": "upscale_method",
          "name": "upscale_method",
          "type": "COMBO",
          "widget": {
            "name": "upscale_method"
          }
        },
        {
          "label": "scale_by",
          "name": "scale_by",
          "type": "FLOAT",
          "widget": {
            "name": "scale_by"
          }
        }
      ],
      "outputs": [
        {
          "label": "IMAGE",
          "name": "IMAGE",
          "type": "IMAGE",
          "links": [
            446
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.5.1",
        "Node name for S&R": "ImageScaleBy",
        "hasSecondTab": false,
        "ue_properties": {
          "widget_ue_connectable": {},
          "input_ue_unconnectable": {},
          "version": "7.5.2"
        },
        "widget_ue_connectable": {},
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": [
        "lanczos",
        0.5
      ]
    },
    {
      "id": 196,
      "type": "EmptyImage",
      "pos": [
        -297.40409661225874,
        3231.3901421248493
      ],
      "size": [
        343.98549806521964,
        130.53993761121228
      ],
      "flags": {},
      "order": 16,
      "mode": 0,
      "inputs": [
        {
          "label": "width",
          "name": "width",
          "type": "INT",
          "widget": {
            "name": "width"
          },
          "link": 500
        },
        {
          "label": "height",
          "name": "height",
          "type": "INT",
          "widget": {
            "name": "height"
          },
          "link": 501
        },
        {
          "label": "batch_size",
          "name": "batch_size",
          "type": "INT",
          "widget": {
            "name": "batch_size"
          }
        },
        {
          "label": "color",
          "name": "color",
          "type": "INT",
          "widget": {
            "name": "color"
          }
        }
      ],
      "outputs": [
        {
          "label": "IMAGE",
          "name": "IMAGE",
          "type": "IMAGE",
          "links": [
            445
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.5.1",
        "Node name for S&R": "EmptyImage",
        "hasSecondTab": false,
        "ue_properties": {
          "widget_ue_connectable": {},
          "input_ue_unconnectable": {},
          "version": "7.5.2"
        },
        "widget_ue_connectable": {
          "width": true,
          "height": true
        },
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": [
        1,
        1,
        1,
        0
      ]
    },
    {
      "id": 187,
      "type": "GetImageSize",
      "pos": [
        -495.22020605682917,
        3113.25727507574
      ],
      "size": [
        160.2973023087335,
        124
      ],
      "flags": {},
      "order": 13,
      "mode": 0,
      "inputs": [
        {
          "label": "image",
          "name": "image",
          "type": "IMAGE",
          "link": 447
        }
      ],
      "outputs": [
        {
          "label": "width",
          "name": "width",
          "type": "INT",
          "links": [
            500
          ]
        },
        {
          "label": "height",
          "name": "height",
          "type": "INT",
          "links": [
            501
          ]
        },
        {
          "label": "batch_size",
          "name": "batch_size",
          "type": "INT",
          "links": []
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.7.0",
        "Node name for S&R": "GetImageSize",
        "hasSecondTab": false,
        "ue_properties": {
          "widget_ue_connectable": {},
          "input_ue_unconnectable": {},
          "version": "7.5.2"
        },
        "widget_ue_connectable": {},
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": []
    },
    {
      "id": 189,
      "type": "EmptyLTXVLatentVideo",
      "pos": [
        233.99357975728282,
        2999.418723998898
      ],
      "size": [
        210,
        130
      ],
      "flags": {},
      "order": 24,
      "mode": 0,
      "inputs": [
        {
          "label": "width",
          "name": "width",
          "type": "INT",
          "widget": {
            "name": "width"
          },
          "link": 449
        },
        {
          "label": "height",
          "name": "height",
          "type": "INT",
          "widget": {
            "name": "height"
          },
          "link": 450
        },
        {
          "label": "length",
          "name": "length",
          "type": "INT",
          "widget": {
            "name": "length"
          },
          "link": 451
        },
        {
          "label": "batch_size",
          "name": "batch_size",
          "type": "INT",
          "widget": {
            "name": "batch_size"
          }
        }
      ],
      "outputs": [
        {
          "label": "LATENT",
          "name": "LATENT",
          "type": "LATENT",
          "links": [
            454
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.60",
        "Node name for S&R": "EmptyLTXVLatentVideo",
        "hasSecondTab": false,
        "ue_properties": {
          "widget_ue_connectable": {},
          "input_ue_unconnectable": {},
          "version": "7.5.2"
        },
        "widget_ue_connectable": {
          "width": true,
          "length": true,
          "height": true
        },
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": [
        768,
        512,
        97,
        1
      ]
    },
    {
      "id": 186,
      "type": "GetImageSize",
      "pos": [
        62.76083998016294,
        3000.7503779804024
      ],
      "size": [
        158.66138827433815,
        132.67912429972876
      ],
      "flags": {},
      "order": 22,
      "mode": 0,
      "inputs": [
        {
          "label": "image",
          "name": "image",
          "type": "IMAGE",
          "link": 446
        }
      ],
      "outputs": [
        {
          "label": "width",
          "name": "width",
          "type": "INT",
          "links": [
            449
          ]
        },
        {
          "label": "height",
          "name": "height",
          "type": "INT",
          "links": [
            450
          ]
        },
        {
          "label": "batch_size",
          "name": "batch_size",
          "type": "INT",
          "links": []
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.7.0",
        "Node name for S&R": "GetImageSize",
        "hasSecondTab": false,
        "ue_properties": {
          "widget_ue_connectable": {},
          "input_ue_unconnectable": {},
          "version": "7.5.2"
        },
        "widget_ue_connectable": {},
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": []
    },
    {
      "id": 185,
      "type": "PrimitiveInt",
      "pos": [
        67.14808963629902,
        3184.2067878820462
      ],
      "size": [
        375.0678684684581,
        84.06245098154568
      ],
      "flags": {},
      "order": 4,
      "mode": 0,
      "inputs": [
        {
          "label": "value",
          "name": "value",
          "type": "INT",
          "widget": {
            "name": "value"
          }
        }
      ],
      "outputs": [
        {
          "label": "INT",
          "name": "INT",
          "type": "INT",
          "links": [
            425,
            451
          ]
        }
      ],
      "title": "Length",
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.7.0",
        "Node name for S&R": "PrimitiveInt",
        "hasSecondTab": false,
        "ue_properties": {
          "widget_ue_connectable": {},
          "input_ue_unconnectable": {},
          "version": "7.5.2"
        },
        "widget_ue_connectable": {},
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": [
        241,
        "fixed"
      ]
    },
    {
      "id": 188,
      "type": "LTXVPreprocess",
      "pos": [
        461.9413086120947,
        3001.6667814843568
      ],
      "size": [
        302.07573591844334,
        68.13552688113168
      ],
      "flags": {},
      "order": 17,
      "mode": 0,
      "inputs": [
        {
          "label": "image",
          "name": "image",
          "type": "IMAGE",
          "link": 448
        },
        {
          "label": "img_compression",
          "name": "img_compression",
          "type": "INT",
          "widget": {
            "name": "img_compression"
          }
        }
      ],
      "outputs": [
        {
          "label": "output_image",
          "name": "output_image",
          "type": "IMAGE",
          "links": [
            453,
            458
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.7.0",
        "Node name for S&R": "LTXVPreprocess",
        "hasSecondTab": false,
        "ue_properties": {
          "widget_ue_connectable": {},
          "input_ue_unconnectable": {},
          "version": "7.5.2"
        },
        "widget_ue_connectable": {},
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": [
        33
      ]
    },
    {
      "id": 174,
      "type": "LTXVEmptyLatentAudio",
      "pos": [
        63.23034352968605,
        3312.1901489605434
      ],
      "size": [
        373.66818016504794,
        106
      ],
      "flags": {},
      "order": 9,
      "mode": 0,
      "inputs": [
        {
          "label": "audio_vae",
          "name": "audio_vae",
          "type": "VAE",
          "link": 424
        },
        {
          "label": "frames_number",
          "name": "frames_number",
          "type": "INT",
          "widget": {
            "name": "frames_number"
          },
          "link": 425
        },
        {
          "label": "frame_rate",
          "name": "frame_rate",
          "type": "INT",
          "widget": {
            "name": "frame_rate"
          }
        },
        {
          "label": "batch_size",
          "name": "batch_size",
          "type": "INT",
          "widget": {
            "name": "batch_size"
          }
        }
      ],
      "outputs": [
        {
          "label": "Latent",
          "name": "Latent",
          "type": "LATENT",
          "links": [
            441
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.68",
        "Node name for S&R": "LTXVEmptyLatentAudio",
        "hasSecondTab": false,
        "ue_properties": {
          "widget_ue_connectable": {},
          "input_ue_unconnectable": {},
          "version": "7.5.2"
        },
        "widget_ue_connectable": {
          "frames_number": true
        },
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": [
        97,
        25,
        1
      ]
    },
    {
      "id": 190,
      "type": "LTXVImgToVideoInplace",
      "pos": [
        463.366358831921,
        3116.4481111759033
      ],
      "size": [
        296.6573838002332,
        122
      ],
      "flags": {},
      "order": 25,
      "mode": 0,
      "inputs": [
        {
          "label": "vae",
          "name": "vae",
          "type": "VAE",
          "link": 452
        },
        {
          "label": "image",
          "name": "image",
          "type": "IMAGE",
          "link": 453
        },
        {
          "label": "latent",
          "name": "latent",
          "type": "LATENT",
          "link": 454
        },
        {
          "label": "strength",
          "name": "strength",
          "type": "FLOAT",
          "widget": {
            "name": "strength"
          }
        },
        {
          "label": "bypass",
          "name": "bypass",
          "type": "BOOLEAN",
          "widget": {
            "name": "bypass"
          }
        }
      ],
      "outputs": [
        {
          "label": "latent",
          "name": "latent",
          "type": "LATENT",
          "links": [
            440
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.7.0",
        "Node name for S&R": "LTXVImgToVideoInplace",
        "hasSecondTab": false,
        "ue_properties": {
          "widget_ue_connectable": {},
          "input_ue_unconnectable": {},
          "version": "7.5.2"
        },
        "widget_ue_connectable": {},
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": [
        1,
        false
      ]
    },
    {
      "id": 182,
      "type": "LTXVConcatAVLatent",
      "pos": [
        463.36127646743574,
        3282.8421636714124
      ],
      "size": [
        295.5791821822306,
        46
      ],
      "flags": {},
      "order": 26,
      "mode": 0,
      "inputs": [
        {
          "label": "video_latent",
          "name": "video_latent",
          "type": "LATENT",
          "link": 440
        },
        {
          "label": "audio_latent",
          "name": "audio_latent",
          "type": "LATENT",
          "link": 441
        }
      ],
      "outputs": [
        {
          "label": "latent",
          "name": "latent",
          "type": "LATENT",
          "links": [
            417,
            430
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.7.0",
        "Node name for S&R": "LTXVConcatAVLatent",
        "hasSecondTab": false,
        "ue_properties": {
          "widget_ue_connectable": {},
          "input_ue_unconnectable": {},
          "version": "7.5.2"
        },
        "widget_ue_connectable": {},
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": []
    },
    {
      "id": 169,
      "type": "LTXVScheduler",
      "pos": [
        467.5816933833363,
        3373.329299250768
      ],
      "size": [
        289.11454133098505,
        154
      ],
      "flags": {},
      "order": 27,
      "mode": 0,
      "inputs": [
        {
          "label": "latent",
          "name": "latent",
          "shape": 7,
          "type": "LATENT",
          "link": 417
        },
        {
          "label": "steps",
          "name": "steps",
          "type": "INT",
          "widget": {
            "name": "steps"
          }
        },
        {
          "label": "max_shift",
          "name": "max_shift",
          "type": "FLOAT",
          "widget": {
            "name": "max_shift"
          }
        },
        {
          "label": "base_shift",
          "name": "base_shift",
          "type": "FLOAT",
          "widget": {
            "name": "base_shift"
          }
        },
        {
          "label": "stretch",
          "name": "stretch",
          "type": "BOOLEAN",
          "widget": {
            "name": "stretch"
          }
        },
        {
          "label": "terminal",
          "name": "terminal",
          "type": "FLOAT",
          "widget": {
            "name": "terminal"
          }
        }
      ],
      "outputs": [
        {
          "label": "SIGMAS",
          "name": "SIGMAS",
          "type": "SIGMAS",
          "links": [
            429
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.56",
        "Node name for S&R": "LTXVScheduler",
        "hasSecondTab": false,
        "ue_properties": {
          "widget_ue_connectable": {},
          "input_ue_unconnectable": {},
          "version": "7.5.2"
        },
        "widget_ue_connectable": {},
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": [
        20,
        2.05,
        0.95,
        true,
        0.1
      ]
    },
    {
      "id": 172,
      "type": "LTXVCropGuides",
      "pos": [
        1022.5607232133543,
        3105.6222384990574
      ],
      "size": [
        267.33074951171875,
        66
      ],
      "flags": {},
      "order": 30,
      "mode": 0,
      "inputs": [
        {
          "label": "positive",
          "name": "positive",
          "type": "CONDITIONING",
          "link": 418
        },
        {
          "label": "negative",
          "name": "negative",
          "type": "CONDITIONING",
          "link": 419
        },
        {
          "label": "latent",
          "name": "latent",
          "type": "LATENT",
          "link": 420
        }
      ],
      "outputs": [
        {
          "label": "positive",
          "name": "positive",
          "type": "CONDITIONING",
          "links": [
            486
          ]
        },
        {
          "label": "negative",
          "name": "negative",
          "type": "CONDITIONING",
          "links": [
            487
          ]
        },
        {
          "label": "latent",
          "name": "latent",
          "type": "LATENT",
          "slot_index": 2,
          "links": [
            442
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.68",
        "Node name for S&R": "LTXVCropGuides",
        "hasSecondTab": false,
        "ue_properties": {
          "widget_ue_connectable": {},
          "input_ue_unconnectable": {},
          "version": "7.5.2"
        },
        "widget_ue_connectable": {},
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": []
    },
    {
      "id": 183,
      "type": "LTXVLatentUpsampler",
      "pos": [
        1025.8739022012576,
        3217.3945061363775
      ],
      "size": [
        263.4731750488281,
        95.17268371582031
      ],
      "flags": {},
      "order": 31,
      "mode": 0,
      "inputs": [
        {
          "label": "samples",
          "name": "samples",
          "type": "LATENT",
          "link": 442
        },
        {
          "label": "upscale_model",
          "name": "upscale_model",
          "type": "LATENT_UPSCALE_MODEL",
          "link": 443
        },
        {
          "label": "vae",
          "name": "vae",
          "type": "VAE",
          "link": 444
        }
      ],
      "outputs": [
        {
          "label": "LATENT",
          "name": "LATENT",
          "type": "LATENT",
          "links": [
            459
          ]
        }
      ],
      "title": "spatial",
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.7.0",
        "Node name for S&R": "LTXVLatentUpsampler",
        "hasSecondTab": false,
        "ue_properties": {
          "widget_ue_connectable": {},
          "input_ue_unconnectable": {},
          "version": "7.5.2"
        },
        "widget_ue_connectable": {},
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": []
    },
    {
      "id": 192,
      "type": "LTXVImgToVideoInplace",
      "pos": [
        1015.1207632644347,
        3361.6629213571514
      ],
      "size": [
        270,
        122
      ],
      "flags": {},
      "order": 32,
      "mode": 0,
      "inputs": [
        {
          "label": "vae",
          "name": "vae",
          "type": "VAE",
          "link": 457
        },
        {
          "label": "image",
          "name": "image",
          "type": "IMAGE",
          "link": 458
        },
        {
          "label": "latent",
          "name": "latent",
          "type": "LATENT",
          "link": 459
        },
        {
          "label": "strength",
          "name": "strength",
          "type": "FLOAT",
          "widget": {
            "name": "strength"
          }
        },
        {
          "label": "bypass",
          "name": "bypass",
          "type": "BOOLEAN",
          "widget": {
            "name": "bypass"
          }
        }
      ],
      "outputs": [
        {
          "label": "latent",
          "name": "latent",
          "type": "LATENT",
          "links": [
            455
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.7.0",
        "Node name for S&R": "LTXVImgToVideoInplace",
        "hasSecondTab": false,
        "ue_properties": {
          "widget_ue_connectable": {},
          "input_ue_unconnectable": {},
          "version": "7.5.2"
        },
        "widget_ue_connectable": {},
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": [
        1,
        false
      ]
    },
    {
      "id": 191,
      "type": "LTXVConcatAVLatent",
      "pos": [
        1018.1847724705613,
        3526.9015487296756
      ],
      "size": [
        270,
        110
      ],
      "flags": {},
      "order": 33,
      "mode": 0,
      "inputs": [
        {
          "label": "video_latent",
          "name": "video_latent",
          "type": "LATENT",
          "link": 455
        },
        {
          "label": "audio_latent",
          "name": "audio_latent",
          "type": "LATENT",
          "link": 456
        }
      ],
      "outputs": [
        {
          "label": "latent",
          "name": "latent",
          "type": "LATENT",
          "links": [
            488
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.5.1",
        "Node name for S&R": "LTXVConcatAVLatent",
        "hasSecondTab": false,
        "ue_properties": {
          "widget_ue_connectable": {},
          "input_ue_unconnectable": {},
          "version": "7.5.2"
        },
        "widget_ue_connectable": {},
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": []
    },
    {
      "id": 175,
      "type": "SamplerCustomAdvanced",
      "pos": [
        792.8941002704952,
        3004.4554532739544
      ],
      "size": [
        213.125,
        120
      ],
      "flags": {},
      "order": 28,
      "mode": 0,
      "inputs": [
        {
          "label": "noise",
          "name": "noise",
          "type": "NOISE",
          "link": 426
        },
        {
          "label": "guider",
          "name": "guider",
          "type": "GUIDER",
          "link": 427
        },
        {
          "label": "sampler",
          "name": "sampler",
          "type": "SAMPLER",
          "link": 428
        },
        {
          "label": "sigmas",
          "name": "sigmas",
          "type": "SIGMAS",
          "link": 429
        },
        {
          "label": "latent_image",
          "name": "latent_image",
          "type": "LATENT",
          "link": 430
        }
      ],
      "outputs": [
        {
          "label": "output",
          "name": "output",
          "type": "LATENT",
          "links": [
            431
          ]
        },
        {
          "label": "denoised_output",
          "name": "denoised_output",
          "type": "LATENT",
          "links": []
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.60",
        "Node name for S&R": "SamplerCustomAdvanced",
        "hasSecondTab": false,
        "ue_properties": {
          "widget_ue_connectable": {},
          "input_ue_unconnectable": {},
          "version": "7.5.2"
        },
        "widget_ue_connectable": {},
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": []
    },
    {
      "id": 177,
      "type": "LTXVSeparateAVLatent",
      "pos": [
        1030.0258448490183,
        3011.9356148742186
      ],
      "size": [
        240,
        46
      ],
      "flags": {},
      "order": 29,
      "mode": 0,
      "inputs": [
        {
          "label": "av_latent",
          "name": "av_latent",
          "type": "LATENT",
          "link": 431
        }
      ],
      "outputs": [
        {
          "label": "video_latent",
          "name": "video_latent",
          "type": "LATENT",
          "links": [
            420
          ]
        },
        {
          "label": "audio_latent",
          "name": "audio_latent",
          "type": "LATENT",
          "links": [
            456
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.5.1",
        "Node name for S&R": "LTXVSeparateAVLatent",
        "hasSecondTab": false,
        "ue_properties": {
          "widget_ue_connectable": {},
          "input_ue_unconnectable": {},
          "version": "7.5.2"
        },
        "widget_ue_connectable": {},
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": []
    },
    {
      "id": 214,
      "type": "KSampler",
      "pos": [
        1317.4349824666608,
        3104.003549871563
      ],
      "size": [
        326.04486083984375,
        593.2093505859375
      ],
      "flags": {},
      "order": 34,
      "mode": 0,
      "inputs": [
        {
          "label": "model",
          "name": "model",
          "type": "MODEL",
          "link": 485
        },
        {
          "label": "positive",
          "name": "positive",
          "type": "CONDITIONING",
          "link": 486
        },
        {
          "label": "negative",
          "name": "negative",
          "type": "CONDITIONING",
          "link": 487
        },
        {
          "label": "latent_image",
          "name": "latent_image",
          "type": "LATENT",
          "link": 488
        },
        {
          "label": "seed",
          "name": "seed",
          "type": "INT",
          "widget": {
            "name": "seed"
          }
        },
        {
          "label": "steps",
          "name": "steps",
          "type": "INT",
          "widget": {
            "name": "steps"
          }
        },
        {
          "label": "cfg",
          "name": "cfg",
          "type": "FLOAT",
          "widget": {
            "name": "cfg"
          }
        },
        {
          "label": "sampler_name",
          "name": "sampler_name",
          "type": "COMBO",
          "widget": {
            "name": "sampler_name"
          }
        },
        {
          "label": "scheduler",
          "name": "scheduler",
          "type": "COMBO",
          "widget": {
            "name": "scheduler"
          }
        },
        {
          "label": "denoise",
          "name": "denoise",
          "type": "FLOAT",
          "widget": {
            "name": "denoise"
          }
        }
      ],
      "outputs": [
        {
          "label": "LATENT",
          "name": "LATENT",
          "type": "LATENT",
          "links": [
            489
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.15.1",
        "Node name for S&R": "KSampler",
        "ue_properties": {
          "widget_ue_connectable": {},
          "input_ue_unconnectable": {},
          "version": "7.5.2"
        },
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        1089003954294574,
        "randomize",
        4,
        1,
        "euler",
        "simple",
        0.35
      ]
    },
    {
      "id": 178,
      "type": "LTXVSeparateAVLatent",
      "pos": [
        1679.423417986271,
        3107.5979047928445
      ],
      "size": [
        299.2093200683594,
        63.55540084838867
      ],
      "flags": {},
      "order": 35,
      "mode": 0,
      "inputs": [
        {
          "label": "av_latent",
          "name": "av_latent",
          "type": "LATENT",
          "link": 489
        }
      ],
      "outputs": [
        {
          "label": "video_latent",
          "name": "video_latent",
          "type": "LATENT",
          "links": [
            475
          ]
        },
        {
          "label": "audio_latent",
          "name": "audio_latent",
          "type": "LATENT",
          "links": [
            438
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.5.1",
        "Node name for S&R": "LTXVSeparateAVLatent",
        "hasSecondTab": false,
        "ue_properties": {
          "widget_ue_connectable": {},
          "input_ue_unconnectable": {},
          "version": "7.5.2"
        },
        "widget_ue_connectable": {},
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": []
    },
    {
      "id": 208,
      "type": "VAEDecode",
      "pos": [
        1681.040405708023,
        3215.1276013228135
      ],
      "size": [
        293.5965576171875,
        47.719303131103516
      ],
      "flags": {},
      "order": 36,
      "mode": 0,
      "inputs": [
        {
          "label": "samples",
          "name": "samples",
          "type": "LATENT",
          "link": 475
        },
        {
          "label": "vae",
          "name": "vae",
          "type": "VAE",
          "link": 476
        }
      ],
      "outputs": [
        {
          "label": "IMAGE",
          "name": "IMAGE",
          "type": "IMAGE",
          "links": [
            477
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.75",
        "Node name for S&R": "VAEDecode",
        "hasSecondTab": false,
        "ue_properties": {
          "widget_ue_connectable": {},
          "input_ue_unconnectable": {},
          "version": "7.5.2"
        },
        "widget_ue_connectable": {},
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": []
    },
    {
      "id": 180,
      "type": "LTXVAudioVAEDecode",
      "pos": [
        1682.6873602210846,
        3303.9615517994735
      ],
      "size": [
        289.5957590396597,
        46
      ],
      "flags": {},
      "order": 37,
      "mode": 0,
      "inputs": [
        {
          "label": "samples",
          "name": "samples",
          "type": "LATENT",
          "link": 438
        },
        {
          "label": "audio_vae",
          "name": "audio_vae",
          "type": "VAE",
          "link": 439
        }
      ],
      "outputs": [
        {
          "label": "Audio",
          "name": "Audio",
          "type": "AUDIO",
          "links": [
            478
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.7.0",
        "Node name for S&R": "LTXVAudioVAEDecode",
        "hasSecondTab": false,
        "ue_properties": {
          "widget_ue_connectable": {},
          "input_ue_unconnectable": {},
          "version": "7.5.2"
        },
        "widget_ue_connectable": {},
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": []
    },
    {
      "id": 199,
      "type": "CheckpointLoaderSimple",
      "pos": [
        -756.65216613905,
        2598.0102143175695
      ],
      "size": [
        431.1884110407832,
        98
      ],
      "flags": {},
      "order": 5,
      "mode": 0,
      "inputs": [
        {
          "label": "ckpt_name",
          "name": "ckpt_name",
          "type": "COMBO",
          "widget": {
            "name": "ckpt_name"
          }
        }
      ],
      "outputs": [
        {
          "label": "MODEL",
          "name": "MODEL",
          "type": "MODEL",
          "links": [
            460,
            463
          ]
        },
        {
          "label": "CLIP",
          "name": "CLIP",
          "type": "CLIP",
          "links": []
        },
        {
          "label": "VAE",
          "name": "VAE",
          "type": "VAE",
          "links": [
            444,
            452,
            457,
            476
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.56",
        "Node name for S&R": "CheckpointLoaderSimple",
        "hasSecondTab": false,
        "models": [
          {
            "name": "ltx-2.3-20b-dev.safetensors",
            "directory": "checkpoints",
            "url": "https://huggingface.co/Lightricks/LTX-2.3/resolve/main/ltx-2.3-20b-dev.safetensors"
          }
        ],
        "ue_properties": {
          "widget_ue_connectable": {},
          "input_ue_unconnectable": {},
          "version": "7.5.2"
        },
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "widget_ue_connectable": {},
        "secondTabText": "Send Back",
        "enableTabs": false,
        "tabXOffset": 10
      },
      "widgets_values": [
        "ltx-2.3-22b-dev.safetensors"
      ]
    },
    {
      "id": 194,
      "type": "LoraLoaderModelOnly",
      "pos": [
        -758.2099563177864,
        2760.9965712295193
      ],
      "size": [
        439.44036389242433,
        88.01160048741167
      ],
      "flags": {},
      "order": 10,
      "mode": 0,
      "inputs": [
        {
          "label": "model",
          "name": "model",
          "type": "MODEL",
          "link": 463
        },
        {
          "label": "lora_name",
          "name": "lora_name",
          "type": "COMBO",
          "widget": {
            "name": "lora_name"
          }
        },
        {
          "label": "strength_model",
          "name": "strength_model",
          "type": "FLOAT",
          "widget": {
            "name": "strength_model"
          }
        }
      ],
      "outputs": [
        {
          "label": "MODEL",
          "name": "MODEL",
          "type": "MODEL",
          "links": [
            485
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.75",
        "Node name for S&R": "LoraLoaderModelOnly",
        "hasSecondTab": false,
        "models": [
          {
            "name": "ltx-2.3-20b-distilled-lora-384.safetensors",
            "directory": "loras",
            "url": "https://huggingface.co/Lightricks/LTX-2.3/resolve/main/ltx-2.3-20b-distilled-lora-384.safetensors"
          }
        ],
        "ue_properties": {
          "widget_ue_connectable": {},
          "input_ue_unconnectable": {},
          "version": "7.5.2"
        },
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "widget_ue_connectable": {},
        "secondTabText": "Send Back",
        "enableTabs": false,
        "tabXOffset": 10
      },
      "widgets_values": [
        "ltx-2.3-22b-distilled-lora-384.safetensors",
        0.5
      ]
    },
    {
      "id": 198,
      "type": "LTXAVTextEncoderLoader",
      "pos": [
        -762.597722779675,
        2380.8852143175695
      ],
      "size": [
        435.6371154785156,
        149.64010620117188
      ],
      "flags": {},
      "order": 6,
      "mode": 0,
      "inputs": [
        {
          "label": "text_encoder",
          "name": "text_encoder",
          "type": "COMBO",
          "widget": {
            "name": "text_encoder"
          }
        },
        {
          "label": "ckpt_name",
          "name": "ckpt_name",
          "type": "COMBO",
          "widget": {
            "name": "ckpt_name"
          }
        },
        {
          "label": "device",
          "name": "device",
          "type": "COMBO",
          "widget": {
            "name": "device"
          }
        }
      ],
      "outputs": [
        {
          "label": "CLIP",
          "name": "CLIP",
          "type": "CLIP",
          "links": [
            472,
            473
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.7.0",
        "Node name for S&R": "LTXAVTextEncoderLoader",
        "hasSecondTab": false,
        "models": [
          {
            "name": "ltx-2.3-20b-dev.safetensors",
            "directory": "checkpoints",
            "url": "https://huggingface.co/Lightricks/LTX-2.3/resolve/main/ltx-2.3-20b-dev.safetensors"
          },
          {
            "name": "gemma_3_12B_it_fp4_mixed.safetensors",
            "directory": "text_encoders",
            "url": "https://huggingface.co/Comfy-Org/ltx-2/resolve/main/split_files/text_encoders/gemma_3_12B_it_fp4_mixed.safetensors"
          }
        ],
        "ue_properties": {
          "widget_ue_connectable": {},
          "input_ue_unconnectable": {},
          "version": "7.5.2"
        },
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "widget_ue_connectable": {},
        "secondTabText": "Send Back",
        "enableTabs": false,
        "tabXOffset": 10
      },
      "widgets_values": [
        "gemma_3_12B_it_fp8_scaled.safetensors",
        "ltx-2.3-22b-dev.safetensors",
        "default"
      ]
    },
    {
      "id": 205,
      "type": "DualCLIPLoader",
      "pos": [
        -766.5434975048457,
        2181.2385086860268
      ],
      "size": [
        449.4626159667969,
        131.3118133544922
      ],
      "flags": {},
      "order": 7,
      "mode": 0,
      "inputs": [
        {
          "label": "clip_name1",
          "name": "clip_name1",
          "type": "COMBO",
          "widget": {
            "name": "clip_name1"
          }
        },
        {
          "label": "clip_name2",
          "name": "clip_name2",
          "type": "COMBO",
          "widget": {
            "name": "clip_name2"
          }
        },
        {
          "label": "type",
          "name": "type",
          "type": "COMBO",
          "widget": {
            "name": "type"
          }
        },
        {
          "label": "device",
          "name": "device",
          "shape": 7,
          "type": "COMBO",
          "widget": {
            "name": "device"
          }
        }
      ],
      "outputs": [
        {
          "label": "CLIP",
          "name": "CLIP",
          "type": "CLIP",
          "links": [
            467
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.15.1",
        "Node name for S&R": "DualCLIPLoader",
        "hasSecondTab": false,
        "models": [
          {
            "name": "gemma_3_12B_it_fp4_mixed.safetensors",
            "directory": "text_encoders",
            "url": "https://huggingface.co/Comfy-Org/ltx-2/resolve/main/split_files/text_encoders/gemma_3_12B_it_fp4_mixed.safetensors"
          },
          {
            "name": "ltx-2-19b-embeddings_connector_dev_bf16.safetensors",
            "directory": "text_encoders",
            "url": "https://huggingface.co/Kijai/LTXV2_comfy/resolve/main/text_encoders/ltx-2-19b-embeddings_connector_dev_bf16.safetensors"
          }
        ],
        "ue_properties": {
          "widget_ue_connectable": {},
          "input_ue_unconnectable": {},
          "version": "7.5.2"
        },
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "widget_ue_connectable": {},
        "secondTabText": "Send Back",
        "enableTabs": false,
        "tabXOffset": 10
      },
      "widgets_values": [
        "gemma_3_12B_it_fp8_scaled.safetensors",
        "ltx-2-19b-embeddings_connector_dev_bf16.safetensors",
        "ltxv",
        "default"
      ]
    },
    {
      "id": 209,
      "type": "CreateVideo",
      "pos": [
        1685.752802447043,
        3398.1976220850793
      ],
      "size": [
        278.2788391113281,
        102
      ],
      "flags": {},
      "order": 38,
      "mode": 0,
      "inputs": [
        {
          "label": "images",
          "name": "images",
          "type": "IMAGE",
          "link": 477
        },
        {
          "label": "audio",
          "name": "audio",
          "shape": 7,
          "type": "AUDIO",
          "link": 478
        },
        {
          "label": "fps",
          "name": "fps",
          "type": "FLOAT",
          "widget": {
            "name": "fps"
          }
        },
        {
          "label": "bit_depth",
          "name": "bit_depth",
          "shape": 7,
          "type": "INT",
          "widget": {
            "name": "bit_depth"
          }
        }
      ],
      "outputs": [
        {
          "label": "VIDEO",
          "name": "VIDEO",
          "type": "VIDEO",
          "links": [
            498
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.5.1",
        "Node name for S&R": "CreateVideo",
        "hasSecondTab": false,
        "ue_properties": {
          "widget_ue_connectable": {},
          "input_ue_unconnectable": {},
          "version": "7.5.2"
        },
        "widget_ue_connectable": {},
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": [
        25,
        8
      ]
    },
    {
      "id": 98,
      "type": "LoadImage",
      "pos": [
        -1570,
        2090
      ],
      "size": [
        437.27154541015625,
        628.81884765625
      ],
      "flags": {},
      "order": 8,
      "mode": 0,
      "inputs": [
        {
          "label": "image",
          "name": "image",
          "type": "COMBO",
          "widget": {
            "name": "image"
          }
        },
        {
          "label": "upload",
          "name": "upload",
          "type": "IMAGEUPLOAD",
          "widget": {
            "name": "upload"
          }
        }
      ],
      "outputs": [
        {
          "label": "IMAGE",
          "name": "IMAGE",
          "type": "IMAGE",
          "links": [
            479
          ]
        },
        {
          "label": "MASK",
          "name": "MASK",
          "type": "MASK"
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.5.1",
        "Node name for S&R": "LoadImage",
        "hasSecondTab": false,
        "ue_properties": {
          "widget_ue_connectable": {},
          "input_ue_unconnectable": {},
          "version": "7.5.2"
        },
        "widget_ue_connectable": {},
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": [
        "ComfyUI_temp_pofoj_00040_.png",
        "image"
      ]
    },
    {
      "id": 203,
      "type": "ResizeImageMaskNode",
      "pos": [
        -1097.976879276601,
        2556.0691028677734
      ],
      "size": [
        210,
        154
      ],
      "flags": {},
      "order": 12,
      "mode": 0,
      "inputs": [
        {
          "label": "input",
          "name": "input",
          "type": "IMAGE,MASK",
          "link": 479
        },
        {
          "label": "resize_type",
          "name": "resize_type",
          "type": "COMFY_DYNAMICCOMBO_V3",
          "widget": {
            "name": "resize_type"
          }
        },
        {
          "label": "scale_method",
          "name": "scale_method",
          "type": "COMBO",
          "widget": {
            "name": "scale_method"
          }
        }
      ],
      "outputs": [
        {
          "label": "resized",
          "name": "resized",
          "type": "IMAGE",
          "links": [
            447,
            466,
            468
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.7.0",
        "Node name for S&R": "ResizeImageMaskNode",
        "hasSecondTab": false,
        "ue_properties": {
          "widget_ue_connectable": {},
          "input_ue_unconnectable": {},
          "version": "7.5.2"
        },
        "widget_ue_connectable": {},
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": [
        "scale dimensions",
        0,
        0,
        "center",
        "lanczos"
      ]
    },
    {
      "id": 200,
      "type": "TextGenerateLTX2Prompt",
      "pos": [
        -1100,
        2090
      ],
      "size": [
        223.923828125,
        412
      ],
      "flags": {},
      "order": 15,
      "mode": 0,
      "inputs": [
        {
          "label": "clip",
          "name": "clip",
          "type": "CLIP",
          "link": 467
        },
        {
          "label": "image",
          "name": "image",
          "shape": 7,
          "type": "IMAGE",
          "link": 468
        },
        {
          "label": "video",
          "name": "video",
          "shape": 7,
          "type": "IMAGE"
        },
        {
          "label": "audio",
          "name": "audio",
          "shape": 7,
          "type": "AUDIO"
        },
        {
          "label": "prompt",
          "name": "prompt",
          "type": "STRING",
          "widget": {
            "name": "prompt"
          }
        },
        {
          "label": "max_length",
          "name": "max_length",
          "type": "INT",
          "widget": {
            "name": "max_length"
          }
        },
        {
          "label": "sampling_mode",
          "name": "sampling_mode",
          "type": "COMFY_DYNAMICCOMBO_V3",
          "widget": {
            "name": "sampling_mode"
          }
        },
        {
          "label": "thinking",
          "name": "thinking",
          "shape": 7,
          "type": "BOOLEAN",
          "widget": {
            "name": "thinking"
          }
        },
        {
          "label": "use_default_template",
          "name": "use_default_template",
          "shape": 7,
          "type": "BOOLEAN",
          "widget": {
            "name": "use_default_template"
          }
        }
      ],
      "outputs": [
        {
          "label": "generated_text",
          "name": "generated_text",
          "type": "STRING",
          "links": [
            469,
            499
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.15.1",
        "Node name for S&R": "TextGenerateLTX2Prompt",
        "hasSecondTab": false,
        "ue_properties": {
          "widget_ue_connectable": {},
          "input_ue_unconnectable": {},
          "version": "7.5.2"
        },
        "widget_ue_connectable": {},
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": [
        "画面中的人物打了个招呼然后对着镜头做了个俏皮的比心和飞吻动作 最后走出了画面",
        100,
        "on",
        0.7,
        64,
        0.95,
        0.05,
        1.05,
        3,
        0,
        false,
        true
      ]
    },
    {
      "id": 211,
      "type": "SaveVideo",
      "pos": [
        2078.792293292236,
        2104.9156759599523
      ],
      "size": [
        669.2171630859375,
        1334.758478338068
      ],
      "flags": {
        "collapsed": false
      },
      "order": 39,
      "mode": 0,
      "inputs": [
        {
          "label": "video",
          "name": "video",
          "type": "VIDEO",
          "link": 498
        },
        {
          "label": "filename_prefix",
          "name": "filename_prefix",
          "type": "STRING",
          "widget": {
            "name": "filename_prefix"
          }
        },
        {
          "label": "format",
          "name": "format",
          "type": "COMBO",
          "widget": {
            "name": "format"
          }
        },
        {
          "label": "codec",
          "name": "codec",
          "type": "COMBO",
          "widget": {
            "name": "codec"
          }
        }
      ],
      "outputs": [
        {
          "label": "video_url",
          "name": "video",
          "type": "VIDEO"
        },
        {
          "label": "video",
          "name": "video",
          "type": "VIDEO"
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.5.1",
        "Node name for S&R": "SaveVideo",
        "hasSecondTab": false,
        "ue_properties": {
          "widget_ue_connectable": {},
          "input_ue_unconnectable": {},
          "version": "7.5.2"
        },
        "widget_ue_connectable": {},
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": [
        "video/LTX_2.3_i2v",
        "auto",
        "auto"
      ]
    }
  ],
  "links": [
    [
      417,
      182,
      0,
      169,
      0,
      "LATENT"
    ],
    [
      418,
      204,
      0,
      172,
      0,
      "CONDITIONING"
    ],
    [
      419,
      204,
      1,
      172,
      1,
      "CONDITIONING"
    ],
    [
      420,
      177,
      0,
      172,
      2,
      "LATENT"
    ],
    [
      424,
      181,
      0,
      174,
      0,
      "VAE"
    ],
    [
      425,
      185,
      0,
      174,
      1,
      "INT"
    ],
    [
      426,
      201,
      0,
      175,
      0,
      "NOISE"
    ],
    [
      427,
      193,
      0,
      175,
      1,
      "GUIDER"
    ],
    [
      428,
      168,
      0,
      175,
      2,
      "SAMPLER"
    ],
    [
      429,
      169,
      0,
      175,
      3,
      "SIGMAS"
    ],
    [
      430,
      182,
      0,
      175,
      4,
      "LATENT"
    ],
    [
      431,
      175,
      0,
      177,
      0,
      "LATENT"
    ],
    [
      438,
      178,
      1,
      180,
      0,
      "LATENT"
    ],
    [
      439,
      181,
      0,
      180,
      1,
      "VAE"
    ],
    [
      440,
      190,
      0,
      182,
      0,
      "LATENT"
    ],
    [
      441,
      174,
      0,
      182,
      1,
      "LATENT"
    ],
    [
      442,
      172,
      2,
      183,
      0,
      "LATENT"
    ],
    [
      443,
      195,
      0,
      183,
      1,
      "LATENT_UPSCALE_MODEL"
    ],
    [
      444,
      199,
      2,
      183,
      2,
      "VAE"
    ],
    [
      445,
      196,
      0,
      184,
      0,
      "IMAGE"
    ],
    [
      446,
      184,
      0,
      186,
      0,
      "IMAGE"
    ],
    [
      447,
      203,
      0,
      187,
      0,
      "IMAGE"
    ],
    [
      448,
      197,
      0,
      188,
      0,
      "IMAGE"
    ],
    [
      449,
      186,
      0,
      189,
      0,
      "INT"
    ],
    [
      450,
      186,
      1,
      189,
      1,
      "INT"
    ],
    [
      451,
      185,
      0,
      189,
      2,
      "INT"
    ],
    [
      452,
      199,
      2,
      190,
      0,
      "VAE"
    ],
    [
      453,
      188,
      0,
      190,
      1,
      "IMAGE"
    ],
    [
      454,
      189,
      0,
      190,
      2,
      "LATENT"
    ],
    [
      455,
      192,
      0,
      191,
      0,
      "LATENT"
    ],
    [
      456,
      177,
      1,
      191,
      1,
      "LATENT"
    ],
    [
      457,
      199,
      2,
      192,
      0,
      "VAE"
    ],
    [
      458,
      188,
      0,
      192,
      1,
      "IMAGE"
    ],
    [
      459,
      183,
      0,
      192,
      2,
      "LATENT"
    ],
    [
      460,
      199,
      0,
      193,
      0,
      "MODEL"
    ],
    [
      461,
      204,
      0,
      193,
      1,
      "CONDITIONING"
    ],
    [
      462,
      204,
      1,
      193,
      2,
      "CONDITIONING"
    ],
    [
      463,
      199,
      0,
      194,
      0,
      "MODEL"
    ],
    [
      466,
      203,
      0,
      197,
      0,
      "IMAGE"
    ],
    [
      467,
      205,
      0,
      200,
      0,
      "CLIP"
    ],
    [
      468,
      203,
      0,
      200,
      1,
      "IMAGE"
    ],
    [
      469,
      200,
      0,
      202,
      0,
      "STRING"
    ],
    [
      470,
      207,
      0,
      204,
      0,
      "CONDITIONING"
    ],
    [
      471,
      206,
      0,
      204,
      1,
      "CONDITIONING"
    ],
    [
      472,
      198,
      0,
      206,
      0,
      "CLIP"
    ],
    [
      473,
      198,
      0,
      207,
      0,
      "CLIP"
    ],
    [
      475,
      178,
      0,
      208,
      0,
      "LATENT"
    ],
    [
      476,
      199,
      2,
      208,
      1,
      "VAE"
    ],
    [
      477,
      208,
      0,
      209,
      0,
      "IMAGE"
    ],
    [
      478,
      180,
      0,
      209,
      1,
      "AUDIO"
    ],
    [
      479,
      98,
      0,
      203,
      0,
      "IMAGE"
    ],
    [
      485,
      194,
      0,
      214,
      0,
      "MODEL"
    ],
    [
      486,
      172,
      0,
      214,
      1,
      "CONDITIONING"
    ],
    [
      487,
      172,
      1,
      214,
      2,
      "CONDITIONING"
    ],
    [
      488,
      191,
      0,
      214,
      3,
      "LATENT"
    ],
    [
      489,
      214,
      0,
      178,
      0,
      "LATENT"
    ],
    [
      498,
      209,
      0,
      211,
      0,
      "VIDEO"
    ],
    [
      499,
      200,
      0,
      207,
      1,
      "STRING"
    ],
    [
      500,
      187,
      0,
      196,
      0,
      "INT"
    ],
    [
      501,
      187,
      1,
      196,
      1,
      "INT"
    ]
  ],
  "groups": [
    {
      "id": 1,
      "title": "Group",
      "bounding": [
        -819.9842581118085,
        2028.6154315488052,
        2833.318444825726,
        1723.6842270463985
      ],
      "color": "#3f789e",
      "flags": {}
    }
  ],
  "config": {},
  "extra": {
    "VHS_KeepIntermediate": true,
    "links_added_by_ue": [],
    "comfy_fork_version": "feature/av_inference@a6994ed1",
    "VHS_MetadataImage": true,
    "ue_links": [],
    "0246.VERSION": [
      0,
      0,
      4
    ],
    "workflowRendererVersion": "LG",
    "VHS_latentpreviewrate": 0,
    "frontendVersion": "1.45.20",
    "VHS_latentpreview": false,
    "prompt": {
      "1": {
        "class_type": "CheckpointLoaderSimple",
        "inputs": {
          "ckpt_name": "ltx-av-step-1751000_vocoder_24K.safetensors"
        },
        "_meta": {
          "title": "Load Checkpoint"
        }
      },
      "2": {
        "class_type": "LTXVGemmaCLIPModelLoader",
        "inputs": {
          "ltxv_path": "ltx-av-step-1751000_vocoder_24K.safetensors",
          "gemma_path": "gemma-3-12b-it-qat-q4_0-unquantized_readout_proj/model/model.safetensors",
          "max_length": 1024
        },
        "_meta": {
          "title": "🅛🅣🅧 Gemma 3 Model Loader"
        }
      },
      "3": {
        "class_type": "CLIPTextEncode",
        "inputs": {
          "text": "",
          "clip": [
            "2",
            0
          ]
        },
        "_meta": {
          "title": "CLIP Text Encode (Prompt)"
        }
      },
      "4": {
        "class_type": "CLIPTextEncode",
        "inputs": {
          "text": "blurry, low quality, still frame, frames, watermark, overlay, titles, has blurbox, has subtitles",
          "clip": [
            "2",
            0
          ]
        },
        "_meta": {
          "title": "CLIP Text Encode (Prompt)"
        }
      },
      "8": {
        "class_type": "KSamplerSelect",
        "inputs": {
          "sampler_name": "euler"
        },
        "_meta": {
          "title": "KSamplerSelect"
        }
      },
      "9": {
        "class_type": "LTXVScheduler",
        "inputs": {
          "stretch": true,
          "latent": [
            "28",
            0
          ],
          "max_shift": 2.05,
          "terminal": 0.1,
          "steps": 20,
          "base_shift": 0.95
        },
        "_meta": {
          "title": "LTXVScheduler"
        }
      },
      "11": {
        "class_type": "RandomNoise",
        "inputs": {
          "noise_seed": 10
        },
        "_meta": {
          "title": "RandomNoise"
        }
      },
      "12": {
        "class_type": "VAEDecode",
        "inputs": {
          "vae": [
            "1",
            2
          ],
          "samples": [
            "29",
            0
          ]
        },
        "_meta": {
          "title": "VAE Decode"
        }
      },
      "13": {
        "class_type": "LTXVAudioVAELoader",
        "inputs": {
          "ckpt_name": "ltx-av-step-1751000_vocoder_24K.safetensors"
        },
        "_meta": {
          "title": "🅛🅣🅧 LTXV Audio VAE Loader"
        }
      },
      "14": {
        "class_type": "LTXVAudioVAEDecode",
        "inputs": {
          "audio_vae": [
            "13",
            0
          ],
          "samples": [
            "29",
            1
          ]
        },
        "_meta": {
          "title": "🅛🅣🅧 LTXV Audio VAE Decode"
        }
      },
      "15": {
        "class_type": "VHS_VideoCombine",
        "inputs": {
          "save_output": true,
          "filename_prefix": "AnimateDiff",
          "images": [
            "12",
            0
          ],
          "loop_count": 0,
          "pix_fmt": "yuv420p",
          "save_metadata": true,
          "crf": 19,
          "trim_to_audio": false,
          "format": "video/h264-mp4",
          "audio": [
            "14",
            0
          ],
          "frame_rate": [
            "23",
            0
          ],
          "pingpong": false
        },
        "_meta": {
          "title": "Video Combine 🎥🅥🅗🅢"
        }
      },
      "17": {
        "class_type": "MultimodalGuider",
        "inputs": {
          "skip_blocks": "29",
          "negative": [
            "22",
            1
          ],
          "model": [
            "28",
            1
          ],
          "positive": [
            "22",
            0
          ],
          "parameters": [
            "18",
            0
          ]
        },
        "_meta": {
          "title": "🅛🅣🅧 Multimodal Guider"
        }
      },
      "18": {
        "class_type": "GuiderParameters",
        "inputs": {
          "modality": "VIDEO",
          "cfg": 3,
          "rescale": 0,
          "stg": 0,
          "parameters": [
            "19",
            0
          ],
          "modality_scale": 3
        },
        "_meta": {
          "title": "🅛🅣🅧 Guider Parameters"
        }
      },
      "19": {
        "class_type": "GuiderParameters",
        "inputs": {
          "modality": "AUDIO",
          "cfg": 7,
          "rescale": 0,
          "stg": 0,
          "modality_scale": 3
        },
        "_meta": {
          "title": "🅛🅣🅧 Guider Parameters"
        }
      },
      "21": {
        "class_type": "PreviewAudio",
        "inputs": {
          "audio": [
            "14",
            0
          ],
          "audioUI": ""
        },
        "_meta": {
          "title": "PreviewAudio"
        }
      },
      "22": {
        "class_type": "LTXVConditioning",
        "inputs": {
          "negative": [
            "4",
            0
          ],
          "positive": [
            "3",
            0
          ],
          "frame_rate": [
            "23",
            0
          ]
        },
        "_meta": {
          "title": "LTXVConditioning"
        }
      },
      "23": {
        "class_type": "FloatConstant",
        "inputs": {
          "value": 25
        },
        "_meta": {
          "title": "Float Constant"
        }
      },
      "26": {
        "class_type": "LTXVEmptyLatentAudio",
        "inputs": {
          "batch_size": 1,
          "frame_rate": [
            "42",
            0
          ],
          "frames_number": [
            "27",
            0
          ]
        },
        "_meta": {
          "title": "🅛🅣🅧 LTXV Empty Latent Audio"
        }
      },
      "27": {
        "class_type": "INTConstant",
        "inputs": {
          "value": 105
        },
        "_meta": {
          "title": "INT Constant"
        }
      },
      "28": {
        "class_type": "LTXVConcatAVLatent",
        "inputs": {
          "audio_latent": [
            "26",
            0
          ],
          "video_latent": [
            "43",
            0
          ],
          "model": [
            "44",
            0
          ]
        },
        "_meta": {
          "title": "🅛🅣🅧 LTXV Concat AV Latent"
        }
      },
      "29": {
        "class_type": "LTXVSeparateAVLatent",
        "inputs": {
          "av_latent": [
            "41",
            0
          ],
          "model": [
            "28",
            1
          ]
        },
        "_meta": {
          "title": "🅛🅣🅧 LTXV Separate AV Latent"
        }
      },
      "41": {
        "class_type": "SamplerCustomAdvanced",
        "inputs": {
          "guider": [
            "17",
            0
          ],
          "latent_image": [
            "28",
            0
          ],
          "noise": [
            "11",
            0
          ],
          "sigmas": [
            "9",
            0
          ],
          "sampler": [
            "8",
            0
          ]
        },
        "_meta": {
          "title": "SamplerCustomAdvanced"
        }
      },
      "42": {
        "class_type": "CM_FloatToInt",
        "inputs": {
          "a": [
            "23",
            0
          ]
        },
        "_meta": {
          "title": "FloatToInt"
        }
      },
      "43": {
        "class_type": "EmptyLTXVLatentVideo",
        "inputs": {
          "batch_size": 1,
          "width": 768,
          "length": [
            "27",
            0
          ],
          "height": 512
        },
        "_meta": {
          "title": "EmptyLTXVLatentVideo"
        }
      },
      "44": {
        "class_type": "LTXVSequenceParallelMultiGPUPatcher",
        "inputs": {
          "disable_backup": false,
          "torch_compile": true,
          "model": [
            "1",
            0
          ]
        },
        "_meta": {
          "title": "LTXVSequenceParallelMultiGPUPatcher"
        }
      },
      "45": {
        "class_type": "LTXVAddGuide",
        "inputs": {
          "strength": 1,
          "frame_idx": 0
        },
        "_meta": {
          "title": "LTXVAddGuide"
        }
      }
    },
    "ds": {
      "scale": 0.4500000000000029,
      "offset": [
        1978.0876253495505,
        -1350.4521087015141
      ]
    }
  },
  "version": 0.4
}
```
