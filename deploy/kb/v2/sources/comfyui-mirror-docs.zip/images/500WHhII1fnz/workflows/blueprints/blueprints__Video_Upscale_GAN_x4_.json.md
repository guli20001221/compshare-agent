# Video Upscale(GAN x4)

- 来源类别：内置工作流蓝图
- 镜像内原始路径：`/ComfyUI/blueprints/Video Upscale(GAN x4).json`
- 节点数量：1
- 连线数量：0

## 节点类型

- `cf95b747-3e17-46cb-8097-cac60ff9b2e1` × 1

## 原始工作流 JSON

```json
{
  "revision": 0,
  "last_node_id": 13,
  "last_link_id": 0,
  "nodes": [
    {
      "id": 13,
      "type": "cf95b747-3e17-46cb-8097-cac60ff9b2e1",
      "pos": [
        1120,
        330
      ],
      "size": [
        240,
        58
      ],
      "flags": {},
      "order": 3,
      "mode": 0,
      "inputs": [
        {
          "localized_name": "video",
          "name": "video",
          "type": "VIDEO",
          "link": null
        },
        {
          "name": "model_name",
          "type": "COMBO",
          "widget": {
            "name": "model_name"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "localized_name": "VIDEO",
          "name": "VIDEO",
          "type": "VIDEO",
          "links": []
        }
      ],
      "title": "Video Upscale(GAN x4)",
      "properties": {
        "proxyWidgets": [
          [
            "-1",
            "model_name"
          ]
        ],
        "cnr_id": "comfy-core",
        "ver": "0.14.1"
      },
      "widgets_values": [
        "RealESRGAN_x4plus.safetensors"
      ]
    }
  ],
  "links": [],
  "version": 0.4,
  "definitions": {
    "subgraphs": [
      {
        "id": "cf95b747-3e17-46cb-8097-cac60ff9b2e1",
        "version": 1,
        "state": {
          "lastGroupId": 0,
          "lastNodeId": 13,
          "lastLinkId": 19,
          "lastRerouteId": 0
        },
        "revision": 0,
        "config": {},
        "name": "Video Upscale(GAN x4)",
        "inputNode": {
          "id": -10,
          "bounding": [
            550,
            460,
            120,
            80
          ]
        },
        "outputNode": {
          "id": -20,
          "bounding": [
            1490,
            460,
            120,
            60
          ]
        },
        "inputs": [
          {
            "id": "666d633e-93e7-42dc-8d11-2b7b99b0f2a6",
            "name": "video",
            "type": "VIDEO",
            "linkIds": [
              10
            ],
            "localized_name": "video",
            "pos": [
              650,
              480
            ]
          },
          {
            "id": "2e23a087-caa8-4d65-99e6-662761aa905a",
            "name": "model_name",
            "type": "COMBO",
            "linkIds": [
              19
            ],
            "pos": [
              650,
              500
            ]
          }
        ],
        "outputs": [
          {
            "id": "0c1768ea-3ec2-412f-9af6-8e0fa36dae70",
            "name": "VIDEO",
            "type": "VIDEO",
            "linkIds": [
              15
            ],
            "localized_name": "VIDEO",
            "pos": [
              1510,
              480
            ]
          }
        ],
        "widgets": [],
        "nodes": [
          {
            "id": 2,
            "type": "ImageUpscaleWithModel",
            "pos": [
              1110,
              450
            ],
            "size": [
              320,
              46
            ],
            "flags": {},
            "order": 1,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "upscale_model",
                "name": "upscale_model",
                "type": "UPSCALE_MODEL",
                "link": 1
              },
              {
                "localized_name": "image",
                "name": "image",
                "type": "IMAGE",
                "link": 14
              }
            ],
            "outputs": [
              {
                "localized_name": "IMAGE",
                "name": "IMAGE",
                "type": "IMAGE",
                "links": [
                  13
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.10.0",
              "Node name for S&R": "ImageUpscaleWithModel"
            }
          },
          {
            "id": 11,
            "type": "CreateVideo",
            "pos": [
              1110,
              550
            ],
            "size": [
              320,
              78
            ],
            "flags": {},
            "order": 3,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "images",
                "name": "images",
                "type": "IMAGE",
                "link": 13
              },
              {
                "localized_name": "audio",
                "name": "audio",
                "shape": 7,
                "type": "AUDIO",
                "link": 16
              },
              {
                "localized_name": "fps",
                "name": "fps",
                "type": "FLOAT",
                "widget": {
                  "name": "fps"
                },
                "link": 12
              }
            ],
            "outputs": [
              {
                "localized_name": "VIDEO",
                "name": "VIDEO",
                "type": "VIDEO",
                "links": [
                  15
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.10.0",
              "Node name for S&R": "CreateVideo"
            },
            "widgets_values": [
              30
            ]
          },
          {
            "id": 10,
            "type": "GetVideoComponents",
            "pos": [
              1110,
              330
            ],
            "size": [
              320,
              70
            ],
            "flags": {},
            "order": 2,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "video",
                "name": "video",
                "type": "VIDEO",
                "link": 10
              }
            ],
            "outputs": [
              {
                "localized_name": "images",
                "name": "images",
                "type": "IMAGE",
                "links": [
                  14
                ]
              },
              {
                "localized_name": "audio",
                "name": "audio",
                "type": "AUDIO",
                "links": [
                  16
                ]
              },
              {
                "localized_name": "fps",
                "name": "fps",
                "type": "FLOAT",
                "links": [
                  12
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.10.0",
              "Node name for S&R": "GetVideoComponents"
            }
          },
          {
            "id": 1,
            "type": "UpscaleModelLoader",
            "pos": [
              750,
              450
            ],
            "size": [
              280,
              60
            ],
            "flags": {},
            "order": 0,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "model_name",
                "name": "model_name",
                "type": "COMBO",
                "widget": {
                  "name": "model_name"
                },
                "link": 19
              }
            ],
            "outputs": [
              {
                "localized_name": "UPSCALE_MODEL",
                "name": "UPSCALE_MODEL",
                "type": "UPSCALE_MODEL",
                "links": [
                  1
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.10.0",
              "Node name for S&R": "UpscaleModelLoader",
              "models": [
                {
                  "name": "RealESRGAN_x4plus.safetensors",
                  "url": "https://huggingface.co/Comfy-Org/Real-ESRGAN_repackaged/resolve/main/RealESRGAN_x4plus.safetensors",
                  "directory": "upscale_models"
                }
              ]
            },
            "widgets_values": [
              "RealESRGAN_x4plus.safetensors"
            ]
          }
        ],
        "groups": [],
        "links": [
          {
            "id": 1,
            "origin_id": 1,
            "origin_slot": 0,
            "target_id": 2,
            "target_slot": 0,
            "type": "UPSCALE_MODEL"
          },
          {
            "id": 14,
            "origin_id": 10,
            "origin_slot": 0,
            "target_id": 2,
            "target_slot": 1,
            "type": "IMAGE"
          },
          {
            "id": 13,
            "origin_id": 2,
            "origin_slot": 0,
            "target_id": 11,
            "target_slot": 0,
            "type": "IMAGE"
          },
          {
            "id": 16,
            "origin_id": 10,
            "origin_slot": 1,
            "target_id": 11,
            "target_slot": 1,
            "type": "AUDIO"
          },
          {
            "id": 12,
            "origin_id": 10,
            "origin_slot": 2,
            "target_id": 11,
            "target_slot": 2,
            "type": "FLOAT"
          },
          {
            "id": 10,
            "origin_id": -10,
            "origin_slot": 0,
            "target_id": 10,
            "target_slot": 0,
            "type": "VIDEO"
          },
          {
            "id": 15,
            "origin_id": 11,
            "origin_slot": 0,
            "target_id": -20,
            "target_slot": 0,
            "type": "VIDEO"
          },
          {
            "id": 19,
            "origin_id": -10,
            "origin_slot": 1,
            "target_id": 1,
            "target_slot": 0,
            "type": "COMBO"
          }
        ],
        "extra": {
          "workflowRendererVersion": "LG"
        },
        "category": "Video generation and editing/Upscale",
        "description": "Upscales video to 4× resolution using a GAN-based upscaling model."
      }
    ]
  },
  "extra": {}
}
```
