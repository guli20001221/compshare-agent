# Text to Image (Z-Image-Turbo)

- 来源类别：内置工作流蓝图
- 镜像内原始路径：`/ComfyUI/blueprints/Text to Image (Z-Image-Turbo).json`
- 节点数量：1
- 连线数量：0

## 节点类型

- `f2fdebf6-dfaf-43b6-9eb2-7f70613cfdc1` × 1

## 原始工作流 JSON

```json
{
  "revision": 0,
  "last_node_id": 57,
  "last_link_id": 0,
  "nodes": [
    {
      "id": 57,
      "type": "f2fdebf6-dfaf-43b6-9eb2-7f70613cfdc1",
      "pos": [
        130,
        200
      ],
      "size": [
        400,
        470
      ],
      "flags": {},
      "order": 1,
      "mode": 0,
      "inputs": [
        {
          "label": "prompt",
          "name": "text",
          "type": "STRING",
          "widget": {
            "name": "text"
          },
          "link": null
        },
        {
          "name": "width",
          "type": "INT",
          "widget": {
            "name": "width"
          },
          "link": null
        },
        {
          "name": "height",
          "type": "INT",
          "widget": {
            "name": "height"
          },
          "link": null
        },
        {
          "name": "seed",
          "type": "INT",
          "widget": {
            "name": "seed"
          },
          "link": null
        },
        {
          "name": "steps",
          "type": "INT",
          "widget": {
            "name": "steps"
          },
          "link": null
        },
        {
          "name": "unet_name",
          "type": "COMBO",
          "widget": {
            "name": "unet_name"
          },
          "link": null
        },
        {
          "name": "clip_name",
          "type": "COMBO",
          "widget": {
            "name": "clip_name"
          },
          "link": null
        },
        {
          "name": "vae_name",
          "type": "COMBO",
          "widget": {
            "name": "vae_name"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "localized_name": "IMAGE",
          "name": "IMAGE",
          "type": "IMAGE",
          "links": []
        }
      ],
      "properties": {
        "proxyWidgets": [
          [
            "27",
            "text"
          ],
          [
            "13",
            "width"
          ],
          [
            "13",
            "height"
          ],
          [
            "3",
            "seed"
          ],
          [
            "3",
            "steps"
          ],
          [
            "28",
            "unet_name"
          ],
          [
            "30",
            "clip_name"
          ],
          [
            "29",
            "vae_name"
          ],
          [
            "3",
            "control_after_generate"
          ]
        ],
        "cnr_id": "comfy-core",
        "ver": "0.3.73",
        "enableTabs": false,
        "tabWidth": 65,
        "tabXOffset": 10,
        "hasSecondTab": false,
        "secondTabText": "Send Back",
        "secondTabOffset": 80,
        "secondTabWidth": 65
      },
      "widgets_values": [],
      "title": "Text to Image (Z-Image-Turbo)"
    }
  ],
  "links": [],
  "version": 0.4,
  "definitions": {
    "subgraphs": [
      {
        "id": "f2fdebf6-dfaf-43b6-9eb2-7f70613cfdc1",
        "version": 1,
        "state": {
          "lastGroupId": 4,
          "lastNodeId": 61,
          "lastLinkId": 75,
          "lastRerouteId": 0
        },
        "revision": 0,
        "config": {},
        "name": "Text to Image (Z-Image-Turbo)",
        "inputNode": {
          "id": -10,
          "bounding": [
            -560,
            480,
            120,
            200
          ]
        },
        "outputNode": {
          "id": -20,
          "bounding": [
            1670,
            320,
            120,
            60
          ]
        },
        "inputs": [
          {
            "id": "fb178669-e742-4a53-8a69-7df59834dfd8",
            "name": "text",
            "type": "STRING",
            "linkIds": [
              34
            ],
            "label": "prompt",
            "pos": [
              -460,
              500
            ]
          },
          {
            "id": "dd780b3c-23e9-46ff-8469-156008f42e5a",
            "name": "width",
            "type": "INT",
            "linkIds": [
              35
            ],
            "pos": [
              -460,
              520
            ]
          },
          {
            "id": "7b08d546-6bb0-4ef9-82e9-ffae5e1ee6bc",
            "name": "height",
            "type": "INT",
            "linkIds": [
              36
            ],
            "pos": [
              -460,
              540
            ]
          },
          {
            "id": "f77677f7-6bf6-4c19-a71f-c4a553d5981e",
            "name": "seed",
            "type": "INT",
            "linkIds": [
              71
            ],
            "pos": [
              -460,
              560
            ]
          },
          {
            "id": "ef9a9fb1-5983-4bc9-a60b-cf5aec48bff1",
            "name": "steps",
            "type": "INT",
            "linkIds": [
              72
            ],
            "pos": [
              -460,
              580
            ]
          },
          {
            "id": "a20a1b30-785f-4a04-bb6d-3d61adab9764",
            "name": "unet_name",
            "type": "COMBO",
            "linkIds": [
              73
            ],
            "pos": [
              -460,
              600
            ]
          },
          {
            "id": "4af8fc2b-4655-4086-8240-45f8cb38c6f6",
            "name": "clip_name",
            "type": "COMBO",
            "linkIds": [
              74
            ],
            "pos": [
              -460,
              620
            ]
          },
          {
            "id": "4d518693-2807-439c-9cb6-cffd23ccba2c",
            "name": "vae_name",
            "type": "COMBO",
            "linkIds": [
              75
            ],
            "pos": [
              -460,
              640
            ]
          }
        ],
        "outputs": [
          {
            "id": "1fa72a21-ce00-4952-814e-1f2ffbe87d1d",
            "name": "IMAGE",
            "type": "IMAGE",
            "linkIds": [
              16
            ],
            "localized_name": "IMAGE",
            "pos": [
              1690,
              340
            ]
          }
        ],
        "widgets": [],
        "nodes": [
          {
            "id": 30,
            "type": "CLIPLoader",
            "pos": [
              30,
              420
            ],
            "size": [
              270,
              150
            ],
            "flags": {},
            "order": 7,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "clip_name",
                "name": "clip_name",
                "type": "COMBO",
                "widget": {
                  "name": "clip_name"
                },
                "link": 74
              },
              {
                "localized_name": "type",
                "name": "type",
                "type": "COMBO",
                "widget": {
                  "name": "type"
                },
                "link": null
              },
              {
                "localized_name": "device",
                "name": "device",
                "shape": 7,
                "type": "COMBO",
                "widget": {
                  "name": "device"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "CLIP",
                "name": "CLIP",
                "type": "CLIP",
                "links": [
                  28
                ]
              }
            ],
            "properties": {
              "Node name for S&R": "CLIPLoader",
              "cnr_id": "comfy-core",
              "ver": "0.3.73",
              "models": [
                {
                  "name": "qwen_3_4b.safetensors",
                  "url": "https://huggingface.co/Comfy-Org/z_image_turbo/resolve/main/split_files/text_encoders/qwen_3_4b.safetensors",
                  "directory": "text_encoders"
                }
              ],
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            },
            "widgets_values": [
              "qwen_3_4b.safetensors",
              "lumina2",
              "default"
            ]
          },
          {
            "id": 29,
            "type": "VAELoader",
            "pos": [
              30,
              650
            ],
            "size": [
              270,
              110
            ],
            "flags": {},
            "order": 6,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "vae_name",
                "name": "vae_name",
                "type": "COMBO",
                "widget": {
                  "name": "vae_name"
                },
                "link": 75
              }
            ],
            "outputs": [
              {
                "localized_name": "VAE",
                "name": "VAE",
                "type": "VAE",
                "links": [
                  27
                ]
              }
            ],
            "properties": {
              "Node name for S&R": "VAELoader",
              "cnr_id": "comfy-core",
              "ver": "0.3.73",
              "models": [
                {
                  "name": "ae.safetensors",
                  "url": "https://huggingface.co/Comfy-Org/z_image_turbo/resolve/main/split_files/vae/ae.safetensors",
                  "directory": "vae"
                }
              ],
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            },
            "widgets_values": [
              "ae.safetensors"
            ]
          },
          {
            "id": 33,
            "type": "ConditioningZeroOut",
            "pos": [
              630,
              960
            ],
            "size": [
              230,
              80
            ],
            "flags": {},
            "order": 8,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "conditioning",
                "name": "conditioning",
                "type": "CONDITIONING",
                "link": 32
              }
            ],
            "outputs": [
              {
                "localized_name": "CONDITIONING",
                "name": "CONDITIONING",
                "type": "CONDITIONING",
                "links": [
                  33
                ]
              }
            ],
            "properties": {
              "Node name for S&R": "ConditioningZeroOut",
              "cnr_id": "comfy-core",
              "ver": "0.3.73",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            }
          },
          {
            "id": 8,
            "type": "VAEDecode",
            "pos": [
              1320,
              230
            ],
            "size": [
              230,
              100
            ],
            "flags": {},
            "order": 1,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "samples",
                "name": "samples",
                "type": "LATENT",
                "link": 14
              },
              {
                "localized_name": "vae",
                "name": "vae",
                "type": "VAE",
                "link": 27
              }
            ],
            "outputs": [
              {
                "localized_name": "IMAGE",
                "name": "IMAGE",
                "type": "IMAGE",
                "slot_index": 0,
                "links": [
                  16
                ]
              }
            ],
            "properties": {
              "Node name for S&R": "VAEDecode",
              "cnr_id": "comfy-core",
              "ver": "0.3.64",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            }
          },
          {
            "id": 28,
            "type": "UNETLoader",
            "pos": [
              30,
              230
            ],
            "size": [
              270,
              110
            ],
            "flags": {},
            "order": 5,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "unet_name",
                "name": "unet_name",
                "type": "COMBO",
                "widget": {
                  "name": "unet_name"
                },
                "link": 73
              },
              {
                "localized_name": "weight_dtype",
                "name": "weight_dtype",
                "type": "COMBO",
                "widget": {
                  "name": "weight_dtype"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "MODEL",
                "name": "MODEL",
                "type": "MODEL",
                "links": [
                  26
                ]
              }
            ],
            "properties": {
              "Node name for S&R": "UNETLoader",
              "cnr_id": "comfy-core",
              "ver": "0.3.73",
              "models": [
                {
                  "name": "z_image_turbo_bf16.safetensors",
                  "url": "https://huggingface.co/Comfy-Org/z_image_turbo/resolve/main/split_files/diffusion_models/z_image_turbo_bf16.safetensors",
                  "directory": "diffusion_models"
                }
              ],
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            },
            "widgets_values": [
              "z_image_turbo_bf16.safetensors",
              "default"
            ]
          },
          {
            "id": 27,
            "type": "CLIPTextEncode",
            "pos": [
              400,
              230
            ],
            "size": [
              450,
              650
            ],
            "flags": {},
            "order": 4,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "clip",
                "name": "clip",
                "type": "CLIP",
                "link": 28
              },
              {
                "localized_name": "text",
                "name": "text",
                "type": "STRING",
                "widget": {
                  "name": "text"
                },
                "link": 34
              }
            ],
            "outputs": [
              {
                "localized_name": "CONDITIONING",
                "name": "CONDITIONING",
                "type": "CONDITIONING",
                "links": [
                  30,
                  32
                ]
              }
            ],
            "properties": {
              "Node name for S&R": "CLIPTextEncode",
              "cnr_id": "comfy-core",
              "ver": "0.3.73",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            },
            "widgets_values": [
              ""
            ]
          },
          {
            "id": 13,
            "type": "EmptySD3LatentImage",
            "pos": [
              40,
              890
            ],
            "size": [
              260,
              170
            ],
            "flags": {},
            "order": 3,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "width",
                "name": "width",
                "type": "INT",
                "widget": {
                  "name": "width"
                },
                "link": 35
              },
              {
                "localized_name": "height",
                "name": "height",
                "type": "INT",
                "widget": {
                  "name": "height"
                },
                "link": 36
              },
              {
                "localized_name": "batch_size",
                "name": "batch_size",
                "type": "INT",
                "widget": {
                  "name": "batch_size"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "LATENT",
                "name": "LATENT",
                "type": "LATENT",
                "slot_index": 0,
                "links": [
                  17
                ]
              }
            ],
            "properties": {
              "Node name for S&R": "EmptySD3LatentImage",
              "cnr_id": "comfy-core",
              "ver": "0.3.64",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            },
            "widgets_values": [
              1024,
              1024,
              1
            ]
          },
          {
            "id": 11,
            "type": "ModelSamplingAuraFlow",
            "pos": [
              950,
              230
            ],
            "size": [
              310,
              110
            ],
            "flags": {},
            "order": 2,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "model",
                "name": "model",
                "type": "MODEL",
                "link": 26
              },
              {
                "localized_name": "shift",
                "name": "shift",
                "type": "FLOAT",
                "widget": {
                  "name": "shift"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "MODEL",
                "name": "MODEL",
                "type": "MODEL",
                "slot_index": 0,
                "links": [
                  13
                ]
              }
            ],
            "properties": {
              "Node name for S&R": "ModelSamplingAuraFlow",
              "cnr_id": "comfy-core",
              "ver": "0.3.64",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            },
            "widgets_values": [
              3
            ]
          },
          {
            "id": 3,
            "type": "KSampler",
            "pos": [
              950,
              400
            ],
            "size": [
              320,
              350
            ],
            "flags": {},
            "order": 0,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "model",
                "name": "model",
                "type": "MODEL",
                "link": 13
              },
              {
                "localized_name": "positive",
                "name": "positive",
                "type": "CONDITIONING",
                "link": 30
              },
              {
                "localized_name": "negative",
                "name": "negative",
                "type": "CONDITIONING",
                "link": 33
              },
              {
                "localized_name": "latent_image",
                "name": "latent_image",
                "type": "LATENT",
                "link": 17
              },
              {
                "localized_name": "seed",
                "name": "seed",
                "type": "INT",
                "widget": {
                  "name": "seed"
                },
                "link": 71
              },
              {
                "localized_name": "steps",
                "name": "steps",
                "type": "INT",
                "widget": {
                  "name": "steps"
                },
                "link": 72
              },
              {
                "localized_name": "cfg",
                "name": "cfg",
                "type": "FLOAT",
                "widget": {
                  "name": "cfg"
                },
                "link": null
              },
              {
                "localized_name": "sampler_name",
                "name": "sampler_name",
                "type": "COMBO",
                "widget": {
                  "name": "sampler_name"
                },
                "link": null
              },
              {
                "localized_name": "scheduler",
                "name": "scheduler",
                "type": "COMBO",
                "widget": {
                  "name": "scheduler"
                },
                "link": null
              },
              {
                "localized_name": "denoise",
                "name": "denoise",
                "type": "FLOAT",
                "widget": {
                  "name": "denoise"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "LATENT",
                "name": "LATENT",
                "type": "LATENT",
                "slot_index": 0,
                "links": [
                  14
                ]
              }
            ],
            "properties": {
              "Node name for S&R": "KSampler",
              "cnr_id": "comfy-core",
              "ver": "0.3.64",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            },
            "widgets_values": [
              0,
              "randomize",
              8,
              1,
              "res_multistep",
              "simple",
              1
            ]
          }
        ],
        "groups": [
          {
            "id": 2,
            "title": "Step2 - Image size",
            "bounding": [
              10,
              820,
              320,
              280
            ],
            "color": "#3f789e",
            "font_size": 24,
            "flags": {}
          },
          {
            "id": 3,
            "title": "Step3 - Prompt",
            "bounding": [
              360,
              130,
              530,
              970
            ],
            "color": "#3f789e",
            "font_size": 24,
            "flags": {}
          },
          {
            "id": 4,
            "title": "Step1 - Load models",
            "bounding": [
              0,
              130,
              330,
              660
            ],
            "color": "#3f789e",
            "font_size": 24,
            "flags": {}
          }
        ],
        "links": [
          {
            "id": 32,
            "origin_id": 27,
            "origin_slot": 0,
            "target_id": 33,
            "target_slot": 0,
            "type": "CONDITIONING"
          },
          {
            "id": 26,
            "origin_id": 28,
            "origin_slot": 0,
            "target_id": 11,
            "target_slot": 0,
            "type": "MODEL"
          },
          {
            "id": 14,
            "origin_id": 3,
            "origin_slot": 0,
            "target_id": 8,
            "target_slot": 0,
            "type": "LATENT"
          },
          {
            "id": 27,
            "origin_id": 29,
            "origin_slot": 0,
            "target_id": 8,
            "target_slot": 1,
            "type": "VAE"
          },
          {
            "id": 13,
            "origin_id": 11,
            "origin_slot": 0,
            "target_id": 3,
            "target_slot": 0,
            "type": "MODEL"
          },
          {
            "id": 30,
            "origin_id": 27,
            "origin_slot": 0,
            "target_id": 3,
            "target_slot": 1,
            "type": "CONDITIONING"
          },
          {
            "id": 33,
            "origin_id": 33,
            "origin_slot": 0,
            "target_id": 3,
            "target_slot": 2,
            "type": "CONDITIONING"
          },
          {
            "id": 17,
            "origin_id": 13,
            "origin_slot": 0,
            "target_id": 3,
            "target_slot": 3,
            "type": "LATENT"
          },
          {
            "id": 28,
            "origin_id": 30,
            "origin_slot": 0,
            "target_id": 27,
            "target_slot": 0,
            "type": "CLIP"
          },
          {
            "id": 16,
            "origin_id": 8,
            "origin_slot": 0,
            "target_id": -20,
            "target_slot": 0,
            "type": "IMAGE"
          },
          {
            "id": 34,
            "origin_id": -10,
            "origin_slot": 0,
            "target_id": 27,
            "target_slot": 1,
            "type": "STRING"
          },
          {
            "id": 35,
            "origin_id": -10,
            "origin_slot": 1,
            "target_id": 13,
            "target_slot": 0,
            "type": "INT"
          },
          {
            "id": 36,
            "origin_id": -10,
            "origin_slot": 2,
            "target_id": 13,
            "target_slot": 1,
            "type": "INT"
          },
          {
            "id": 71,
            "origin_id": -10,
            "origin_slot": 3,
            "target_id": 3,
            "target_slot": 4,
            "type": "INT"
          },
          {
            "id": 72,
            "origin_id": -10,
            "origin_slot": 4,
            "target_id": 3,
            "target_slot": 5,
            "type": "INT"
          },
          {
            "id": 73,
            "origin_id": -10,
            "origin_slot": 5,
            "target_id": 28,
            "target_slot": 0,
            "type": "COMBO"
          },
          {
            "id": 74,
            "origin_id": -10,
            "origin_slot": 6,
            "target_id": 30,
            "target_slot": 0,
            "type": "COMBO"
          },
          {
            "id": 75,
            "origin_id": -10,
            "origin_slot": 7,
            "target_id": 29,
            "target_slot": 0,
            "type": "COMBO"
          }
        ],
        "extra": {
          "workflowRendererVersion": "LG"
        },
        "category": "Image generation and editing/Text to image",
        "description": "Generates images from text prompts using Z-Image-Turbo, Alibaba's distilled 6B DiT model."
      }
    ]
  },
  "extra": {}
}
```
