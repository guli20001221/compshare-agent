# 自动分镜图

- 来源类别：用户工作流
- 镜像内原始路径：`/ComfyUI/user/default/workflows/18个开源模型工作流/图片/自动分镜图.json`
- 节点数量：15
- 连线数量：17

## 节点类型

- `LoraLoaderModelOnly` × 2
- `CFGNorm` × 1
- `CLIPLoader` × 1
- `ConditioningZeroOut` × 1
- `KSampler` × 1
- `LoadImage` × 1
- `ModelSamplingAuraFlow` × 1
- `SaveImage` × 1
- `Text Multiline` × 1
- `TextEncodeQwenImageEditPlusAdvance_lrzjason` × 1
- `UNETLoader` × 1
- `VAEDecode` × 1
- `VAELoader` × 1
- `easy promptLine` × 1

## 工作流引用的模型或媒体文件

- `-V1.0-fp32-1c18194f7240.safetensors`
- `qwen_2.5_vl_7b.safetensors`
- `qwen_image_edit_2511_bf16.safetensors`
- `qwen_image_vae.safetensors`

## 原始工作流 JSON

```json
{
  "id": "f23b325b-a6c1-493c-9fac-4dbbc6938a11",
  "revision": 0,
  "last_node_id": 35,
  "last_link_id": 49,
  "nodes": [
    {
      "id": 17,
      "type": "UNETLoader",
      "pos": [
        1804.6736228927664,
        144.33130989150735
      ],
      "size": [
        406.5235290527344,
        82
      ],
      "flags": {},
      "order": 0,
      "mode": 0,
      "inputs": [
        {
          "label": "unet_name",
          "name": "unet_name",
          "type": "COMBO",
          "widget": {
            "name": "unet_name"
          }
        },
        {
          "label": "weight_dtype",
          "name": "weight_dtype",
          "type": "COMBO",
          "widget": {
            "name": "weight_dtype"
          }
        }
      ],
      "outputs": [
        {
          "label": "MODEL",
          "name": "MODEL",
          "type": "MODEL",
          "links": [
            20
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.76",
        "Node name for S&R": "UNETLoader",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "qwen_image_edit_2511_bf16.safetensors",
        "default"
      ],
      "color": "#432",
      "bgcolor": "#653"
    },
    {
      "id": 18,
      "type": "LoraLoaderModelOnly",
      "pos": [
        1802.9357700612145,
        275.2860507647181
      ],
      "size": [
        392.3271179199219,
        82
      ],
      "flags": {},
      "order": 5,
      "mode": 0,
      "inputs": [
        {
          "label": "model",
          "name": "model",
          "type": "MODEL",
          "link": 20
        },
        {
          "label": "lora_name",
          "name": "lora_name",
          "type": "COMBO",
          "widget": {
            "name": "lora_name"
          }
        },
        {
          "label": "strength_model",
          "name": "strength_model",
          "type": "FLOAT",
          "widget": {
            "name": "strength_model"
          }
        }
      ],
      "outputs": [
        {
          "label": "MODEL",
          "name": "MODEL",
          "type": "MODEL",
          "links": [
            40
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.49",
        "Node name for S&R": "LoraLoaderModelOnly",
        "models": [
          {
            "name": "Qwen-Image-Lightning-8steps-V1.0.safetensors",
            "directory": "loras",
            "url": "https://huggingface.co/lightx2v/Qwen-Image-Lightning/resolve/main/Qwen-Image-Lightning-8steps-V1.0.safetensors"
          }
        ],
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "Qwen-Image-Edit-2511-Lightning-4steps-V1.0-fp32-1c18194f7240.safetensors",
        1
      ],
      "color": "#432",
      "bgcolor": "#653"
    },
    {
      "id": 19,
      "type": "LoraLoaderModelOnly",
      "pos": [
        1803.608302306115,
        406.9756357289637
      ],
      "size": [
        399.69586181640625,
        82
      ],
      "flags": {},
      "order": 7,
      "mode": 0,
      "inputs": [
        {
          "label": "model",
          "name": "model",
          "type": "MODEL",
          "link": 40
        },
        {
          "label": "lora_name",
          "name": "lora_name",
          "type": "COMBO",
          "widget": {
            "name": "lora_name"
          }
        },
        {
          "label": "strength_model",
          "name": "strength_model",
          "type": "FLOAT",
          "widget": {
            "name": "strength_model"
          }
        }
      ],
      "outputs": [
        {
          "label": "MODEL",
          "name": "MODEL",
          "type": "MODEL",
          "links": [
            48
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.48",
        "Node name for S&R": "LoraLoaderModelOnly",
        "ue_properties": {
          "widget_ue_connectable": {},
          "input_ue_unconnectable": {},
          "version": "7.2.2"
        },
        "widget_ue_connectable": {
          "lora_name": true,
          "strength_model": true
        }
      },
      "widgets_values": [
        "Qwen-Edit-2509-Multiple-angles.safetensors",
        1.0000000000000002
      ],
      "color": "#432",
      "bgcolor": "#653"
    },
    {
      "id": 4,
      "type": "VAELoader",
      "pos": [
        1799.8123789856108,
        540.6675563410275
      ],
      "size": [
        403.7625427246094,
        66.17958068847656
      ],
      "flags": {},
      "order": 1,
      "mode": 0,
      "inputs": [
        {
          "label": "vae_name",
          "name": "vae_name",
          "type": "COMBO",
          "widget": {
            "name": "vae_name"
          }
        }
      ],
      "outputs": [
        {
          "label": "VAE",
          "name": "VAE",
          "type": "VAE",
          "slot_index": 0,
          "links": [
            27,
            28
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.48",
        "Node name for S&R": "VAELoader",
        "hasSecondTab": false,
        "models": [
          {
            "directory_invalid": true,
            "name": "qwen_image_vae.safetensors",
            "directory": "vae",
            "url": "https://huggingface.co/Comfy-Org/Qwen-Image_ComfyUI/resolve/main/split_files/vae/qwen_image_vae.safetensors"
          }
        ],
        "widget_ue_connectable": {},
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": [
        "qwen_image_vae.safetensors"
      ],
      "color": "#432",
      "bgcolor": "#653"
    },
    {
      "id": 35,
      "type": "CLIPLoader",
      "pos": [
        1802.0323185310783,
        657.0962919764083
      ],
      "size": [
        395.6950089889433,
        106
      ],
      "flags": {},
      "order": 2,
      "mode": 0,
      "inputs": [],
      "outputs": [
        {
          "name": "CLIP",
          "type": "CLIP",
          "links": [
            49
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.27.0",
        "Node name for S&R": "CLIPLoader"
      },
      "widgets_values": [
        "qwen_2.5_vl_7b.safetensors",
        "qwen_image",
        "default"
      ]
    },
    {
      "id": 14,
      "type": "TextEncodeQwenImageEditPlusAdvance_lrzjason",
      "pos": [
        2827.0063653522334,
        155.67608388159408
      ],
      "size": [
        402.659912109375,
        695.3538208007812
      ],
      "flags": {},
      "order": 8,
      "mode": 0,
      "inputs": [
        {
          "label": "clip",
          "name": "clip",
          "type": "CLIP",
          "link": 49
        },
        {
          "label": "vae",
          "name": "vae",
          "shape": 7,
          "type": "VAE",
          "link": 27
        },
        {
          "label": "vl_resize_image1",
          "name": "vl_resize_image1",
          "shape": 7,
          "type": "IMAGE",
          "link": 17
        },
        {
          "label": "vl_resize_image2",
          "name": "vl_resize_image2",
          "shape": 7,
          "type": "IMAGE"
        },
        {
          "label": "vl_resize_image3",
          "name": "vl_resize_image3",
          "shape": 7,
          "type": "IMAGE"
        },
        {
          "label": "not_resize_image1",
          "name": "not_resize_image1",
          "shape": 7,
          "type": "IMAGE"
        },
        {
          "label": "not_resize_image2",
          "name": "not_resize_image2",
          "shape": 7,
          "type": "IMAGE"
        },
        {
          "label": "not_resize_image3",
          "name": "not_resize_image3",
          "shape": 7,
          "type": "IMAGE"
        },
        {
          "label": "prompt",
          "name": "prompt",
          "type": "STRING",
          "widget": {
            "name": "prompt"
          },
          "link": 18
        },
        {
          "label": "target_size",
          "name": "target_size",
          "shape": 7,
          "type": "COMBO",
          "widget": {
            "name": "target_size"
          }
        },
        {
          "label": "target_vl_size",
          "name": "target_vl_size",
          "shape": 7,
          "type": "COMBO",
          "widget": {
            "name": "target_vl_size"
          }
        },
        {
          "label": "upscale_method",
          "name": "upscale_method",
          "shape": 7,
          "type": "COMBO",
          "widget": {
            "name": "upscale_method"
          }
        },
        {
          "label": "crop_method",
          "name": "crop_method",
          "shape": 7,
          "type": "COMBO",
          "widget": {
            "name": "crop_method"
          }
        },
        {
          "label": "instruction",
          "name": "instruction",
          "shape": 7,
          "type": "STRING",
          "widget": {
            "name": "instruction"
          }
        }
      ],
      "outputs": [
        {
          "label": "conditioning_with_full_ref",
          "name": "conditioning_with_full_ref",
          "type": "CONDITIONING",
          "links": [
            9,
            12
          ]
        },
        {
          "label": "latent",
          "name": "latent",
          "type": "LATENT",
          "links": [
            14
          ]
        },
        {
          "label": "target_image1",
          "name": "target_image1",
          "type": "IMAGE",
          "links": []
        },
        {
          "label": "target_image2",
          "name": "target_image2",
          "type": "IMAGE"
        },
        {
          "label": "target_image3",
          "name": "target_image3",
          "type": "IMAGE"
        },
        {
          "label": "vl_resized_image1",
          "name": "vl_resized_image1",
          "type": "IMAGE"
        },
        {
          "label": "vl_resized_image2",
          "name": "vl_resized_image2",
          "type": "IMAGE"
        },
        {
          "label": "vl_resized_image3",
          "name": "vl_resized_image3",
          "type": "IMAGE"
        },
        {
          "label": "conditioning_with_first_ref",
          "name": "conditioning_with_first_ref",
          "type": "CONDITIONING"
        },
        {
          "label": "pad_info",
          "name": "pad_info",
          "type": "ANY"
        }
      ],
      "properties": {
        "Node name for S&R": "TextEncodeQwenImageEditPlusAdvance_lrzjason",
        "cnr_id": "qweneditutils",
        "ver": "1.1.2",
        "ue_properties": {
          "widget_ue_connectable": {},
          "input_ue_unconnectable": {},
          "version": "7.2.2"
        },
        "widget_ue_connectable": {
          "target_size": true,
          "instruction": true,
          "target_vl_size": true,
          "upscale_method": true,
          "prompt": true,
          "crop": true
        }
      },
      "widgets_values": [
        "",
        1536,
        384,
        "lanczos",
        "center",
        "Describe the key features of the input image (color, shape, size, texture, objects, background), then explain how the user's text instruction should alter or modify the image. Generate a new image that meets the user's requirements while maintaining consistency with the original input where appropriate."
      ]
    },
    {
      "id": 20,
      "type": "Text Multiline",
      "pos": [
        2225.99213118807,
        147.53381229158626
      ],
      "size": [
        585.0008544921875,
        348.79486083984375
      ],
      "flags": {},
      "order": 3,
      "mode": 0,
      "inputs": [
        {
          "label": "text",
          "name": "text",
          "type": "STRING",
          "widget": {
            "name": "text"
          }
        }
      ],
      "outputs": [
        {
          "label": "STRING",
          "name": "STRING",
          "type": "STRING",
          "links": [
            24
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "Text Multiline",
        "cnr_id": "was-ns",
        "ver": "3.0.1",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "Next Scene：将镜头向前移动\nNext Scene：将镜头向左移动\nNext Scene：将镜头向下移动\nNext Scene：将镜头向左旋转45度\nNext Scene：将镜头向右旋转45度\nNext Scene：将镜头转为特写镜头\nNext Scene：将镜头转为广角镜头\nNext Scene：将镜头转为正面全身镜头\nNext Scene：将镜头转为背后全身镜头"
      ]
    },
    {
      "id": 3,
      "type": "easy promptLine",
      "pos": [
        2222.6886071887543,
        553.3017126660694
      ],
      "size": [
        578.7301025390625,
        284.9609069824219
      ],
      "flags": {},
      "order": 6,
      "mode": 0,
      "inputs": [
        {
          "label": "prompt",
          "name": "prompt",
          "type": "STRING",
          "widget": {
            "name": "prompt"
          },
          "link": 24
        },
        {
          "label": "start_index",
          "name": "start_index",
          "type": "INT",
          "widget": {
            "name": "start_index"
          }
        },
        {
          "label": "max_rows",
          "name": "max_rows",
          "type": "INT",
          "widget": {
            "name": "max_rows"
          }
        }
      ],
      "outputs": [
        {
          "label": "STRING",
          "name": "STRING",
          "shape": 6,
          "type": "STRING",
          "links": []
        },
        {
          "label": "COMBO",
          "name": "COMBO",
          "shape": 6,
          "type": "*",
          "links": [
            18
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "easy promptLine",
        "cnr_id": "comfyui-easy-use",
        "ver": "8ecc929cd41cf0f7ef6fcc45d4bbc5729c6f287f",
        "ue_properties": {
          "widget_ue_connectable": {},
          "input_ue_unconnectable": {},
          "version": "7.2.2"
        },
        "widget_ue_connectable": {
          "start_index": true,
          "max_rows": true,
          "prompt": true
        }
      },
      "widgets_values": [
        "Next Scene：将镜头向前移动Move the camera forward\nNext Scene：将镜头向右移动Move the camera right\nNext Scene：将镜头向下移动Move the camera down\nNext Scene：将镜头向上移动Move the camera up\nNext Scene：将镜头向左旋转45度Rotate the camera 45 degrees to the left\nNext Scene：将镜头向右旋转45度Rotate the camera 45 degrees to the right\nNext Scene：将镜头转为广角镜头Turn the camera to a wide-angle lens\nNext Scene：将镜头转为特写镜头Turn the camera to a close-up\nNext Scene：将镜头转为俯视Turn the camera to a top-down view\n\n\n\n\n",
        0,
        1000,
        ""
      ]
    },
    {
      "id": 25,
      "type": "ModelSamplingAuraFlow",
      "pos": [
        3242.95975569709,
        157.48612260296477
      ],
      "size": [
        245.15818786621094,
        99.46732330322266
      ],
      "flags": {},
      "order": 9,
      "mode": 0,
      "inputs": [
        {
          "label": "model",
          "name": "model",
          "type": "MODEL",
          "link": 48
        },
        {
          "label": "shift",
          "name": "shift",
          "type": "FLOAT",
          "widget": {
            "name": "shift"
          }
        }
      ],
      "outputs": [
        {
          "label": "MODEL",
          "name": "MODEL",
          "type": "MODEL",
          "links": [
            41
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.48",
        "Node name for S&R": "ModelSamplingAuraFlow",
        "hasSecondTab": false,
        "ue_properties": {
          "widget_ue_connectable": {},
          "input_ue_unconnectable": {},
          "version": "7.1"
        },
        "widget_ue_connectable": {},
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": [
        3
      ]
    },
    {
      "id": 24,
      "type": "CFGNorm",
      "pos": [
        3243.430962790899,
        308.2789836658451
      ],
      "size": [
        250.61167907714844,
        94.755126953125
      ],
      "flags": {},
      "order": 11,
      "mode": 0,
      "inputs": [
        {
          "label": "model",
          "name": "model",
          "type": "MODEL",
          "link": 41
        },
        {
          "label": "strength",
          "name": "strength",
          "type": "FLOAT",
          "widget": {
            "name": "strength"
          }
        },
        {
          "label": "pre_cfg",
          "name": "pre_cfg",
          "shape": 7,
          "type": "BOOLEAN",
          "widget": {
            "name": "pre_cfg"
          }
        }
      ],
      "outputs": [
        {
          "label": "patched_model",
          "name": "patched_model",
          "type": "MODEL",
          "links": [
            43
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.50",
        "Node name for S&R": "CFGNorm",
        "hasSecondTab": false,
        "ue_properties": {
          "widget_ue_connectable": {
            "strength": true
          },
          "input_ue_unconnectable": {},
          "version": "7.1"
        },
        "widget_ue_connectable": {},
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": [
        1,
        false
      ]
    },
    {
      "id": 7,
      "type": "VAEDecode",
      "pos": [
        3461.368566846543,
        441.8898656549611
      ],
      "size": [
        140,
        84.50496956481766
      ],
      "flags": {
        "collapsed": false
      },
      "order": 13,
      "mode": 0,
      "inputs": [
        {
          "label": "samples",
          "name": "samples",
          "type": "LATENT",
          "link": 5
        },
        {
          "label": "vae",
          "name": "vae",
          "type": "VAE",
          "link": 28
        }
      ],
      "outputs": [
        {
          "label": "IMAGE",
          "name": "IMAGE",
          "type": "IMAGE",
          "slot_index": 0,
          "links": [
            10
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.48",
        "Node name for S&R": "VAEDecode",
        "hasSecondTab": false,
        "ue_properties": {
          "widget_ue_connectable": {},
          "input_ue_unconnectable": {},
          "version": "7.2.2"
        },
        "widget_ue_connectable": {},
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": []
    },
    {
      "id": 10,
      "type": "ConditioningZeroOut",
      "pos": [
        3248.190908184185,
        450.50096983935373
      ],
      "size": [
        204.134765625,
        66.4918532518181
      ],
      "flags": {},
      "order": 10,
      "mode": 0,
      "inputs": [
        {
          "label": "conditioning",
          "name": "conditioning",
          "type": "CONDITIONING",
          "link": 9
        }
      ],
      "outputs": [
        {
          "label": "CONDITIONING",
          "name": "CONDITIONING",
          "type": "CONDITIONING",
          "links": [
            13
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.59",
        "Node name for S&R": "ConditioningZeroOut",
        "hasSecondTab": false,
        "ue_properties": {
          "widget_ue_connectable": {},
          "input_ue_unconnectable": {},
          "version": "7.2.2"
        },
        "widget_ue_connectable": {},
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": []
    },
    {
      "id": 12,
      "type": "KSampler",
      "pos": [
        3246.079708595736,
        569.016403341822
      ],
      "size": [
        354.2635190113474,
        281.548980125252
      ],
      "flags": {},
      "order": 12,
      "mode": 0,
      "inputs": [
        {
          "label": "model",
          "name": "model",
          "type": "MODEL",
          "link": 43
        },
        {
          "label": "positive",
          "name": "positive",
          "type": "CONDITIONING",
          "link": 12
        },
        {
          "label": "negative",
          "name": "negative",
          "type": "CONDITIONING",
          "link": 13
        },
        {
          "label": "latent_image",
          "name": "latent_image",
          "type": "LATENT",
          "link": 14
        },
        {
          "label": "seed",
          "name": "seed",
          "type": "INT",
          "widget": {
            "name": "seed"
          }
        },
        {
          "label": "steps",
          "name": "steps",
          "type": "INT",
          "widget": {
            "name": "steps"
          }
        },
        {
          "label": "cfg",
          "name": "cfg",
          "type": "FLOAT",
          "widget": {
            "name": "cfg"
          }
        },
        {
          "label": "sampler_name",
          "name": "sampler_name",
          "type": "COMBO",
          "widget": {
            "name": "sampler_name"
          }
        },
        {
          "label": "scheduler",
          "name": "scheduler",
          "type": "COMBO",
          "widget": {
            "name": "scheduler"
          }
        },
        {
          "label": "denoise",
          "name": "denoise",
          "type": "FLOAT",
          "widget": {
            "name": "denoise"
          }
        }
      ],
      "outputs": [
        {
          "label": "LATENT",
          "name": "LATENT",
          "type": "LATENT",
          "slot_index": 0,
          "links": [
            5
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.48",
        "Node name for S&R": "KSampler",
        "hasSecondTab": false,
        "ue_properties": {
          "widget_ue_connectable": {},
          "input_ue_unconnectable": {},
          "version": "7.2.2"
        },
        "widget_ue_connectable": {
          "scheduler": true,
          "denoise": true,
          "seed": true,
          "cfg": true,
          "sampler_name": true,
          "steps": true
        },
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": [
        1,
        "fixed",
        4,
        1,
        "euler",
        "simple",
        1
      ]
    },
    {
      "id": 11,
      "type": "SaveImage",
      "pos": [
        3649.8335767275667,
        99.85153994550312
      ],
      "size": [
        1094.5248317261176,
        940.6019558024284
      ],
      "flags": {},
      "order": 14,
      "mode": 0,
      "inputs": [
        {
          "label": "images",
          "name": "images",
          "type": "IMAGE",
          "link": 10
        },
        {
          "label": "filename_prefix",
          "name": "filename_prefix",
          "type": "STRING",
          "widget": {
            "name": "filename_prefix"
          }
        }
      ],
      "outputs": [
        {
          "label": "image_urls",
          "name": "images",
          "type": "IMAGE"
        },
        {
          "label": "images",
          "name": "images",
          "type": "IMAGE"
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.64",
        "Node name for S&R": "SaveImage",
        "ue_properties": {
          "widget_ue_connectable": {},
          "input_ue_unconnectable": {},
          "version": "7.2.2"
        },
        "widget_ue_connectable": {
          "filename_prefix": true
        }
      },
      "widgets_values": [
        "Batch"
      ]
    },
    {
      "id": 13,
      "type": "LoadImage",
      "pos": [
        1147.3062654265602,
        97.31170220060385
      ],
      "size": [
        601.9202270507812,
        708.2225952148438
      ],
      "flags": {},
      "order": 4,
      "mode": 0,
      "inputs": [
        {
          "label": "image",
          "name": "image",
          "type": "COMBO",
          "widget": {
            "name": "image"
          }
        },
        {
          "label": "upload",
          "name": "upload",
          "type": "IMAGEUPLOAD",
          "widget": {
            "name": "upload"
          }
        }
      ],
      "outputs": [
        {
          "label": "IMAGE",
          "name": "IMAGE",
          "type": "IMAGE",
          "links": [
            17
          ]
        },
        {
          "label": "MASK",
          "name": "MASK",
          "type": "MASK"
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.50",
        "Node name for S&R": "LoadImage",
        "hasSecondTab": false,
        "ue_properties": {
          "widget_ue_connectable": {
            "image": true,
            "upload": true
          },
          "input_ue_unconnectable": {},
          "version": "7.2.2"
        },
        "widget_ue_connectable": {
          "image": true,
          "upload": true
        },
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": [
        "u=214975317,651249542&fm=253&app=138&f=JPEG.jpg",
        "image"
      ]
    }
  ],
  "links": [
    [
      5,
      12,
      0,
      7,
      0,
      "LATENT"
    ],
    [
      9,
      14,
      0,
      10,
      0,
      "CONDITIONING"
    ],
    [
      10,
      7,
      0,
      11,
      0,
      "IMAGE"
    ],
    [
      12,
      14,
      0,
      12,
      1,
      "CONDITIONING"
    ],
    [
      13,
      10,
      0,
      12,
      2,
      "CONDITIONING"
    ],
    [
      14,
      14,
      1,
      12,
      3,
      "LATENT"
    ],
    [
      17,
      13,
      0,
      14,
      2,
      "IMAGE"
    ],
    [
      18,
      3,
      1,
      14,
      8,
      "STRING"
    ],
    [
      20,
      17,
      0,
      18,
      0,
      "MODEL"
    ],
    [
      24,
      20,
      0,
      3,
      0,
      "STRING"
    ],
    [
      27,
      4,
      0,
      14,
      1,
      "VAE"
    ],
    [
      28,
      4,
      0,
      7,
      1,
      "VAE"
    ],
    [
      40,
      18,
      0,
      19,
      0,
      "MODEL"
    ],
    [
      41,
      25,
      0,
      24,
      0,
      "MODEL"
    ],
    [
      43,
      24,
      0,
      12,
      0,
      "MODEL"
    ],
    [
      48,
      19,
      0,
      25,
      0,
      "MODEL"
    ],
    [
      49,
      35,
      0,
      14,
      0,
      "CLIP"
    ]
  ],
  "groups": [
    {
      "id": 1,
      "title": "Group",
      "bounding": [
        1781.0301513671875,
        62.84662628173828,
        1851.415843081841,
        816.0313489229118
      ],
      "color": "#3f789e",
      "flags": {}
    }
  ],
  "config": {},
  "extra": {
    "links_added_by_ue": [],
    "ue_links": [],
    "0246.VERSION": [
      0,
      0,
      4
    ],
    "workflowRendererVersion": "LG",
    "frontendVersion": "1.45.20",
    "ds": {
      "scale": 0.49500000000000277,
      "offset": [
        -939.2778063805273,
        591.6576781408413
      ]
    },
    "VHS_latentpreview": false,
    "VHS_latentpreviewrate": 0,
    "VHS_MetadataImage": true,
    "VHS_KeepIntermediate": true
  },
  "version": 0.4
}
```
