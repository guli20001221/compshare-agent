# 声音克隆+文本转语音

- 来源类别：用户工作流
- 镜像内原始路径：`/ComfyUI/user/default/workflows/18个开源模型工作流/音频/声音克隆+文本转语音.json`
- 节点数量：5
- 连线数量：4

## 节点类型

- `AudioCrop` × 1
- `LoadAudio` × 1
- `Qwen3TTSModelLoader` × 1
- `Qwen3TTSVoiceClone` × 1
- `SaveAudio` × 1

## 工作流引用的模型或媒体文件

- `001-1.mp4`

## 原始工作流 JSON

```json
{
  "id": "e4b45388-59a4-4312-a2ad-89f4b598f126",
  "revision": 0,
  "last_node_id": 9,
  "last_link_id": 10,
  "nodes": [
    {
      "id": 4,
      "type": "Qwen3TTSModelLoader",
      "pos": [
        384.4439697265625,
        210.2650604248047
      ],
      "size": [
        539.7064208984375,
        112.68083190917969
      ],
      "flags": {},
      "order": 0,
      "mode": 0,
      "inputs": [
        {
          "label": "模型名称",
          "name": "模型名称",
          "type": "COMBO",
          "widget": {
            "name": "模型名称"
          }
        },
        {
          "label": "运行设备",
          "name": "运行设备",
          "type": "COMBO",
          "widget": {
            "name": "运行设备"
          }
        },
        {
          "label": "精度",
          "name": "精度",
          "type": "COMBO",
          "widget": {
            "name": "精度"
          }
        }
      ],
      "outputs": [
        {
          "label": "模型",
          "name": "模型",
          "type": "QWEN3_TTS_MODEL",
          "links": [
            1
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "Qwen3TTSModelLoader",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "Qwen/Qwen3-TTS-12Hz-1.7B-Base",
        "cuda",
        "fp16"
      ],
      "color": "#223",
      "bgcolor": "#335"
    },
    {
      "id": 1,
      "type": "Qwen3TTSVoiceClone",
      "pos": [
        947.3533935546875,
        206.75131225585938
      ],
      "size": [
        397.167724609375,
        467.3768005371094
      ],
      "flags": {},
      "order": 3,
      "mode": 0,
      "inputs": [
        {
          "label": "模型",
          "name": "模型",
          "type": "QWEN3_TTS_MODEL",
          "link": 1
        },
        {
          "label": "参考音频",
          "name": "参考音频",
          "type": "AUDIO",
          "link": 2
        },
        {
          "label": "文本",
          "name": "文本",
          "type": "STRING",
          "widget": {
            "name": "文本"
          }
        },
        {
          "label": "语言",
          "name": "语言",
          "type": "COMBO",
          "widget": {
            "name": "语言"
          }
        },
        {
          "label": "自动卸载模型",
          "name": "自动卸载模型",
          "type": "BOOLEAN",
          "widget": {
            "name": "自动卸载模型"
          }
        },
        {
          "label": "最大生成Token数",
          "name": "最大生成Token数",
          "type": "INT",
          "widget": {
            "name": "最大生成Token数"
          }
        },
        {
          "label": "seed",
          "name": "seed",
          "type": "INT",
          "widget": {
            "name": "seed"
          }
        },
        {
          "label": "批量模式",
          "name": "批量模式",
          "shape": 7,
          "type": "BOOLEAN",
          "widget": {
            "name": "批量模式"
          }
        },
        {
          "label": "top_p",
          "name": "top_p",
          "shape": 7,
          "type": "FLOAT",
          "widget": {
            "name": "top_p"
          }
        },
        {
          "label": "top_k",
          "name": "top_k",
          "shape": 7,
          "type": "INT",
          "widget": {
            "name": "top_k"
          }
        },
        {
          "label": "temperature",
          "name": "temperature",
          "shape": 7,
          "type": "FLOAT",
          "widget": {
            "name": "temperature"
          }
        },
        {
          "label": "repetition_penalty",
          "name": "repetition_penalty",
          "shape": 7,
          "type": "FLOAT",
          "widget": {
            "name": "repetition_penalty"
          }
        },
        {
          "label": "启用高级采样配置",
          "name": "启用高级采样配置",
          "shape": 7,
          "type": "BOOLEAN",
          "widget": {
            "name": "启用高级采样配置"
          }
        }
      ],
      "outputs": [
        {
          "label": "音频",
          "name": "音频",
          "shape": 6,
          "type": "AUDIO",
          "links": [
            4
          ]
        },
        {
          "label": "角色预设",
          "name": "角色预设",
          "type": "QWEN3_TTS_VOICE_PROMPT"
        }
      ],
      "properties": {
        "Node name for S&R": "Qwen3TTSVoiceClone",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "好了本期视频就到这里了如果你也喜欢我的视频记得点赞关注收藏我是鲍勃同学咱们下期再见",
        "",
        "自动",
        false,
        2048,
        470071832201763,
        "randomize",
        1,
        false,
        0.8,
        50,
        0.8,
        1.1,
        false
      ]
    },
    {
      "id": 2,
      "type": "SaveAudio",
      "pos": [
        1378.40234375,
        206.51119995117188
      ],
      "size": [
        270,
        112
      ],
      "flags": {},
      "order": 4,
      "mode": 0,
      "inputs": [
        {
          "label": "音频",
          "name": "audio",
          "type": "AUDIO",
          "link": 4
        },
        {
          "label": "filename_prefix",
          "name": "filename_prefix",
          "type": "STRING",
          "widget": {
            "name": "filename_prefix"
          }
        },
        {
          "label": "audioUI",
          "name": "audioUI",
          "type": "AUDIO_UI",
          "widget": {
            "name": "audioUI"
          }
        }
      ],
      "outputs": [
        {
          "label": "audio",
          "name": "audio",
          "type": "AUDIO",
          "links": null
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.5.1",
        "Node name for S&R": "SaveAudio",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "audio/ComfyUI"
      ]
    },
    {
      "id": 3,
      "type": "AudioCrop",
      "pos": [
        656.4161376953125,
        394.74395751953125
      ],
      "size": [
        270,
        82
      ],
      "flags": {},
      "order": 2,
      "mode": 0,
      "inputs": [
        {
          "label": "audio",
          "name": "audio",
          "type": "AUDIO",
          "link": 5
        },
        {
          "label": "start_time",
          "name": "start_time",
          "type": "STRING",
          "widget": {
            "name": "start_time"
          }
        },
        {
          "label": "end_time",
          "name": "end_time",
          "type": "STRING",
          "widget": {
            "name": "end_time"
          }
        }
      ],
      "outputs": [
        {
          "label": "AUDIO",
          "name": "AUDIO",
          "type": "AUDIO",
          "links": [
            2
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "AudioCrop",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "0:00",
        "0:05"
      ]
    },
    {
      "id": 7,
      "type": "LoadAudio",
      "pos": [
        379.7532958984375,
        389.24920654296875
      ],
      "size": [
        250.78541564941406,
        236.64044189453125
      ],
      "flags": {},
      "order": 1,
      "mode": 0,
      "inputs": [
        {
          "label": "audio",
          "name": "audio",
          "type": "COMBO",
          "widget": {
            "name": "audio"
          }
        },
        {
          "label": "audioUI",
          "name": "audioUI",
          "type": "AUDIO_UI",
          "widget": {
            "name": "audioUI"
          }
        },
        {
          "label": "upload",
          "name": "upload",
          "type": "AUDIOUPLOAD",
          "widget": {
            "name": "upload"
          }
        }
      ],
      "outputs": [
        {
          "label": "音频",
          "name": "AUDIO",
          "type": "AUDIO",
          "links": [
            5
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.5.1",
        "Node name for S&R": "LoadAudio",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "001-1.mp4",
        null,
        null
      ],
      "color": "#2a363b",
      "bgcolor": "#3f5159"
    }
  ],
  "links": [
    [
      1,
      4,
      0,
      1,
      0,
      "QWEN3_TTS_MODEL"
    ],
    [
      2,
      3,
      0,
      1,
      1,
      "AUDIO"
    ],
    [
      4,
      1,
      0,
      2,
      0,
      "AUDIO"
    ],
    [
      5,
      7,
      0,
      3,
      0,
      "AUDIO"
    ]
  ],
  "groups": [
    {
      "id": 1,
      "title": "声音克隆+文本转语音",
      "bounding": [
        362.1827087402344,
        107.31880950927734,
        1312.6156005859375,
        597.19482421875
      ],
      "color": "#3f789e",
      "font_size": 24,
      "flags": {}
    }
  ],
  "config": {},
  "extra": {
    "ds": {
      "scale": 1.2839025177495011,
      "offset": [
        -205.4057881484243,
        -2.0605789045516643
      ]
    },
    "frontendVersion": "1.23.4",
    "links_added_by_ue": [],
    "ue_links": [],
    "0246.VERSION": [
      0,
      0,
      4
    ],
    "VHS_latentpreview": false,
    "VHS_latentpreviewrate": 0,
    "VHS_MetadataImage": true,
    "VHS_KeepIntermediate": true
  },
  "version": 0.4
}
```
