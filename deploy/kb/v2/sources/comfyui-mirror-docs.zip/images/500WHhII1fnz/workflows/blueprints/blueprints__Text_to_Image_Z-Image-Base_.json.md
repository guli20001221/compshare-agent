# Text to Image (Z-Image-Base)

- 来源类别：内置工作流蓝图
- 镜像内原始路径：`/ComfyUI/blueprints/Text to Image (Z-Image-Base).json`
- 节点数量：1
- 连线数量：0

## 节点类型

- `8a2bb267-5858-4aaf-bdcd-61002711af19` × 1

## 原始工作流 JSON

```json
{
  "revision": 0,
  "last_node_id": 126,
  "last_link_id": 0,
  "nodes": [
    {
      "id": 126,
      "type": "8a2bb267-5858-4aaf-bdcd-61002711af19",
      "pos": [
        -2280,
        2850
      ],
      "size": [
        410,
        560
      ],
      "flags": {},
      "order": 1,
      "mode": 0,
      "inputs": [
        {
          "label": "prompt",
          "name": "text",
          "type": "STRING",
          "widget": {
            "name": "text"
          },
          "link": null
        },
        {
          "name": "width",
          "type": "INT",
          "widget": {
            "name": "width"
          },
          "link": null
        },
        {
          "name": "height",
          "type": "INT",
          "widget": {
            "name": "height"
          },
          "link": null
        },
        {
          "name": "steps",
          "type": "INT",
          "widget": {
            "name": "steps"
          },
          "link": null
        },
        {
          "name": "cfg",
          "type": "FLOAT",
          "widget": {
            "name": "cfg"
          },
          "link": null
        },
        {
          "name": "seed",
          "type": "INT",
          "widget": {
            "name": "seed"
          },
          "link": null
        },
        {
          "name": "unet_name",
          "type": "COMBO",
          "widget": {
            "name": "unet_name"
          },
          "link": null
        },
        {
          "name": "clip_name",
          "type": "COMBO",
          "widget": {
            "name": "clip_name"
          },
          "link": null
        },
        {
          "name": "vae_name",
          "type": "COMBO",
          "widget": {
            "name": "vae_name"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "localized_name": "IMAGE",
          "name": "IMAGE",
          "type": "IMAGE",
          "links": []
        }
      ],
      "properties": {
        "proxyWidgets": [
          [
            "67",
            "text"
          ],
          [
            "68",
            "width"
          ],
          [
            "68",
            "height"
          ],
          [
            "69",
            "steps"
          ],
          [
            "69",
            "cfg"
          ],
          [
            "69",
            "seed"
          ],
          [
            "66",
            "unet_name"
          ],
          [
            "62",
            "clip_name"
          ],
          [
            "63",
            "vae_name"
          ],
          [
            "69",
            "control_after_generate"
          ]
        ],
        "cnr_id": "comfy-core",
        "ver": "0.13.0",
        "enableTabs": false,
        "tabWidth": 65,
        "tabXOffset": 10,
        "hasSecondTab": false,
        "secondTabText": "Send Back",
        "secondTabOffset": 80,
        "secondTabWidth": 65
      },
      "widgets_values": [],
      "title": "Text to Image (Z-Image-Base)"
    }
  ],
  "links": [],
  "version": 0.4,
  "definitions": {
    "subgraphs": [
      {
        "id": "8a2bb267-5858-4aaf-bdcd-61002711af19",
        "version": 1,
        "state": {
          "lastGroupId": 16,
          "lastNodeId": 126,
          "lastLinkId": 229,
          "lastRerouteId": 0
        },
        "revision": 0,
        "config": {},
        "name": "Text to Image (Z-Image-Base)",
        "description": "Generates images from text prompts using Z-Image base weights with Qwen3 text encoder and bundled VAE.",
        "inputNode": {
          "id": -10,
          "bounding": [
            -220,
            40,
            120,
            220
          ]
        },
        "outputNode": {
          "id": -20,
          "bounding": [
            1840,
            -150,
            120,
            60
          ]
        },
        "inputs": [
          {
            "id": "af36fee5-4f8b-4a8e-bfa8-cb8fe7006cc3",
            "name": "text",
            "type": "STRING",
            "linkIds": [
              108
            ],
            "label": "prompt",
            "pos": [
              -120,
              60
            ]
          },
          {
            "id": "357f0059-e8e6-41f6-a290-c53b0a60c0ed",
            "name": "width",
            "type": "INT",
            "linkIds": [
              114
            ],
            "pos": [
              -120,
              80
            ]
          },
          {
            "id": "4a442743-a9c2-4aa5-9efd-05d43f3322d3",
            "name": "height",
            "type": "INT",
            "linkIds": [
              115
            ],
            "pos": [
              -120,
              100
            ]
          },
          {
            "id": "a0fc336b-d349-418e-8415-318653f7b6b3",
            "name": "steps",
            "type": "INT",
            "linkIds": [
              116
            ],
            "pos": [
              -120,
              120
            ]
          },
          {
            "id": "2f253ace-1e1a-415f-9b95-a10430bd5749",
            "name": "cfg",
            "type": "FLOAT",
            "linkIds": [
              117
            ],
            "pos": [
              -120,
              140
            ]
          },
          {
            "id": "18a6ad37-23aa-4bf7-a0cd-1d6ca6e2a128",
            "name": "seed",
            "type": "INT",
            "linkIds": [
              118
            ],
            "pos": [
              -120,
              160
            ]
          },
          {
            "id": "d1fc4937-8505-4ec6-9fc4-a33ef7b45eee",
            "name": "unet_name",
            "type": "COMBO",
            "linkIds": [
              119
            ],
            "pos": [
              -120,
              180
            ]
          },
          {
            "id": "db45dd49-d990-4ceb-a849-f96341874cdd",
            "name": "clip_name",
            "type": "COMBO",
            "linkIds": [
              120
            ],
            "pos": [
              -120,
              200
            ]
          },
          {
            "id": "37b8eac6-9b1b-452b-81f3-0ba9e34a576a",
            "name": "vae_name",
            "type": "COMBO",
            "linkIds": [
              121
            ],
            "pos": [
              -120,
              220
            ]
          }
        ],
        "outputs": [
          {
            "id": "f2bea309-bfe7-4ccb-9ffe-9475bf1da2ae",
            "name": "IMAGE",
            "type": "IMAGE",
            "linkIds": [
              79
            ],
            "localized_name": "IMAGE",
            "pos": [
              1860,
              -130
            ]
          }
        ],
        "widgets": [],
        "nodes": [
          {
            "id": 67,
            "type": "CLIPTextEncode",
            "pos": [
              600,
              -90
            ],
            "size": [
              410,
              320
            ],
            "flags": {},
            "order": 5,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "clip",
                "name": "clip",
                "type": "CLIP",
                "link": 78
              },
              {
                "localized_name": "text",
                "name": "text",
                "type": "STRING",
                "widget": {
                  "name": "text"
                },
                "link": 108
              }
            ],
            "outputs": [
              {
                "localized_name": "CONDITIONING",
                "name": "CONDITIONING",
                "type": "CONDITIONING",
                "links": [
                  75
                ]
              }
            ],
            "title": "CLIP Text Encode (Positive Prompt)",
            "properties": {
              "Node name for S&R": "CLIPTextEncode",
              "cnr_id": "comfy-core",
              "ver": "0.3.73",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            },
            "widgets_values": [
              ""
            ],
            "color": "#232",
            "bgcolor": "#353"
          },
          {
            "id": 68,
            "type": "EmptySD3LatentImage",
            "pos": [
              240,
              620
            ],
            "size": [
              260,
              170
            ],
            "flags": {},
            "order": 6,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "width",
                "name": "width",
                "type": "INT",
                "widget": {
                  "name": "width"
                },
                "link": 114
              },
              {
                "localized_name": "height",
                "name": "height",
                "type": "INT",
                "widget": {
                  "name": "height"
                },
                "link": 115
              },
              {
                "localized_name": "batch_size",
                "name": "batch_size",
                "type": "INT",
                "widget": {
                  "name": "batch_size"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "LATENT",
                "name": "LATENT",
                "type": "LATENT",
                "slot_index": 0,
                "links": [
                  77
                ]
              }
            ],
            "properties": {
              "Node name for S&R": "EmptySD3LatentImage",
              "cnr_id": "comfy-core",
              "ver": "0.3.64",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            },
            "widgets_values": [
              1024,
              1024,
              1
            ]
          },
          {
            "id": 63,
            "type": "VAELoader",
            "pos": [
              230,
              340
            ],
            "size": [
              270,
              110
            ],
            "flags": {},
            "order": 2,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "vae_name",
                "name": "vae_name",
                "type": "COMBO",
                "widget": {
                  "name": "vae_name"
                },
                "link": 121
              }
            ],
            "outputs": [
              {
                "localized_name": "VAE",
                "name": "VAE",
                "type": "VAE",
                "links": [
                  73
                ]
              }
            ],
            "properties": {
              "Node name for S&R": "VAELoader",
              "cnr_id": "comfy-core",
              "ver": "0.3.73",
              "models": [
                {
                  "name": "ae.safetensors",
                  "url": "https://huggingface.co/Comfy-Org/z_image_turbo/resolve/main/split_files/vae/ae.safetensors",
                  "directory": "vae"
                }
              ],
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            },
            "widgets_values": [
              "ae.safetensors"
            ]
          },
          {
            "id": 62,
            "type": "CLIPLoader",
            "pos": [
              230,
              110
            ],
            "size": [
              270,
              150
            ],
            "flags": {},
            "order": 1,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "clip_name",
                "name": "clip_name",
                "type": "COMBO",
                "widget": {
                  "name": "clip_name"
                },
                "link": 120
              },
              {
                "localized_name": "type",
                "name": "type",
                "type": "COMBO",
                "widget": {
                  "name": "type"
                },
                "link": null
              },
              {
                "localized_name": "device",
                "name": "device",
                "shape": 7,
                "type": "COMBO",
                "widget": {
                  "name": "device"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "CLIP",
                "name": "CLIP",
                "type": "CLIP",
                "links": [
                  78,
                  82
                ]
              }
            ],
            "properties": {
              "Node name for S&R": "CLIPLoader",
              "cnr_id": "comfy-core",
              "ver": "0.3.73",
              "models": [
                {
                  "name": "qwen_3_4b.safetensors",
                  "url": "https://huggingface.co/Comfy-Org/z_image_turbo/resolve/main/split_files/text_encoders/qwen_3_4b.safetensors",
                  "directory": "text_encoders"
                }
              ],
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            },
            "widgets_values": [
              "qwen_3_4b.safetensors",
              "lumina2",
              "default"
            ]
          },
          {
            "id": 65,
            "type": "VAEDecode",
            "pos": [
              1450,
              -150
            ],
            "size": [
              230,
              100
            ],
            "flags": {},
            "order": 3,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "samples",
                "name": "samples",
                "type": "LATENT",
                "link": 72
              },
              {
                "localized_name": "vae",
                "name": "vae",
                "type": "VAE",
                "link": 73
              }
            ],
            "outputs": [
              {
                "localized_name": "IMAGE",
                "name": "IMAGE",
                "type": "IMAGE",
                "slot_index": 0,
                "links": [
                  79
                ]
              }
            ],
            "properties": {
              "Node name for S&R": "VAEDecode",
              "cnr_id": "comfy-core",
              "ver": "0.3.64",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            }
          },
          {
            "id": 70,
            "type": "ModelSamplingAuraFlow",
            "pos": [
              1100,
              -150
            ],
            "size": [
              310,
              110
            ],
            "flags": {},
            "order": 8,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "model",
                "name": "model",
                "type": "MODEL",
                "link": 109
              },
              {
                "localized_name": "shift",
                "name": "shift",
                "type": "FLOAT",
                "widget": {
                  "name": "shift"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "MODEL",
                "name": "MODEL",
                "type": "MODEL",
                "slot_index": 0,
                "links": [
                  74
                ]
              }
            ],
            "properties": {
              "Node name for S&R": "ModelSamplingAuraFlow",
              "cnr_id": "comfy-core",
              "ver": "0.3.64",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            },
            "widgets_values": [
              3
            ]
          },
          {
            "id": 66,
            "type": "UNETLoader",
            "pos": [
              230,
              -90
            ],
            "size": [
              270,
              110
            ],
            "flags": {},
            "order": 4,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "unet_name",
                "name": "unet_name",
                "type": "COMBO",
                "widget": {
                  "name": "unet_name"
                },
                "link": 119
              },
              {
                "localized_name": "weight_dtype",
                "name": "weight_dtype",
                "type": "COMBO",
                "widget": {
                  "name": "weight_dtype"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "MODEL",
                "name": "MODEL",
                "type": "MODEL",
                "links": [
                  109
                ]
              }
            ],
            "properties": {
              "Node name for S&R": "UNETLoader",
              "cnr_id": "comfy-core",
              "ver": "0.3.73",
              "models": [
                {
                  "name": "z_image_bf16.safetensors",
                  "url": "https://huggingface.co/Comfy-Org/z_image/resolve/main/split_files/diffusion_models/z_image_bf16.safetensors",
                  "directory": "diffusion_models"
                }
              ],
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            },
            "widgets_values": [
              "z_image_bf16.safetensors",
              "default"
            ]
          },
          {
            "id": 71,
            "type": "CLIPTextEncode",
            "pos": [
              600,
              310
            ],
            "size": [
              390,
              140
            ],
            "flags": {},
            "order": 9,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "clip",
                "name": "clip",
                "type": "CLIP",
                "link": 82
              },
              {
                "label": "prompt",
                "localized_name": "text",
                "name": "text",
                "type": "STRING",
                "widget": {
                  "name": "text"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "CONDITIONING",
                "name": "CONDITIONING",
                "type": "CONDITIONING",
                "links": [
                  83
                ]
              }
            ],
            "title": "CLIP Text Encode (Negative Prompt)",
            "properties": {
              "Node name for S&R": "CLIPTextEncode",
              "cnr_id": "comfy-core",
              "ver": "0.3.73",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            },
            "widgets_values": [
              ""
            ],
            "color": "#323",
            "bgcolor": "#535"
          },
          {
            "id": 69,
            "type": "KSampler",
            "pos": [
              1100,
              10
            ],
            "size": [
              310,
              440
            ],
            "flags": {},
            "order": 7,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "model",
                "name": "model",
                "type": "MODEL",
                "link": 74
              },
              {
                "localized_name": "positive",
                "name": "positive",
                "type": "CONDITIONING",
                "link": 75
              },
              {
                "localized_name": "negative",
                "name": "negative",
                "type": "CONDITIONING",
                "link": 83
              },
              {
                "localized_name": "latent_image",
                "name": "latent_image",
                "type": "LATENT",
                "link": 77
              },
              {
                "localized_name": "seed",
                "name": "seed",
                "type": "INT",
                "widget": {
                  "name": "seed"
                },
                "link": 118
              },
              {
                "localized_name": "steps",
                "name": "steps",
                "type": "INT",
                "widget": {
                  "name": "steps"
                },
                "link": 116
              },
              {
                "localized_name": "cfg",
                "name": "cfg",
                "type": "FLOAT",
                "widget": {
                  "name": "cfg"
                },
                "link": 117
              },
              {
                "localized_name": "sampler_name",
                "name": "sampler_name",
                "type": "COMBO",
                "widget": {
                  "name": "sampler_name"
                },
                "link": null
              },
              {
                "localized_name": "scheduler",
                "name": "scheduler",
                "type": "COMBO",
                "widget": {
                  "name": "scheduler"
                },
                "link": null
              },
              {
                "localized_name": "denoise",
                "name": "denoise",
                "type": "FLOAT",
                "widget": {
                  "name": "denoise"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "LATENT",
                "name": "LATENT",
                "type": "LATENT",
                "slot_index": 0,
                "links": [
                  72
                ]
              }
            ],
            "properties": {
              "Node name for S&R": "KSampler",
              "cnr_id": "comfy-core",
              "ver": "0.3.64",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            },
            "widgets_values": [
              0,
              "randomize",
              25,
              4,
              "res_multistep",
              "simple",
              1
            ]
          },
          {
            "id": 87,
            "type": "MarkdownNote",
            "pos": [
              1110,
              -360
            ],
            "size": [
              300,
              120
            ],
            "flags": {},
            "order": 0,
            "mode": 0,
            "inputs": [],
            "outputs": [],
            "properties": {},
            "widgets_values": [
              "- Steps: 30～50\n- cfg:  3～5"
            ],
            "color": "#222",
            "bgcolor": "#000",
            "title": "Original Settings"
          }
        ],
        "groups": [
          {
            "id": 2,
            "title": "Step2 - Image size",
            "bounding": [
              200,
              530,
              330,
              287.9999544955691
            ],
            "color": "#3f789e",
            "flags": {}
          },
          {
            "id": 3,
            "title": "Step3 - Prompt",
            "bounding": [
              570,
              -200,
              470,
              700
            ],
            "color": "#3f789e",
            "flags": {}
          },
          {
            "id": 4,
            "title": "Step1 - Load models",
            "bounding": [
              200,
              -200,
              330,
              700
            ],
            "color": "#3f789e",
            "flags": {}
          }
        ],
        "links": [
          {
            "id": 78,
            "origin_id": 62,
            "origin_slot": 0,
            "target_id": 67,
            "target_slot": 0,
            "type": "CLIP"
          },
          {
            "id": 74,
            "origin_id": 70,
            "origin_slot": 0,
            "target_id": 69,
            "target_slot": 0,
            "type": "MODEL"
          },
          {
            "id": 75,
            "origin_id": 67,
            "origin_slot": 0,
            "target_id": 69,
            "target_slot": 1,
            "type": "CONDITIONING"
          },
          {
            "id": 83,
            "origin_id": 71,
            "origin_slot": 0,
            "target_id": 69,
            "target_slot": 2,
            "type": "CONDITIONING"
          },
          {
            "id": 77,
            "origin_id": 68,
            "origin_slot": 0,
            "target_id": 69,
            "target_slot": 3,
            "type": "LATENT"
          },
          {
            "id": 82,
            "origin_id": 62,
            "origin_slot": 0,
            "target_id": 71,
            "target_slot": 0,
            "type": "CLIP"
          },
          {
            "id": 72,
            "origin_id": 69,
            "origin_slot": 0,
            "target_id": 65,
            "target_slot": 0,
            "type": "LATENT"
          },
          {
            "id": 73,
            "origin_id": 63,
            "origin_slot": 0,
            "target_id": 65,
            "target_slot": 1,
            "type": "VAE"
          },
          {
            "id": 79,
            "origin_id": 65,
            "origin_slot": 0,
            "target_id": -20,
            "target_slot": 0,
            "type": "IMAGE"
          },
          {
            "id": 108,
            "origin_id": -10,
            "origin_slot": 0,
            "target_id": 67,
            "target_slot": 1,
            "type": "STRING"
          },
          {
            "id": 109,
            "origin_id": 66,
            "origin_slot": 0,
            "target_id": 70,
            "target_slot": 0,
            "type": "MODEL"
          },
          {
            "id": 114,
            "origin_id": -10,
            "origin_slot": 1,
            "target_id": 68,
            "target_slot": 0,
            "type": "INT"
          },
          {
            "id": 115,
            "origin_id": -10,
            "origin_slot": 2,
            "target_id": 68,
            "target_slot": 1,
            "type": "INT"
          },
          {
            "id": 116,
            "origin_id": -10,
            "origin_slot": 3,
            "target_id": 69,
            "target_slot": 5,
            "type": "INT"
          },
          {
            "id": 117,
            "origin_id": -10,
            "origin_slot": 4,
            "target_id": 69,
            "target_slot": 6,
            "type": "FLOAT"
          },
          {
            "id": 118,
            "origin_id": -10,
            "origin_slot": 5,
            "target_id": 69,
            "target_slot": 4,
            "type": "INT"
          },
          {
            "id": 119,
            "origin_id": -10,
            "origin_slot": 6,
            "target_id": 66,
            "target_slot": 0,
            "type": "COMBO"
          },
          {
            "id": 120,
            "origin_id": -10,
            "origin_slot": 7,
            "target_id": 62,
            "target_slot": 0,
            "type": "COMBO"
          },
          {
            "id": 121,
            "origin_id": -10,
            "origin_slot": 8,
            "target_id": 63,
            "target_slot": 0,
            "type": "COMBO"
          }
        ],
        "extra": {
          "workflowRendererVersion": "LG"
        },
        "category": "Image generation and editing/Text to image"
      }
    ]
  },
  "extra": {}
}
```
