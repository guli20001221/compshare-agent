# Image Depth Estimation (Lotus Depth)

- 来源类别：内置工作流蓝图
- 镜像内原始路径：`/ComfyUI/blueprints/Image Depth Estimation (Lotus Depth).json`
- 节点数量：1
- 连线数量：0

## 节点类型

- `96338968-1242-4f02-b6a1-d496af4bcffe` × 1

## 原始工作流 JSON

```json
{
  "revision": 0,
  "last_node_id": 76,
  "last_link_id": 0,
  "nodes": [
    {
      "id": 76,
      "type": "96338968-1242-4f02-b6a1-d496af4bcffe",
      "pos": [
        670,
        1280
      ],
      "size": [
        400,
        201.3125
      ],
      "flags": {},
      "order": 0,
      "mode": 0,
      "inputs": [
        {
          "localized_name": "pixels",
          "name": "pixels",
          "type": "IMAGE",
          "link": null
        },
        {
          "label": "depth_intensity",
          "name": "sigma",
          "type": "FLOAT",
          "widget": {
            "name": "sigma"
          },
          "link": null
        },
        {
          "name": "unet_name",
          "type": "COMBO",
          "widget": {
            "name": "unet_name"
          },
          "link": null
        },
        {
          "name": "vae_name",
          "type": "COMBO",
          "widget": {
            "name": "vae_name"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "localized_name": "IMAGE",
          "name": "IMAGE",
          "type": "IMAGE",
          "links": []
        }
      ],
      "title": "Image Depth Estimation (Lotus Depth)",
      "properties": {
        "proxyWidgets": [
          [
            "28",
            "sigma"
          ],
          [
            "10",
            "unet_name"
          ],
          [
            "14",
            "vae_name"
          ]
        ],
        "cnr_id": "comfy-core",
        "ver": "0.14.1"
      },
      "widgets_values": []
    }
  ],
  "links": [],
  "version": 0.4,
  "definitions": {
    "subgraphs": [
      {
        "id": "96338968-1242-4f02-b6a1-d496af4bcffe",
        "version": 1,
        "state": {
          "lastGroupId": 1,
          "lastNodeId": 76,
          "lastLinkId": 245,
          "lastRerouteId": 0
        },
        "revision": 0,
        "config": {},
        "name": "Image Depth Estimation (Lotus Depth)",
        "inputNode": {
          "id": -10,
          "bounding": [
            -60,
            -172.61268043518066,
            126.625,
            120
          ]
        },
        "outputNode": {
          "id": -20,
          "bounding": [
            1650,
            -172.61268043518066,
            120,
            60
          ]
        },
        "inputs": [
          {
            "id": "3bdd30c3-4ec9-485a-814b-e7d39fb6b5cc",
            "name": "pixels",
            "type": "IMAGE",
            "linkIds": [
              37
            ],
            "localized_name": "pixels",
            "pos": [
              46.625,
              -152.61268043518066
            ]
          },
          {
            "id": "f9a1017c-f4b9-43b4-94c2-41c088b3a492",
            "name": "sigma",
            "type": "FLOAT",
            "linkIds": [
              243
            ],
            "label": "depth_intensity",
            "pos": [
              46.625,
              -132.61268043518066
            ]
          },
          {
            "id": "cb96b9fe-93e7-41cf-b27f-6d6dc3a1890b",
            "name": "unet_name",
            "type": "COMBO",
            "linkIds": [
              244
            ],
            "pos": [
              46.625,
              -112.61268043518066
            ]
          },
          {
            "id": "42c8efad-1661-49c7-89b5-2b735b72424d",
            "name": "vae_name",
            "type": "COMBO",
            "linkIds": [
              245
            ],
            "pos": [
              46.625,
              -92.61268043518066
            ]
          }
        ],
        "outputs": [
          {
            "id": "2ec278bd-0b66-4b30-9c5b-994d5f638214",
            "name": "IMAGE",
            "type": "IMAGE",
            "linkIds": [
              242
            ],
            "localized_name": "IMAGE",
            "pos": [
              1670,
              -152.61268043518066
            ]
          }
        ],
        "widgets": [],
        "nodes": [
          {
            "id": 10,
            "type": "UNETLoader",
            "pos": [
              110,
              -250
            ],
            "size": [
              260,
              90
            ],
            "flags": {},
            "order": 4,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "unet_name",
                "name": "unet_name",
                "type": "COMBO",
                "widget": {
                  "name": "unet_name"
                },
                "link": 244
              },
              {
                "localized_name": "weight_dtype",
                "name": "weight_dtype",
                "type": "COMBO",
                "widget": {
                  "name": "weight_dtype"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "MODEL",
                "name": "MODEL",
                "type": "MODEL",
                "slot_index": 0,
                "links": [
                  31,
                  241
                ]
              }
            ],
            "properties": {
              "Node name for S&R": "UNETLoader",
              "cnr_id": "comfy-core",
              "ver": "0.3.34",
              "models": [
                {
                  "name": "lotus-depth-d-v1-1.safetensors",
                  "url": "https://huggingface.co/Comfy-Org/lotus/resolve/main/lotus-depth-d-v1-1.safetensors",
                  "directory": "diffusion_models"
                }
              ],
              "widget_ue_connectable": {}
            },
            "widgets_values": [
              "lotus-depth-d-v1-1.safetensors",
              "default"
            ]
          },
          {
            "id": 18,
            "type": "DisableNoise",
            "pos": [
              610,
              -270
            ],
            "size": [
              180,
              40
            ],
            "flags": {},
            "order": 0,
            "mode": 0,
            "inputs": [],
            "outputs": [
              {
                "localized_name": "NOISE",
                "name": "NOISE",
                "type": "NOISE",
                "slot_index": 0,
                "links": [
                  237
                ]
              }
            ],
            "properties": {
              "Node name for S&R": "DisableNoise",
              "cnr_id": "comfy-core",
              "ver": "0.3.34",
              "widget_ue_connectable": {}
            }
          },
          {
            "id": 74,
            "type": "VAEEncode",
            "pos": [
              620,
              160
            ],
            "size": [
              180,
              50
            ],
            "flags": {},
            "order": 11,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "pixels",
                "name": "pixels",
                "type": "IMAGE",
                "link": 37
              },
              {
                "localized_name": "vae",
                "name": "vae",
                "type": "VAE",
                "link": 38
              }
            ],
            "outputs": [
              {
                "localized_name": "LATENT",
                "name": "LATENT",
                "type": "LATENT",
                "slot_index": 0,
                "links": [
                  201
                ]
              }
            ],
            "properties": {
              "Node name for S&R": "VAEEncode",
              "cnr_id": "comfy-core",
              "ver": "0.3.34",
              "widget_ue_connectable": {}
            }
          },
          {
            "id": 21,
            "type": "KSamplerSelect",
            "pos": [
              610,
              -60
            ],
            "size": [
              210,
              60
            ],
            "flags": {},
            "order": 1,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "sampler_name",
                "name": "sampler_name",
                "type": "COMBO",
                "widget": {
                  "name": "sampler_name"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "SAMPLER",
                "name": "SAMPLER",
                "type": "SAMPLER",
                "slot_index": 0,
                "links": [
                  33
                ]
              }
            ],
            "properties": {
              "Node name for S&R": "KSamplerSelect",
              "cnr_id": "comfy-core",
              "ver": "0.3.34",
              "widget_ue_connectable": {}
            },
            "widgets_values": [
              "euler"
            ]
          },
          {
            "id": 19,
            "type": "BasicGuider",
            "pos": [
              610,
              -170
            ],
            "size": [
              180,
              50
            ],
            "flags": {},
            "order": 7,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "model",
                "name": "model",
                "type": "MODEL",
                "link": 241
              },
              {
                "localized_name": "conditioning",
                "name": "conditioning",
                "type": "CONDITIONING",
                "link": 238
              }
            ],
            "outputs": [
              {
                "localized_name": "GUIDER",
                "name": "GUIDER",
                "type": "GUIDER",
                "slot_index": 0,
                "links": [
                  27
                ]
              }
            ],
            "properties": {
              "Node name for S&R": "BasicGuider",
              "cnr_id": "comfy-core",
              "ver": "0.3.34",
              "widget_ue_connectable": {}
            }
          },
          {
            "id": 16,
            "type": "SamplerCustomAdvanced",
            "pos": [
              890,
              -130
            ],
            "size": [
              300,
              280
            ],
            "flags": {},
            "order": 6,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "noise",
                "name": "noise",
                "type": "NOISE",
                "link": 237
              },
              {
                "localized_name": "guider",
                "name": "guider",
                "type": "GUIDER",
                "link": 27
              },
              {
                "localized_name": "sampler",
                "name": "sampler",
                "type": "SAMPLER",
                "link": 33
              },
              {
                "localized_name": "sigmas",
                "name": "sigmas",
                "type": "SIGMAS",
                "link": 194
              },
              {
                "localized_name": "latent_image",
                "name": "latent_image",
                "type": "LATENT",
                "link": 201
              }
            ],
            "outputs": [
              {
                "localized_name": "output",
                "name": "output",
                "type": "LATENT",
                "slot_index": 0,
                "links": [
                  232
                ]
              },
              {
                "localized_name": "denoised_output",
                "name": "denoised_output",
                "type": "LATENT",
                "slot_index": 1,
                "links": []
              }
            ],
            "properties": {
              "Node name for S&R": "SamplerCustomAdvanced",
              "cnr_id": "comfy-core",
              "ver": "0.3.34",
              "widget_ue_connectable": {}
            }
          },
          {
            "id": 28,
            "type": "SetFirstSigma",
            "pos": [
              620,
              50
            ],
            "size": [
              210,
              60
            ],
            "flags": {},
            "order": 10,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "sigmas",
                "name": "sigmas",
                "type": "SIGMAS",
                "link": 66
              },
              {
                "localized_name": "sigma",
                "name": "sigma",
                "type": "FLOAT",
                "widget": {
                  "name": "sigma"
                },
                "link": 243
              }
            ],
            "outputs": [
              {
                "localized_name": "SIGMAS",
                "name": "SIGMAS",
                "type": "SIGMAS",
                "slot_index": 0,
                "links": [
                  194
                ]
              }
            ],
            "properties": {
              "Node name for S&R": "SetFirstSigma",
              "cnr_id": "comfy-core",
              "ver": "0.3.34",
              "widget_ue_connectable": {}
            },
            "widgets_values": [
              999.0000000000002
            ]
          },
          {
            "id": 8,
            "type": "VAEDecode",
            "pos": [
              1210,
              -120
            ],
            "size": [
              180,
              50
            ],
            "flags": {},
            "order": 3,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "samples",
                "name": "samples",
                "type": "LATENT",
                "link": 232
              },
              {
                "localized_name": "vae",
                "name": "vae",
                "type": "VAE",
                "link": 240
              }
            ],
            "outputs": [
              {
                "localized_name": "IMAGE",
                "name": "IMAGE",
                "type": "IMAGE",
                "slot_index": 0,
                "links": [
                  35
                ]
              }
            ],
            "properties": {
              "Node name for S&R": "VAEDecode",
              "cnr_id": "comfy-core",
              "ver": "0.3.34",
              "widget_ue_connectable": {}
            }
          },
          {
            "id": 22,
            "type": "ImageInvert",
            "pos": [
              1200,
              -220
            ],
            "size": [
              180,
              40
            ],
            "flags": {},
            "order": 9,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "image",
                "name": "image",
                "type": "IMAGE",
                "link": 35
              }
            ],
            "outputs": [
              {
                "localized_name": "IMAGE",
                "name": "IMAGE",
                "type": "IMAGE",
                "slot_index": 0,
                "links": [
                  242
                ]
              }
            ],
            "properties": {
              "Node name for S&R": "ImageInvert",
              "cnr_id": "comfy-core",
              "ver": "0.3.34",
              "widget_ue_connectable": {}
            }
          },
          {
            "id": 14,
            "type": "VAELoader",
            "pos": [
              120,
              -90
            ],
            "size": [
              260,
              60
            ],
            "flags": {},
            "order": 5,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "vae_name",
                "name": "vae_name",
                "type": "COMBO",
                "widget": {
                  "name": "vae_name"
                },
                "link": 245
              }
            ],
            "outputs": [
              {
                "localized_name": "VAE",
                "name": "VAE",
                "type": "VAE",
                "slot_index": 0,
                "links": [
                  38,
                  240
                ]
              }
            ],
            "properties": {
              "Node name for S&R": "VAELoader",
              "cnr_id": "comfy-core",
              "ver": "0.3.34",
              "models": [
                {
                  "name": "vae-ft-mse-840000-ema-pruned.safetensors",
                  "url": "https://huggingface.co/stabilityai/sd-vae-ft-mse-original/resolve/main/vae-ft-mse-840000-ema-pruned.safetensors",
                  "directory": "vae"
                }
              ],
              "widget_ue_connectable": {}
            },
            "widgets_values": [
              "vae-ft-mse-840000-ema-pruned.safetensors"
            ]
          },
          {
            "id": 75,
            "type": "LotusConditioning",
            "pos": [
              400,
              -150
            ],
            "size": [
              180,
              40
            ],
            "flags": {},
            "order": 2,
            "mode": 0,
            "inputs": [],
            "outputs": [
              {
                "localized_name": "conditioning",
                "name": "conditioning",
                "type": "CONDITIONING",
                "slot_index": 0,
                "links": [
                  238
                ]
              }
            ],
            "properties": {
              "Node name for S&R": "LotusConditioning",
              "cnr_id": "comfy-core",
              "ver": "0.3.34",
              "widget_ue_connectable": {}
            }
          },
          {
            "id": 20,
            "type": "BasicScheduler",
            "pos": [
              170,
              40
            ],
            "size": [
              210,
              110
            ],
            "flags": {},
            "order": 8,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "model",
                "name": "model",
                "type": "MODEL",
                "link": 31
              },
              {
                "localized_name": "scheduler",
                "name": "scheduler",
                "type": "COMBO",
                "widget": {
                  "name": "scheduler"
                },
                "link": null
              },
              {
                "localized_name": "steps",
                "name": "steps",
                "type": "INT",
                "widget": {
                  "name": "steps"
                },
                "link": null
              },
              {
                "localized_name": "denoise",
                "name": "denoise",
                "type": "FLOAT",
                "widget": {
                  "name": "denoise"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "SIGMAS",
                "name": "SIGMAS",
                "type": "SIGMAS",
                "slot_index": 0,
                "links": [
                  66
                ]
              }
            ],
            "properties": {
              "Node name for S&R": "BasicScheduler",
              "cnr_id": "comfy-core",
              "ver": "0.3.34",
              "widget_ue_connectable": {}
            },
            "widgets_values": [
              "normal",
              1,
              1
            ]
          }
        ],
        "groups": [],
        "links": [
          {
            "id": 232,
            "origin_id": 16,
            "origin_slot": 0,
            "target_id": 8,
            "target_slot": 0,
            "type": "LATENT"
          },
          {
            "id": 240,
            "origin_id": 14,
            "origin_slot": 0,
            "target_id": 8,
            "target_slot": 1,
            "type": "VAE"
          },
          {
            "id": 237,
            "origin_id": 18,
            "origin_slot": 0,
            "target_id": 16,
            "target_slot": 0,
            "type": "NOISE"
          },
          {
            "id": 27,
            "origin_id": 19,
            "origin_slot": 0,
            "target_id": 16,
            "target_slot": 1,
            "type": "GUIDER"
          },
          {
            "id": 33,
            "origin_id": 21,
            "origin_slot": 0,
            "target_id": 16,
            "target_slot": 2,
            "type": "SAMPLER"
          },
          {
            "id": 194,
            "origin_id": 28,
            "origin_slot": 0,
            "target_id": 16,
            "target_slot": 3,
            "type": "SIGMAS"
          },
          {
            "id": 201,
            "origin_id": 74,
            "origin_slot": 0,
            "target_id": 16,
            "target_slot": 4,
            "type": "LATENT"
          },
          {
            "id": 241,
            "origin_id": 10,
            "origin_slot": 0,
            "target_id": 19,
            "target_slot": 0,
            "type": "MODEL"
          },
          {
            "id": 238,
            "origin_id": 75,
            "origin_slot": 0,
            "target_id": 19,
            "target_slot": 1,
            "type": "CONDITIONING"
          },
          {
            "id": 31,
            "origin_id": 10,
            "origin_slot": 0,
            "target_id": 20,
            "target_slot": 0,
            "type": "MODEL"
          },
          {
            "id": 35,
            "origin_id": 8,
            "origin_slot": 0,
            "target_id": 22,
            "target_slot": 0,
            "type": "IMAGE"
          },
          {
            "id": 38,
            "origin_id": 14,
            "origin_slot": 0,
            "target_id": 74,
            "target_slot": 1,
            "type": "VAE"
          },
          {
            "id": 66,
            "origin_id": 20,
            "origin_slot": 0,
            "target_id": 28,
            "target_slot": 0,
            "type": "SIGMAS"
          },
          {
            "id": 37,
            "origin_id": -10,
            "origin_slot": 0,
            "target_id": 74,
            "target_slot": 0,
            "type": "IMAGE"
          },
          {
            "id": 242,
            "origin_id": 22,
            "origin_slot": 0,
            "target_id": -20,
            "target_slot": 0,
            "type": "IMAGE"
          },
          {
            "id": 243,
            "origin_id": -10,
            "origin_slot": 1,
            "target_id": 28,
            "target_slot": 1,
            "type": "FLOAT"
          },
          {
            "id": 244,
            "origin_id": -10,
            "origin_slot": 2,
            "target_id": 10,
            "target_slot": 0,
            "type": "COMBO"
          },
          {
            "id": 245,
            "origin_id": -10,
            "origin_slot": 3,
            "target_id": 14,
            "target_slot": 0,
            "type": "COMBO"
          }
        ],
        "extra": {
          "workflowRendererVersion": "LG"
        },
        "category": "Conditioning & Preprocessors/Depth",
        "description": "Estimates a monocular depth map from an input image using the Lotus depth estimation model."
      }
    ]
  },
  "extra": {
    "ds": {
      "scale": 1.3589709866044692,
      "offset": [
        -138.53613935617864,
        -786.0629126022195
      ]
    }
  }
}
```
