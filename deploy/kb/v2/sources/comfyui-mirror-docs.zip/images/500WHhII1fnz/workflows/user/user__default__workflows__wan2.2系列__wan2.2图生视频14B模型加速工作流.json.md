# wan2.2图生视频14B模型加速工作流

- 来源类别：用户工作流
- 镜像内原始路径：`/ComfyUI/user/default/workflows/wan2.2系列/wan2.2图生视频14B模型加速工作流.json`
- 节点数量：19
- 连线数量：24

## 节点类型

- `CLIPTextEncode` × 2
- `KSamplerAdvanced` × 2
- `LoraLoaderModelOnly` × 2
- `ModelSamplingSD3` × 2
- `PathchSageAttentionKJ` × 2
- `UNETLoader` × 2
- `CLIPLoader` × 1
- `CreateVideo` × 1
- `LoadImage` × 1
- `SaveVideo` × 1
- `VAEDecode` × 1
- `VAELoader` × 1
- `WanImageToVideo` × 1

## 工作流引用的模型或媒体文件

- `caled.safetensors`
- `e_14B_fp16.safetensors`
- `till_rank256_bf16.safetensors`
- `wan_2.1_vae.safetensors`

## 原始工作流 JSON

```json
{
  "id": "ec7da562-7e21-4dac-a0d2-f4441e1efd3b",
  "revision": 0,
  "last_node_id": 75,
  "last_link_id": 154,
  "nodes": [
    {
      "id": 8,
      "type": "VAEDecode",
      "pos": [
        1240,
        -40
      ],
      "size": [
        210,
        46
      ],
      "flags": {},
      "order": 16,
      "mode": 0,
      "inputs": [
        {
          "label": "Latent",
          "localized_name": "Latent",
          "name": "samples",
          "type": "LATENT",
          "link": 124
        },
        {
          "label": "VAE",
          "localized_name": "vae",
          "name": "vae",
          "type": "VAE",
          "link": 76
        }
      ],
      "outputs": [
        {
          "label": "图像",
          "localized_name": "图像",
          "name": "IMAGE",
          "type": "IMAGE",
          "slot_index": 0,
          "links": [
            131
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.45",
        "Node name for S&R": "VAEDecode"
      },
      "widgets_values": []
    },
    {
      "id": 7,
      "type": "CLIPTextEncode",
      "pos": [
        420,
        410
      ],
      "size": [
        425.27801513671875,
        180.6060791015625
      ],
      "flags": {},
      "order": 6,
      "mode": 0,
      "inputs": [
        {
          "label": "CLIP",
          "localized_name": "clip",
          "name": "clip",
          "type": "CLIP",
          "link": 75
        },
        {
          "localized_name": "文本",
          "name": "text",
          "type": "STRING",
          "widget": {
            "name": "text"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "条件",
          "localized_name": "条件",
          "name": "CONDITIONING",
          "type": "CONDITIONING",
          "slot_index": 0,
          "links": [
            135
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.45",
        "Node name for S&R": "CLIPTextEncode"
      },
      "widgets_values": [
        "色调艳丽，过曝，静态，细节模糊不清，字幕，风格，作品，画作，画面，静止，整体发灰，最差质量，低质量，JPEG压缩残留，丑陋的，残缺的，多余的手指，画得不好的手部，画得不好的脸部，畸形的，毁容的，形态畸形的肢体，手指融合，静止不动的画面，杂乱的背景，三条腿，背景人很多，倒着走"
      ],
      "color": "#322",
      "bgcolor": "#533"
    },
    {
      "id": 38,
      "type": "CLIPLoader",
      "pos": [
        38.86457061767578,
        189.26513671875
      ],
      "size": [
        346.391845703125,
        106
      ],
      "flags": {},
      "order": 0,
      "mode": 0,
      "inputs": [
        {
          "localized_name": "CLIP名称",
          "name": "clip_name",
          "type": "COMBO",
          "widget": {
            "name": "clip_name"
          },
          "link": null
        },
        {
          "localized_name": "类型",
          "name": "type",
          "type": "COMBO",
          "widget": {
            "name": "type"
          },
          "link": null
        },
        {
          "localized_name": "设备",
          "name": "device",
          "shape": 7,
          "type": "COMBO",
          "widget": {
            "name": "device"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "CLIP",
          "localized_name": "CLIP",
          "name": "CLIP",
          "type": "CLIP",
          "slot_index": 0,
          "links": [
            74,
            75
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.45",
        "Node name for S&R": "CLIPLoader",
        "models": [
          {
            "name": "umt5_xxl_fp8_e4m3fn_scaled.safetensors",
            "url": "https://huggingface.co/Comfy-Org/Wan_2.1_ComfyUI_repackaged/resolve/main/split_files/text_encoders/umt5_xxl_fp8_e4m3fn_scaled.safetensors",
            "directory": "text_encoders"
          }
        ]
      },
      "widgets_values": [
        "umt5_xxl_fp8_e4m3fn_scaled.safetensors",
        "wan",
        "default"
      ]
    },
    {
      "id": 39,
      "type": "VAELoader",
      "pos": [
        40,
        350
      ],
      "size": [
        344.731689453125,
        59.98149108886719
      ],
      "flags": {},
      "order": 1,
      "mode": 0,
      "inputs": [
        {
          "localized_name": "vae名称",
          "name": "vae_name",
          "type": "COMBO",
          "widget": {
            "name": "vae_name"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "localized_name": "VAE",
          "name": "VAE",
          "type": "VAE",
          "slot_index": 0,
          "links": [
            76,
            141
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.45",
        "Node name for S&R": "VAELoader",
        "models": [
          {
            "name": "wan_2.1_vae.safetensors",
            "url": "https://huggingface.co/Comfy-Org/Wan_2.2_ComfyUI_Repackaged/resolve/main/split_files/vae/wan_2.1_vae.safetensors",
            "directory": "vae"
          }
        ]
      },
      "widgets_values": [
        "wan_2.1_vae.safetensors"
      ]
    },
    {
      "id": 57,
      "type": "KSamplerAdvanced",
      "pos": [
        890,
        -60
      ],
      "size": [
        304.748046875,
        334
      ],
      "flags": {},
      "order": 14,
      "mode": 0,
      "inputs": [
        {
          "label": "模型",
          "localized_name": "模型",
          "name": "model",
          "type": "MODEL",
          "link": 147
        },
        {
          "label": "正面条件",
          "localized_name": "正面条件",
          "name": "positive",
          "type": "CONDITIONING",
          "link": 136
        },
        {
          "label": "负面条件",
          "localized_name": "负面条件",
          "name": "negative",
          "type": "CONDITIONING",
          "link": 137
        },
        {
          "label": "Latent",
          "localized_name": "Latent图像",
          "name": "latent_image",
          "type": "LATENT",
          "link": 140
        },
        {
          "localized_name": "添加噪波",
          "name": "add_noise",
          "type": "COMBO",
          "widget": {
            "name": "add_noise"
          },
          "link": null
        },
        {
          "localized_name": "随机种",
          "name": "noise_seed",
          "type": "INT",
          "widget": {
            "name": "noise_seed"
          },
          "link": null
        },
        {
          "localized_name": "步数",
          "name": "steps",
          "type": "INT",
          "widget": {
            "name": "steps"
          },
          "link": null
        },
        {
          "localized_name": "CFG",
          "name": "cfg",
          "type": "FLOAT",
          "widget": {
            "name": "cfg"
          },
          "link": null
        },
        {
          "localized_name": "采样器",
          "name": "sampler_name",
          "type": "COMBO",
          "widget": {
            "name": "sampler_name"
          },
          "link": null
        },
        {
          "localized_name": "调度器",
          "name": "scheduler",
          "type": "COMBO",
          "widget": {
            "name": "scheduler"
          },
          "link": null
        },
        {
          "localized_name": "开始降噪步数",
          "name": "start_at_step",
          "type": "INT",
          "widget": {
            "name": "start_at_step"
          },
          "link": null
        },
        {
          "localized_name": "结束降噪步数",
          "name": "end_at_step",
          "type": "INT",
          "widget": {
            "name": "end_at_step"
          },
          "link": null
        },
        {
          "localized_name": "返回噪波",
          "name": "return_with_leftover_noise",
          "type": "COMBO",
          "widget": {
            "name": "return_with_leftover_noise"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "Latent",
          "localized_name": "Latent",
          "name": "LATENT",
          "type": "LATENT",
          "links": [
            113
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.45",
        "Node name for S&R": "KSamplerAdvanced"
      },
      "widgets_values": [
        "enable",
        496345172287810,
        "randomize",
        8,
        1,
        "euler",
        "simple",
        0,
        4,
        "enable"
      ]
    },
    {
      "id": 63,
      "type": "WanImageToVideo",
      "pos": [
        450,
        690
      ],
      "size": [
        342.5999755859375,
        210
      ],
      "flags": {},
      "order": 9,
      "mode": 0,
      "inputs": [
        {
          "label": "positive",
          "localized_name": "正面",
          "name": "positive",
          "type": "CONDITIONING",
          "link": 134
        },
        {
          "label": "negative",
          "localized_name": "负面",
          "name": "negative",
          "type": "CONDITIONING",
          "link": 135
        },
        {
          "label": "vae",
          "localized_name": "vae",
          "name": "vae",
          "type": "VAE",
          "link": 141
        },
        {
          "label": "clip_vision_output",
          "localized_name": "clip视觉输出",
          "name": "clip_vision_output",
          "shape": 7,
          "type": "CLIP_VISION_OUTPUT",
          "link": null
        },
        {
          "label": "start_image",
          "localized_name": "开始图像",
          "name": "start_image",
          "shape": 7,
          "type": "IMAGE",
          "link": 133
        },
        {
          "label": "width",
          "localized_name": "宽度",
          "name": "width",
          "type": "INT",
          "widget": {
            "name": "width"
          },
          "link": null
        },
        {
          "label": "height",
          "localized_name": "高度",
          "name": "height",
          "type": "INT",
          "widget": {
            "name": "height"
          },
          "link": null
        },
        {
          "label": "length",
          "localized_name": "长度",
          "name": "length",
          "type": "INT",
          "widget": {
            "name": "length"
          },
          "link": null
        },
        {
          "label": "batch_size",
          "localized_name": "批量大小",
          "name": "batch_size",
          "type": "INT",
          "widget": {
            "name": "batch_size"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "positive",
          "localized_name": "正面",
          "name": "positive",
          "type": "CONDITIONING",
          "slot_index": 0,
          "links": [
            136,
            138
          ]
        },
        {
          "label": "negative",
          "localized_name": "负面",
          "name": "negative",
          "type": "CONDITIONING",
          "slot_index": 1,
          "links": [
            137,
            139
          ]
        },
        {
          "label": "latent",
          "localized_name": "潜在",
          "name": "latent",
          "type": "LATENT",
          "slot_index": 2,
          "links": [
            140
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.45",
        "Node name for S&R": "WanImageToVideo"
      },
      "widgets_values": [
        1280,
        720,
        81,
        1
      ]
    },
    {
      "id": 60,
      "type": "CreateVideo",
      "pos": [
        1240,
        60
      ],
      "size": [
        270,
        78
      ],
      "flags": {},
      "order": 17,
      "mode": 0,
      "inputs": [
        {
          "label": "images",
          "localized_name": "图像",
          "name": "images",
          "type": "IMAGE",
          "link": 131
        },
        {
          "label": "audio",
          "localized_name": "音频",
          "name": "audio",
          "shape": 7,
          "type": "AUDIO",
          "link": null
        },
        {
          "label": "fps",
          "localized_name": "帧率",
          "name": "fps",
          "type": "FLOAT",
          "widget": {
            "name": "fps"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "VIDEO",
          "localized_name": "视频",
          "name": "VIDEO",
          "type": "VIDEO",
          "links": [
            132
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.45",
        "Node name for S&R": "CreateVideo"
      },
      "widgets_values": [
        16
      ]
    },
    {
      "id": 62,
      "type": "LoadImage",
      "pos": [
        50,
        570
      ],
      "size": [
        315,
        314
      ],
      "flags": {},
      "order": 2,
      "mode": 0,
      "inputs": [
        {
          "localized_name": "图像",
          "name": "image",
          "type": "COMBO",
          "widget": {
            "name": "image"
          },
          "link": null
        },
        {
          "localized_name": "选择文件上传",
          "name": "upload",
          "type": "IMAGEUPLOAD",
          "widget": {
            "name": "upload"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "图像",
          "localized_name": "图像",
          "name": "IMAGE",
          "type": "IMAGE",
          "slot_index": 0,
          "links": [
            133
          ]
        },
        {
          "label": "遮罩",
          "localized_name": "遮罩",
          "name": "MASK",
          "type": "MASK",
          "slot_index": 1,
          "links": null
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.45",
        "Node name for S&R": "LoadImage"
      },
      "widgets_values": [
        "图片 (3).png",
        "image"
      ]
    },
    {
      "id": 6,
      "type": "CLIPTextEncode",
      "pos": [
        420,
        210
      ],
      "size": [
        422.84503173828125,
        164.31304931640625
      ],
      "flags": {},
      "order": 5,
      "mode": 0,
      "inputs": [
        {
          "label": "CLIP",
          "localized_name": "clip",
          "name": "clip",
          "type": "CLIP",
          "link": 74
        },
        {
          "localized_name": "文本",
          "name": "text",
          "type": "STRING",
          "widget": {
            "name": "text"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "条件",
          "localized_name": "条件",
          "name": "CONDITIONING",
          "type": "CONDITIONING",
          "slot_index": 0,
          "links": [
            134
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.45",
        "Node name for S&R": "CLIPTextEncode"
      },
      "widgets_values": [
        "The girl extended a finger to her mouth and closed one eye to make a wink"
      ],
      "color": "#232",
      "bgcolor": "#353"
    },
    {
      "id": 37,
      "type": "UNETLoader",
      "pos": [
        34.225364685058594,
        -71.77911376953125
      ],
      "size": [
        346.7470703125,
        82
      ],
      "flags": {},
      "order": 3,
      "mode": 0,
      "inputs": [
        {
          "localized_name": "UNET名称",
          "name": "unet_name",
          "type": "COMBO",
          "widget": {
            "name": "unet_name"
          },
          "link": null
        },
        {
          "localized_name": "剪枝类型",
          "name": "weight_dtype",
          "type": "COMBO",
          "widget": {
            "name": "weight_dtype"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "模型",
          "localized_name": "模型",
          "name": "MODEL",
          "type": "MODEL",
          "slot_index": 0,
          "links": [
            150
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.45",
        "Node name for S&R": "UNETLoader",
        "models": [
          {
            "name": "wan2.2_i2v_high_noise_14B_fp8_scaled.safetensors",
            "url": "https://huggingface.co/Comfy-Org/Wan_2.2_ComfyUI_Repackaged/resolve/main/split_files/diffusion_models/wan2.2_i2v_high_noise_14B_fp8_scaled.safetensors",
            "directory": "diffusion_models"
          }
        ]
      },
      "widgets_values": [
        "wan2.2_i2v_high_noise_14B_fp16.safetensors",
        "fp8_e4m3fn"
      ]
    },
    {
      "id": 56,
      "type": "UNETLoader",
      "pos": [
        34.70310592651367,
        57.175601959228516
      ],
      "size": [
        346.7470703125,
        82
      ],
      "flags": {},
      "order": 4,
      "mode": 0,
      "inputs": [
        {
          "localized_name": "UNET名称",
          "name": "unet_name",
          "type": "COMBO",
          "widget": {
            "name": "unet_name"
          },
          "link": null
        },
        {
          "localized_name": "剪枝类型",
          "name": "weight_dtype",
          "type": "COMBO",
          "widget": {
            "name": "weight_dtype"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "模型",
          "localized_name": "模型",
          "name": "MODEL",
          "type": "MODEL",
          "slot_index": 0,
          "links": [
            153
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.45",
        "Node name for S&R": "UNETLoader",
        "models": [
          {
            "name": "wan2.2_i2v_low_noise_14B_fp8_scaled.safetensors",
            "url": "https://huggingface.co/Comfy-Org/Wan_2.2_ComfyUI_Repackaged/resolve/main/split_files/diffusion_models/wan2.2_i2v_low_noise_14B_fp8_scaled.safetensors",
            "directory": "diffusion_models"
          }
        ]
      },
      "widgets_values": [
        "wan2.2_i2v_low_noise_14B_fp16.safetensors",
        "fp8_e4m3fn"
      ]
    },
    {
      "id": 58,
      "type": "KSamplerAdvanced",
      "pos": [
        890,
        360
      ],
      "size": [
        304.748046875,
        498.6905822753906
      ],
      "flags": {},
      "order": 15,
      "mode": 0,
      "inputs": [
        {
          "label": "模型",
          "localized_name": "模型",
          "name": "model",
          "type": "MODEL",
          "link": 148
        },
        {
          "label": "正面条件",
          "localized_name": "正面条件",
          "name": "positive",
          "type": "CONDITIONING",
          "link": 138
        },
        {
          "label": "负面条件",
          "localized_name": "负面条件",
          "name": "negative",
          "type": "CONDITIONING",
          "link": 139
        },
        {
          "label": "Latent",
          "localized_name": "Latent图像",
          "name": "latent_image",
          "type": "LATENT",
          "link": 113
        },
        {
          "localized_name": "添加噪波",
          "name": "add_noise",
          "type": "COMBO",
          "widget": {
            "name": "add_noise"
          },
          "link": null
        },
        {
          "localized_name": "随机种",
          "name": "noise_seed",
          "type": "INT",
          "widget": {
            "name": "noise_seed"
          },
          "link": null
        },
        {
          "localized_name": "步数",
          "name": "steps",
          "type": "INT",
          "widget": {
            "name": "steps"
          },
          "link": null
        },
        {
          "localized_name": "CFG",
          "name": "cfg",
          "type": "FLOAT",
          "widget": {
            "name": "cfg"
          },
          "link": null
        },
        {
          "localized_name": "采样器",
          "name": "sampler_name",
          "type": "COMBO",
          "widget": {
            "name": "sampler_name"
          },
          "link": null
        },
        {
          "localized_name": "调度器",
          "name": "scheduler",
          "type": "COMBO",
          "widget": {
            "name": "scheduler"
          },
          "link": null
        },
        {
          "localized_name": "开始降噪步数",
          "name": "start_at_step",
          "type": "INT",
          "widget": {
            "name": "start_at_step"
          },
          "link": null
        },
        {
          "localized_name": "结束降噪步数",
          "name": "end_at_step",
          "type": "INT",
          "widget": {
            "name": "end_at_step"
          },
          "link": null
        },
        {
          "localized_name": "返回噪波",
          "name": "return_with_leftover_noise",
          "type": "COMBO",
          "widget": {
            "name": "return_with_leftover_noise"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "Latent",
          "localized_name": "Latent",
          "name": "LATENT",
          "type": "LATENT",
          "links": [
            124
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.45",
        "Node name for S&R": "KSamplerAdvanced"
      },
      "widgets_values": [
        "disable",
        0,
        "fixed",
        8,
        1,
        "euler",
        "simple",
        4,
        10000,
        "disable"
      ]
    },
    {
      "id": 55,
      "type": "ModelSamplingSD3",
      "pos": [
        647.2962646484375,
        70.42301177978516
      ],
      "size": [
        210,
        58
      ],
      "flags": {},
      "order": 13,
      "mode": 0,
      "inputs": [
        {
          "label": "模型",
          "localized_name": "模型",
          "name": "model",
          "type": "MODEL",
          "link": 154
        },
        {
          "localized_name": "偏移",
          "name": "shift",
          "type": "FLOAT",
          "widget": {
            "name": "shift"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "模型",
          "localized_name": "模型",
          "name": "MODEL",
          "type": "MODEL",
          "slot_index": 0,
          "links": [
            148
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.45",
        "Node name for S&R": "ModelSamplingSD3"
      },
      "widgets_values": [
        8
      ]
    },
    {
      "id": 68,
      "type": "PathchSageAttentionKJ",
      "pos": [
        415.1214294433594,
        73.9180908203125
      ],
      "size": [
        210,
        58
      ],
      "flags": {
        "collapsed": false
      },
      "order": 10,
      "mode": 0,
      "inputs": [
        {
          "label": "model",
          "localized_name": "model",
          "name": "model",
          "type": "MODEL",
          "link": 149
        },
        {
          "label": "sage_attention",
          "localized_name": "sage_attention",
          "name": "sage_attention",
          "type": "COMBO",
          "widget": {
            "name": "sage_attention"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "MODEL",
          "localized_name": "模型",
          "name": "MODEL",
          "type": "MODEL",
          "links": [
            151
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "PathchSageAttentionKJ",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "auto"
      ]
    },
    {
      "id": 70,
      "type": "PathchSageAttentionKJ",
      "pos": [
        414.0581359863281,
        -24.71457290649414
      ],
      "size": [
        210,
        58
      ],
      "flags": {
        "collapsed": false
      },
      "order": 11,
      "mode": 0,
      "inputs": [
        {
          "label": "model",
          "localized_name": "model",
          "name": "model",
          "type": "MODEL",
          "link": 152
        },
        {
          "label": "sage_attention",
          "localized_name": "sage_attention",
          "name": "sage_attention",
          "type": "COMBO",
          "widget": {
            "name": "sage_attention"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "MODEL",
          "localized_name": "模型",
          "name": "MODEL",
          "type": "MODEL",
          "links": [
            154
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "PathchSageAttentionKJ",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "auto"
      ]
    },
    {
      "id": 54,
      "type": "ModelSamplingSD3",
      "pos": [
        649.6350708007812,
        -27.254718780517578
      ],
      "size": [
        210,
        60
      ],
      "flags": {},
      "order": 12,
      "mode": 0,
      "inputs": [
        {
          "label": "模型",
          "localized_name": "模型",
          "name": "model",
          "type": "MODEL",
          "link": 151
        },
        {
          "localized_name": "偏移",
          "name": "shift",
          "type": "FLOAT",
          "widget": {
            "name": "shift"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "模型",
          "localized_name": "模型",
          "name": "MODEL",
          "type": "MODEL",
          "slot_index": 0,
          "links": [
            147
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.45",
        "Node name for S&R": "ModelSamplingSD3"
      },
      "widgets_values": [
        8.000000000000002
      ]
    },
    {
      "id": 61,
      "type": "SaveVideo",
      "pos": [
        1240,
        190
      ],
      "size": [
        1202.205322265625,
        712.625732421875
      ],
      "flags": {},
      "order": 18,
      "mode": 0,
      "inputs": [
        {
          "label": "video",
          "localized_name": "视频",
          "name": "video",
          "type": "VIDEO",
          "link": 132
        },
        {
          "label": "filename_prefix",
          "localized_name": "文件名前缀",
          "name": "filename_prefix",
          "type": "STRING",
          "widget": {
            "name": "filename_prefix"
          },
          "link": null
        },
        {
          "label": "format",
          "localized_name": "格式",
          "name": "format",
          "type": "COMBO",
          "widget": {
            "name": "format"
          },
          "link": null
        },
        {
          "label": "codec",
          "localized_name": "编码器",
          "name": "codec",
          "type": "COMBO",
          "widget": {
            "name": "codec"
          },
          "link": null
        }
      ],
      "outputs": [],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.45",
        "Node name for S&R": "SaveVideo"
      },
      "widgets_values": [
        "video/ComfyUI",
        "auto",
        "auto"
      ]
    },
    {
      "id": 67,
      "type": "LoraLoaderModelOnly",
      "pos": [
        420.0476989746094,
        -142.43905639648438
      ],
      "size": [
        210,
        82
      ],
      "flags": {
        "collapsed": false
      },
      "order": 7,
      "mode": 0,
      "inputs": [
        {
          "label": "模型",
          "localized_name": "模型",
          "name": "model",
          "type": "MODEL",
          "link": 150
        },
        {
          "localized_name": "LoRA名称",
          "name": "lora_name",
          "type": "COMBO",
          "widget": {
            "name": "lora_name"
          },
          "link": null
        },
        {
          "localized_name": "模型强度",
          "name": "strength_model",
          "type": "FLOAT",
          "widget": {
            "name": "strength_model"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "模型",
          "localized_name": "模型",
          "name": "MODEL",
          "type": "MODEL",
          "links": [
            149
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.47",
        "Node name for S&R": "LoraLoaderModelOnly",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "lightx2v/lightx2v_I2V_14B_480p_cfg_step_distill_rank256_bf16.safetensors",
        1
      ]
    },
    {
      "id": 69,
      "type": "LoraLoaderModelOnly",
      "pos": [
        648.5441284179688,
        -145.42861938476562
      ],
      "size": [
        210,
        82
      ],
      "flags": {
        "collapsed": false
      },
      "order": 8,
      "mode": 0,
      "inputs": [
        {
          "label": "模型",
          "localized_name": "模型",
          "name": "model",
          "type": "MODEL",
          "link": 153
        },
        {
          "localized_name": "LoRA名称",
          "name": "lora_name",
          "type": "COMBO",
          "widget": {
            "name": "lora_name"
          },
          "link": null
        },
        {
          "localized_name": "模型强度",
          "name": "strength_model",
          "type": "FLOAT",
          "widget": {
            "name": "strength_model"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "模型",
          "localized_name": "模型",
          "name": "MODEL",
          "type": "MODEL",
          "links": [
            152
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.47",
        "Node name for S&R": "LoraLoaderModelOnly",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "lightx2v/lightx2v_I2V_14B_480p_cfg_step_distill_rank256_bf16.safetensors",
        1
      ]
    }
  ],
  "links": [
    [
      74,
      38,
      0,
      6,
      0,
      "CLIP"
    ],
    [
      75,
      38,
      0,
      7,
      0,
      "CLIP"
    ],
    [
      76,
      39,
      0,
      8,
      1,
      "VAE"
    ],
    [
      113,
      57,
      0,
      58,
      3,
      "LATENT"
    ],
    [
      124,
      58,
      0,
      8,
      0,
      "LATENT"
    ],
    [
      131,
      8,
      0,
      60,
      0,
      "IMAGE"
    ],
    [
      132,
      60,
      0,
      61,
      0,
      "VIDEO"
    ],
    [
      133,
      62,
      0,
      63,
      4,
      "IMAGE"
    ],
    [
      134,
      6,
      0,
      63,
      0,
      "CONDITIONING"
    ],
    [
      135,
      7,
      0,
      63,
      1,
      "CONDITIONING"
    ],
    [
      136,
      63,
      0,
      57,
      1,
      "CONDITIONING"
    ],
    [
      137,
      63,
      1,
      57,
      2,
      "CONDITIONING"
    ],
    [
      138,
      63,
      0,
      58,
      1,
      "CONDITIONING"
    ],
    [
      139,
      63,
      1,
      58,
      2,
      "CONDITIONING"
    ],
    [
      140,
      63,
      2,
      57,
      3,
      "LATENT"
    ],
    [
      141,
      39,
      0,
      63,
      2,
      "VAE"
    ],
    [
      147,
      54,
      0,
      57,
      0,
      "MODEL"
    ],
    [
      148,
      55,
      0,
      58,
      0,
      "MODEL"
    ],
    [
      149,
      67,
      0,
      68,
      0,
      "MODEL"
    ],
    [
      150,
      37,
      0,
      67,
      0,
      "MODEL"
    ],
    [
      151,
      68,
      0,
      54,
      0,
      "MODEL"
    ],
    [
      152,
      69,
      0,
      70,
      0,
      "MODEL"
    ],
    [
      153,
      56,
      0,
      69,
      0,
      "MODEL"
    ],
    [
      154,
      70,
      0,
      55,
      0,
      "MODEL"
    ]
  ],
  "groups": [
    {
      "id": 1,
      "title": "Step1 - Load models",
      "bounding": [
        20,
        -150,
        371.0310363769531,
        571.3974609375
      ],
      "color": "#3f789e",
      "font_size": 24,
      "flags": {}
    },
    {
      "id": 2,
      "title": "Step2 - Upload start_image",
      "bounding": [
        20,
        450,
        370,
        470
      ],
      "color": "#3f789e",
      "font_size": 24,
      "flags": {}
    },
    {
      "id": 3,
      "title": "Step4 -  Prompt",
      "bounding": [
        410,
        140,
        445.27801513671875,
        464.2060852050781
      ],
      "color": "#3f789e",
      "font_size": 24,
      "flags": {}
    },
    {
      "id": 4,
      "title": "Step3 - Video size & length",
      "bounding": [
        410,
        620,
        440,
        300
      ],
      "color": "#3f789e",
      "font_size": 24,
      "flags": {}
    }
  ],
  "config": {},
  "extra": {
    "ds": {
      "scale": 1.2284597357368139,
      "offset": [
        -11.612936416766843,
        293.10917371200014
      ]
    },
    "frontendVersion": "1.23.4",
    "VHS_latentpreview": false,
    "VHS_latentpreviewrate": 0,
    "VHS_MetadataImage": true,
    "VHS_KeepIntermediate": true
  },
  "version": 0.4
}
```
