# Qwen-Image文生图工作流

- 来源类别：用户工作流
- 镜像内原始路径：`/ComfyUI/user/default/workflows/Qwen-Image/Qwen-Image文生图工作流.json`
- 节点数量：10
- 连线数量：10

## 节点类型

- `CLIPTextEncode` × 2
- `CLIPLoader` × 1
- `EmptyLatentImage` × 1
- `KSampler` × 1
- `LoraLoaderModelOnly` × 1
- `PreviewImage` × 1
- `UNETLoader` × 1
- `VAEDecode` × 1
- `VAELoader` × 1

## 工作流引用的模型或媒体文件

- `qwen_2.5_vl_7b.safetensors`
- `qwen_image_fp8_e4m3fn.safetensors`
- `qwen_image_vae.safetensors`

## 原始工作流 JSON

```json
{
  "id": "661fd8fe-7742-4810-bc81-fd3bbd3fd535",
  "revision": 0,
  "last_node_id": 26,
  "last_link_id": 26,
  "nodes": [
    {
      "id": 19,
      "type": "CLIPTextEncode",
      "pos": [
        725.1940307617188,
        57.00590133666992
      ],
      "size": [
        400,
        200
      ],
      "flags": {},
      "order": 5,
      "mode": 0,
      "inputs": [
        {
          "label": "CLIP",
          "localized_name": "clip",
          "name": "clip",
          "type": "CLIP",
          "link": 17
        },
        {
          "localized_name": "文本",
          "name": "text",
          "type": "STRING",
          "widget": {
            "name": "text"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "条件",
          "localized_name": "条件",
          "name": "CONDITIONING",
          "type": "CONDITIONING",
          "links": [
            20
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.50",
        "Node name for S&R": "CLIPTextEncode",
        "enableTabs": false,
        "tabWidth": 65,
        "tabXOffset": 10,
        "hasSecondTab": false,
        "secondTabText": "Send Back",
        "secondTabOffset": 80,
        "secondTabWidth": 65
      },
      "widgets_values": [
        "帮我生成一张图片：这是一张Bob品牌的11.11抢先购促销广告图,画面上方有“Bob”与红色的“11.11抢先购”标识,主标题为“双11焕新 算力启航 疯抢！爆款显卡低至5折”,画面底部有活动日期：“2025年11月11日-12月12日”画面中心有明显的低至999元的文字排版,图中展示一款三风扇的有科技感的高端显卡，带有“Bob”品牌标识,产品为主观镜头拍摄,主要显示产品,放大,特写镜头给到产品,产品拍摄角度为仰视45度角,全息投影,3D立体效果,极简主义,背景为浅色调,搭配透明与绿色薄地台子从右往左延伸出来产品在上装饰元素,还有印有品牌及活动标识的绿色科技元素点缀,电路板点缀,促销信息突出,既强化了品牌的专业属性,又充分烘托出年终大促的热烈气氛,极具吸引力与转化力,"
      ]
    },
    {
      "id": 22,
      "type": "CLIPTextEncode",
      "pos": [
        728.1557006835938,
        307.7845153808594
      ],
      "size": [
        400,
        200
      ],
      "flags": {},
      "order": 6,
      "mode": 0,
      "inputs": [
        {
          "label": "CLIP",
          "localized_name": "clip",
          "name": "clip",
          "type": "CLIP",
          "link": 19
        },
        {
          "localized_name": "文本",
          "name": "text",
          "type": "STRING",
          "widget": {
            "name": "text"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "条件",
          "localized_name": "条件",
          "name": "CONDITIONING",
          "type": "CONDITIONING",
          "links": [
            21
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.50",
        "Node name for S&R": "CLIPTextEncode",
        "enableTabs": false,
        "tabWidth": 65,
        "tabXOffset": 10,
        "hasSecondTab": false,
        "secondTabText": "Send Back",
        "secondTabOffset": 80,
        "secondTabWidth": 65
      },
      "widgets_values": [
        "色调艳丽，过曝，静态，细节模糊不清，风格，画面，整体发灰，最差质量，低质量，JPEG压缩残留，丑陋的，残缺的，多余的手指，杂乱的背景，三条腿，"
      ]
    },
    {
      "id": 24,
      "type": "EmptyLatentImage",
      "pos": [
        732.1050415039062,
        554.6143188476562
      ],
      "size": [
        393.9854431152344,
        106
      ],
      "flags": {},
      "order": 0,
      "mode": 0,
      "inputs": [
        {
          "localized_name": "宽度",
          "name": "width",
          "type": "INT",
          "widget": {
            "name": "width"
          },
          "link": null
        },
        {
          "localized_name": "高度",
          "name": "height",
          "type": "INT",
          "widget": {
            "name": "height"
          },
          "link": null
        },
        {
          "localized_name": "批次大小",
          "name": "batch_size",
          "type": "INT",
          "widget": {
            "name": "batch_size"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "Latent",
          "localized_name": "Latent",
          "name": "LATENT",
          "type": "LATENT",
          "links": [
            23
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.50",
        "Node name for S&R": "EmptyLatentImage",
        "enableTabs": false,
        "tabWidth": 65,
        "tabXOffset": 10,
        "hasSecondTab": false,
        "secondTabText": "Send Back",
        "secondTabOffset": 80,
        "secondTabWidth": 65
      },
      "widgets_values": [
        1664,
        928,
        1
      ]
    },
    {
      "id": 23,
      "type": "KSampler",
      "pos": [
        1182.322021484375,
        53.05665588378906
      ],
      "size": [
        315,
        262
      ],
      "flags": {},
      "order": 7,
      "mode": 0,
      "inputs": [
        {
          "label": "模型",
          "localized_name": "模型",
          "name": "model",
          "type": "MODEL",
          "link": 22
        },
        {
          "label": "正面条件",
          "localized_name": "正面条件",
          "name": "positive",
          "type": "CONDITIONING",
          "link": 20
        },
        {
          "label": "负面条件",
          "localized_name": "负面条件",
          "name": "negative",
          "type": "CONDITIONING",
          "link": 21
        },
        {
          "label": "Latent",
          "localized_name": "Latent图像",
          "name": "latent_image",
          "type": "LATENT",
          "link": 23
        },
        {
          "localized_name": "随机种",
          "name": "seed",
          "type": "INT",
          "widget": {
            "name": "seed"
          },
          "link": null
        },
        {
          "localized_name": "步数",
          "name": "steps",
          "type": "INT",
          "widget": {
            "name": "steps"
          },
          "link": null
        },
        {
          "localized_name": "CFG",
          "name": "cfg",
          "type": "FLOAT",
          "widget": {
            "name": "cfg"
          },
          "link": null
        },
        {
          "localized_name": "采样器",
          "name": "sampler_name",
          "type": "COMBO",
          "widget": {
            "name": "sampler_name"
          },
          "link": null
        },
        {
          "localized_name": "调度器",
          "name": "scheduler",
          "type": "COMBO",
          "widget": {
            "name": "scheduler"
          },
          "link": null
        },
        {
          "localized_name": "降噪",
          "name": "denoise",
          "type": "FLOAT",
          "widget": {
            "name": "denoise"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "Latent",
          "localized_name": "Latent",
          "name": "LATENT",
          "type": "LATENT",
          "links": [
            24
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.50",
        "Node name for S&R": "KSampler",
        "enableTabs": false,
        "tabWidth": 65,
        "tabXOffset": 10,
        "hasSecondTab": false,
        "secondTabText": "Send Back",
        "secondTabOffset": 80,
        "secondTabWidth": 65
      },
      "widgets_values": [
        320917192430504,
        "randomize",
        25,
        3.5,
        "euler",
        "normal",
        1
      ]
    },
    {
      "id": 25,
      "type": "VAEDecode",
      "pos": [
        1526.8956298828125,
        54.04397201538086
      ],
      "size": [
        210,
        46
      ],
      "flags": {},
      "order": 8,
      "mode": 0,
      "inputs": [
        {
          "label": "Latent",
          "localized_name": "Latent",
          "name": "samples",
          "type": "LATENT",
          "link": 24
        },
        {
          "label": "VAE",
          "localized_name": "vae",
          "name": "vae",
          "type": "VAE",
          "link": 25
        }
      ],
      "outputs": [
        {
          "label": "图像",
          "localized_name": "图像",
          "name": "IMAGE",
          "type": "IMAGE",
          "links": [
            26
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.50",
        "Node name for S&R": "VAEDecode",
        "enableTabs": false,
        "tabWidth": 65,
        "tabXOffset": 10,
        "hasSecondTab": false,
        "secondTabText": "Send Back",
        "secondTabOffset": 80,
        "secondTabWidth": 65
      },
      "widgets_values": []
    },
    {
      "id": 26,
      "type": "PreviewImage",
      "pos": [
        1763.8515625,
        55.03118896484375
      ],
      "size": [
        210,
        246
      ],
      "flags": {},
      "order": 9,
      "mode": 0,
      "inputs": [
        {
          "label": "图像",
          "localized_name": "图像",
          "name": "images",
          "type": "IMAGE",
          "link": 26
        }
      ],
      "outputs": [],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.50",
        "Node name for S&R": "PreviewImage",
        "enableTabs": false,
        "tabWidth": 65,
        "tabXOffset": 10,
        "hasSecondTab": false,
        "secondTabText": "Send Back",
        "secondTabOffset": 80,
        "secondTabWidth": 65
      },
      "widgets_values": []
    },
    {
      "id": 16,
      "type": "UNETLoader",
      "pos": [
        383.58184814453125,
        49.107421875
      ],
      "size": [
        315,
        82
      ],
      "flags": {},
      "order": 1,
      "mode": 0,
      "inputs": [
        {
          "localized_name": "UNET名称",
          "name": "unet_name",
          "type": "COMBO",
          "widget": {
            "name": "unet_name"
          },
          "link": null
        },
        {
          "localized_name": "剪枝类型",
          "name": "weight_dtype",
          "type": "COMBO",
          "widget": {
            "name": "weight_dtype"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "模型",
          "localized_name": "模型",
          "name": "MODEL",
          "type": "MODEL",
          "links": [
            18
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.50",
        "Node name for S&R": "UNETLoader",
        "enableTabs": false,
        "tabWidth": 65,
        "tabXOffset": 10,
        "hasSecondTab": false,
        "secondTabText": "Send Back",
        "secondTabOffset": 80,
        "secondTabWidth": 65
      },
      "widgets_values": [
        "qwen_image_fp8_e4m3fn.safetensors",
        "default"
      ]
    },
    {
      "id": 21,
      "type": "LoraLoaderModelOnly",
      "pos": [
        388.5180969238281,
        169.56004333496094
      ],
      "size": [
        315,
        82
      ],
      "flags": {},
      "order": 4,
      "mode": 4,
      "inputs": [
        {
          "label": "模型",
          "localized_name": "模型",
          "name": "model",
          "type": "MODEL",
          "link": 18
        },
        {
          "localized_name": "LoRA名称",
          "name": "lora_name",
          "type": "COMBO",
          "widget": {
            "name": "lora_name"
          },
          "link": null
        },
        {
          "localized_name": "模型强度",
          "name": "strength_model",
          "type": "FLOAT",
          "widget": {
            "name": "strength_model"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "模型",
          "localized_name": "模型",
          "name": "MODEL",
          "type": "MODEL",
          "links": [
            22
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.50",
        "Node name for S&R": "LoraLoaderModelOnly",
        "enableTabs": false,
        "tabWidth": 65,
        "tabXOffset": 10,
        "hasSecondTab": false,
        "secondTabText": "Send Back",
        "secondTabOffset": 80,
        "secondTabWidth": 65
      },
      "widgets_values": [
        "3D创意标题字体F.1/Qwen千问_支持中文输入Qwen-V2",
        1
      ]
    },
    {
      "id": 17,
      "type": "CLIPLoader",
      "pos": [
        383.581787109375,
        297.9112548828125
      ],
      "size": [
        315,
        106
      ],
      "flags": {},
      "order": 2,
      "mode": 0,
      "inputs": [
        {
          "localized_name": "CLIP名称",
          "name": "clip_name",
          "type": "COMBO",
          "widget": {
            "name": "clip_name"
          },
          "link": null
        },
        {
          "localized_name": "类型",
          "name": "type",
          "type": "COMBO",
          "widget": {
            "name": "type"
          },
          "link": null
        },
        {
          "localized_name": "设备",
          "name": "device",
          "shape": 7,
          "type": "COMBO",
          "widget": {
            "name": "device"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "CLIP",
          "localized_name": "CLIP",
          "name": "CLIP",
          "type": "CLIP",
          "links": [
            17,
            19
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.50",
        "Node name for S&R": "CLIPLoader",
        "enableTabs": false,
        "tabWidth": 65,
        "tabXOffset": 10,
        "hasSecondTab": false,
        "secondTabText": "Send Back",
        "secondTabOffset": 80,
        "secondTabWidth": 65
      },
      "widgets_values": [
        "qwen_2.5_vl_7b.safetensors",
        "qwen_image",
        "default"
      ]
    },
    {
      "id": 18,
      "type": "VAELoader",
      "pos": [
        383.5818176269531,
        457.8564453125
      ],
      "size": [
        315,
        58
      ],
      "flags": {},
      "order": 3,
      "mode": 0,
      "inputs": [
        {
          "localized_name": "vae名称",
          "name": "vae_name",
          "type": "COMBO",
          "widget": {
            "name": "vae_name"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "localized_name": "VAE",
          "name": "VAE",
          "type": "VAE",
          "links": [
            25
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.50",
        "Node name for S&R": "VAELoader",
        "enableTabs": false,
        "tabWidth": 65,
        "tabXOffset": 10,
        "hasSecondTab": false,
        "secondTabText": "Send Back",
        "secondTabOffset": 80,
        "secondTabWidth": 65
      },
      "widgets_values": [
        "qwen_image_vae.safetensors"
      ]
    }
  ],
  "links": [
    [
      17,
      17,
      0,
      19,
      0,
      "CLIP"
    ],
    [
      18,
      16,
      0,
      21,
      0,
      "MODEL"
    ],
    [
      19,
      17,
      0,
      22,
      0,
      "CLIP"
    ],
    [
      20,
      19,
      0,
      23,
      1,
      "CONDITIONING"
    ],
    [
      21,
      22,
      0,
      23,
      2,
      "CONDITIONING"
    ],
    [
      22,
      21,
      0,
      23,
      0,
      "MODEL"
    ],
    [
      23,
      24,
      0,
      23,
      3,
      "LATENT"
    ],
    [
      24,
      23,
      0,
      25,
      0,
      "LATENT"
    ],
    [
      25,
      18,
      0,
      25,
      1,
      "VAE"
    ],
    [
      26,
      25,
      0,
      26,
      0,
      "IMAGE"
    ]
  ],
  "groups": [],
  "config": {},
  "extra": {
    "ds": {
      "scale": 1.2839025177495011,
      "offset": [
        -243.7295083027686,
        60.31868447596485
      ]
    },
    "frontendVersion": "1.25.4",
    "ue_links": [],
    "links_added_by_ue": [],
    "VHS_latentpreview": false,
    "VHS_latentpreviewrate": 0,
    "VHS_MetadataImage": true,
    "VHS_KeepIntermediate": true
  },
  "version": 0.4
}
```
