# 文生视频

- 来源类别：用户工作流
- 镜像内原始路径：`/ComfyUI/user/default/workflows/18个开源模型工作流/视频/文生视频.json`
- 节点数量：41
- 连线数量：60

## 节点类型

- `LoraLoaderModelOnly` × 3
- `CFGGuider` × 2
- `CLIPTextEncode` × 2
- `KSamplerSelect` × 2
- `LTXVAudioVAEDecode` × 2
- `LTXVConcatAVLatent` × 2
- `LTXVSeparateAVLatent` × 2
- `PrimitiveInt` × 2
- `RandomNoise` × 2
- `SamplerCustomAdvanced` × 2
- `VAEDecodeTiled` × 2
- `CheckpointLoaderSimple` × 1
- `ComfyNumberConvert` × 1
- `EmptyImage` × 1
- `EmptyLTXVLatentVideo` × 1
- `GetImageSize` × 1
- `ImageScaleBy` × 1
- `ImpactExecutionOrderController` × 1
- `LTXAVTextEncoderLoader` × 1
- `LTXVAudioVAELoader` × 1
- `LTXVConditioning` × 1
- `LTXVCropGuides` × 1
- `LTXVEmptyLatentAudio` × 1
- `LTXVLatentUpsampler` × 1
- `LTXVScheduler` × 1
- `LatentUpscaleModelLoader` × 1
- `LayerUtility: TextBox` × 1
- `ManualSigmas` × 1
- `VHS_VideoCombine` × 1

## 工作流引用的模型或媒体文件

- `/ComfyUI/output/ltx-2.3/t2v_00001-audio.mp4`
- `caled.safetensors`
- `caler-x2-1.0.safetensors`
- `jgfq_1779793459.mp4`
- `ltx-2-19b-ic-lora-detailer.safetensors`
- `ltx-2-19b-lora-camera-control-dolly-in.safetensors`
- `ltx-2.3-22b-dev.safetensors`
- `t2v_00001-audio.mp4`
- `tilled-lora-384.safetensors`

## 原始工作流 JSON

```json
{
  "id": "7f5e0c56-93b4-4937-b7f2-efd0f1853e33",
  "revision": 0,
  "last_node_id": 195,
  "last_link_id": 452,
  "nodes": [
    {
      "id": 114,
      "type": "RandomNoise",
      "pos": [
        -1150,
        2060
      ],
      "size": [
        270,
        82
      ],
      "flags": {},
      "order": 0,
      "mode": 0,
      "inputs": [
        {
          "label": "noise_seed",
          "name": "noise_seed",
          "type": "INT",
          "widget": {
            "name": "noise_seed"
          }
        }
      ],
      "outputs": [
        {
          "label": "NOISE",
          "name": "NOISE",
          "type": "NOISE",
          "links": [
            269
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.75",
        "Node name for S&R": "RandomNoise",
        "hasSecondTab": false,
        "widget_ue_connectable": {
          "noise_seed": true
        },
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": [
        397667915300547,
        "randomize"
      ]
    },
    {
      "id": 103,
      "type": "CFGGuider",
      "pos": [
        -1150,
        2200
      ],
      "size": [
        270,
        98
      ],
      "flags": {},
      "order": 33,
      "mode": 0,
      "inputs": [
        {
          "label": "model",
          "name": "model",
          "type": "MODEL",
          "link": 309
        },
        {
          "label": "positive",
          "name": "positive",
          "type": "CONDITIONING",
          "link": 274
        },
        {
          "label": "negative",
          "name": "negative",
          "type": "CONDITIONING",
          "link": 275
        },
        {
          "label": "cfg",
          "name": "cfg",
          "type": "FLOAT",
          "widget": {
            "name": "cfg"
          }
        }
      ],
      "outputs": [
        {
          "label": "GUIDER",
          "name": "GUIDER",
          "type": "GUIDER",
          "links": [
            270
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.71",
        "Node name for S&R": "CFGGuider",
        "hasSecondTab": false,
        "widget_ue_connectable": {
          "cfg": true
        },
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": [
        1
      ]
    },
    {
      "id": 100,
      "type": "ManualSigmas",
      "pos": [
        -1150,
        2350
      ],
      "size": [
        270,
        58
      ],
      "flags": {},
      "order": 1,
      "mode": 0,
      "inputs": [
        {
          "label": "sigmas",
          "name": "sigmas",
          "type": "STRING",
          "widget": {
            "name": "sigmas"
          }
        }
      ],
      "outputs": [
        {
          "label": "SIGMAS",
          "name": "SIGMAS",
          "type": "SIGMAS",
          "links": [
            272
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.5.1",
        "Node name for S&R": "ManualSigmas",
        "hasSecondTab": false,
        "widget_ue_connectable": {
          "sigmas": true
        },
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": [
        "0.909375, 0.725, 0.421875, 0.0"
      ]
    },
    {
      "id": 180,
      "type": "ImpactExecutionOrderController",
      "pos": [
        -2451.734618243876,
        2236.33204940922
      ],
      "size": [
        392.2785339355469,
        51.73447036743164
      ],
      "flags": {},
      "order": 24,
      "mode": 0,
      "inputs": [
        {
          "label": "signal",
          "name": "signal",
          "type": "*",
          "link": 403
        },
        {
          "label": "value",
          "name": "value",
          "type": "*",
          "link": 436
        }
      ],
      "outputs": [
        {
          "label": "signal",
          "name": "signal",
          "type": "*",
          "links": [
            405,
            406
          ]
        },
        {
          "label": "value",
          "name": "value",
          "type": "*",
          "links": []
        }
      ],
      "properties": {
        "Node name for S&R": "ImpactExecutionOrderController",
        "cnr_id": "comfyui-impact-pack",
        "ver": "8.25.0",
        "widget_ue_connectable": {}
      },
      "widgets_values": []
    },
    {
      "id": 128,
      "type": "CFGGuider",
      "pos": [
        -1990,
        2190
      ],
      "size": [
        270,
        106.66666412353516
      ],
      "flags": {},
      "order": 26,
      "mode": 0,
      "inputs": [
        {
          "label": "model",
          "name": "model",
          "type": "MODEL",
          "link": 307
        },
        {
          "label": "positive",
          "name": "positive",
          "type": "CONDITIONING",
          "link": 405
        },
        {
          "label": "negative",
          "name": "negative",
          "type": "CONDITIONING",
          "link": 255
        },
        {
          "label": "cfg",
          "name": "cfg",
          "type": "FLOAT",
          "widget": {
            "name": "cfg"
          }
        }
      ],
      "outputs": [
        {
          "label": "GUIDER",
          "name": "GUIDER",
          "type": "GUIDER",
          "links": [
            258
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.64",
        "Node name for S&R": "CFGGuider",
        "hasSecondTab": false,
        "widget_ue_connectable": {
          "cfg": true
        },
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": [
        4
      ]
    },
    {
      "id": 116,
      "type": "LTXVSeparateAVLatent",
      "pos": [
        -1680,
        2230
      ],
      "size": [
        240,
        46
      ],
      "flags": {},
      "order": 29,
      "mode": 0,
      "inputs": [
        {
          "label": "av_latent",
          "name": "av_latent",
          "type": "LATENT",
          "link": 268
        }
      ],
      "outputs": [
        {
          "label": "video_latent",
          "name": "video_latent",
          "type": "LATENT",
          "links": [
            266,
            329
          ]
        },
        {
          "label": "audio_latent",
          "name": "audio_latent",
          "type": "LATENT",
          "links": [
            263,
            334
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.5.1",
        "Node name for S&R": "LTXVSeparateAVLatent",
        "hasSecondTab": false,
        "widget_ue_connectable": {},
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": []
    },
    {
      "id": 152,
      "type": "LTXVAudioVAEDecode",
      "pos": [
        -1670,
        2330
      ],
      "size": [
        240,
        46
      ],
      "flags": {},
      "order": 32,
      "mode": 0,
      "inputs": [
        {
          "label": "samples",
          "name": "samples",
          "type": "LATENT",
          "link": 334
        },
        {
          "label": "audio_vae",
          "name": "audio_vae",
          "type": "VAE",
          "link": 443
        }
      ],
      "outputs": [
        {
          "label": "Audio",
          "name": "Audio",
          "type": "AUDIO",
          "links": []
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.7.0",
        "Node name for S&R": "LTXVAudioVAEDecode",
        "hasSecondTab": false,
        "widget_ue_connectable": {},
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": []
    },
    {
      "id": 113,
      "type": "SamplerCustomAdvanced",
      "pos": [
        -1670,
        2050
      ],
      "size": [
        235.63583374023438,
        118.81522369384766
      ],
      "flags": {},
      "order": 28,
      "mode": 0,
      "inputs": [
        {
          "label": "noise",
          "name": "noise",
          "type": "NOISE",
          "link": 257
        },
        {
          "label": "guider",
          "name": "guider",
          "type": "GUIDER",
          "link": 258
        },
        {
          "label": "sampler",
          "name": "sampler",
          "type": "SAMPLER",
          "link": 259
        },
        {
          "label": "sigmas",
          "name": "sigmas",
          "type": "SIGMAS",
          "link": 426
        },
        {
          "label": "latent_image",
          "name": "latent_image",
          "type": "LATENT",
          "link": 261
        }
      ],
      "outputs": [
        {
          "label": "output",
          "name": "output",
          "type": "LATENT",
          "links": [
            268
          ]
        },
        {
          "label": "denoised_output",
          "name": "denoised_output",
          "type": "LATENT",
          "links": []
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.60",
        "Node name for S&R": "SamplerCustomAdvanced",
        "hasSecondTab": false,
        "widget_ue_connectable": {},
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": []
    },
    {
      "id": 151,
      "type": "VAEDecodeTiled",
      "pos": [
        -1680,
        2440
      ],
      "size": [
        233.8642120361328,
        150
      ],
      "flags": {},
      "order": 31,
      "mode": 0,
      "inputs": [
        {
          "label": "samples",
          "name": "samples",
          "type": "LATENT",
          "link": 329
        },
        {
          "label": "vae",
          "name": "vae",
          "type": "VAE",
          "link": 437
        },
        {
          "label": "tile_size",
          "name": "tile_size",
          "type": "INT",
          "widget": {
            "name": "tile_size"
          }
        },
        {
          "label": "overlap",
          "name": "overlap",
          "type": "INT",
          "widget": {
            "name": "overlap"
          }
        },
        {
          "label": "temporal_size",
          "name": "temporal_size",
          "type": "INT",
          "widget": {
            "name": "temporal_size"
          }
        },
        {
          "label": "temporal_overlap",
          "name": "temporal_overlap",
          "type": "INT",
          "widget": {
            "name": "temporal_overlap"
          }
        }
      ],
      "outputs": [
        {
          "label": "IMAGE",
          "name": "IMAGE",
          "type": "IMAGE",
          "links": []
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.7.0",
        "Node name for S&R": "VAEDecodeTiled",
        "hasSecondTab": false,
        "widget_ue_connectable": {
          "overlap": true,
          "tile_size": true,
          "temporal_overlap": true,
          "temporal_size": true
        },
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": [
        512,
        64,
        64,
        16
      ]
    },
    {
      "id": 110,
      "type": "CLIPTextEncode",
      "pos": [
        -2919.370116290751,
        2749.191180268595
      ],
      "size": [
        406.0369567871094,
        132.20108032226562
      ],
      "flags": {},
      "order": 13,
      "mode": 0,
      "inputs": [
        {
          "label": "clip",
          "name": "clip",
          "type": "CLIP",
          "link": 441
        },
        {
          "label": "text",
          "name": "text",
          "type": "STRING",
          "widget": {
            "name": "text"
          }
        }
      ],
      "outputs": [
        {
          "label": "CONDITIONING",
          "name": "CONDITIONING",
          "type": "CONDITIONING",
          "links": [
            284
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.56",
        "Node name for S&R": "CLIPTextEncode",
        "hasSecondTab": false,
        "widget_ue_connectable": {
          "text": true
        },
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": [
        "blurry, low quality, still frame, frames, watermark, overlay, titles, has blurbox, has subtitles"
      ],
      "color": "#323",
      "bgcolor": "#535"
    },
    {
      "id": 124,
      "type": "LTXVSeparateAVLatent",
      "pos": [
        -862.8528757863278,
        2227.3717716214505
      ],
      "size": [
        278.7748718261719,
        59.98817443847656
      ],
      "flags": {},
      "order": 37,
      "mode": 0,
      "inputs": [
        {
          "label": "av_latent",
          "name": "av_latent",
          "type": "LATENT",
          "link": 296
        }
      ],
      "outputs": [
        {
          "label": "video_latent",
          "name": "video_latent",
          "type": "LATENT",
          "links": [
            299
          ]
        },
        {
          "label": "audio_latent",
          "name": "audio_latent",
          "type": "LATENT",
          "links": [
            294
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.5.1",
        "Node name for S&R": "LTXVSeparateAVLatent",
        "hasSecondTab": false,
        "widget_ue_connectable": {},
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": []
    },
    {
      "id": 126,
      "type": "VAEDecodeTiled",
      "pos": [
        -852.8528757863278,
        2347.3717716214505
      ],
      "size": [
        270,
        150
      ],
      "flags": {},
      "order": 38,
      "mode": 0,
      "inputs": [
        {
          "label": "samples",
          "name": "samples",
          "type": "LATENT",
          "link": 299
        },
        {
          "label": "vae",
          "name": "vae",
          "type": "VAE",
          "link": 439
        },
        {
          "label": "tile_size",
          "name": "tile_size",
          "type": "INT",
          "widget": {
            "name": "tile_size"
          }
        },
        {
          "label": "overlap",
          "name": "overlap",
          "type": "INT",
          "widget": {
            "name": "overlap"
          }
        },
        {
          "label": "temporal_size",
          "name": "temporal_size",
          "type": "INT",
          "widget": {
            "name": "temporal_size"
          }
        },
        {
          "label": "temporal_overlap",
          "name": "temporal_overlap",
          "type": "INT",
          "widget": {
            "name": "temporal_overlap"
          }
        }
      ],
      "outputs": [
        {
          "label": "IMAGE",
          "name": "IMAGE",
          "type": "IMAGE",
          "links": [
            431
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.7.0",
        "Node name for S&R": "VAEDecodeTiled",
        "hasSecondTab": false,
        "widget_ue_connectable": {
          "overlap": true,
          "tile_size": true,
          "temporal_overlap": true,
          "temporal_size": true
        },
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": [
        512,
        64,
        64,
        16
      ]
    },
    {
      "id": 160,
      "type": "LTXVAudioVAELoader",
      "pos": [
        -2936.007079181376,
        2225.830828706095
      ],
      "size": [
        441.23663330078125,
        65.16801452636719
      ],
      "flags": {},
      "order": 2,
      "mode": 0,
      "inputs": [
        {
          "label": "ckpt_name",
          "name": "ckpt_name",
          "type": "COMBO",
          "widget": {
            "name": "ckpt_name"
          }
        }
      ],
      "outputs": [
        {
          "label": "Audio VAE",
          "name": "Audio VAE",
          "type": "VAE",
          "links": [
            442,
            443,
            444
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.68",
        "Node name for S&R": "LTXVAudioVAELoader",
        "hasSecondTab": false,
        "models": [
          {
            "name": "ltx-2-19b-dev-fp8.safetensors",
            "directory": "checkpoints",
            "url": "https://huggingface.co/Lightricks/LTX-2/resolve/main/ltx-2-19b-dev-fp8.safetensors"
          }
        ],
        "widget_ue_connectable": {
          "ckpt_name": true
        },
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": [
        "ltx-2.3-22b-dev.safetensors"
      ]
    },
    {
      "id": 161,
      "type": "LTXAVTextEncoderLoader",
      "pos": [
        -2929.539061603251,
        2347.016863862345
      ],
      "size": [
        429.0183410644531,
        106.71681213378906
      ],
      "flags": {},
      "order": 3,
      "mode": 0,
      "inputs": [
        {
          "label": "text_encoder",
          "name": "text_encoder",
          "type": "COMBO",
          "widget": {
            "name": "text_encoder"
          }
        },
        {
          "label": "ckpt_name",
          "name": "ckpt_name",
          "type": "COMBO",
          "widget": {
            "name": "ckpt_name"
          }
        },
        {
          "label": "device",
          "name": "device",
          "type": "COMBO",
          "widget": {
            "name": "device"
          }
        }
      ],
      "outputs": [
        {
          "label": "CLIP",
          "name": "CLIP",
          "type": "CLIP",
          "links": [
            440,
            441
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.7.0",
        "Node name for S&R": "LTXAVTextEncoderLoader",
        "hasSecondTab": false,
        "models": [
          {
            "name": "ltx-2-19b-dev-fp8.safetensors",
            "directory": "checkpoints",
            "url": "https://huggingface.co/Lightricks/LTX-2/resolve/main/ltx-2-19b-dev-fp8.safetensors"
          },
          {
            "name": "gemma_3_12B_it.safetensors",
            "directory": "text_encoders",
            "url": "https://huggingface.co/Comfy-Org/ltx-2/resolve/main/split_files/text_encoders/gemma_3_12B_it.safetensors"
          }
        ],
        "widget_ue_connectable": {
          "ckpt_name": true,
          "text_encoder": true,
          "device": true
        },
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": [
        "gemma_3_12B_it_fp8_scaled.safetensors",
        "ltx-2.3-22b-dev.safetensors",
        "default"
      ]
    },
    {
      "id": 107,
      "type": "LTXVConditioning",
      "pos": [
        -2458.125731525126,
        2080.22413925297
      ],
      "size": [
        397.5888977050781,
        98.85221862792969
      ],
      "flags": {},
      "order": 22,
      "mode": 0,
      "inputs": [
        {
          "label": "positive",
          "name": "positive",
          "type": "CONDITIONING",
          "link": 283
        },
        {
          "label": "negative",
          "name": "negative",
          "type": "CONDITIONING",
          "link": 284
        },
        {
          "label": "frame_rate",
          "name": "frame_rate",
          "type": "FLOAT",
          "widget": {
            "name": "frame_rate"
          },
          "link": 450
        }
      ],
      "outputs": [
        {
          "label": "positive",
          "name": "positive",
          "type": "CONDITIONING",
          "links": [
            403
          ]
        },
        {
          "label": "negative",
          "name": "negative",
          "type": "CONDITIONING",
          "links": [
            255,
            355
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.56",
        "Node name for S&R": "LTXVConditioning",
        "hasSecondTab": false,
        "widget_ue_connectable": {
          "frame_rate": true
        },
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": [
        25
      ]
    },
    {
      "id": 136,
      "type": "KSamplerSelect",
      "pos": [
        -1150,
        2460
      ],
      "size": [
        270,
        58
      ],
      "flags": {},
      "order": 4,
      "mode": 0,
      "inputs": [
        {
          "label": "sampler_name",
          "name": "sampler_name",
          "type": "COMBO",
          "widget": {
            "name": "sampler_name"
          }
        }
      ],
      "outputs": [
        {
          "label": "SAMPLER",
          "name": "SAMPLER",
          "type": "SAMPLER",
          "links": [
            271
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.75",
        "Node name for S&R": "KSamplerSelect",
        "hasSecondTab": false,
        "widget_ue_connectable": {
          "sampler_name": true
        },
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": [
        "euler"
      ]
    },
    {
      "id": 134,
      "type": "LoraLoaderModelOnly",
      "pos": [
        -2465.6299443862085,
        2334.687838071098
      ],
      "size": [
        414.72930908203125,
        88.8541030883789
      ],
      "flags": {},
      "order": 18,
      "mode": 0,
      "inputs": [
        {
          "label": "model",
          "name": "model",
          "type": "MODEL",
          "link": 435
        },
        {
          "label": "lora_name",
          "name": "lora_name",
          "type": "COMBO",
          "widget": {
            "name": "lora_name"
          }
        },
        {
          "label": "strength_model",
          "name": "strength_model",
          "type": "FLOAT",
          "widget": {
            "name": "strength_model"
          }
        }
      ],
      "outputs": [
        {
          "label": "MODEL",
          "name": "MODEL",
          "type": "MODEL",
          "links": [
            307
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.68",
        "Node name for S&R": "LoraLoaderModelOnly",
        "hasSecondTab": false,
        "models": [
          {
            "name": "ltx-2-19b-lora-camera-control-dolly-left.safetensors",
            "directory": "loras",
            "url": "https://huggingface.co/Lightricks/LTX-2-19b-LoRA-Camera-Control-Dolly-Left/resolve/main/ltx-2-19b-lora-camera-control-dolly-left.safetensors"
          }
        ],
        "widget_ue_connectable": {
          "lora_name": true,
          "strength_model": true
        },
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": [
        "ltx-2-19b-lora-camera-control-dolly-in.safetensors",
        1
      ]
    },
    {
      "id": 132,
      "type": "LoraLoaderModelOnly",
      "pos": [
        -2466.0908842588583,
        2464.5206682400944
      ],
      "size": [
        417.1184341356693,
        82
      ],
      "flags": {},
      "order": 17,
      "mode": 0,
      "inputs": [
        {
          "label": "model",
          "name": "model",
          "type": "MODEL",
          "link": 434
        },
        {
          "label": "lora_name",
          "name": "lora_name",
          "type": "COMBO",
          "widget": {
            "name": "lora_name"
          }
        },
        {
          "label": "strength_model",
          "name": "strength_model",
          "type": "FLOAT",
          "widget": {
            "name": "strength_model"
          }
        }
      ],
      "outputs": [
        {
          "label": "MODEL",
          "name": "MODEL",
          "type": "MODEL",
          "links": [
            308
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.75",
        "Node name for S&R": "LoraLoaderModelOnly",
        "hasSecondTab": false,
        "models": [
          {
            "name": "ltx-2-19b-distilled-lora-384.safetensors",
            "directory": "loras",
            "url": "https://huggingface.co/Lightricks/LTX-2/resolve/main/ltx-2-19b-distilled-lora-384.safetensors"
          }
        ],
        "widget_ue_connectable": {
          "lora_name": true,
          "strength_model": true
        },
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": [
        "ltx-2.3-22b-distilled-lora-384.safetensors",
        0.6
      ]
    },
    {
      "id": 121,
      "type": "CLIPTextEncode",
      "pos": [
        -2920.9729878191465,
        2496.240417421167
      ],
      "size": [
        412.6962585449219,
        213.65003967285156
      ],
      "flags": {},
      "order": 19,
      "mode": 0,
      "inputs": [
        {
          "label": "clip",
          "name": "clip",
          "type": "CLIP",
          "link": 440
        },
        {
          "label": "text",
          "name": "text",
          "type": "STRING",
          "widget": {
            "name": "text"
          },
          "link": 452
        }
      ],
      "outputs": [
        {
          "label": "CONDITIONING",
          "name": "CONDITIONING",
          "type": "CONDITIONING",
          "links": [
            283
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.56",
        "Node name for S&R": "CLIPTextEncode",
        "hasSecondTab": false,
        "widget_ue_connectable": {
          "text": true
        },
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": [
        ""
      ],
      "color": "#232",
      "bgcolor": "#353"
    },
    {
      "id": 112,
      "type": "PrimitiveInt",
      "pos": [
        -3410,
        2330
      ],
      "size": [
        379.9081915639413,
        82
      ],
      "flags": {},
      "order": 5,
      "mode": 0,
      "inputs": [
        {
          "label": "value",
          "name": "value",
          "type": "INT",
          "widget": {
            "name": "value"
          }
        }
      ],
      "outputs": [
        {
          "label": "INT",
          "name": "INT",
          "type": "INT",
          "links": [
            279,
            289
          ]
        }
      ],
      "title": "Length",
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.7.0",
        "Node name for S&R": "PrimitiveInt",
        "hasSecondTab": false,
        "widget_ue_connectable": {
          "value": true
        },
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": [
        121,
        "fixed"
      ]
    },
    {
      "id": 101,
      "type": "LatentUpscaleModelLoader",
      "pos": [
        -2476.2774971186504,
        2594.2453086133114
      ],
      "size": [
        423.6760327312609,
        58
      ],
      "flags": {},
      "order": 6,
      "mode": 0,
      "inputs": [
        {
          "label": "model_name",
          "name": "model_name",
          "type": "COMBO",
          "widget": {
            "name": "model_name"
          }
        }
      ],
      "outputs": [
        {
          "label": "LATENT_UPSCALE_MODEL",
          "name": "LATENT_UPSCALE_MODEL",
          "type": "LATENT_UPSCALE_MODEL",
          "links": [
            281
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.7.0",
        "Node name for S&R": "LatentUpscaleModelLoader",
        "hasSecondTab": false,
        "models": [
          {
            "name": "ltx-2-spatial-upscaler-x2-1.0.safetensors",
            "directory": "latent_upscale_models",
            "url": "https://huggingface.co/Lightricks/LTX-2/resolve/main/ltx-2-spatial-upscaler-x2-1.0.safetensors"
          }
        ],
        "widget_ue_connectable": {
          "model_name": true
        },
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": [
        "ltx-2.3-spatial-upscaler-x2-1.0.safetensors"
      ]
    },
    {
      "id": 133,
      "type": "LoraLoaderModelOnly",
      "pos": [
        -2477.5176239393463,
        2703.3382832369502
      ],
      "size": [
        420.8985710241209,
        82
      ],
      "flags": {},
      "order": 21,
      "mode": 0,
      "inputs": [
        {
          "label": "model",
          "name": "model",
          "type": "MODEL",
          "link": 308
        },
        {
          "label": "lora_name",
          "name": "lora_name",
          "type": "COMBO",
          "widget": {
            "name": "lora_name"
          }
        },
        {
          "label": "strength_model",
          "name": "strength_model",
          "type": "FLOAT",
          "widget": {
            "name": "strength_model"
          }
        }
      ],
      "outputs": [
        {
          "label": "MODEL",
          "name": "MODEL",
          "type": "MODEL",
          "links": [
            309
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.68",
        "Node name for S&R": "LoraLoaderModelOnly",
        "hasSecondTab": false,
        "models": [
          {
            "name": "ltx-2-19b-lora-camera-control-dolly-left.safetensors",
            "directory": "loras",
            "url": "https://huggingface.co/Lightricks/LTX-2-19b-LoRA-Camera-Control-Dolly-Left/resolve/main/ltx-2-19b-lora-camera-control-dolly-left.safetensors"
          }
        ],
        "widget_ue_connectable": {
          "lora_name": true,
          "strength_model": true
        },
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": [
        "ltx-2-19b-ic-lora-detailer.safetensors",
        0.32000000000000006
      ]
    },
    {
      "id": 135,
      "type": "KSamplerSelect",
      "pos": [
        -1990,
        2340
      ],
      "size": [
        270,
        68.88021087646484
      ],
      "flags": {},
      "order": 7,
      "mode": 0,
      "inputs": [
        {
          "label": "sampler_name",
          "name": "sampler_name",
          "type": "COMBO",
          "widget": {
            "name": "sampler_name"
          }
        }
      ],
      "outputs": [
        {
          "label": "SAMPLER",
          "name": "SAMPLER",
          "type": "SAMPLER",
          "links": [
            259
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.56",
        "Node name for S&R": "KSamplerSelect",
        "hasSecondTab": false,
        "widget_ue_connectable": {
          "sampler_name": true
        },
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": [
        "euler"
      ]
    },
    {
      "id": 115,
      "type": "RandomNoise",
      "pos": [
        -1980,
        2050
      ],
      "size": [
        270,
        82
      ],
      "flags": {},
      "order": 8,
      "mode": 0,
      "inputs": [
        {
          "label": "noise_seed",
          "name": "noise_seed",
          "type": "INT",
          "widget": {
            "name": "noise_seed"
          }
        }
      ],
      "outputs": [
        {
          "label": "NOISE",
          "name": "NOISE",
          "type": "NOISE",
          "links": [
            257
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.56",
        "Node name for S&R": "RandomNoise",
        "hasSecondTab": false,
        "widget_ue_connectable": {
          "noise_seed": true
        },
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": [
        1008603064491997,
        "randomize"
      ]
    },
    {
      "id": 109,
      "type": "LTXVConcatAVLatent",
      "pos": [
        -2001.0868833978493,
        2449.3092859137696
      ],
      "size": [
        283.6583939712257,
        56.966766357421875
      ],
      "flags": {},
      "order": 25,
      "mode": 0,
      "inputs": [
        {
          "label": "video_latent",
          "name": "video_latent",
          "type": "LATENT",
          "link": 290
        },
        {
          "label": "audio_latent",
          "name": "audio_latent",
          "type": "LATENT",
          "link": 291
        }
      ],
      "outputs": [
        {
          "label": "latent",
          "name": "latent",
          "type": "LATENT",
          "links": [
            256,
            261
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.7.0",
        "Node name for S&R": "LTXVConcatAVLatent",
        "hasSecondTab": false,
        "widget_ue_connectable": {},
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": []
    },
    {
      "id": 98,
      "type": "LTXVScheduler",
      "pos": [
        -1989.0443662955117,
        2553.429434309447
      ],
      "size": [
        270,
        170
      ],
      "flags": {},
      "order": 27,
      "mode": 0,
      "inputs": [
        {
          "label": "latent",
          "name": "latent",
          "shape": 7,
          "type": "LATENT",
          "link": 256
        },
        {
          "label": "steps",
          "name": "steps",
          "type": "INT",
          "widget": {
            "name": "steps"
          }
        },
        {
          "label": "max_shift",
          "name": "max_shift",
          "type": "FLOAT",
          "widget": {
            "name": "max_shift"
          }
        },
        {
          "label": "base_shift",
          "name": "base_shift",
          "type": "FLOAT",
          "widget": {
            "name": "base_shift"
          }
        },
        {
          "label": "stretch",
          "name": "stretch",
          "type": "BOOLEAN",
          "widget": {
            "name": "stretch"
          }
        },
        {
          "label": "terminal",
          "name": "terminal",
          "type": "FLOAT",
          "widget": {
            "name": "terminal"
          }
        }
      ],
      "outputs": [
        {
          "label": "SIGMAS",
          "name": "SIGMAS",
          "type": "SIGMAS",
          "links": [
            426
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.56",
        "Node name for S&R": "LTXVScheduler",
        "hasSecondTab": false,
        "widget_ue_connectable": {
          "stretch": true,
          "max_shift": true,
          "terminal": true,
          "steps": true,
          "base_shift": true
        },
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": [
        20,
        2.05,
        0.95,
        true,
        0.1
      ]
    },
    {
      "id": 118,
      "type": "LTXVLatentUpsampler",
      "pos": [
        -1410,
        2180
      ],
      "size": [
        235.1999969482422,
        98
      ],
      "flags": {},
      "order": 34,
      "mode": 0,
      "inputs": [
        {
          "label": "samples",
          "name": "samples",
          "type": "LATENT",
          "link": 280
        },
        {
          "label": "upscale_model",
          "name": "upscale_model",
          "type": "LATENT_UPSCALE_MODEL",
          "link": 281
        },
        {
          "label": "vae",
          "name": "vae",
          "type": "VAE",
          "link": 438
        }
      ],
      "outputs": [
        {
          "label": "LATENT",
          "name": "LATENT",
          "type": "LATENT",
          "links": [
            262
          ]
        }
      ],
      "title": "spatial",
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.7.0",
        "Node name for S&R": "LTXVLatentUpsampler",
        "hasSecondTab": false,
        "widget_ue_connectable": {},
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": []
    },
    {
      "id": 117,
      "type": "LTXVConcatAVLatent",
      "pos": [
        -1400,
        2320
      ],
      "size": [
        229.26231275125747,
        108.68586475626398
      ],
      "flags": {},
      "order": 35,
      "mode": 0,
      "inputs": [
        {
          "label": "video_latent",
          "name": "video_latent",
          "type": "LATENT",
          "link": 262
        },
        {
          "label": "audio_latent",
          "name": "audio_latent",
          "type": "LATENT",
          "link": 263
        }
      ],
      "outputs": [
        {
          "label": "latent",
          "name": "latent",
          "type": "LATENT",
          "links": [
            273
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.5.1",
        "Node name for S&R": "LTXVConcatAVLatent",
        "hasSecondTab": false,
        "widget_ue_connectable": {},
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": []
    },
    {
      "id": 127,
      "type": "LTXVAudioVAEDecode",
      "pos": [
        -1410,
        2480
      ],
      "size": [
        240,
        46
      ],
      "flags": {},
      "order": 39,
      "mode": 0,
      "inputs": [
        {
          "label": "samples",
          "name": "samples",
          "type": "LATENT",
          "link": 294
        },
        {
          "label": "audio_vae",
          "name": "audio_vae",
          "type": "VAE",
          "link": 444
        }
      ],
      "outputs": [
        {
          "label": "Audio",
          "name": "Audio",
          "type": "AUDIO",
          "links": [
            432
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.7.0",
        "Node name for S&R": "LTXVAudioVAEDecode",
        "hasSecondTab": false,
        "widget_ue_connectable": {},
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": []
    },
    {
      "id": 102,
      "type": "LTXVCropGuides",
      "pos": [
        -1410,
        2070
      ],
      "size": [
        240,
        66
      ],
      "flags": {},
      "order": 30,
      "mode": 0,
      "inputs": [
        {
          "label": "positive",
          "name": "positive",
          "type": "CONDITIONING",
          "link": 406
        },
        {
          "label": "negative",
          "name": "negative",
          "type": "CONDITIONING",
          "link": 355
        },
        {
          "label": "latent",
          "name": "latent",
          "type": "LATENT",
          "link": 266
        }
      ],
      "outputs": [
        {
          "label": "positive",
          "name": "positive",
          "type": "CONDITIONING",
          "links": [
            274
          ]
        },
        {
          "label": "negative",
          "name": "negative",
          "type": "CONDITIONING",
          "links": [
            275
          ]
        },
        {
          "label": "latent",
          "name": "latent",
          "type": "LATENT",
          "slot_index": 2,
          "links": [
            280
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.68",
        "Node name for S&R": "LTXVCropGuides",
        "hasSecondTab": false,
        "widget_ue_connectable": {},
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": []
    },
    {
      "id": 119,
      "type": "SamplerCustomAdvanced",
      "pos": [
        -872.8528757863278,
        2067.3717716214505
      ],
      "size": [
        282.6361389160156,
        106
      ],
      "flags": {},
      "order": 36,
      "mode": 0,
      "inputs": [
        {
          "label": "noise",
          "name": "noise",
          "type": "NOISE",
          "link": 269
        },
        {
          "label": "guider",
          "name": "guider",
          "type": "GUIDER",
          "link": 270
        },
        {
          "label": "sampler",
          "name": "sampler",
          "type": "SAMPLER",
          "link": 271
        },
        {
          "label": "sigmas",
          "name": "sigmas",
          "type": "SIGMAS",
          "link": 272
        },
        {
          "label": "latent_image",
          "name": "latent_image",
          "type": "LATENT",
          "link": 273
        }
      ],
      "outputs": [
        {
          "label": "output",
          "name": "output",
          "type": "LATENT",
          "links": []
        },
        {
          "label": "denoised_output",
          "name": "denoised_output",
          "type": "LATENT",
          "links": [
            296
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.75",
        "Node name for S&R": "SamplerCustomAdvanced",
        "hasSecondTab": false,
        "widget_ue_connectable": {},
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": []
    },
    {
      "id": 111,
      "type": "EmptyImage",
      "pos": [
        -3410,
        2480
      ],
      "size": [
        389.25634671873604,
        130
      ],
      "flags": {},
      "order": 9,
      "mode": 0,
      "inputs": [
        {
          "label": "width",
          "name": "width",
          "type": "INT",
          "widget": {
            "name": "width"
          }
        },
        {
          "label": "height",
          "name": "height",
          "type": "INT",
          "widget": {
            "name": "height"
          }
        },
        {
          "label": "batch_size",
          "name": "batch_size",
          "type": "INT",
          "widget": {
            "name": "batch_size"
          }
        },
        {
          "label": "color",
          "name": "color",
          "type": "INT",
          "widget": {
            "name": "color"
          }
        }
      ],
      "outputs": [
        {
          "label": "IMAGE",
          "name": "IMAGE",
          "type": "IMAGE",
          "links": [
            276
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.5.1",
        "Node name for S&R": "EmptyImage",
        "hasSecondTab": false,
        "widget_ue_connectable": {
          "batch_size": true,
          "color": true,
          "width": true,
          "height": true
        },
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": [
        720,
        1280,
        1,
        0
      ]
    },
    {
      "id": 104,
      "type": "ImageScaleBy",
      "pos": [
        -1700.0518497387172,
        2629.7677968207972
      ],
      "size": [
        272.6927185058594,
        120.77466583251953
      ],
      "flags": {},
      "order": 14,
      "mode": 0,
      "inputs": [
        {
          "label": "image",
          "name": "image",
          "type": "IMAGE",
          "link": 276
        },
        {
          "label": "upscale_method",
          "name": "upscale_method",
          "type": "COMBO",
          "widget": {
            "name": "upscale_method"
          }
        },
        {
          "label": "scale_by",
          "name": "scale_by",
          "type": "FLOAT",
          "widget": {
            "name": "scale_by"
          }
        }
      ],
      "outputs": [
        {
          "label": "IMAGE",
          "name": "IMAGE",
          "type": "IMAGE",
          "links": [
            277
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.5.1",
        "Node name for S&R": "ImageScaleBy",
        "hasSecondTab": false,
        "widget_ue_connectable": {
          "scale_by": true,
          "upscale_method": true
        },
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": [
        "area",
        0.5
      ]
    },
    {
      "id": 105,
      "type": "GetImageSize",
      "pos": [
        -1412.3950160349432,
        2594.8598001932364
      ],
      "size": [
        290.1785583496094,
        136
      ],
      "flags": {},
      "order": 20,
      "mode": 0,
      "inputs": [
        {
          "label": "image",
          "name": "image",
          "type": "IMAGE",
          "link": 277
        }
      ],
      "outputs": [
        {
          "label": "width",
          "name": "width",
          "type": "INT",
          "links": [
            287
          ]
        },
        {
          "label": "height",
          "name": "height",
          "type": "INT",
          "links": [
            288
          ]
        },
        {
          "label": "batch_size",
          "name": "batch_size",
          "type": "INT",
          "links": []
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.7.0",
        "Node name for S&R": "GetImageSize",
        "hasSecondTab": false,
        "widget_ue_connectable": {},
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": []
    },
    {
      "id": 108,
      "type": "EmptyLTXVLatentVideo",
      "pos": [
        -1098.3573199194443,
        2585.8474476844203
      ],
      "size": [
        270,
        146.6666717529297
      ],
      "flags": {},
      "order": 23,
      "mode": 0,
      "inputs": [
        {
          "label": "width",
          "name": "width",
          "type": "INT",
          "widget": {
            "name": "width"
          },
          "link": 287
        },
        {
          "label": "height",
          "name": "height",
          "type": "INT",
          "widget": {
            "name": "height"
          },
          "link": 288
        },
        {
          "label": "length",
          "name": "length",
          "type": "INT",
          "widget": {
            "name": "length"
          },
          "link": 289
        },
        {
          "label": "batch_size",
          "name": "batch_size",
          "type": "INT",
          "widget": {
            "name": "batch_size"
          }
        }
      ],
      "outputs": [
        {
          "label": "LATENT",
          "name": "LATENT",
          "type": "LATENT",
          "links": [
            290
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.60",
        "Node name for S&R": "EmptyLTXVLatentVideo",
        "hasSecondTab": false,
        "widget_ue_connectable": {
          "batch_size": true,
          "width": true,
          "length": true,
          "height": true
        },
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": [
        768,
        512,
        97,
        1
      ]
    },
    {
      "id": 106,
      "type": "LTXVEmptyLatentAudio",
      "pos": [
        -820.0338807319222,
        2593.9865329415293
      ],
      "size": [
        233.42822758838383,
        123.18020728984038
      ],
      "flags": {},
      "order": 15,
      "mode": 0,
      "inputs": [
        {
          "label": "audio_vae",
          "name": "audio_vae",
          "type": "VAE",
          "link": 442
        },
        {
          "label": "frames_number",
          "name": "frames_number",
          "type": "INT",
          "widget": {
            "name": "frames_number"
          },
          "link": 279
        },
        {
          "label": "frame_rate",
          "name": "frame_rate",
          "type": "INT",
          "widget": {
            "name": "frame_rate"
          },
          "link": 303
        },
        {
          "label": "batch_size",
          "name": "batch_size",
          "type": "INT",
          "widget": {
            "name": "batch_size"
          }
        }
      ],
      "outputs": [
        {
          "label": "Latent",
          "name": "Latent",
          "type": "LATENT",
          "links": [
            291
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.68",
        "Node name for S&R": "LTXVEmptyLatentAudio",
        "hasSecondTab": false,
        "widget_ue_connectable": {
          "batch_size": true,
          "frame_rate": true,
          "frames_number": true
        },
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": [
        97,
        25,
        1
      ]
    },
    {
      "id": 193,
      "type": "ComfyNumberConvert",
      "pos": [
        -707.1061519403358,
        2545.3340234083653
      ],
      "size": [
        140,
        46
      ],
      "flags": {
        "collapsed": true
      },
      "order": 16,
      "mode": 0,
      "inputs": [
        {
          "label": "value",
          "name": "value",
          "type": "INT,FLOAT,STRING,BOOLEAN",
          "link": 448
        }
      ],
      "outputs": [
        {
          "name": "FLOAT",
          "type": "FLOAT",
          "links": [
            449,
            450
          ]
        },
        {
          "name": "INT",
          "type": "INT",
          "links": null
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.27.0",
        "Node name for S&R": "ComfyNumberConvert"
      },
      "widgets_values": []
    },
    {
      "id": 130,
      "type": "PrimitiveInt",
      "pos": [
        -875.9352692684479,
        2544.451241676698
      ],
      "size": [
        270,
        82
      ],
      "flags": {
        "collapsed": true
      },
      "order": 10,
      "mode": 0,
      "inputs": [
        {
          "label": "value",
          "name": "value",
          "type": "INT",
          "widget": {
            "name": "value"
          }
        }
      ],
      "outputs": [
        {
          "label": "INT",
          "name": "INT",
          "type": "INT",
          "links": [
            303,
            448
          ]
        }
      ],
      "title": "Frame Rate(int)",
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.7.0",
        "Node name for S&R": "PrimitiveInt",
        "hasSecondTab": false,
        "widget_ue_connectable": {
          "value": true
        },
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": [
        24,
        "fixed"
      ]
    },
    {
      "id": 187,
      "type": "VHS_VideoCombine",
      "pos": [
        -523.2278129203107,
        2024.9408917288272
      ],
      "size": [
        714.5543727401828,
        1607.6463325794039
      ],
      "flags": {},
      "order": 40,
      "mode": 0,
      "inputs": [
        {
          "label": "images",
          "name": "images",
          "type": "IMAGE",
          "link": 431
        },
        {
          "label": "audio",
          "name": "audio",
          "shape": 7,
          "type": "AUDIO",
          "link": 432
        },
        {
          "label": "meta_batch",
          "name": "meta_batch",
          "shape": 7,
          "type": "VHS_BatchManager"
        },
        {
          "label": "vae",
          "name": "vae",
          "shape": 7,
          "type": "VAE"
        },
        {
          "label": "frame_rate",
          "name": "frame_rate",
          "type": "FLOAT",
          "widget": {
            "name": "frame_rate"
          },
          "link": 449
        },
        {
          "label": "loop_count",
          "name": "loop_count",
          "type": "INT",
          "widget": {
            "name": "loop_count"
          }
        },
        {
          "label": "filename_prefix",
          "name": "filename_prefix",
          "type": "STRING",
          "widget": {
            "name": "filename_prefix"
          }
        },
        {
          "label": "format",
          "name": "format",
          "type": "COMBO",
          "widget": {
            "name": "format"
          }
        },
        {
          "label": "pingpong",
          "name": "pingpong",
          "type": "BOOLEAN",
          "widget": {
            "name": "pingpong"
          }
        },
        {
          "label": "save_output",
          "name": "save_output",
          "type": "BOOLEAN",
          "widget": {
            "name": "save_output"
          }
        },
        {
          "label": "pix_fmt",
          "name": "pix_fmt",
          "type": [
            "yuv420p",
            "yuv420p10le"
          ],
          "widget": {
            "name": "pix_fmt"
          }
        },
        {
          "label": "crf",
          "name": "crf",
          "type": "INT",
          "widget": {
            "name": "crf"
          }
        },
        {
          "label": "save_metadata",
          "name": "save_metadata",
          "type": "BOOLEAN",
          "widget": {
            "name": "save_metadata"
          }
        },
        {
          "label": "trim_to_audio",
          "name": "trim_to_audio",
          "type": "BOOLEAN",
          "widget": {
            "name": "trim_to_audio"
          }
        }
      ],
      "outputs": [
        {
          "label": "Filenames",
          "name": "Filenames",
          "type": "VHS_FILENAMES"
        }
      ],
      "properties": {
        "Node name for S&R": "VHS_VideoCombine",
        "cnr_id": "comfyui-videohelpersuite",
        "ver": "1.7.7",
        "widget_ue_connectable": {
          "save_output": true,
          "filename_prefix": true,
          "loop_count": true,
          "pix_fmt": true,
          "save_metadata": true,
          "crf": true,
          "trim_to_audio": true,
          "format": true,
          "frame_rate": true,
          "pingpong": true
        }
      },
      "widgets_values": {
        "frame_rate": 8,
        "loop_count": 0,
        "filename_prefix": "ltx-2.3/t2v",
        "format": "video/h264-mp4",
        "pix_fmt": "yuv420p",
        "crf": 19,
        "save_metadata": true,
        "trim_to_audio": false,
        "pingpong": false,
        "save_output": true,
        "videopreview": {
          "paused": false,
          "hidden": false,
          "params": {
            "score": "0",
            "filename": "t2v_00001-audio.mp4",
            "cos_url": "https://rh-images-1252422369.cos.ap-beijing.myqcloud.com//ac88cb40c80f9dec8b5a9b61ebea9178/output/ltx-2.3/t2v_00003_p80-audio_sjgfq_1779793459.mp4",
            "workflow": "t2v_00001.png",
            "fullpath": "/ComfyUI/output/ltx-2.3/t2v_00001-audio.mp4",
            "format": "video/h264-mp4",
            "subfolder": "ltx-2.3",
            "label": "Normal",
            "type": "output",
            "frame_rate": 24
          }
        }
      }
    },
    {
      "id": 159,
      "type": "CheckpointLoaderSimple",
      "pos": [
        -2938.543700275126,
        2065.1486997998445
      ],
      "size": [
        442.3332824707031,
        101.76976013183594
      ],
      "flags": {},
      "order": 11,
      "mode": 0,
      "inputs": [
        {
          "label": "ckpt_name",
          "name": "ckpt_name",
          "type": "COMBO",
          "widget": {
            "name": "ckpt_name"
          }
        }
      ],
      "outputs": [
        {
          "label": "MODEL",
          "name": "MODEL",
          "type": "MODEL",
          "links": [
            434,
            435
          ]
        },
        {
          "label": "CLIP",
          "name": "CLIP",
          "type": "CLIP",
          "links": []
        },
        {
          "label": "VAE",
          "name": "VAE",
          "type": "VAE",
          "links": [
            436,
            437,
            438,
            439
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.56",
        "Node name for S&R": "CheckpointLoaderSimple",
        "hasSecondTab": false,
        "models": [
          {
            "name": "ltx-2-19b-dev-fp8.safetensors",
            "directory": "checkpoints",
            "url": "https://huggingface.co/Lightricks/LTX-2/resolve/main/ltx-2-19b-dev-fp8.safetensors"
          }
        ],
        "widget_ue_connectable": {
          "ckpt_name": true
        },
        "secondTabText": "Send Back",
        "enableTabs": false,
        "secondTabOffset": 80,
        "tabWidth": 65,
        "secondTabWidth": 65,
        "tabXOffset": 10
      },
      "widgets_values": [
        "ltx-2.3-22b-dev.safetensors"
      ]
    },
    {
      "id": 195,
      "type": "LayerUtility: TextBox",
      "pos": [
        -3430,
        2080
      ],
      "size": [
        400,
        200
      ],
      "flags": {},
      "order": 12,
      "mode": 0,
      "inputs": [],
      "outputs": [
        {
          "name": "text",
          "type": "STRING",
          "links": [
            452
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "LayerUtility: TextBox"
      },
      "widgets_values": [
        "Medium shot: A beautiful 20-year-old woman with shoulder-length brown hair, wearing a cream-colored casual sweater, sits on a modern gray fabric sofa in a well-lit living room. She holds a smartphone with both hands, her thumbs tapping the screen as she plays a casual puzzle game. Soft natural daylight streams in from a window on the left, casting gentle shadows. She looks down at the phone, her brow slightly furrowed, and speaks with a light, playful tone: \"Can anyone help me?\" The camera performs a slow, smooth push-in, moving from a medium shot to a medium close-up. She then lifts the phone slightly, shakes it gently toward the camera, and smiles warmly, saying: \"Hope you can get past Level 10 too.\" Ambient indoor silence, crisp dialogue audio."
      ],
      "color": "rgba(38, 73, 116, 0.7)"
    }
  ],
  "links": [
    [
      255,
      107,
      1,
      128,
      2,
      "CONDITIONING"
    ],
    [
      256,
      109,
      0,
      98,
      0,
      "LATENT"
    ],
    [
      257,
      115,
      0,
      113,
      0,
      "NOISE"
    ],
    [
      258,
      128,
      0,
      113,
      1,
      "GUIDER"
    ],
    [
      259,
      135,
      0,
      113,
      2,
      "SAMPLER"
    ],
    [
      261,
      109,
      0,
      113,
      4,
      "LATENT"
    ],
    [
      262,
      118,
      0,
      117,
      0,
      "LATENT"
    ],
    [
      263,
      116,
      1,
      117,
      1,
      "LATENT"
    ],
    [
      266,
      116,
      0,
      102,
      2,
      "LATENT"
    ],
    [
      268,
      113,
      0,
      116,
      0,
      "LATENT"
    ],
    [
      269,
      114,
      0,
      119,
      0,
      "NOISE"
    ],
    [
      270,
      103,
      0,
      119,
      1,
      "GUIDER"
    ],
    [
      271,
      136,
      0,
      119,
      2,
      "SAMPLER"
    ],
    [
      272,
      100,
      0,
      119,
      3,
      "SIGMAS"
    ],
    [
      273,
      117,
      0,
      119,
      4,
      "LATENT"
    ],
    [
      274,
      102,
      0,
      103,
      1,
      "CONDITIONING"
    ],
    [
      275,
      102,
      1,
      103,
      2,
      "CONDITIONING"
    ],
    [
      276,
      111,
      0,
      104,
      0,
      "IMAGE"
    ],
    [
      277,
      104,
      0,
      105,
      0,
      "IMAGE"
    ],
    [
      279,
      112,
      0,
      106,
      1,
      "INT"
    ],
    [
      280,
      102,
      2,
      118,
      0,
      "LATENT"
    ],
    [
      281,
      101,
      0,
      118,
      1,
      "LATENT_UPSCALE_MODEL"
    ],
    [
      283,
      121,
      0,
      107,
      0,
      "CONDITIONING"
    ],
    [
      284,
      110,
      0,
      107,
      1,
      "CONDITIONING"
    ],
    [
      287,
      105,
      0,
      108,
      0,
      "INT"
    ],
    [
      288,
      105,
      1,
      108,
      1,
      "INT"
    ],
    [
      289,
      112,
      0,
      108,
      2,
      "INT"
    ],
    [
      290,
      108,
      0,
      109,
      0,
      "LATENT"
    ],
    [
      291,
      106,
      0,
      109,
      1,
      "LATENT"
    ],
    [
      294,
      124,
      1,
      127,
      0,
      "LATENT"
    ],
    [
      296,
      119,
      1,
      124,
      0,
      "LATENT"
    ],
    [
      299,
      124,
      0,
      126,
      0,
      "LATENT"
    ],
    [
      303,
      130,
      0,
      106,
      2,
      "INT"
    ],
    [
      307,
      134,
      0,
      128,
      0,
      "MODEL"
    ],
    [
      308,
      132,
      0,
      133,
      0,
      "MODEL"
    ],
    [
      309,
      133,
      0,
      103,
      0,
      "MODEL"
    ],
    [
      329,
      116,
      0,
      151,
      0,
      "LATENT"
    ],
    [
      334,
      116,
      1,
      152,
      0,
      "LATENT"
    ],
    [
      355,
      107,
      1,
      102,
      1,
      "CONDITIONING"
    ],
    [
      403,
      107,
      0,
      180,
      0,
      "CONDITIONING"
    ],
    [
      405,
      180,
      0,
      128,
      1,
      "CONDITIONING"
    ],
    [
      406,
      180,
      0,
      102,
      0,
      "CONDITIONING"
    ],
    [
      426,
      98,
      0,
      113,
      3,
      "SIGMAS"
    ],
    [
      431,
      126,
      0,
      187,
      0,
      "IMAGE"
    ],
    [
      432,
      127,
      0,
      187,
      1,
      "AUDIO"
    ],
    [
      434,
      159,
      0,
      132,
      0,
      "MODEL"
    ],
    [
      435,
      159,
      0,
      134,
      0,
      "MODEL"
    ],
    [
      436,
      159,
      2,
      180,
      1,
      "*"
    ],
    [
      437,
      159,
      2,
      151,
      1,
      "VAE"
    ],
    [
      438,
      159,
      2,
      118,
      2,
      "VAE"
    ],
    [
      439,
      159,
      2,
      126,
      1,
      "VAE"
    ],
    [
      440,
      161,
      0,
      121,
      0,
      "CLIP"
    ],
    [
      441,
      161,
      0,
      110,
      0,
      "CLIP"
    ],
    [
      442,
      160,
      0,
      106,
      0,
      "VAE"
    ],
    [
      443,
      160,
      0,
      152,
      1,
      "VAE"
    ],
    [
      444,
      160,
      0,
      127,
      1,
      "VAE"
    ],
    [
      448,
      130,
      0,
      193,
      0,
      "INT"
    ],
    [
      449,
      193,
      0,
      187,
      4,
      "FLOAT"
    ],
    [
      450,
      193,
      0,
      107,
      2,
      "FLOAT"
    ],
    [
      452,
      195,
      0,
      121,
      1,
      "STRING"
    ]
  ],
  "groups": [
    {
      "id": 16,
      "title": "工作区",
      "bounding": [
        -2001.2750244140625,
        1962.8873291015625,
        1437.2821489451426,
        796.8686416732653
      ],
      "color": "#3f789e",
      "flags": {}
    },
    {
      "id": 19,
      "title": "模型加载区",
      "bounding": [
        -2958.4151241931286,
        1972.5658036765126,
        928.8407781651686,
        935.306269818205
      ],
      "color": "#3f789e",
      "flags": {}
    }
  ],
  "config": {},
  "extra": {
    "VHS_KeepIntermediate": true,
    "links_added_by_ue": [],
    "comfy_fork_version": "feature/av_inference@a6994ed1",
    "VHS_MetadataImage": true,
    "ue_links": [],
    "0246.VERSION": [
      0,
      0,
      4
    ],
    "workflowRendererVersion": "LG",
    "VHS_latentpreviewrate": 0,
    "frontendVersion": "1.45.20",
    "VHS_latentpreview": false,
    "prompt": {
      "1": {
        "class_type": "CheckpointLoaderSimple",
        "inputs": {
          "ckpt_name": "ltx-av-step-1751000_vocoder_24K.safetensors"
        },
        "_meta": {
          "title": "Load Checkpoint"
        }
      },
      "2": {
        "class_type": "LTXVGemmaCLIPModelLoader",
        "inputs": {
          "ltxv_path": "ltx-av-step-1751000_vocoder_24K.safetensors",
          "gemma_path": "gemma-3-12b-it-qat-q4_0-unquantized_readout_proj/model/model.safetensors",
          "max_length": 1024
        },
        "_meta": {
          "title": "🅛🅣🅧 Gemma 3 Model Loader"
        }
      },
      "3": {
        "class_type": "CLIPTextEncode",
        "inputs": {
          "text": "A medium close-up shot features a Caucasian man with a closely shaven head and face, wearing a black baseball cap with \"PNTR\" in white letters on the front, and a dark grey t-shirt with \"JUST DO IT\" visible across his chest. A small black microphone is clipped to his shirt collar. He is positioned slightly to the left of the frame, looking intently downwards and to his right, his eyes focused off-camera. His facial expression is one of deep concentration, with his brow slightly furrowed. As he looks down, a quick sniff sound is heard, and then he speaks with a deep male voice and a slightly frustrated tone, saying, \"I think it's so bad.\" The camera remains static throughout, maintaining a shallow depth of field, which keeps the man in sharp focus while the background is softly blurred, revealing a light-colored wall with white wooden shelving or trim, and a partially open white wooden door on the right. After a brief pause, another short, audible sniff is heard. The man then continues to speak, his voice maintaining the same quality, as he states, \"So bad. So bad.\" He elaborates further, emphasizing his point with a final statement, \"This got to be, it's got to be the worst tool I've ever seen.\"",
          "clip": [
            "2",
            0
          ]
        },
        "_meta": {
          "title": "CLIP Text Encode (Prompt)"
        }
      },
      "4": {
        "class_type": "CLIPTextEncode",
        "inputs": {
          "text": "blurry, low quality, still frame, frames, watermark, overlay, titles, has blurbox, has subtitles",
          "clip": [
            "2",
            0
          ]
        },
        "_meta": {
          "title": "CLIP Text Encode (Prompt)"
        }
      },
      "8": {
        "class_type": "KSamplerSelect",
        "inputs": {
          "sampler_name": "euler"
        },
        "_meta": {
          "title": "KSamplerSelect"
        }
      },
      "9": {
        "class_type": "LTXVScheduler",
        "inputs": {
          "stretch": true,
          "latent": [
            "28",
            0
          ],
          "max_shift": 2.05,
          "terminal": 0.1,
          "steps": 20,
          "base_shift": 0.95
        },
        "_meta": {
          "title": "LTXVScheduler"
        }
      },
      "11": {
        "class_type": "RandomNoise",
        "inputs": {
          "noise_seed": 10
        },
        "_meta": {
          "title": "RandomNoise"
        }
      },
      "12": {
        "class_type": "VAEDecode",
        "inputs": {
          "vae": [
            "1",
            2
          ],
          "samples": [
            "29",
            0
          ]
        },
        "_meta": {
          "title": "VAE Decode"
        }
      },
      "13": {
        "class_type": "LTXVAudioVAELoader",
        "inputs": {
          "ckpt_name": "ltx-av-step-1751000_vocoder_24K.safetensors"
        },
        "_meta": {
          "title": "🅛🅣🅧 LTXV Audio VAE Loader"
        }
      },
      "14": {
        "class_type": "LTXVAudioVAEDecode",
        "inputs": {
          "audio_vae": [
            "13",
            0
          ],
          "samples": [
            "29",
            1
          ]
        },
        "_meta": {
          "title": "🅛🅣🅧 LTXV Audio VAE Decode"
        }
      },
      "15": {
        "class_type": "VHS_VideoCombine",
        "inputs": {
          "save_output": true,
          "filename_prefix": "AnimateDiff",
          "images": [
            "12",
            0
          ],
          "loop_count": 0,
          "pix_fmt": "yuv420p",
          "save_metadata": true,
          "crf": 19,
          "trim_to_audio": false,
          "format": "video/h264-mp4",
          "audio": [
            "14",
            0
          ],
          "frame_rate": [
            "23",
            0
          ],
          "pingpong": false
        },
        "_meta": {
          "title": "Video Combine 🎥🅥🅗🅢"
        }
      },
      "17": {
        "class_type": "MultimodalGuider",
        "inputs": {
          "skip_blocks": "29",
          "negative": [
            "22",
            1
          ],
          "model": [
            "28",
            1
          ],
          "positive": [
            "22",
            0
          ],
          "parameters": [
            "18",
            0
          ]
        },
        "_meta": {
          "title": "🅛🅣🅧 Multimodal Guider"
        }
      },
      "18": {
        "class_type": "GuiderParameters",
        "inputs": {
          "modality": "VIDEO",
          "cfg": 3,
          "rescale": 0,
          "stg": 0,
          "parameters": [
            "19",
            0
          ],
          "modality_scale": 3
        },
        "_meta": {
          "title": "🅛🅣🅧 Guider Parameters"
        }
      },
      "19": {
        "class_type": "GuiderParameters",
        "inputs": {
          "modality": "AUDIO",
          "cfg": 7,
          "rescale": 0,
          "stg": 0,
          "modality_scale": 3
        },
        "_meta": {
          "title": "🅛🅣🅧 Guider Parameters"
        }
      },
      "21": {
        "class_type": "PreviewAudio",
        "inputs": {
          "audio": [
            "14",
            0
          ],
          "audioUI": ""
        },
        "_meta": {
          "title": "PreviewAudio"
        }
      },
      "22": {
        "class_type": "LTXVConditioning",
        "inputs": {
          "negative": [
            "4",
            0
          ],
          "positive": [
            "3",
            0
          ],
          "frame_rate": [
            "23",
            0
          ]
        },
        "_meta": {
          "title": "LTXVConditioning"
        }
      },
      "23": {
        "class_type": "FloatConstant",
        "inputs": {
          "value": 25
        },
        "_meta": {
          "title": "Float Constant"
        }
      },
      "26": {
        "class_type": "LTXVEmptyLatentAudio",
        "inputs": {
          "batch_size": 1,
          "frame_rate": [
            "42",
            0
          ],
          "frames_number": [
            "27",
            0
          ]
        },
        "_meta": {
          "title": "🅛🅣🅧 LTXV Empty Latent Audio"
        }
      },
      "27": {
        "class_type": "INTConstant",
        "inputs": {
          "value": 105
        },
        "_meta": {
          "title": "INT Constant"
        }
      },
      "28": {
        "class_type": "LTXVConcatAVLatent",
        "inputs": {
          "audio_latent": [
            "26",
            0
          ],
          "video_latent": [
            "43",
            0
          ],
          "model": [
            "44",
            0
          ]
        },
        "_meta": {
          "title": "🅛🅣🅧 LTXV Concat AV Latent"
        }
      },
      "29": {
        "class_type": "LTXVSeparateAVLatent",
        "inputs": {
          "av_latent": [
            "41",
            0
          ],
          "model": [
            "28",
            1
          ]
        },
        "_meta": {
          "title": "🅛🅣🅧 LTXV Separate AV Latent"
        }
      },
      "41": {
        "class_type": "SamplerCustomAdvanced",
        "inputs": {
          "guider": [
            "17",
            0
          ],
          "latent_image": [
            "28",
            0
          ],
          "noise": [
            "11",
            0
          ],
          "sigmas": [
            "9",
            0
          ],
          "sampler": [
            "8",
            0
          ]
        },
        "_meta": {
          "title": "SamplerCustomAdvanced"
        }
      },
      "42": {
        "class_type": "CM_FloatToInt",
        "inputs": {
          "a": [
            "23",
            0
          ]
        },
        "_meta": {
          "title": "FloatToInt"
        }
      },
      "43": {
        "class_type": "EmptyLTXVLatentVideo",
        "inputs": {
          "batch_size": 1,
          "width": 768,
          "length": [
            "27",
            0
          ],
          "height": 512
        },
        "_meta": {
          "title": "EmptyLTXVLatentVideo"
        }
      },
      "44": {
        "class_type": "LTXVSequenceParallelMultiGPUPatcher",
        "inputs": {
          "disable_backup": false,
          "torch_compile": true,
          "model": [
            "1",
            0
          ]
        },
        "_meta": {
          "title": "LTXVSequenceParallelMultiGPUPatcher"
        }
      },
      "45": {
        "class_type": "LTXVAddGuide",
        "inputs": {
          "strength": 1,
          "frame_idx": 0
        },
        "_meta": {
          "title": "LTXVAddGuide"
        }
      }
    },
    "ds": {
      "scale": 0.5445000000000039,
      "offset": [
        4010.8190407863967,
        -1539.473608840433
      ]
    }
  },
  "version": 0.4
}
```
