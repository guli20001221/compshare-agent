# 视频风格转绘

- 来源类别：用户工作流
- 镜像内原始路径：`/ComfyUI/user/default/workflows/18个开源模型工作流/视频/视频风格转绘.json`
- 节点数量：18
- 连线数量：22

## 节点类型

- `INTConstant` × 1
- `LayerUtility: ImageScaleByAspectRatio V2` × 1
- `LoadWanVideoT5TextEncoder` × 1
- `Note` × 1
- `PrimitiveStringMultiline` × 1
- `VHS_LoadVideo` × 1
- `VHS_VideoCombine` × 1
- `WanVideoBlockSwap` × 1
- `WanVideoDecode` × 1
- `WanVideoLoraSelect` × 1
- `WanVideoModelLoader` × 1
- `WanVideoSLG` × 1
- `WanVideoSampler` × 1
- `WanVideoTextEncode` × 1
- `WanVideoTorchCompileSettings` × 1
- `WanVideoVACEEncode` × 1
- `WanVideoVACEModelSelect` × 1
- `WanVideoVAELoader` × 1

## 工作流引用的模型或媒体文件

- `/ComfyUI/output/xiaren_00001-audio.mp4`
- `CAIL_00001-audio.mp4`
- `Wan2_1-T2V-14B_fp8_e4m3fn.safetensors`
- `Wan2_1_VAE_bf16.safetensors`
- `ditto_global_comfy.safetensors`
- `till_v2_lora_rank256_bf16.safetensors`
- `umt5-xxl-enc-bf16.safetensors`
- `xiaren_00001-audio.mp4`

## 原始工作流 JSON

```json
{
  "id": "8f675bcb-5f3d-41ee-b8f9-07e7a22a1ace",
  "revision": 0,
  "last_node_id": 66,
  "last_link_id": 79,
  "nodes": [
    {
      "id": 38,
      "type": "WanVideoLoraSelect",
      "pos": [
        1050.9414657577902,
        148.0781774554294
      ],
      "size": [
        391.4609785613411,
        163.82248307784516
      ],
      "flags": {},
      "order": 0,
      "mode": 0,
      "inputs": [
        {
          "label": "prev_lora",
          "localized_name": "prev_lora",
          "name": "prev_lora",
          "shape": 7,
          "type": "WANVIDLORA"
        },
        {
          "label": "blocks",
          "localized_name": "blocks",
          "name": "blocks",
          "shape": 7,
          "type": "SELECTEDBLOCKS"
        },
        {
          "label": "lora",
          "localized_name": "lora",
          "name": "lora",
          "type": "COMBO",
          "widget": {
            "name": "lora"
          }
        },
        {
          "label": "strength",
          "localized_name": "strength",
          "name": "strength",
          "type": "FLOAT",
          "widget": {
            "name": "strength"
          }
        },
        {
          "label": "low_mem_load",
          "localized_name": "low_mem_load",
          "name": "low_mem_load",
          "shape": 7,
          "type": "BOOLEAN",
          "widget": {
            "name": "low_mem_load"
          }
        },
        {
          "label": "merge_loras",
          "localized_name": "merge_loras",
          "name": "merge_loras",
          "shape": 7,
          "type": "BOOLEAN",
          "widget": {
            "name": "merge_loras"
          }
        }
      ],
      "outputs": [
        {
          "label": "lora",
          "localized_name": "lora",
          "name": "lora",
          "type": "WANVIDLORA",
          "links": [
            29
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "WanVideoLoraSelect",
        "cnr_id": "ComfyUI-WanVideoWrapper",
        "ver": "a4b1a4be7ac69ba705cd9cc43450751cd2e6f25c",
        "widget_ue_connectable": {
          "lora": true,
          "strength": true,
          "low_mem_load": true
        }
      },
      "widgets_values": [
        "lightx2v/lightx2v_T2V_14B_cfg_step_distill_v2_lora_rank256_bf16.safetensors",
        1.0000000000000002,
        false,
        true
      ]
    },
    {
      "id": 8,
      "type": "WanVideoBlockSwap",
      "pos": [
        1048.6191106328554,
        358.5242754830303
      ],
      "size": [
        409.2439270019531,
        208.2310028076172
      ],
      "flags": {},
      "order": 1,
      "mode": 0,
      "inputs": [
        {
          "label": "blocks_to_swap",
          "localized_name": "blocks_to_swap",
          "name": "blocks_to_swap",
          "type": "INT",
          "widget": {
            "name": "blocks_to_swap"
          }
        },
        {
          "label": "offload_img_emb",
          "localized_name": "offload_img_emb",
          "name": "offload_img_emb",
          "type": "BOOLEAN",
          "widget": {
            "name": "offload_img_emb"
          }
        },
        {
          "label": "offload_txt_emb",
          "localized_name": "offload_txt_emb",
          "name": "offload_txt_emb",
          "type": "BOOLEAN",
          "widget": {
            "name": "offload_txt_emb"
          }
        },
        {
          "label": "use_non_blocking",
          "localized_name": "use_non_blocking",
          "name": "use_non_blocking",
          "shape": 7,
          "type": "BOOLEAN",
          "widget": {
            "name": "use_non_blocking"
          }
        },
        {
          "label": "vace_blocks_to_swap",
          "localized_name": "vace_blocks_to_swap",
          "name": "vace_blocks_to_swap",
          "shape": 7,
          "type": "INT",
          "widget": {
            "name": "vace_blocks_to_swap"
          }
        },
        {
          "label": "prefetch_blocks",
          "localized_name": "prefetch_blocks",
          "name": "prefetch_blocks",
          "shape": 7,
          "type": "INT",
          "widget": {
            "name": "prefetch_blocks"
          }
        },
        {
          "label": "block_swap_debug",
          "localized_name": "block_swap_debug",
          "name": "block_swap_debug",
          "shape": 7,
          "type": "BOOLEAN",
          "widget": {
            "name": "block_swap_debug"
          }
        }
      ],
      "outputs": [
        {
          "label": "block_swap_args",
          "localized_name": "block_swap_args",
          "name": "block_swap_args",
          "type": "BLOCKSWAPARGS",
          "slot_index": 0,
          "links": [
            1
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "WanVideoBlockSwap",
        "cnr_id": "ComfyUI-WanVideoWrapper",
        "ver": "3869b0482b615b6a8fd6f346467c5ef6627eed72",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        25,
        false,
        false,
        false,
        0,
        0,
        false
      ]
    },
    {
      "id": 9,
      "type": "WanVideoVACEModelSelect",
      "pos": [
        1051.2851270450685,
        614.0709413378969
      ],
      "size": [
        418.62762451171875,
        92.18547058105469
      ],
      "flags": {},
      "order": 2,
      "mode": 0,
      "inputs": [
        {
          "label": "vace_model",
          "localized_name": "vace_model",
          "name": "vace_model",
          "type": "COMBO",
          "widget": {
            "name": "vace_model"
          }
        }
      ],
      "outputs": [
        {
          "label": "extra_model",
          "localized_name": "extra_model",
          "name": "extra_model",
          "type": "VACEPATH",
          "links": [
            40
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "WanVideoVACEModelSelect",
        "cnr_id": "ComfyUI-WanVideoWrapper",
        "ver": "fd562e9730ded3bb36af461c517731208dfc3746",
        "widget_ue_connectable": {
          "vace_model": true
        }
      },
      "widgets_values": [
        "ditto_global_comfy.safetensors"
      ]
    },
    {
      "id": 10,
      "type": "WanVideoVAELoader",
      "pos": [
        1050.7847637376194,
        749.4123347510954
      ],
      "size": [
        413.98370361328125,
        130
      ],
      "flags": {},
      "order": 3,
      "mode": 0,
      "inputs": [
        {
          "label": "compile_args",
          "localized_name": "compile_args",
          "name": "compile_args",
          "shape": 7,
          "type": "WANCOMPILEARGS"
        },
        {
          "label": "model_name",
          "localized_name": "model_name",
          "name": "model_name",
          "type": "COMBO",
          "widget": {
            "name": "model_name"
          }
        },
        {
          "label": "precision",
          "localized_name": "precision",
          "name": "precision",
          "shape": 7,
          "type": "COMBO",
          "widget": {
            "name": "precision"
          }
        },
        {
          "localized_name": "use_cpu_cache",
          "name": "use_cpu_cache",
          "shape": 7,
          "type": "BOOLEAN",
          "widget": {
            "name": "use_cpu_cache"
          },
          "link": null
        },
        {
          "localized_name": "verbose",
          "name": "verbose",
          "shape": 7,
          "type": "BOOLEAN",
          "widget": {
            "name": "verbose"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "vae",
          "localized_name": "vae",
          "name": "vae",
          "type": "WANVAE",
          "slot_index": 0,
          "links": [
            34,
            36
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "WanVideoVAELoader",
        "cnr_id": "ComfyUI-WanVideoWrapper",
        "ver": "3869b0482b615b6a8fd6f346467c5ef6627eed72",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "Wan2_1_VAE_bf16.safetensors",
        "bf16",
        false,
        false
      ]
    },
    {
      "id": 3,
      "type": "WanVideoTorchCompileSettings",
      "pos": [
        1471.8244657795722,
        149.65262791408685
      ],
      "size": [
        390.5999755859375,
        250
      ],
      "flags": {},
      "order": 4,
      "mode": 0,
      "inputs": [
        {
          "label": "backend",
          "localized_name": "backend",
          "name": "backend",
          "type": "COMBO",
          "widget": {
            "name": "backend"
          }
        },
        {
          "label": "fullgraph",
          "localized_name": "fullgraph",
          "name": "fullgraph",
          "type": "BOOLEAN",
          "widget": {
            "name": "fullgraph"
          }
        },
        {
          "label": "mode",
          "localized_name": "mode",
          "name": "mode",
          "type": "COMBO",
          "widget": {
            "name": "mode"
          }
        },
        {
          "label": "dynamic",
          "localized_name": "dynamic",
          "name": "dynamic",
          "type": "BOOLEAN",
          "widget": {
            "name": "dynamic"
          }
        },
        {
          "label": "dynamo_cache_size_limit",
          "localized_name": "dynamo_cache_size_limit",
          "name": "dynamo_cache_size_limit",
          "type": "INT",
          "widget": {
            "name": "dynamo_cache_size_limit"
          }
        },
        {
          "label": "compile_transformer_blocks_only",
          "localized_name": "compile_transformer_blocks_only",
          "name": "compile_transformer_blocks_only",
          "type": "BOOLEAN",
          "widget": {
            "name": "compile_transformer_blocks_only"
          }
        },
        {
          "label": "dynamo_recompile_limit",
          "localized_name": "dynamo_recompile_limit",
          "name": "dynamo_recompile_limit",
          "shape": 7,
          "type": "INT",
          "widget": {
            "name": "dynamo_recompile_limit"
          }
        },
        {
          "label": "force_parameter_static_shapes",
          "localized_name": "force_parameter_static_shapes",
          "name": "force_parameter_static_shapes",
          "shape": 7,
          "type": "BOOLEAN",
          "widget": {
            "name": "force_parameter_static_shapes"
          }
        },
        {
          "localized_name": "allow_unmerged_lora_compile",
          "name": "allow_unmerged_lora_compile",
          "shape": 7,
          "type": "BOOLEAN",
          "widget": {
            "name": "allow_unmerged_lora_compile"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "torch_compile_args",
          "localized_name": "torch_compile_args",
          "name": "torch_compile_args",
          "type": "WANCOMPILEARGS",
          "slot_index": 0,
          "links": [
            49
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "WanVideoTorchCompileSettings",
        "cnr_id": "ComfyUI-WanVideoWrapper",
        "ver": "3869b0482b615b6a8fd6f346467c5ef6627eed72",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "inductor",
        false,
        "default",
        false,
        64,
        true,
        128,
        true,
        false
      ]
    },
    {
      "id": 6,
      "type": "WanVideoModelLoader",
      "pos": [
        1478.040393088556,
        440.240243872676
      ],
      "size": [
        388.133735826038,
        338
      ],
      "flags": {},
      "order": 10,
      "mode": 0,
      "inputs": [
        {
          "label": "compile_args",
          "localized_name": "compile_args",
          "name": "compile_args",
          "shape": 7,
          "type": "WANCOMPILEARGS",
          "link": 49
        },
        {
          "label": "block_swap_args",
          "localized_name": "block_swap_args",
          "name": "block_swap_args",
          "shape": 7,
          "type": "BLOCKSWAPARGS",
          "link": 1
        },
        {
          "label": "lora",
          "localized_name": "lora",
          "name": "lora",
          "shape": 7,
          "type": "WANVIDLORA",
          "link": 29
        },
        {
          "label": "vram_management_args",
          "localized_name": "vram_management_args",
          "name": "vram_management_args",
          "shape": 7,
          "type": "VRAM_MANAGEMENTARGS"
        },
        {
          "label": "extra_model",
          "localized_name": "extra_model",
          "name": "extra_model",
          "shape": 7,
          "type": "VACEPATH"
        },
        {
          "label": "fantasytalking_model",
          "localized_name": "fantasytalking_model",
          "name": "fantasytalking_model",
          "shape": 7,
          "type": "FANTASYTALKINGMODEL"
        },
        {
          "label": "multitalk_model",
          "localized_name": "multitalk_model",
          "name": "multitalk_model",
          "shape": 7,
          "type": "MULTITALKMODEL"
        },
        {
          "label": "fantasyportrait_model",
          "localized_name": "fantasyportrait_model",
          "name": "fantasyportrait_model",
          "shape": 7,
          "type": "FANTASYPORTRAITMODEL"
        },
        {
          "label": "model",
          "localized_name": "model",
          "name": "model",
          "type": "COMBO",
          "widget": {
            "name": "model"
          }
        },
        {
          "label": "base_precision",
          "localized_name": "base_precision",
          "name": "base_precision",
          "type": "COMBO",
          "widget": {
            "name": "base_precision"
          }
        },
        {
          "label": "quantization",
          "localized_name": "quantization",
          "name": "quantization",
          "type": "COMBO",
          "widget": {
            "name": "quantization"
          }
        },
        {
          "label": "load_device",
          "localized_name": "load_device",
          "name": "load_device",
          "type": "COMBO",
          "widget": {
            "name": "load_device"
          }
        },
        {
          "label": "attention_mode",
          "localized_name": "attention_mode",
          "name": "attention_mode",
          "shape": 7,
          "type": "COMBO",
          "widget": {
            "name": "attention_mode"
          }
        },
        {
          "label": "rms_norm_function",
          "localized_name": "rms_norm_function",
          "name": "rms_norm_function",
          "shape": 7,
          "type": "COMBO",
          "widget": {
            "name": "rms_norm_function"
          }
        },
        {
          "label": "vace_model",
          "name": "vace_model",
          "shape": 7,
          "type": "VACEPATH",
          "link": 40
        }
      ],
      "outputs": [
        {
          "label": "model",
          "localized_name": "model",
          "name": "model",
          "type": "WANVIDEOMODEL",
          "slot_index": 0,
          "links": [
            72,
            73
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "WanVideoModelLoader",
        "cnr_id": "ComfyUI-WanVideoWrapper",
        "ver": "3869b0482b615b6a8fd6f346467c5ef6627eed72",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "Wan2_1-T2V-14B_fp8_e4m3fn.safetensors",
        "fp16",
        "fp8_e4m3fn",
        "offload_device",
        "sageattn",
        "default"
      ]
    },
    {
      "id": 12,
      "type": "LoadWanVideoT5TextEncoder",
      "pos": [
        1484.8089678696463,
        821.0296099740315
      ],
      "size": [
        378.1868728756267,
        130
      ],
      "flags": {},
      "order": 5,
      "mode": 0,
      "inputs": [
        {
          "label": "model_name",
          "localized_name": "model_name",
          "name": "model_name",
          "type": "COMBO",
          "widget": {
            "name": "model_name"
          }
        },
        {
          "label": "precision",
          "localized_name": "precision",
          "name": "precision",
          "type": "COMBO",
          "widget": {
            "name": "precision"
          }
        },
        {
          "label": "load_device",
          "localized_name": "load_device",
          "name": "load_device",
          "shape": 7,
          "type": "COMBO",
          "widget": {
            "name": "load_device"
          }
        },
        {
          "label": "quantization",
          "localized_name": "quantization",
          "name": "quantization",
          "shape": 7,
          "type": "COMBO",
          "widget": {
            "name": "quantization"
          }
        }
      ],
      "outputs": [
        {
          "label": "wan_t5_model",
          "localized_name": "wan_t5_model",
          "name": "wan_t5_model",
          "type": "WANTEXTENCODER",
          "slot_index": 0,
          "links": [
            35
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "LoadWanVideoT5TextEncoder",
        "cnr_id": "ComfyUI-WanVideoWrapper",
        "ver": "3869b0482b615b6a8fd6f346467c5ef6627eed72",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "umt5-xxl-enc-bf16.safetensors",
        "bf16",
        "offload_device",
        "disabled"
      ]
    },
    {
      "id": 35,
      "type": "WanVideoSampler",
      "pos": [
        2440,
        150
      ],
      "size": [
        315,
        742.1923217773438
      ],
      "flags": {},
      "order": 15,
      "mode": 0,
      "inputs": [
        {
          "label": "model",
          "localized_name": "model",
          "name": "model",
          "type": "WANVIDEOMODEL",
          "link": 73
        },
        {
          "label": "image_embeds",
          "localized_name": "image_embeds",
          "name": "image_embeds",
          "type": "WANVIDIMAGE_EMBEDS",
          "link": 16
        },
        {
          "label": "text_embeds",
          "localized_name": "text_embeds",
          "name": "text_embeds",
          "shape": 7,
          "type": "WANVIDEOTEXTEMBEDS",
          "link": 17
        },
        {
          "label": "samples",
          "localized_name": "samples",
          "name": "samples",
          "shape": 7,
          "type": "LATENT"
        },
        {
          "label": "feta_args",
          "localized_name": "feta_args",
          "name": "feta_args",
          "shape": 7,
          "type": "FETAARGS"
        },
        {
          "label": "context_options",
          "localized_name": "context_options",
          "name": "context_options",
          "shape": 7,
          "type": "WANVIDCONTEXT"
        },
        {
          "label": "cache_args",
          "localized_name": "cache_args",
          "name": "cache_args",
          "shape": 7,
          "type": "CACHEARGS"
        },
        {
          "label": "flowedit_args",
          "localized_name": "flowedit_args",
          "name": "flowedit_args",
          "shape": 7,
          "type": "FLOWEDITARGS"
        },
        {
          "label": "slg_args",
          "localized_name": "slg_args",
          "name": "slg_args",
          "shape": 7,
          "type": "SLGARGS",
          "link": 18
        },
        {
          "label": "loop_args",
          "localized_name": "loop_args",
          "name": "loop_args",
          "shape": 7,
          "type": "LOOPARGS"
        },
        {
          "label": "experimental_args",
          "localized_name": "experimental_args",
          "name": "experimental_args",
          "shape": 7,
          "type": "EXPERIMENTALARGS"
        },
        {
          "label": "sigmas",
          "localized_name": "sigmas",
          "name": "sigmas",
          "shape": 7,
          "type": "SIGMAS"
        },
        {
          "label": "unianimate_poses",
          "localized_name": "unianimate_poses",
          "name": "unianimate_poses",
          "shape": 7,
          "type": "UNIANIMATE_POSE"
        },
        {
          "label": "fantasytalking_embeds",
          "localized_name": "fantasytalking_embeds",
          "name": "fantasytalking_embeds",
          "shape": 7,
          "type": "FANTASYTALKING_EMBEDS"
        },
        {
          "label": "uni3c_embeds",
          "localized_name": "uni3c_embeds",
          "name": "uni3c_embeds",
          "shape": 7,
          "type": "UNI3C_EMBEDS"
        },
        {
          "label": "multitalk_embeds",
          "localized_name": "multitalk_embeds",
          "name": "multitalk_embeds",
          "shape": 7,
          "type": "MULTITALK_EMBEDS"
        },
        {
          "label": "freeinit_args",
          "localized_name": "freeinit_args",
          "name": "freeinit_args",
          "shape": 7,
          "type": "FREEINITARGS"
        },
        {
          "label": "steps",
          "localized_name": "steps",
          "name": "steps",
          "type": "INT",
          "widget": {
            "name": "steps"
          }
        },
        {
          "label": "cfg",
          "localized_name": "cfg",
          "name": "cfg",
          "type": "FLOAT",
          "widget": {
            "name": "cfg"
          }
        },
        {
          "label": "shift",
          "localized_name": "shift",
          "name": "shift",
          "type": "FLOAT",
          "widget": {
            "name": "shift"
          }
        },
        {
          "label": "seed",
          "localized_name": "seed",
          "name": "seed",
          "type": "INT",
          "widget": {
            "name": "seed"
          }
        },
        {
          "label": "force_offload",
          "localized_name": "force_offload",
          "name": "force_offload",
          "type": "BOOLEAN",
          "widget": {
            "name": "force_offload"
          }
        },
        {
          "label": "scheduler",
          "localized_name": "scheduler",
          "name": "scheduler",
          "type": "COMBO",
          "widget": {
            "name": "scheduler"
          }
        },
        {
          "label": "riflex_freq_index",
          "localized_name": "riflex_freq_index",
          "name": "riflex_freq_index",
          "type": "INT",
          "widget": {
            "name": "riflex_freq_index"
          }
        },
        {
          "label": "denoise_strength",
          "localized_name": "denoise_strength",
          "name": "denoise_strength",
          "shape": 7,
          "type": "FLOAT",
          "widget": {
            "name": "denoise_strength"
          }
        },
        {
          "label": "batched_cfg",
          "localized_name": "batched_cfg",
          "name": "batched_cfg",
          "shape": 7,
          "type": "BOOLEAN",
          "widget": {
            "name": "batched_cfg"
          }
        },
        {
          "label": "rope_function",
          "localized_name": "rope_function",
          "name": "rope_function",
          "shape": 7,
          "type": "COMBO",
          "widget": {
            "name": "rope_function"
          }
        },
        {
          "label": "start_step",
          "localized_name": "start_step",
          "name": "start_step",
          "shape": 7,
          "type": "INT",
          "widget": {
            "name": "start_step"
          }
        },
        {
          "label": "end_step",
          "localized_name": "end_step",
          "name": "end_step",
          "shape": 7,
          "type": "INT",
          "widget": {
            "name": "end_step"
          }
        },
        {
          "label": "add_noise_to_samples",
          "localized_name": "add_noise_to_samples",
          "name": "add_noise_to_samples",
          "shape": 7,
          "type": "BOOLEAN",
          "widget": {
            "name": "add_noise_to_samples"
          }
        },
        {
          "label": "teacache_args",
          "name": "teacache_args",
          "shape": 7,
          "type": "TEACACHEARGS"
        }
      ],
      "outputs": [
        {
          "label": "samples",
          "localized_name": "samples",
          "name": "samples",
          "type": "LATENT",
          "slot_index": 0,
          "links": [
            19
          ]
        },
        {
          "label": "denoised_samples",
          "localized_name": "denoised_samples",
          "name": "denoised_samples",
          "type": "LATENT"
        }
      ],
      "properties": {
        "Node name for S&R": "WanVideoSampler",
        "cnr_id": "ComfyUI-WanVideoWrapper",
        "ver": "209c65ba41993c7a9425697f217990df9d13d6d2",
        "widget_ue_connectable": {
          "scheduler": true,
          "denoise_strength": true,
          "seed": true,
          "cfg": true,
          "shift": true,
          "batched_cfg": true,
          "rope_function": true,
          "force_offload": true,
          "riflex_freq_index": true,
          "steps": true
        }
      },
      "widgets_values": [
        4,
        1.2000000000000002,
        2.0000000000000004,
        1022006359105194,
        "randomize",
        true,
        "unipc",
        0,
        1,
        false,
        "comfy",
        0,
        -1,
        false
      ]
    },
    {
      "id": 49,
      "type": "VHS_VideoCombine",
      "pos": [
        3130,
        150
      ],
      "size": [
        480.33380126953125,
        334
      ],
      "flags": {},
      "order": 17,
      "mode": 0,
      "inputs": [
        {
          "label": "images",
          "localized_name": "images",
          "name": "images",
          "type": "IMAGE",
          "link": 45
        },
        {
          "label": "audio",
          "localized_name": "audio",
          "name": "audio",
          "shape": 7,
          "type": "AUDIO",
          "link": 74
        },
        {
          "label": "meta_batch",
          "localized_name": "meta_batch",
          "name": "meta_batch",
          "shape": 7,
          "type": "VHS_BatchManager"
        },
        {
          "label": "vae",
          "localized_name": "vae",
          "name": "vae",
          "shape": 7,
          "type": "VAE"
        },
        {
          "label": "frame_rate",
          "localized_name": "frame_rate",
          "name": "frame_rate",
          "type": "FLOAT",
          "widget": {
            "name": "frame_rate"
          }
        },
        {
          "label": "loop_count",
          "localized_name": "loop_count",
          "name": "loop_count",
          "type": "INT",
          "widget": {
            "name": "loop_count"
          }
        },
        {
          "label": "filename_prefix",
          "localized_name": "filename_prefix",
          "name": "filename_prefix",
          "type": "STRING",
          "widget": {
            "name": "filename_prefix"
          }
        },
        {
          "label": "format",
          "localized_name": "format",
          "name": "format",
          "type": "COMBO",
          "widget": {
            "name": "format"
          }
        },
        {
          "label": "pingpong",
          "localized_name": "pingpong",
          "name": "pingpong",
          "type": "BOOLEAN",
          "widget": {
            "name": "pingpong"
          }
        },
        {
          "label": "save_output",
          "localized_name": "save_output",
          "name": "save_output",
          "type": "BOOLEAN",
          "widget": {
            "name": "save_output"
          }
        },
        {
          "name": "pix_fmt",
          "type": [
            "yuv420p",
            "yuv420p10le"
          ],
          "widget": {
            "name": "pix_fmt"
          },
          "link": null
        },
        {
          "name": "crf",
          "type": "INT",
          "widget": {
            "name": "crf"
          },
          "link": null
        },
        {
          "name": "save_metadata",
          "type": "BOOLEAN",
          "widget": {
            "name": "save_metadata"
          },
          "link": null
        },
        {
          "name": "trim_to_audio",
          "type": "BOOLEAN",
          "widget": {
            "name": "trim_to_audio"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "Filenames",
          "localized_name": "Filenames",
          "name": "Filenames",
          "type": "VHS_FILENAMES"
        }
      ],
      "properties": {
        "Node name for S&R": "VHS_VideoCombine",
        "cnr_id": "comfyui-videohelpersuite",
        "ver": "a7ce59e381934733bfae03b1be029756d6ce936d",
        "widget_ue_connectable": {
          "save_output": true,
          "filename_prefix": true,
          "loop_count": true,
          "format": true,
          "frame_rate": true,
          "pingpong": true
        }
      },
      "widgets_values": {
        "frame_rate": 16,
        "loop_count": 0,
        "filename_prefix": "xiaren",
        "format": "video/h264-mp4",
        "pix_fmt": "yuv420p",
        "crf": 23,
        "save_metadata": true,
        "trim_to_audio": false,
        "pingpong": false,
        "save_output": true,
        "videopreview": {
          "paused": false,
          "hidden": false,
          "params": {
            "score": "0",
            "filename": "xiaren_00001-audio.mp4",
            "workflow": "xiaren_00001.png",
            "fullpath": "/ComfyUI/output/xiaren_00001-audio.mp4",
            "format": "video/h264-mp4",
            "subfolder": "",
            "label": "Normal",
            "type": "output",
            "frame_rate": 16
          }
        }
      }
    },
    {
      "id": 33,
      "type": "WanVideoSLG",
      "pos": [
        1880,
        470
      ],
      "size": [
        518.8199676730674,
        106
      ],
      "flags": {},
      "order": 6,
      "mode": 0,
      "inputs": [
        {
          "label": "blocks",
          "localized_name": "blocks",
          "name": "blocks",
          "type": "STRING",
          "widget": {
            "name": "blocks"
          }
        },
        {
          "label": "start_percent",
          "localized_name": "start_percent",
          "name": "start_percent",
          "type": "FLOAT",
          "widget": {
            "name": "start_percent"
          }
        },
        {
          "label": "end_percent",
          "localized_name": "end_percent",
          "name": "end_percent",
          "type": "FLOAT",
          "widget": {
            "name": "end_percent"
          }
        }
      ],
      "outputs": [
        {
          "label": "slg_args",
          "localized_name": "slg_args",
          "name": "slg_args",
          "type": "SLGARGS",
          "links": [
            18
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "WanVideoSLG",
        "cnr_id": "ComfyUI-WanVideoWrapper",
        "ver": "2d2a184723dae88388e130659f51c36fcadeaba8",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "2",
        0.20000000000000004,
        0.7000000000000002
      ]
    },
    {
      "id": 29,
      "type": "WanVideoVACEEncode",
      "pos": [
        1890,
        620
      ],
      "size": [
        531.1357421875,
        282
      ],
      "flags": {},
      "order": 14,
      "mode": 0,
      "inputs": [
        {
          "label": "vae",
          "localized_name": "vae",
          "name": "vae",
          "type": "WANVAE",
          "link": 34
        },
        {
          "label": "input_frames",
          "localized_name": "input_frames",
          "name": "input_frames",
          "shape": 7,
          "type": "IMAGE",
          "link": 57
        },
        {
          "label": "ref_images",
          "localized_name": "ref_images",
          "name": "ref_images",
          "shape": 7,
          "type": "IMAGE"
        },
        {
          "label": "input_masks",
          "localized_name": "input_masks",
          "name": "input_masks",
          "shape": 7,
          "type": "MASK"
        },
        {
          "label": "prev_vace_embeds",
          "localized_name": "prev_vace_embeds",
          "name": "prev_vace_embeds",
          "shape": 7,
          "type": "WANVIDIMAGE_EMBEDS"
        },
        {
          "label": "width",
          "localized_name": "width",
          "name": "width",
          "type": "INT",
          "widget": {
            "name": "width"
          },
          "link": 69
        },
        {
          "label": "height",
          "localized_name": "height",
          "name": "height",
          "type": "INT",
          "widget": {
            "name": "height"
          },
          "link": 70
        },
        {
          "label": "num_frames",
          "localized_name": "num_frames",
          "name": "num_frames",
          "type": "INT",
          "widget": {
            "name": "num_frames"
          },
          "link": 71
        },
        {
          "label": "strength",
          "localized_name": "strength",
          "name": "strength",
          "type": "FLOAT",
          "widget": {
            "name": "strength"
          }
        },
        {
          "label": "vace_start_percent",
          "localized_name": "vace_start_percent",
          "name": "vace_start_percent",
          "type": "FLOAT",
          "widget": {
            "name": "vace_start_percent"
          }
        },
        {
          "label": "vace_end_percent",
          "localized_name": "vace_end_percent",
          "name": "vace_end_percent",
          "type": "FLOAT",
          "widget": {
            "name": "vace_end_percent"
          }
        },
        {
          "label": "tiled_vae",
          "localized_name": "tiled_vae",
          "name": "tiled_vae",
          "shape": 7,
          "type": "BOOLEAN",
          "widget": {
            "name": "tiled_vae"
          }
        }
      ],
      "outputs": [
        {
          "label": "vace_embeds",
          "localized_name": "vace_embeds",
          "name": "vace_embeds",
          "type": "WANVIDIMAGE_EMBEDS",
          "links": [
            16
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "WanVideoVACEEncode",
        "cnr_id": "ComfyUI-WanVideoWrapper",
        "ver": "4cebb550326361286ed0a5430cc668241d65b832",
        "widget_ue_connectable": {
          "vace_end_percent": true,
          "vace_start_percent": true,
          "strength": true,
          "tiled_vae": true,
          "width": true,
          "num_frames": true,
          "height": true
        }
      },
      "widgets_values": [
        832,
        480,
        33,
        0.9750000000000002,
        0,
        1,
        false
      ],
      "color": "#223",
      "bgcolor": "#335"
    },
    {
      "id": 30,
      "type": "WanVideoTextEncode",
      "pos": [
        1880,
        140
      ],
      "size": [
        532.030517578125,
        274.2516174316406
      ],
      "flags": {},
      "order": 12,
      "mode": 0,
      "inputs": [
        {
          "label": "t5",
          "localized_name": "t5",
          "name": "t5",
          "shape": 7,
          "type": "WANTEXTENCODER",
          "link": 35
        },
        {
          "label": "model_to_offload",
          "localized_name": "model_to_offload",
          "name": "model_to_offload",
          "shape": 7,
          "type": "WANVIDEOMODEL",
          "link": 72
        },
        {
          "label": "positive_prompt",
          "localized_name": "positive_prompt",
          "name": "positive_prompt",
          "type": "STRING",
          "widget": {
            "name": "positive_prompt"
          },
          "link": 61
        },
        {
          "label": "negative_prompt",
          "localized_name": "negative_prompt",
          "name": "negative_prompt",
          "type": "STRING",
          "widget": {
            "name": "negative_prompt"
          }
        },
        {
          "label": "force_offload",
          "localized_name": "force_offload",
          "name": "force_offload",
          "shape": 7,
          "type": "BOOLEAN",
          "widget": {
            "name": "force_offload"
          }
        },
        {
          "label": "use_disk_cache",
          "localized_name": "use_disk_cache",
          "name": "use_disk_cache",
          "shape": 7,
          "type": "BOOLEAN",
          "widget": {
            "name": "use_disk_cache"
          }
        },
        {
          "label": "device",
          "localized_name": "device",
          "name": "device",
          "shape": 7,
          "type": "COMBO",
          "widget": {
            "name": "device"
          }
        }
      ],
      "outputs": [
        {
          "label": "text_embeds",
          "localized_name": "text_embeds",
          "name": "text_embeds",
          "type": "WANVIDEOTEXTEMBEDS",
          "slot_index": 0,
          "links": [
            17
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "WanVideoTextEncode",
        "cnr_id": "ComfyUI-WanVideoWrapper",
        "ver": "3869b0482b615b6a8fd6f346467c5ef6627eed72",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "",
        "flickering artifact, jpg artifacts, compression, distortion, morphing, low-res, fake, oversaturated, overexposed, over bright, strange behavior, distorted limbs, unnatural motion, unrealistic anatomy, glitch, extra limbs,",
        true,
        false,
        "gpu"
      ],
      "color": "#232",
      "bgcolor": "#353"
    },
    {
      "id": 37,
      "type": "WanVideoDecode",
      "pos": [
        2775.229892872423,
        145.68916909930923
      ],
      "size": [
        315,
        198
      ],
      "flags": {},
      "order": 16,
      "mode": 0,
      "inputs": [
        {
          "label": "vae",
          "localized_name": "vae",
          "name": "vae",
          "type": "WANVAE",
          "link": 36
        },
        {
          "label": "samples",
          "localized_name": "samples",
          "name": "samples",
          "type": "LATENT",
          "link": 19
        },
        {
          "label": "enable_vae_tiling",
          "localized_name": "enable_vae_tiling",
          "name": "enable_vae_tiling",
          "type": "BOOLEAN",
          "widget": {
            "name": "enable_vae_tiling"
          }
        },
        {
          "label": "tile_x",
          "localized_name": "tile_x",
          "name": "tile_x",
          "type": "INT",
          "widget": {
            "name": "tile_x"
          }
        },
        {
          "label": "tile_y",
          "localized_name": "tile_y",
          "name": "tile_y",
          "type": "INT",
          "widget": {
            "name": "tile_y"
          }
        },
        {
          "label": "tile_stride_x",
          "localized_name": "tile_stride_x",
          "name": "tile_stride_x",
          "type": "INT",
          "widget": {
            "name": "tile_stride_x"
          }
        },
        {
          "label": "tile_stride_y",
          "localized_name": "tile_stride_y",
          "name": "tile_stride_y",
          "type": "INT",
          "widget": {
            "name": "tile_stride_y"
          }
        },
        {
          "label": "normalization",
          "localized_name": "normalization",
          "name": "normalization",
          "shape": 7,
          "type": "COMBO",
          "widget": {
            "name": "normalization"
          }
        }
      ],
      "outputs": [
        {
          "label": "images",
          "localized_name": "images",
          "name": "images",
          "type": "IMAGE",
          "slot_index": 0,
          "links": [
            45
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "WanVideoDecode",
        "cnr_id": "ComfyUI-WanVideoWrapper",
        "ver": "209c65ba41993c7a9425697f217990df9d13d6d2",
        "widget_ue_connectable": {
          "tile_y": true,
          "tile_x": true,
          "tile_stride_y": true,
          "tile_stride_x": true,
          "enable_vae_tiling": true
        }
      },
      "widgets_values": [
        false,
        272,
        272,
        144,
        128,
        "default"
      ]
    },
    {
      "id": 53,
      "type": "LayerUtility: ImageScaleByAspectRatio V2",
      "pos": [
        2781.589899837737,
        390.9189600681403
      ],
      "size": [
        303.6851501464844,
        330
      ],
      "flags": {},
      "order": 13,
      "mode": 0,
      "inputs": [
        {
          "label": "image",
          "localized_name": "图像",
          "name": "image",
          "shape": 7,
          "type": "IMAGE",
          "link": 50
        },
        {
          "label": "mask",
          "localized_name": "遮罩",
          "name": "mask",
          "shape": 7,
          "type": "MASK"
        },
        {
          "label": "aspect_ratio",
          "localized_name": "宽高比",
          "name": "aspect_ratio",
          "type": "COMBO",
          "widget": {
            "name": "aspect_ratio"
          }
        },
        {
          "label": "proportional_width",
          "localized_name": "比例宽度",
          "name": "proportional_width",
          "type": "INT",
          "widget": {
            "name": "proportional_width"
          }
        },
        {
          "label": "proportional_height",
          "localized_name": "比例高度",
          "name": "proportional_height",
          "type": "INT",
          "widget": {
            "name": "proportional_height"
          }
        },
        {
          "label": "fit",
          "localized_name": "适应",
          "name": "fit",
          "type": "COMBO",
          "widget": {
            "name": "fit"
          }
        },
        {
          "label": "method",
          "localized_name": "方法",
          "name": "method",
          "type": "COMBO",
          "widget": {
            "name": "method"
          }
        },
        {
          "label": "round_to_multiple",
          "localized_name": "四舍五入到倍数",
          "name": "round_to_multiple",
          "type": "COMBO",
          "widget": {
            "name": "round_to_multiple"
          }
        },
        {
          "label": "scale_to_side",
          "localized_name": "缩放至边",
          "name": "scale_to_side",
          "type": "COMBO",
          "widget": {
            "name": "scale_to_side"
          }
        },
        {
          "label": "scale_to_length",
          "localized_name": "缩放至长度",
          "name": "scale_to_length",
          "type": "INT",
          "widget": {
            "name": "scale_to_length"
          },
          "link": null
        },
        {
          "label": "background_color",
          "localized_name": "背景颜色",
          "name": "background_color",
          "type": "STRING",
          "widget": {
            "name": "background_color"
          }
        }
      ],
      "outputs": [
        {
          "label": "image",
          "localized_name": "image",
          "name": "image",
          "type": "IMAGE",
          "links": [
            57
          ]
        },
        {
          "label": "mask",
          "localized_name": "mask",
          "name": "mask",
          "type": "MASK"
        },
        {
          "label": "original_size",
          "localized_name": "original_size",
          "name": "original_size",
          "type": "BOX"
        },
        {
          "label": "width",
          "localized_name": "width",
          "name": "width",
          "type": "INT",
          "links": [
            69
          ]
        },
        {
          "label": "height",
          "localized_name": "height",
          "name": "height",
          "type": "INT",
          "links": [
            70
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "LayerUtility: ImageScaleByAspectRatio V2",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "original",
        1,
        1,
        "letterbox",
        "lanczos",
        "32",
        "longest",
        939,
        "#000000"
      ],
      "color": "rgba(38, 73, 116, 0.7)"
    },
    {
      "id": 58,
      "type": "PrimitiveStringMultiline",
      "pos": [
        587.203475717237,
        125.81991670943778
      ],
      "size": [
        400,
        200
      ],
      "flags": {},
      "order": 8,
      "mode": 0,
      "inputs": [
        {
          "label": "value",
          "localized_name": "值",
          "name": "value",
          "type": "STRING",
          "widget": {
            "name": "value"
          }
        }
      ],
      "outputs": [
        {
          "label": "STRING",
          "localized_name": "字符串",
          "name": "STRING",
          "type": "STRING",
          "links": [
            61
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.27.0",
        "Node name for S&R": "PrimitiveStringMultiline",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "Make it a Claymation. "
      ]
    },
    {
      "id": 16,
      "type": "VHS_LoadVideo",
      "pos": [
        673.3790656440597,
        393.8791815291643
      ],
      "size": [
        307.2709045410156,
        821.9362345377605
      ],
      "flags": {},
      "order": 11,
      "mode": 0,
      "inputs": [
        {
          "label": "meta_batch",
          "localized_name": "meta_batch",
          "name": "meta_batch",
          "shape": 7,
          "type": "VHS_BatchManager"
        },
        {
          "label": "vae",
          "localized_name": "vae",
          "name": "vae",
          "shape": 7,
          "type": "VAE"
        },
        {
          "label": "video",
          "localized_name": "video",
          "name": "video",
          "type": "COMBO",
          "widget": {
            "name": "video"
          }
        },
        {
          "label": "force_rate",
          "localized_name": "force_rate",
          "name": "force_rate",
          "type": "FLOAT",
          "widget": {
            "name": "force_rate"
          },
          "link": null
        },
        {
          "label": "custom_width",
          "localized_name": "custom_width",
          "name": "custom_width",
          "type": "INT",
          "widget": {
            "name": "custom_width"
          }
        },
        {
          "label": "custom_height",
          "localized_name": "custom_height",
          "name": "custom_height",
          "type": "INT",
          "widget": {
            "name": "custom_height"
          }
        },
        {
          "label": "frame_load_cap",
          "localized_name": "frame_load_cap",
          "name": "frame_load_cap",
          "type": "INT",
          "widget": {
            "name": "frame_load_cap"
          },
          "link": 79
        },
        {
          "label": "skip_first_frames",
          "localized_name": "skip_first_frames",
          "name": "skip_first_frames",
          "type": "INT",
          "widget": {
            "name": "skip_first_frames"
          }
        },
        {
          "label": "select_every_nth",
          "localized_name": "select_every_nth",
          "name": "select_every_nth",
          "type": "INT",
          "widget": {
            "name": "select_every_nth"
          }
        },
        {
          "label": "format",
          "localized_name": "format",
          "name": "format",
          "shape": 7,
          "type": "COMBO",
          "widget": {
            "name": "format"
          }
        }
      ],
      "outputs": [
        {
          "label": "IMAGE",
          "localized_name": "图像",
          "name": "IMAGE",
          "type": "IMAGE",
          "links": [
            50
          ]
        },
        {
          "label": "frame_count",
          "localized_name": "frame_count",
          "name": "frame_count",
          "type": "INT",
          "links": [
            71
          ]
        },
        {
          "label": "audio",
          "localized_name": "audio",
          "name": "audio",
          "type": "AUDIO",
          "links": [
            74
          ]
        },
        {
          "label": "video_info",
          "localized_name": "video_info",
          "name": "video_info",
          "type": "VHS_VIDEOINFO",
          "links": []
        }
      ],
      "properties": {
        "Node name for S&R": "VHS_LoadVideo",
        "cnr_id": "comfyui-videohelpersuite",
        "ver": "c9dcc3a229437df232d61da4f9697c87c1f22428",
        "widget_ue_connectable": {
          "custom_height": true,
          "force_rate": true,
          "custom_width": true,
          "select_every_nth": true,
          "frame_load_cap": true,
          "format": true,
          "video": true,
          "skip_first_frames": true
        }
      },
      "widgets_values": {
        "video": "WanVideo_SCAIL_00001-audio.mp4",
        "force_rate": 16,
        "custom_width": 0,
        "custom_height": 0,
        "frame_load_cap": 0,
        "skip_first_frames": 1,
        "select_every_nth": 1,
        "format": "AnimateDiff",
        "videopreview": {
          "paused": false,
          "hidden": false,
          "params": {
            "custom_height": 0,
            "filename": "WanVideo_SCAIL_00001-audio.mp4",
            "force_rate": 16,
            "custom_width": 0,
            "select_every_nth": 1,
            "frame_load_cap": 0,
            "format": "video/mp4",
            "skip_first_frames": 1,
            "type": "input"
          }
        }
      },
      "color": "#223",
      "bgcolor": "#335"
    },
    {
      "id": 64,
      "type": "INTConstant",
      "pos": [
        314.71333617382686,
        570.6680327276207
      ],
      "size": [
        303.1830636014256,
        58
      ],
      "flags": {
        "collapsed": false
      },
      "order": 9,
      "mode": 0,
      "inputs": [
        {
          "localized_name": "value",
          "name": "value",
          "type": "INT",
          "widget": {
            "name": "value"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "localized_name": "value",
          "name": "value",
          "type": "INT",
          "links": [
            79
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "INTConstant"
      },
      "widgets_values": [
        800
      ],
      "color": "#1b4669",
      "bgcolor": "#29699c"
    },
    {
      "id": 1,
      "type": "Note",
      "pos": [
        -19.16680896897809,
        44.056867390697555
      ],
      "size": [
        583.2238159179688,
        451.4023742675781
      ],
      "flags": {},
      "order": 7,
      "mode": 0,
      "inputs": [],
      "outputs": [],
      "properties": {
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "Make the scene in fire. - 让场景处于着火状态。\nMake it Steampunk style (mechanical with gears, pipes and brass details). - 使其呈现蒸汽朋克风格（带有齿轮、管道和黄铜细节的机械感）。\nMake it a Japanese anime style, cel shading video. - 使其成为日式动漫风格的赛璐璐着色视频。\nMake it a pencil sketch style video. - 使其成为铅笔素描风格的视频。\nMake it a Pixel Art video. - 使其成为像素艺术风格的视频。\nMake it a Claymation. - 使其成为黏土动画风格。\nMake it a Ukiyo-e style video. - 使其成为浮世绘风格的视频。\nMake it a Renaissance art style video. - 使其成为文艺复兴艺术风格的视频。\nMake it a drawing by Van Gogh. - 使其呈现梵高画作的风格。\nMake it Cyberpunk style. (implants, futuristic). - 使其呈现赛博朋克风格。（包含植入物、未来感元素）\nMake it watercolor drawing style. - 使其成为水彩画风格。\nMake it Comic Book Style. - 使其成为漫画书风格。\nMake it Children's Book Illustration. - 使其成为儿童绘本插画风格。\nMake it a Charcoal Drawing. - 使其成为炭笔画风格。\nMake it Rick and Morty style. - 使其呈现《瑞克和莫蒂》的风格。\nMake it Spirited Away style. - 使其呈现《千与千寻》的风格。\nMake it Moe style anime. - 使其成为萌系动漫风格。\nMake it Pixar style. - 使其呈现皮克斯风格。\nMake it Golden Age Warner/Disney style. - 使其呈现华纳/迪士尼黄金时代的风格。\nMake it My Little Pony style. - 使其呈现《我的小马驹》的风格。\nMake it sculptured with bronze. - 使其成为青铜雕塑风格。\nMake it sculptured with rainbow candy and biscuits. - 使其成为用彩虹糖果和饼干雕刻而成的风格。\nMake it sculptured with tasty and delicious chocolate. - 使其成为用美味巧克力雕刻而成的风格。\nMake it sculptured with silver. - 使其成为银质雕塑风格。\nMake it sculptured with gold. - 使其成为金质雕塑风格。\nMake it sculptured with rusted iron. - 使其成为生锈铁材雕塑风格。\nMake it sculptured with glass. - 使其成为玻璃雕塑风格。\nMake it sculptured with bricks. - 使其成为砖块雕塑风格。\nMake it sculptured with ice. - 使其成为冰雕风格。\nMake it sculptured with slime. - 使其成为黏液雕塑风格。\nTurn it into the 3D Chibi style. - 将其转换为3DQ版风格。\nTurn it into the Fabric style. - 将其转换为布料质感风格。\nTurn it into the Ghibli style. - 将其转换为吉卜力工作室风格。\nTurn it into the Jojo style. - 将其转换为《JOJO的奇妙冒险》风格。\nTurn it into the LEGO style. - 将其转换为乐高风格。\nTurn it into the Paper Cutting style. - 将其转换为剪纸风格。"
      ],
      "color": "#432",
      "bgcolor": "#653"
    }
  ],
  "links": [
    [
      1,
      8,
      0,
      6,
      1,
      "BLOCKSWAPARGS"
    ],
    [
      16,
      29,
      0,
      35,
      1,
      "WANVIDIMAGE_EMBEDS"
    ],
    [
      17,
      30,
      0,
      35,
      2,
      "WANVIDEOTEXTEMBEDS"
    ],
    [
      18,
      33,
      0,
      35,
      8,
      "SLGARGS"
    ],
    [
      19,
      35,
      0,
      37,
      1,
      "LATENT"
    ],
    [
      29,
      38,
      0,
      6,
      2,
      "WANVIDLORA"
    ],
    [
      34,
      10,
      0,
      29,
      0,
      "WANVAE"
    ],
    [
      35,
      12,
      0,
      30,
      0,
      "WANTEXTENCODER"
    ],
    [
      36,
      10,
      0,
      37,
      0,
      "WANVAE"
    ],
    [
      40,
      9,
      0,
      6,
      14,
      "VACEPATH"
    ],
    [
      45,
      37,
      0,
      49,
      0,
      "IMAGE"
    ],
    [
      49,
      3,
      0,
      6,
      0,
      "WANCOMPILEARGS"
    ],
    [
      50,
      16,
      0,
      53,
      0,
      "IMAGE"
    ],
    [
      57,
      53,
      0,
      29,
      1,
      "IMAGE"
    ],
    [
      61,
      58,
      0,
      30,
      2,
      "STRING"
    ],
    [
      69,
      53,
      3,
      29,
      5,
      "INT"
    ],
    [
      70,
      53,
      4,
      29,
      6,
      "INT"
    ],
    [
      71,
      16,
      1,
      29,
      7,
      "INT"
    ],
    [
      72,
      6,
      0,
      30,
      1,
      "WANVIDEOMODEL"
    ],
    [
      73,
      6,
      0,
      35,
      0,
      "WANVIDEOMODEL"
    ],
    [
      74,
      16,
      2,
      49,
      1,
      "AUDIO"
    ],
    [
      79,
      64,
      0,
      16,
      6,
      "INT"
    ]
  ],
  "groups": [
    {
      "id": 1,
      "title": "Models",
      "bounding": [
        1029.1697998046875,
        65.79586029052734,
        2086.454777038386,
        944.5312329277376
      ],
      "color": "#88A",
      "flags": {}
    }
  ],
  "config": {},
  "extra": {
    "VHS_KeepIntermediate": true,
    "links_added_by_ue": [],
    "VHS_MetadataImage": true,
    "ue_links": [],
    "0246.VERSION": [
      0,
      0,
      4
    ],
    "VHS_latentpreviewrate": 0,
    "frontendVersion": "1.45.20",
    "VHS_latentpreview": false,
    "ds": {
      "scale": 0.7247295000000037,
      "offset": [
        1406.1414857456655,
        369.0238133971554
      ]
    }
  },
  "version": 0.4
}
```
