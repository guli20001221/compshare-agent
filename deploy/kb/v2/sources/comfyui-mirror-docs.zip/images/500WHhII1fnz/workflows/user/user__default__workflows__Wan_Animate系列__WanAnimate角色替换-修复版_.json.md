# WanAnimate角色替换-修复版 

- 来源类别：用户工作流
- 镜像内原始路径：`/ComfyUI/user/default/workflows/Wan Animate系列/WanAnimate角色替换-修复版 .json`
- 节点数量：35
- 连线数量：49

## 节点类型

- `VHS_VideoCombine` × 4
- `INTConstant` × 2
- `BlockifyMask` × 1
- `CLIPVisionLoader` × 1
- `DWPreprocessor` × 1
- `DownloadAndLoadSAM2Model` × 1
- `DrawMaskOnImage` × 1
- `FaceMaskFromPoseKeypoints` × 1
- `GrowMask` × 1
- `ImageCropByMaskAndResize` × 1
- `ImageResizeKJv2` × 1
- `LoadImage` × 1
- `Note` × 1
- `PixelPerfectResolution` × 1
- `PointsEditor` × 1
- `PreviewImage` × 1
- `Reroute` × 1
- `Sam2Segmentation` × 1
- `VHS_LoadVideo` × 1
- `WanVideoAnimateEmbeds` × 1
- `WanVideoBlockSwap` × 1
- `WanVideoClipVisionEncode` × 1
- `WanVideoDecode` × 1
- `WanVideoLoraSelectMulti` × 1
- `WanVideoModelLoader` × 1
- `WanVideoSampler` × 1
- `WanVideoSetBlockSwap` × 1
- `WanVideoSetLoRAs` × 1
- `WanVideoTextEncodeCached` × 1
- `WanVideoTorchCompileSettings` × 1
- `WanVideoVAELoader` × 1

## 工作流引用的模型或媒体文件

- `/ComfyUI/output/Wanimate_00045.mp4`
- `/ComfyUI/temp/WanVideo2_1_T2V_00001.mp4`
- `/ComfyUI/temp/WanVideo2_1_T2V_00002.mp4`
- `/ComfyUI/temp/WanVideo2_1_T2V_00003.mp4`
- `2pq0.MP4`
- `Wan2_1_VAE_bf16.safetensors`
- `WanVideo2_1_T2V_00001.mp4`
- `WanVideo2_1_T2V_00002.mp4`
- `WanVideo2_1_T2V_00003.mp4`
- `Wanimate_00045.mp4`
- `aV1_LoRA_14B_rank512_bf16.safetensors`
- `caled_KJ.safetensors`
- `cript.pt`
- `ion_h.safetensors`
- `ized_dynamic_avg_rank_15_bf16.safetensors`
- `ized_dynamic_avg_rank_22_bf16.safetensors`
- `till_v2_lora_rank32_bf16.safetensors`
- `umt5-xxl-enc-fp8_e4m3fn.safetensors`

## 原始工作流 JSON

```json
{
  "id": "8b7a9a57-2303-4ef5-9fc2-bf41713bd1fc",
  "revision": 0,
  "last_node_id": 177,
  "last_link_id": 321,
  "nodes": [
    {
      "id": 48,
      "type": "WanVideoSetLoRAs",
      "pos": [
        23.853769302368164,
        -1095.2469482421875
      ],
      "size": [
        178.5533203125,
        46
      ],
      "flags": {},
      "order": 14,
      "mode": 0,
      "inputs": [
        {
          "label": "model",
          "localized_name": "model",
          "name": "model",
          "type": "WANVIDEOMODEL",
          "link": 59
        },
        {
          "label": "lora",
          "localized_name": "lora",
          "name": "lora",
          "shape": 7,
          "type": "WANVIDLORA",
          "link": 289
        }
      ],
      "outputs": [
        {
          "label": "model",
          "localized_name": "model",
          "name": "model",
          "type": "WANVIDEOMODEL",
          "links": [
            62
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "WanVideoSetLoRAs",
        "cnr_id": "ComfyUI-WanVideoWrapper",
        "ver": "e5ef9752a7e846b232fc05fd993327a2e870a788",
        "widget_ue_connectable": {}
      },
      "widgets_values": [],
      "color": "#223",
      "bgcolor": "#335"
    },
    {
      "id": 51,
      "type": "WanVideoBlockSwap",
      "pos": [
        -579.3214721679688,
        -609.92822265625
      ],
      "size": [
        571.8246459960938,
        202
      ],
      "flags": {},
      "order": 0,
      "mode": 0,
      "inputs": [
        {
          "label": "blocks_to_swap",
          "localized_name": "blocks_to_swap",
          "name": "blocks_to_swap",
          "type": "INT",
          "widget": {
            "name": "blocks_to_swap"
          },
          "link": null
        },
        {
          "label": "offload_img_emb",
          "localized_name": "offload_img_emb",
          "name": "offload_img_emb",
          "type": "BOOLEAN",
          "widget": {
            "name": "offload_img_emb"
          },
          "link": null
        },
        {
          "label": "offload_txt_emb",
          "localized_name": "offload_txt_emb",
          "name": "offload_txt_emb",
          "type": "BOOLEAN",
          "widget": {
            "name": "offload_txt_emb"
          },
          "link": null
        },
        {
          "label": "use_non_blocking",
          "localized_name": "use_non_blocking",
          "name": "use_non_blocking",
          "shape": 7,
          "type": "BOOLEAN",
          "widget": {
            "name": "use_non_blocking"
          },
          "link": null
        },
        {
          "label": "vace_blocks_to_swap",
          "localized_name": "vace_blocks_to_swap",
          "name": "vace_blocks_to_swap",
          "shape": 7,
          "type": "INT",
          "widget": {
            "name": "vace_blocks_to_swap"
          },
          "link": null
        },
        {
          "label": "prefetch_blocks",
          "localized_name": "prefetch_blocks",
          "name": "prefetch_blocks",
          "shape": 7,
          "type": "INT",
          "widget": {
            "name": "prefetch_blocks"
          },
          "link": null
        },
        {
          "label": "block_swap_debug",
          "localized_name": "block_swap_debug",
          "name": "block_swap_debug",
          "shape": 7,
          "type": "BOOLEAN",
          "widget": {
            "name": "block_swap_debug"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "block_swap_args",
          "localized_name": "block_swap_args",
          "name": "block_swap_args",
          "type": "BLOCKSWAPARGS",
          "links": [
            64
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "WanVideoBlockSwap",
        "cnr_id": "ComfyUI-WanVideoWrapper",
        "ver": "e5ef9752a7e846b232fc05fd993327a2e870a788",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        40,
        false,
        false,
        true,
        0,
        1,
        false
      ],
      "color": "#223",
      "bgcolor": "#335"
    },
    {
      "id": 35,
      "type": "WanVideoTorchCompileSettings",
      "pos": [
        -1191.103271484375,
        -465.1506652832031
      ],
      "size": [
        589.0321044921875,
        250
      ],
      "flags": {},
      "order": 1,
      "mode": 0,
      "inputs": [
        {
          "label": "backend",
          "localized_name": "backend",
          "name": "backend",
          "type": "COMBO",
          "widget": {
            "name": "backend"
          },
          "link": null
        },
        {
          "label": "fullgraph",
          "localized_name": "fullgraph",
          "name": "fullgraph",
          "type": "BOOLEAN",
          "widget": {
            "name": "fullgraph"
          },
          "link": null
        },
        {
          "label": "mode",
          "localized_name": "mode",
          "name": "mode",
          "type": "COMBO",
          "widget": {
            "name": "mode"
          },
          "link": null
        },
        {
          "label": "dynamic",
          "localized_name": "dynamic",
          "name": "dynamic",
          "type": "BOOLEAN",
          "widget": {
            "name": "dynamic"
          },
          "link": null
        },
        {
          "label": "dynamo_cache_size_limit",
          "localized_name": "dynamo_cache_size_limit",
          "name": "dynamo_cache_size_limit",
          "type": "INT",
          "widget": {
            "name": "dynamo_cache_size_limit"
          },
          "link": null
        },
        {
          "label": "compile_transformer_blocks_only",
          "localized_name": "compile_transformer_blocks_only",
          "name": "compile_transformer_blocks_only",
          "type": "BOOLEAN",
          "widget": {
            "name": "compile_transformer_blocks_only"
          },
          "link": null
        },
        {
          "label": "dynamo_recompile_limit",
          "localized_name": "dynamo_recompile_limit",
          "name": "dynamo_recompile_limit",
          "shape": 7,
          "type": "INT",
          "widget": {
            "name": "dynamo_recompile_limit"
          },
          "link": null
        },
        {
          "label": "force_parameter_static_shapes",
          "localized_name": "force_parameter_static_shapes",
          "name": "force_parameter_static_shapes",
          "shape": 7,
          "type": "BOOLEAN",
          "widget": {
            "name": "force_parameter_static_shapes"
          },
          "link": null
        },
        {
          "label": "allow_unmerged_lora_compile",
          "localized_name": "allow_unmerged_lora_compile",
          "name": "allow_unmerged_lora_compile",
          "shape": 7,
          "type": "BOOLEAN",
          "widget": {
            "name": "allow_unmerged_lora_compile"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "torch_compile_args",
          "localized_name": "torch_compile_args",
          "name": "torch_compile_args",
          "type": "WANCOMPILEARGS",
          "slot_index": 0,
          "links": [
            100
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "WanVideoTorchCompileSettings",
        "cnr_id": "ComfyUI-WanVideoWrapper",
        "ver": "e5ef9752a7e846b232fc05fd993327a2e870a788",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "inductor",
        false,
        "default",
        false,
        64,
        true,
        128,
        false,
        false
      ],
      "color": "#223",
      "bgcolor": "#335"
    },
    {
      "id": 50,
      "type": "WanVideoSetBlockSwap",
      "pos": [
        16.051923751831055,
        -844.3607177734375
      ],
      "size": [
        209.6841796875,
        46
      ],
      "flags": {},
      "order": 19,
      "mode": 0,
      "inputs": [
        {
          "label": "model",
          "localized_name": "model",
          "name": "model",
          "type": "WANVIDEOMODEL",
          "link": 62
        },
        {
          "label": "block_swap_args",
          "localized_name": "block_swap_args",
          "name": "block_swap_args",
          "shape": 7,
          "type": "BLOCKSWAPARGS",
          "link": 64
        }
      ],
      "outputs": [
        {
          "label": "model",
          "localized_name": "model",
          "name": "model",
          "type": "WANVIDEOMODEL",
          "links": [
            63
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "WanVideoSetBlockSwap",
        "cnr_id": "ComfyUI-WanVideoWrapper",
        "ver": "e5ef9752a7e846b232fc05fd993327a2e870a788",
        "widget_ue_connectable": {}
      },
      "widgets_values": [],
      "color": "#223",
      "bgcolor": "#335"
    },
    {
      "id": 62,
      "type": "WanVideoAnimateEmbeds",
      "pos": [
        667.8512573242188,
        -1086.259033203125
      ],
      "size": [
        274.2164001464844,
        370
      ],
      "flags": {},
      "order": 30,
      "mode": 0,
      "inputs": [
        {
          "label": "vae",
          "localized_name": "vae",
          "name": "vae",
          "type": "WANVAE",
          "link": 296
        },
        {
          "label": "clip_embeds",
          "localized_name": "clip_embeds",
          "name": "clip_embeds",
          "shape": 7,
          "type": "WANVIDIMAGE_CLIPEMBEDS",
          "link": 96
        },
        {
          "label": "ref_images",
          "localized_name": "ref_images",
          "name": "ref_images",
          "shape": 7,
          "type": "IMAGE",
          "link": 310
        },
        {
          "label": "pose_images",
          "localized_name": "pose_images",
          "name": "pose_images",
          "shape": 7,
          "type": "IMAGE",
          "link": 308
        },
        {
          "label": "face_images",
          "localized_name": "face_images",
          "name": "face_images",
          "shape": 7,
          "type": "IMAGE",
          "link": 309
        },
        {
          "label": "bg_images",
          "localized_name": "bg_images",
          "name": "bg_images",
          "shape": 7,
          "type": "IMAGE",
          "link": 303
        },
        {
          "label": "mask",
          "localized_name": "mask",
          "name": "mask",
          "shape": 7,
          "type": "MASK",
          "link": 302
        },
        {
          "label": "width",
          "localized_name": "width",
          "name": "width",
          "type": "INT",
          "widget": {
            "name": "width"
          },
          "link": 312
        },
        {
          "label": "height",
          "localized_name": "height",
          "name": "height",
          "type": "INT",
          "widget": {
            "name": "height"
          },
          "link": 313
        },
        {
          "label": "num_frames",
          "localized_name": "num_frames",
          "name": "num_frames",
          "type": "INT",
          "widget": {
            "name": "num_frames"
          },
          "link": 299
        },
        {
          "label": "force_offload",
          "localized_name": "force_offload",
          "name": "force_offload",
          "type": "BOOLEAN",
          "widget": {
            "name": "force_offload"
          },
          "link": null
        },
        {
          "label": "frame_window_size",
          "localized_name": "frame_window_size",
          "name": "frame_window_size",
          "type": "INT",
          "widget": {
            "name": "frame_window_size"
          },
          "link": null
        },
        {
          "label": "colormatch",
          "localized_name": "colormatch",
          "name": "colormatch",
          "type": "COMBO",
          "widget": {
            "name": "colormatch"
          },
          "link": null
        },
        {
          "label": "pose_strength",
          "localized_name": "pose_strength",
          "name": "pose_strength",
          "type": "FLOAT",
          "widget": {
            "name": "pose_strength"
          },
          "link": null
        },
        {
          "label": "face_strength",
          "localized_name": "face_strength",
          "name": "face_strength",
          "type": "FLOAT",
          "widget": {
            "name": "face_strength"
          },
          "link": null
        },
        {
          "label": "tiled_vae",
          "localized_name": "tiled_vae",
          "name": "tiled_vae",
          "shape": 7,
          "type": "BOOLEAN",
          "widget": {
            "name": "tiled_vae"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "image_embeds",
          "localized_name": "image_embeds",
          "name": "image_embeds",
          "type": "WANVIDIMAGE_EMBEDS",
          "links": [
            84
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "WanVideoAnimateEmbeds",
        "cnr_id": "ComfyUI-WanVideoWrapper",
        "ver": "761b1d191e50d589465e31dc0d40ff7c59b1b7b0",
        "widget_ue_connectable": {
          "width": true,
          "height": true,
          "num_frames": true
        }
      },
      "widgets_values": [
        832,
        480,
        501,
        false,
        77,
        "disabled",
        1,
        1,
        false
      ],
      "color": "#322",
      "bgcolor": "#533"
    },
    {
      "id": 104,
      "type": "Sam2Segmentation",
      "pos": [
        49.7124137878418,
        -3390.30810546875
      ],
      "size": [
        272.087890625,
        182
      ],
      "flags": {},
      "order": 21,
      "mode": 0,
      "inputs": [
        {
          "label": "SAM2",
          "localized_name": "sam2_model",
          "name": "sam2_model",
          "type": "SAM2MODEL",
          "link": 185
        },
        {
          "label": "图像",
          "localized_name": "image",
          "name": "image",
          "type": "IMAGE",
          "link": 294
        },
        {
          "label": "正面坐标",
          "localized_name": "coordinates_positive",
          "name": "coordinates_positive",
          "shape": 7,
          "type": "STRING",
          "link": 210
        },
        {
          "label": "负面坐标",
          "localized_name": "coordinates_negative",
          "name": "coordinates_negative",
          "shape": 7,
          "type": "STRING",
          "link": null
        },
        {
          "label": "BBox",
          "localized_name": "bboxes",
          "name": "bboxes",
          "shape": 7,
          "type": "BBOX",
          "link": null
        },
        {
          "label": "遮罩",
          "localized_name": "mask",
          "name": "mask",
          "shape": 7,
          "type": "MASK",
          "link": null
        },
        {
          "localized_name": "保持模型加载",
          "name": "keep_model_loaded",
          "type": "BOOLEAN",
          "widget": {
            "name": "keep_model_loaded"
          },
          "link": null
        },
        {
          "localized_name": "孤岛物体",
          "name": "individual_objects",
          "shape": 7,
          "type": "BOOLEAN",
          "widget": {
            "name": "individual_objects"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "遮罩",
          "localized_name": "mask",
          "name": "mask",
          "type": "MASK",
          "links": [
            187
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "Sam2Segmentation",
        "cnr_id": "ComfyUI-segment-anything-2",
        "ver": "c59676b008a76237002926f684d0ca3a9b29ac54",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        false,
        false
      ]
    },
    {
      "id": 100,
      "type": "GrowMask",
      "pos": [
        341.24310302734375,
        -3398.93994140625
      ],
      "size": [
        270,
        82
      ],
      "flags": {
        "collapsed": false
      },
      "order": 23,
      "mode": 0,
      "inputs": [
        {
          "label": "遮罩",
          "localized_name": "遮罩",
          "name": "mask",
          "type": "MASK",
          "link": 187
        },
        {
          "localized_name": "扩展",
          "name": "expand",
          "type": "INT",
          "widget": {
            "name": "expand"
          },
          "link": null
        },
        {
          "localized_name": "倒角",
          "name": "tapered_corners",
          "type": "BOOLEAN",
          "widget": {
            "name": "tapered_corners"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "遮罩",
          "localized_name": "遮罩",
          "name": "MASK",
          "type": "MASK",
          "links": [
            198
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.59",
        "Node name for S&R": "GrowMask",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        10,
        true
      ]
    },
    {
      "id": 108,
      "type": "BlockifyMask",
      "pos": [
        629.9188842773438,
        -3394.334716796875
      ],
      "size": [
        270,
        82
      ],
      "flags": {},
      "order": 26,
      "mode": 0,
      "inputs": [
        {
          "label": "masks",
          "localized_name": "masks",
          "name": "masks",
          "type": "MASK",
          "link": 198
        },
        {
          "label": "block_size",
          "localized_name": "block_size",
          "name": "block_size",
          "type": "INT",
          "widget": {
            "name": "block_size"
          },
          "link": null
        },
        {
          "label": "device",
          "localized_name": "device",
          "name": "device",
          "shape": 7,
          "type": "COMBO",
          "widget": {
            "name": "device"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "mask",
          "localized_name": "mask",
          "name": "mask",
          "type": "MASK",
          "links": [
            301,
            302
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "BlockifyMask",
        "cnr_id": "comfyui-kjnodes",
        "ver": "00da1910634fbf314d407608efb281ae6f7f1ba2",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        32,
        "cpu"
      ]
    },
    {
      "id": 99,
      "type": "DrawMaskOnImage",
      "pos": [
        924.1703491210938,
        -3406.406494140625
      ],
      "size": [
        270,
        102
      ],
      "flags": {},
      "order": 28,
      "mode": 0,
      "inputs": [
        {
          "label": "image",
          "localized_name": "image",
          "name": "image",
          "type": "IMAGE",
          "link": 298
        },
        {
          "label": "mask",
          "localized_name": "mask",
          "name": "mask",
          "type": "MASK",
          "link": 301
        },
        {
          "label": "color",
          "localized_name": "color",
          "name": "color",
          "type": "STRING",
          "widget": {
            "name": "color"
          },
          "link": null
        },
        {
          "label": "device",
          "localized_name": "device",
          "name": "device",
          "shape": 7,
          "type": "COMBO",
          "widget": {
            "name": "device"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "images",
          "localized_name": "images",
          "name": "images",
          "type": "IMAGE",
          "links": [
            303,
            304
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "DrawMaskOnImage",
        "cnr_id": "comfyui-kjnodes",
        "ver": "623b5913dc7f240fd8b26422e99f8849a21c5473",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "0, 0, 0",
        "cpu"
      ]
    },
    {
      "id": 64,
      "type": "ImageResizeKJv2",
      "pos": [
        -886.1908569335938,
        -1835.9456787109375
      ],
      "size": [
        270,
        336
      ],
      "flags": {},
      "order": 12,
      "mode": 0,
      "inputs": [
        {
          "label": "image",
          "localized_name": "image",
          "name": "image",
          "type": "IMAGE",
          "link": 82
        },
        {
          "label": "mask",
          "localized_name": "mask",
          "name": "mask",
          "shape": 7,
          "type": "MASK",
          "link": null
        },
        {
          "label": "width",
          "localized_name": "width",
          "name": "width",
          "type": "INT",
          "widget": {
            "name": "width"
          },
          "link": 286
        },
        {
          "label": "height",
          "localized_name": "height",
          "name": "height",
          "type": "INT",
          "widget": {
            "name": "height"
          },
          "link": 287
        },
        {
          "label": "upscale_method",
          "localized_name": "upscale_method",
          "name": "upscale_method",
          "type": "COMBO",
          "widget": {
            "name": "upscale_method"
          },
          "link": null
        },
        {
          "label": "keep_proportion",
          "localized_name": "keep_proportion",
          "name": "keep_proportion",
          "type": "COMBO",
          "widget": {
            "name": "keep_proportion"
          },
          "link": null
        },
        {
          "label": "pad_color",
          "localized_name": "pad_color",
          "name": "pad_color",
          "type": "STRING",
          "widget": {
            "name": "pad_color"
          },
          "link": null
        },
        {
          "label": "crop_position",
          "localized_name": "crop_position",
          "name": "crop_position",
          "type": "COMBO",
          "widget": {
            "name": "crop_position"
          },
          "link": null
        },
        {
          "label": "divisible_by",
          "localized_name": "divisible_by",
          "name": "divisible_by",
          "type": "INT",
          "widget": {
            "name": "divisible_by"
          },
          "link": null
        },
        {
          "label": "device",
          "localized_name": "device",
          "name": "device",
          "shape": 7,
          "type": "COMBO",
          "widget": {
            "name": "device"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "IMAGE",
          "localized_name": "图像",
          "name": "IMAGE",
          "type": "IMAGE",
          "links": [
            291,
            310,
            311
          ]
        },
        {
          "label": "width",
          "localized_name": "width",
          "name": "width",
          "type": "INT",
          "links": []
        },
        {
          "label": "height",
          "localized_name": "height",
          "name": "height",
          "type": "INT",
          "links": []
        },
        {
          "label": "mask",
          "localized_name": "mask",
          "name": "mask",
          "type": "MASK",
          "links": null
        }
      ],
      "properties": {
        "Node name for S&R": "ImageResizeKJv2",
        "cnr_id": "comfyui-kjnodes",
        "ver": "468fcc86f0b29e79a8510e8239eb15714d6747a6",
        "widget_ue_connectable": {
          "width": true,
          "height": true
        }
      },
      "widgets_values": [
        832,
        480,
        "lanczos",
        "crop",
        "0, 0, 0",
        "top",
        16,
        "cpu"
      ]
    },
    {
      "id": 172,
      "type": "PreviewImage",
      "pos": [
        -598.16943359375,
        -1835.3773193359375
      ],
      "size": [
        222.21678161621094,
        411.2475891113281
      ],
      "flags": {},
      "order": 15,
      "mode": 0,
      "inputs": [
        {
          "label": "图像",
          "localized_name": "图像",
          "name": "images",
          "type": "IMAGE",
          "link": 291
        }
      ],
      "outputs": [
        {
          "localized_name": "images",
          "name": "images",
          "type": "IMAGE",
          "links": null
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.59",
        "Node name for S&R": "PreviewImage",
        "widget_ue_connectable": {}
      },
      "widgets_values": []
    },
    {
      "id": 147,
      "type": "Reroute",
      "pos": [
        -190.720703125,
        -1869.3841552734375
      ],
      "size": [
        75,
        26
      ],
      "flags": {},
      "order": 17,
      "mode": 0,
      "inputs": [
        {
          "label": "",
          "name": "",
          "type": "*",
          "link": 252
        }
      ],
      "outputs": [
        {
          "label": "",
          "name": "",
          "type": "IMAGE",
          "links": [
            253,
            254,
            277
          ]
        }
      ],
      "properties": {
        "showOutputText": false,
        "horizontal": false,
        "widget_ue_connectable": {}
      }
    },
    {
      "id": 152,
      "type": "PixelPerfectResolution",
      "pos": [
        -192.43807983398438,
        -1781.0733642578125
      ],
      "size": [
        291.71484375,
        106
      ],
      "flags": {
        "collapsed": false
      },
      "order": 20,
      "mode": 0,
      "inputs": [
        {
          "label": "图像",
          "localized_name": "original_image",
          "name": "original_image",
          "type": "IMAGE",
          "link": 277
        },
        {
          "label": "image_gen_width",
          "localized_name": "宽度",
          "name": "image_gen_width",
          "type": "INT",
          "widget": {
            "name": "image_gen_width"
          },
          "link": 260
        },
        {
          "label": "image_gen_height",
          "localized_name": "高度",
          "name": "image_gen_height",
          "type": "INT",
          "widget": {
            "name": "image_gen_height"
          },
          "link": 261
        },
        {
          "localized_name": "拉伸模式",
          "name": "resize_mode",
          "type": "COMBO",
          "widget": {
            "name": "resize_mode"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "分辨率(整数)",
          "localized_name": "RESOLUTION (INT)",
          "name": "RESOLUTION (INT)",
          "type": "INT",
          "links": [
            262
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "PixelPerfectResolution",
        "cnr_id": "comfyui_controlnet_aux",
        "ver": "cc6b232f4a47f0cdf70f4e1bfa24b74bd0d75bf1",
        "widget_ue_connectable": {
          "image_gen_width": true,
          "image_gen_height": true
        }
      },
      "widgets_values": [
        512,
        512,
        "Crop and Resize"
      ]
    },
    {
      "id": 73,
      "type": "DWPreprocessor",
      "pos": [
        118.7885971069336,
        -1788.220947265625
      ],
      "size": [
        371.1239013671875,
        222
      ],
      "flags": {},
      "order": 22,
      "mode": 0,
      "inputs": [
        {
          "label": "图像",
          "localized_name": "image",
          "name": "image",
          "type": "IMAGE",
          "link": 253
        },
        {
          "localized_name": "检测手部",
          "name": "detect_hand",
          "shape": 7,
          "type": "COMBO",
          "widget": {
            "name": "detect_hand"
          },
          "link": null
        },
        {
          "localized_name": "检测身体",
          "name": "detect_body",
          "shape": 7,
          "type": "COMBO",
          "widget": {
            "name": "detect_body"
          },
          "link": null
        },
        {
          "localized_name": "检测面部",
          "name": "detect_face",
          "shape": 7,
          "type": "COMBO",
          "widget": {
            "name": "detect_face"
          },
          "link": null
        },
        {
          "label": "resolution",
          "localized_name": "分辨率",
          "name": "resolution",
          "shape": 7,
          "type": "INT",
          "widget": {
            "name": "resolution"
          },
          "link": 262
        },
        {
          "localized_name": "BBox检测",
          "name": "bbox_detector",
          "shape": 7,
          "type": "COMBO",
          "widget": {
            "name": "bbox_detector"
          },
          "link": null
        },
        {
          "localized_name": "姿态预估",
          "name": "pose_estimator",
          "shape": 7,
          "type": "COMBO",
          "widget": {
            "name": "pose_estimator"
          },
          "link": null
        },
        {
          "localized_name": "scale_stick_for_xinsr_cn",
          "name": "scale_stick_for_xinsr_cn",
          "shape": 7,
          "type": "COMBO",
          "widget": {
            "name": "scale_stick_for_xinsr_cn"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "图像",
          "localized_name": "图像",
          "name": "IMAGE",
          "type": "IMAGE",
          "links": [
            292,
            308
          ]
        },
        {
          "label": "姿态关键点",
          "localized_name": "POSE_KEYPOINT",
          "name": "POSE_KEYPOINT",
          "type": "POSE_KEYPOINT",
          "links": [
            219
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "DWPreprocessor",
        "cnr_id": "comfyui_controlnet_aux",
        "ver": "1d7cdce8cb771fbc39a432a6338168c12a338ef4",
        "widget_ue_connectable": {
          "resolution": true
        }
      },
      "widgets_values": [
        "enable",
        "enable",
        "enable",
        960,
        "yolox_l.torchscript.pt",
        "dw-ll_ucoco_384_bs5.torchscript.pt",
        "disable"
      ]
    },
    {
      "id": 120,
      "type": "FaceMaskFromPoseKeypoints",
      "pos": [
        122.45403289794922,
        -1521.021728515625
      ],
      "size": [
        368.8381042480469,
        80.93645477294922
      ],
      "flags": {},
      "order": 25,
      "mode": 0,
      "inputs": [
        {
          "label": "pose_kps",
          "localized_name": "pose_kps",
          "name": "pose_kps",
          "type": "POSE_KEYPOINT",
          "link": 219
        },
        {
          "label": "person_index",
          "localized_name": "person_index",
          "name": "person_index",
          "type": "INT",
          "widget": {
            "name": "person_index"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "MASK",
          "localized_name": "遮罩",
          "name": "MASK",
          "type": "MASK",
          "links": [
            228
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "FaceMaskFromPoseKeypoints",
        "cnr_id": "ComfyUI-WanVideoWrapper",
        "ver": "2bdd81a10b03c14443c79bdf3b783b1feb3d1fa3",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        0
      ]
    },
    {
      "id": 70,
      "type": "WanVideoClipVisionEncode",
      "pos": [
        331.0881042480469,
        -1070.681884765625
      ],
      "size": [
        280.9771423339844,
        262
      ],
      "flags": {},
      "order": 16,
      "mode": 0,
      "inputs": [
        {
          "label": "clip_vision",
          "localized_name": "clip_vision",
          "name": "clip_vision",
          "type": "CLIP_VISION",
          "link": 97
        },
        {
          "label": "image_1",
          "localized_name": "image_1",
          "name": "image_1",
          "type": "IMAGE",
          "link": 311
        },
        {
          "label": "image_2",
          "localized_name": "image_2",
          "name": "image_2",
          "shape": 7,
          "type": "IMAGE",
          "link": null
        },
        {
          "label": "negative_image",
          "localized_name": "negative_image",
          "name": "negative_image",
          "shape": 7,
          "type": "IMAGE",
          "link": null
        },
        {
          "label": "strength_1",
          "localized_name": "strength_1",
          "name": "strength_1",
          "type": "FLOAT",
          "widget": {
            "name": "strength_1"
          },
          "link": null
        },
        {
          "label": "strength_2",
          "localized_name": "strength_2",
          "name": "strength_2",
          "type": "FLOAT",
          "widget": {
            "name": "strength_2"
          },
          "link": null
        },
        {
          "label": "crop",
          "localized_name": "crop",
          "name": "crop",
          "type": "COMBO",
          "widget": {
            "name": "crop"
          },
          "link": null
        },
        {
          "label": "combine_embeds",
          "localized_name": "combine_embeds",
          "name": "combine_embeds",
          "type": "COMBO",
          "widget": {
            "name": "combine_embeds"
          },
          "link": null
        },
        {
          "label": "force_offload",
          "localized_name": "force_offload",
          "name": "force_offload",
          "type": "BOOLEAN",
          "widget": {
            "name": "force_offload"
          },
          "link": null
        },
        {
          "label": "tiles",
          "localized_name": "tiles",
          "name": "tiles",
          "shape": 7,
          "type": "INT",
          "widget": {
            "name": "tiles"
          },
          "link": null
        },
        {
          "label": "ratio",
          "localized_name": "ratio",
          "name": "ratio",
          "shape": 7,
          "type": "FLOAT",
          "widget": {
            "name": "ratio"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "image_embeds",
          "localized_name": "image_embeds",
          "name": "image_embeds",
          "type": "WANVIDIMAGE_CLIPEMBEDS",
          "links": [
            96
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "WanVideoClipVisionEncode",
        "cnr_id": "ComfyUI-WanVideoWrapper",
        "ver": "2bdd81a10b03c14443c79bdf3b783b1feb3d1fa3",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        1,
        1,
        "center",
        "average",
        true,
        0,
        0.5
      ],
      "color": "#233",
      "bgcolor": "#355"
    },
    {
      "id": 27,
      "type": "WanVideoSampler",
      "pos": [
        955.7927856445312,
        -1085.4578857421875
      ],
      "size": [
        315,
        902
      ],
      "flags": {},
      "order": 32,
      "mode": 0,
      "inputs": [
        {
          "label": "model",
          "localized_name": "model",
          "name": "model",
          "type": "WANVIDEOMODEL",
          "link": 63
        },
        {
          "label": "image_embeds",
          "localized_name": "image_embeds",
          "name": "image_embeds",
          "type": "WANVIDIMAGE_EMBEDS",
          "link": 84
        },
        {
          "label": "text_embeds",
          "localized_name": "text_embeds",
          "name": "text_embeds",
          "shape": 7,
          "type": "WANVIDEOTEXTEMBEDS",
          "link": 281
        },
        {
          "label": "samples",
          "localized_name": "samples",
          "name": "samples",
          "shape": 7,
          "type": "LATENT",
          "link": null
        },
        {
          "label": "feta_args",
          "localized_name": "feta_args",
          "name": "feta_args",
          "shape": 7,
          "type": "FETAARGS",
          "link": null
        },
        {
          "label": "context_options",
          "localized_name": "context_options",
          "name": "context_options",
          "shape": 7,
          "type": "WANVIDCONTEXT",
          "link": null
        },
        {
          "label": "cache_args",
          "localized_name": "cache_args",
          "name": "cache_args",
          "shape": 7,
          "type": "CACHEARGS",
          "link": null
        },
        {
          "label": "flowedit_args",
          "localized_name": "flowedit_args",
          "name": "flowedit_args",
          "shape": 7,
          "type": "FLOWEDITARGS",
          "link": null
        },
        {
          "label": "slg_args",
          "localized_name": "slg_args",
          "name": "slg_args",
          "shape": 7,
          "type": "SLGARGS",
          "link": null
        },
        {
          "label": "loop_args",
          "localized_name": "loop_args",
          "name": "loop_args",
          "shape": 7,
          "type": "LOOPARGS",
          "link": null
        },
        {
          "label": "experimental_args",
          "localized_name": "experimental_args",
          "name": "experimental_args",
          "shape": 7,
          "type": "EXPERIMENTALARGS",
          "link": null
        },
        {
          "label": "sigmas",
          "localized_name": "sigmas",
          "name": "sigmas",
          "shape": 7,
          "type": "SIGMAS",
          "link": null
        },
        {
          "label": "unianimate_poses",
          "localized_name": "unianimate_poses",
          "name": "unianimate_poses",
          "shape": 7,
          "type": "UNIANIMATE_POSE",
          "link": null
        },
        {
          "label": "fantasytalking_embeds",
          "localized_name": "fantasytalking_embeds",
          "name": "fantasytalking_embeds",
          "shape": 7,
          "type": "FANTASYTALKING_EMBEDS",
          "link": null
        },
        {
          "label": "uni3c_embeds",
          "localized_name": "uni3c_embeds",
          "name": "uni3c_embeds",
          "shape": 7,
          "type": "UNI3C_EMBEDS",
          "link": null
        },
        {
          "label": "multitalk_embeds",
          "localized_name": "multitalk_embeds",
          "name": "multitalk_embeds",
          "shape": 7,
          "type": "MULTITALK_EMBEDS",
          "link": null
        },
        {
          "label": "freeinit_args",
          "localized_name": "freeinit_args",
          "name": "freeinit_args",
          "shape": 7,
          "type": "FREEINITARGS",
          "link": null
        },
        {
          "label": "steps",
          "localized_name": "steps",
          "name": "steps",
          "type": "INT",
          "widget": {
            "name": "steps"
          },
          "link": null
        },
        {
          "label": "cfg",
          "localized_name": "cfg",
          "name": "cfg",
          "type": "FLOAT",
          "widget": {
            "name": "cfg"
          },
          "link": null
        },
        {
          "label": "shift",
          "localized_name": "shift",
          "name": "shift",
          "type": "FLOAT",
          "widget": {
            "name": "shift"
          },
          "link": null
        },
        {
          "label": "seed",
          "localized_name": "seed",
          "name": "seed",
          "type": "INT",
          "widget": {
            "name": "seed"
          },
          "link": null
        },
        {
          "label": "force_offload",
          "localized_name": "force_offload",
          "name": "force_offload",
          "type": "BOOLEAN",
          "widget": {
            "name": "force_offload"
          },
          "link": null
        },
        {
          "label": "scheduler",
          "localized_name": "scheduler",
          "name": "scheduler",
          "type": "COMBO",
          "widget": {
            "name": "scheduler"
          },
          "link": null
        },
        {
          "label": "riflex_freq_index",
          "localized_name": "riflex_freq_index",
          "name": "riflex_freq_index",
          "type": "INT",
          "widget": {
            "name": "riflex_freq_index"
          },
          "link": null
        },
        {
          "label": "denoise_strength",
          "localized_name": "denoise_strength",
          "name": "denoise_strength",
          "shape": 7,
          "type": "FLOAT",
          "widget": {
            "name": "denoise_strength"
          },
          "link": null
        },
        {
          "label": "batched_cfg",
          "localized_name": "batched_cfg",
          "name": "batched_cfg",
          "shape": 7,
          "type": "BOOLEAN",
          "widget": {
            "name": "batched_cfg"
          },
          "link": null
        },
        {
          "label": "rope_function",
          "localized_name": "rope_function",
          "name": "rope_function",
          "shape": 7,
          "type": "COMBO",
          "widget": {
            "name": "rope_function"
          },
          "link": null
        },
        {
          "label": "start_step",
          "localized_name": "start_step",
          "name": "start_step",
          "shape": 7,
          "type": "INT",
          "widget": {
            "name": "start_step"
          },
          "link": null
        },
        {
          "label": "end_step",
          "localized_name": "end_step",
          "name": "end_step",
          "shape": 7,
          "type": "INT",
          "widget": {
            "name": "end_step"
          },
          "link": null
        },
        {
          "label": "add_noise_to_samples",
          "localized_name": "add_noise_to_samples",
          "name": "add_noise_to_samples",
          "shape": 7,
          "type": "BOOLEAN",
          "widget": {
            "name": "add_noise_to_samples"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "samples",
          "localized_name": "samples",
          "name": "samples",
          "type": "LATENT",
          "slot_index": 0,
          "links": [
            33
          ]
        },
        {
          "label": "denoised_samples",
          "localized_name": "denoised_samples",
          "name": "denoised_samples",
          "type": "LATENT",
          "links": null
        }
      ],
      "properties": {
        "Node name for S&R": "WanVideoSampler",
        "cnr_id": "ComfyUI-WanVideoWrapper",
        "ver": "e5ef9752a7e846b232fc05fd993327a2e870a788",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        6,
        1,
        5,
        42,
        "fixed",
        true,
        "dpm++_sde",
        0,
        1,
        "",
        "comfy",
        0,
        -1,
        false
      ]
    },
    {
      "id": 28,
      "type": "WanVideoDecode",
      "pos": [
        1282.408447265625,
        -1076.896484375
      ],
      "size": [
        280.3896179199219,
        198
      ],
      "flags": {},
      "order": 33,
      "mode": 0,
      "inputs": [
        {
          "label": "vae",
          "localized_name": "vae",
          "name": "vae",
          "type": "WANVAE",
          "link": 295
        },
        {
          "label": "samples",
          "localized_name": "samples",
          "name": "samples",
          "type": "LATENT",
          "link": 33
        },
        {
          "label": "enable_vae_tiling",
          "localized_name": "enable_vae_tiling",
          "name": "enable_vae_tiling",
          "type": "BOOLEAN",
          "widget": {
            "name": "enable_vae_tiling"
          },
          "link": null
        },
        {
          "label": "tile_x",
          "localized_name": "tile_x",
          "name": "tile_x",
          "type": "INT",
          "widget": {
            "name": "tile_x"
          },
          "link": null
        },
        {
          "label": "tile_y",
          "localized_name": "tile_y",
          "name": "tile_y",
          "type": "INT",
          "widget": {
            "name": "tile_y"
          },
          "link": null
        },
        {
          "label": "tile_stride_x",
          "localized_name": "tile_stride_x",
          "name": "tile_stride_x",
          "type": "INT",
          "widget": {
            "name": "tile_stride_x"
          },
          "link": null
        },
        {
          "label": "tile_stride_y",
          "localized_name": "tile_stride_y",
          "name": "tile_stride_y",
          "type": "INT",
          "widget": {
            "name": "tile_stride_y"
          },
          "link": null
        },
        {
          "label": "normalization",
          "localized_name": "normalization",
          "name": "normalization",
          "shape": 7,
          "type": "COMBO",
          "widget": {
            "name": "normalization"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "images",
          "localized_name": "images",
          "name": "images",
          "type": "IMAGE",
          "slot_index": 0,
          "links": [
            320
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "WanVideoDecode",
        "cnr_id": "ComfyUI-WanVideoWrapper",
        "ver": "e5ef9752a7e846b232fc05fd993327a2e870a788",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        false,
        272,
        272,
        144,
        128,
        "default"
      ]
    },
    {
      "id": 102,
      "type": "DownloadAndLoadSAM2Model",
      "pos": [
        -234.79373168945312,
        -3388.709716796875
      ],
      "size": [
        270,
        130
      ],
      "flags": {},
      "order": 2,
      "mode": 0,
      "inputs": [
        {
          "localized_name": "模型",
          "name": "model",
          "type": "COMBO",
          "widget": {
            "name": "model"
          },
          "link": null
        },
        {
          "localized_name": "分割框架",
          "name": "segmentor",
          "type": "COMBO",
          "widget": {
            "name": "segmentor"
          },
          "link": null
        },
        {
          "localized_name": "设备",
          "name": "device",
          "type": "COMBO",
          "widget": {
            "name": "device"
          },
          "link": null
        },
        {
          "localized_name": "精度",
          "name": "precision",
          "type": "COMBO",
          "widget": {
            "name": "precision"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "SAM2",
          "localized_name": "sam2_model",
          "name": "sam2_model",
          "type": "SAM2MODEL",
          "links": [
            185
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "DownloadAndLoadSAM2Model",
        "cnr_id": "ComfyUI-segment-anything-2",
        "ver": "c59676b008a76237002926f684d0ca3a9b29ac54",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "sam2_hiera_base_plus.safetensors",
        "video",
        "cuda",
        "fp16"
      ]
    },
    {
      "id": 57,
      "type": "LoadImage",
      "pos": [
        -1206.0177001953125,
        -1836.356201171875
      ],
      "size": [
        299.1521301269531,
        550.3935546875
      ],
      "flags": {},
      "order": 3,
      "mode": 0,
      "inputs": [
        {
          "localized_name": "图像",
          "name": "image",
          "type": "COMBO",
          "widget": {
            "name": "image"
          },
          "link": null
        },
        {
          "localized_name": "选择文件上传",
          "name": "upload",
          "type": "IMAGEUPLOAD",
          "widget": {
            "name": "upload"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "图像",
          "localized_name": "图像",
          "name": "IMAGE",
          "type": "IMAGE",
          "links": [
            82
          ]
        },
        {
          "label": "遮罩",
          "localized_name": "遮罩",
          "name": "MASK",
          "type": "MASK",
          "links": null
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.57",
        "Node name for S&R": "LoadImage",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "cefc1e178a82b9014a900fb482c4be773912b21b41ab.webp",
        "image"
      ]
    },
    {
      "id": 22,
      "type": "WanVideoModelLoader",
      "pos": [
        -1205.052490234375,
        -1092.0802001953125
      ],
      "size": [
        601.9249267578125,
        318
      ],
      "flags": {},
      "order": 11,
      "mode": 0,
      "inputs": [
        {
          "label": "compile_args",
          "localized_name": "compile_args",
          "name": "compile_args",
          "shape": 7,
          "type": "WANCOMPILEARGS",
          "link": 100
        },
        {
          "label": "block_swap_args",
          "localized_name": "block_swap_args",
          "name": "block_swap_args",
          "shape": 7,
          "type": "BLOCKSWAPARGS",
          "link": null
        },
        {
          "label": "lora",
          "localized_name": "lora",
          "name": "lora",
          "shape": 7,
          "type": "WANVIDLORA",
          "link": null
        },
        {
          "label": "vram_management_args",
          "localized_name": "vram_management_args",
          "name": "vram_management_args",
          "shape": 7,
          "type": "VRAM_MANAGEMENTARGS",
          "link": null
        },
        {
          "label": "extra_model",
          "localized_name": "extra_model",
          "name": "extra_model",
          "shape": 7,
          "type": "VACEPATH",
          "link": null
        },
        {
          "label": "fantasytalking_model",
          "localized_name": "fantasytalking_model",
          "name": "fantasytalking_model",
          "shape": 7,
          "type": "FANTASYTALKINGMODEL",
          "link": null
        },
        {
          "label": "multitalk_model",
          "localized_name": "multitalk_model",
          "name": "multitalk_model",
          "shape": 7,
          "type": "MULTITALKMODEL",
          "link": null
        },
        {
          "label": "fantasyportrait_model",
          "localized_name": "fantasyportrait_model",
          "name": "fantasyportrait_model",
          "shape": 7,
          "type": "FANTASYPORTRAITMODEL",
          "link": null
        },
        {
          "label": "model",
          "localized_name": "model",
          "name": "model",
          "type": "COMBO",
          "widget": {
            "name": "model"
          },
          "link": null
        },
        {
          "label": "base_precision",
          "localized_name": "base_precision",
          "name": "base_precision",
          "type": "COMBO",
          "widget": {
            "name": "base_precision"
          },
          "link": null
        },
        {
          "label": "quantization",
          "localized_name": "quantization",
          "name": "quantization",
          "type": "COMBO",
          "widget": {
            "name": "quantization"
          },
          "link": null
        },
        {
          "label": "load_device",
          "localized_name": "load_device",
          "name": "load_device",
          "type": "COMBO",
          "widget": {
            "name": "load_device"
          },
          "link": null
        },
        {
          "label": "attention_mode",
          "localized_name": "attention_mode",
          "name": "attention_mode",
          "shape": 7,
          "type": "COMBO",
          "widget": {
            "name": "attention_mode"
          },
          "link": null
        },
        {
          "label": "rms_norm_function",
          "localized_name": "rms_norm_function",
          "name": "rms_norm_function",
          "shape": 7,
          "type": "COMBO",
          "widget": {
            "name": "rms_norm_function"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "model",
          "localized_name": "model",
          "name": "model",
          "type": "WANVIDEOMODEL",
          "slot_index": 0,
          "links": [
            59
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "WanVideoModelLoader",
        "cnr_id": "ComfyUI-WanVideoWrapper",
        "ver": "e5ef9752a7e846b232fc05fd993327a2e870a788",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "Wan2_2-Animate-14B_fp8_e4m3fn_scaled_KJ.safetensors",
        "fp16",
        "disabled",
        "offload_device",
        "sageattn",
        "default"
      ],
      "color": "#223",
      "bgcolor": "#335"
    },
    {
      "id": 71,
      "type": "CLIPVisionLoader",
      "pos": [
        -1202.4473876953125,
        -578.2976684570312
      ],
      "size": [
        601.1581420898438,
        58
      ],
      "flags": {},
      "order": 4,
      "mode": 0,
      "inputs": [
        {
          "localized_name": "CLIP名称",
          "name": "clip_name",
          "type": "COMBO",
          "widget": {
            "name": "clip_name"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "CLIP视觉",
          "localized_name": "CLIP视觉",
          "name": "CLIP_VISION",
          "type": "CLIP_VISION",
          "links": [
            97
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.59",
        "Node name for S&R": "CLIPVisionLoader",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "clip_vision_h.safetensors"
      ],
      "color": "#2a363b",
      "bgcolor": "#3f5159"
    },
    {
      "id": 65,
      "type": "WanVideoTextEncodeCached",
      "pos": [
        437.9472961425781,
        -662.0205688476562
      ],
      "size": [
        488.4488220214844,
        362.56817626953125
      ],
      "flags": {},
      "order": 5,
      "mode": 0,
      "inputs": [
        {
          "label": "extender_args",
          "localized_name": "extender_args",
          "name": "extender_args",
          "shape": 7,
          "type": "WANVIDEOPROMPTEXTENDER_ARGS",
          "link": null
        },
        {
          "label": "model_name",
          "localized_name": "model_name",
          "name": "model_name",
          "type": "COMBO",
          "widget": {
            "name": "model_name"
          },
          "link": null
        },
        {
          "label": "precision",
          "localized_name": "precision",
          "name": "precision",
          "type": "COMBO",
          "widget": {
            "name": "precision"
          },
          "link": null
        },
        {
          "label": "positive_prompt",
          "localized_name": "positive_prompt",
          "name": "positive_prompt",
          "type": "STRING",
          "widget": {
            "name": "positive_prompt"
          },
          "link": null
        },
        {
          "label": "negative_prompt",
          "localized_name": "negative_prompt",
          "name": "negative_prompt",
          "type": "STRING",
          "widget": {
            "name": "negative_prompt"
          },
          "link": null
        },
        {
          "label": "quantization",
          "localized_name": "quantization",
          "name": "quantization",
          "type": "COMBO",
          "widget": {
            "name": "quantization"
          },
          "link": null
        },
        {
          "label": "use_disk_cache",
          "localized_name": "use_disk_cache",
          "name": "use_disk_cache",
          "type": "BOOLEAN",
          "widget": {
            "name": "use_disk_cache"
          },
          "link": null
        },
        {
          "label": "device",
          "localized_name": "device",
          "name": "device",
          "type": "COMBO",
          "widget": {
            "name": "device"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "text_embeds",
          "localized_name": "text_embeds",
          "name": "text_embeds",
          "type": "WANVIDEOTEXTEMBEDS",
          "links": [
            281
          ]
        },
        {
          "label": "negative_text_embeds",
          "localized_name": "negative_text_embeds",
          "name": "negative_text_embeds",
          "type": "WANVIDEOTEXTEMBEDS",
          "links": null
        },
        {
          "label": "positive_prompt",
          "localized_name": "positive_prompt",
          "name": "positive_prompt",
          "type": "STRING",
          "links": null
        }
      ],
      "properties": {
        "Node name for S&R": "WanVideoTextEncodeCached",
        "cnr_id": "ComfyUI-WanVideoWrapper",
        "ver": "761b1d191e50d589465e31dc0d40ff7c59b1b7b0",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "umt5-xxl-enc-fp8_e4m3fn.safetensors",
        "bf16",
        "1 clay style man is speaking,",
        "色调艳丽，过曝，静态，细节模糊不清，字幕，风格，作品，画作，画面，静止，整体发灰，最差质量，低质量，JPEG压缩残留，丑陋的，残缺的，多余的手指，画得不好的手部，画得不好的脸部，畸形的，毁容的，形态畸形的肢体，手指融合，静止不动的画面，杂乱的背景，三条腿，背景人很多，倒着走",
        "disabled",
        false,
        "gpu"
      ],
      "color": "#432",
      "bgcolor": "#653"
    },
    {
      "id": 75,
      "type": "VHS_VideoCombine",
      "pos": [
        1417.3629150390625,
        -3854.7529296875
      ],
      "size": [
        852.673095703125,
        334
      ],
      "flags": {},
      "order": 31,
      "mode": 0,
      "inputs": [
        {
          "label": "图像",
          "localized_name": "images",
          "name": "images",
          "type": "IMAGE",
          "link": 304
        },
        {
          "label": "音频",
          "localized_name": "audio",
          "name": "audio",
          "shape": 7,
          "type": "AUDIO",
          "link": null
        },
        {
          "label": "批次管理",
          "localized_name": "meta_batch",
          "name": "meta_batch",
          "shape": 7,
          "type": "VHS_BatchManager",
          "link": null
        },
        {
          "label": "vae",
          "localized_name": "vae",
          "name": "vae",
          "shape": 7,
          "type": "VAE",
          "link": null
        },
        {
          "localized_name": "帧率",
          "name": "frame_rate",
          "type": "FLOAT",
          "widget": {
            "name": "frame_rate"
          },
          "link": null
        },
        {
          "localized_name": "循环次数",
          "name": "loop_count",
          "type": "INT",
          "widget": {
            "name": "loop_count"
          },
          "link": null
        },
        {
          "localized_name": "文件名前缀",
          "name": "filename_prefix",
          "type": "STRING",
          "widget": {
            "name": "filename_prefix"
          },
          "link": null
        },
        {
          "localized_name": "格式",
          "name": "format",
          "type": "COMBO",
          "widget": {
            "name": "format"
          },
          "link": null
        },
        {
          "localized_name": "Ping-Pong",
          "name": "pingpong",
          "type": "BOOLEAN",
          "widget": {
            "name": "pingpong"
          },
          "link": null
        },
        {
          "localized_name": "保存到输出文件夹",
          "name": "save_output",
          "type": "BOOLEAN",
          "widget": {
            "name": "save_output"
          },
          "link": null
        },
        {
          "name": "pix_fmt",
          "type": [
            "yuv420p",
            "yuv420p10le"
          ],
          "widget": {
            "name": "pix_fmt"
          },
          "link": null
        },
        {
          "name": "crf",
          "type": "INT",
          "widget": {
            "name": "crf"
          },
          "link": null
        },
        {
          "label": "保存元数据",
          "localized_name": "保存元数据",
          "name": "save_metadata",
          "type": "BOOLEAN",
          "widget": {
            "name": "save_metadata"
          },
          "link": null
        },
        {
          "name": "trim_to_audio",
          "type": "BOOLEAN",
          "widget": {
            "name": "trim_to_audio"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "文件名",
          "localized_name": "Filenames",
          "name": "Filenames",
          "type": "VHS_FILENAMES",
          "links": null
        }
      ],
      "properties": {
        "Node name for S&R": "VHS_VideoCombine",
        "cnr_id": "comfyui-videohelpersuite",
        "ver": "8e4d79471bf1952154768e8435a9300077b534fa",
        "widget_ue_connectable": {}
      },
      "widgets_values": {
        "frame_rate": 30,
        "loop_count": 0,
        "filename_prefix": "WanVideo2_1_T2V",
        "format": "video/h264-mp4",
        "pix_fmt": "yuv420p",
        "crf": 19,
        "save_metadata": true,
        "trim_to_audio": false,
        "pingpong": false,
        "save_output": false,
        "videopreview": {
          "hidden": false,
          "paused": false,
          "params": {
            "filename": "WanVideo2_1_T2V_00003.mp4",
            "subfolder": "",
            "type": "temp",
            "format": "video/h264-mp4",
            "frame_rate": 30,
            "workflow": "WanVideo2_1_T2V_00003.png",
            "fullpath": "/ComfyUI/temp/WanVideo2_1_T2V_00003.mp4"
          }
        }
      }
    },
    {
      "id": 174,
      "type": "VHS_VideoCombine",
      "pos": [
        1104.6322021484375,
        -1953.9591064453125
      ],
      "size": [
        270.1362609863281,
        334
      ],
      "flags": {},
      "order": 24,
      "mode": 0,
      "inputs": [
        {
          "label": "图像",
          "localized_name": "images",
          "name": "images",
          "type": "IMAGE",
          "link": 292
        },
        {
          "label": "音频",
          "localized_name": "audio",
          "name": "audio",
          "shape": 7,
          "type": "AUDIO",
          "link": null
        },
        {
          "label": "批次管理",
          "localized_name": "meta_batch",
          "name": "meta_batch",
          "shape": 7,
          "type": "VHS_BatchManager",
          "link": null
        },
        {
          "label": "vae",
          "localized_name": "vae",
          "name": "vae",
          "shape": 7,
          "type": "VAE",
          "link": null
        },
        {
          "localized_name": "帧率",
          "name": "frame_rate",
          "type": "FLOAT",
          "widget": {
            "name": "frame_rate"
          },
          "link": null
        },
        {
          "localized_name": "循环次数",
          "name": "loop_count",
          "type": "INT",
          "widget": {
            "name": "loop_count"
          },
          "link": null
        },
        {
          "localized_name": "文件名前缀",
          "name": "filename_prefix",
          "type": "STRING",
          "widget": {
            "name": "filename_prefix"
          },
          "link": null
        },
        {
          "localized_name": "格式",
          "name": "format",
          "type": "COMBO",
          "widget": {
            "name": "format"
          },
          "link": null
        },
        {
          "localized_name": "Ping-Pong",
          "name": "pingpong",
          "type": "BOOLEAN",
          "widget": {
            "name": "pingpong"
          },
          "link": null
        },
        {
          "localized_name": "保存到输出文件夹",
          "name": "save_output",
          "type": "BOOLEAN",
          "widget": {
            "name": "save_output"
          },
          "link": null
        },
        {
          "name": "pix_fmt",
          "type": [
            "yuv420p",
            "yuv420p10le"
          ],
          "widget": {
            "name": "pix_fmt"
          },
          "link": null
        },
        {
          "name": "crf",
          "type": "INT",
          "widget": {
            "name": "crf"
          },
          "link": null
        },
        {
          "label": "保存元数据",
          "localized_name": "保存元数据",
          "name": "save_metadata",
          "type": "BOOLEAN",
          "widget": {
            "name": "save_metadata"
          },
          "link": null
        },
        {
          "name": "trim_to_audio",
          "type": "BOOLEAN",
          "widget": {
            "name": "trim_to_audio"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "文件名",
          "localized_name": "Filenames",
          "name": "Filenames",
          "type": "VHS_FILENAMES",
          "links": null
        }
      ],
      "properties": {
        "Node name for S&R": "VHS_VideoCombine",
        "cnr_id": "comfyui-videohelpersuite",
        "ver": "8e4d79471bf1952154768e8435a9300077b534fa",
        "widget_ue_connectable": {}
      },
      "widgets_values": {
        "frame_rate": 30,
        "loop_count": 0,
        "filename_prefix": "WanVideo2_1_T2V",
        "format": "video/h264-mp4",
        "pix_fmt": "yuv420p",
        "crf": 19,
        "save_metadata": true,
        "trim_to_audio": false,
        "pingpong": false,
        "save_output": false,
        "videopreview": {
          "hidden": false,
          "paused": false,
          "params": {
            "filename": "WanVideo2_1_T2V_00001.mp4",
            "subfolder": "",
            "type": "temp",
            "format": "video/h264-mp4",
            "frame_rate": 30,
            "workflow": "WanVideo2_1_T2V_00001.png",
            "fullpath": "/ComfyUI/temp/WanVideo2_1_T2V_00001.mp4"
          }
        }
      }
    },
    {
      "id": 150,
      "type": "INTConstant",
      "pos": [
        -2021.3367919921875,
        -3356.828125
      ],
      "size": [
        210,
        58
      ],
      "flags": {},
      "order": 6,
      "mode": 0,
      "inputs": [
        {
          "localized_name": "值",
          "name": "value",
          "type": "INT",
          "widget": {
            "name": "value"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "值",
          "localized_name": "value",
          "name": "value",
          "type": "INT",
          "links": [
            260,
            286,
            312,
            316
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "INTConstant",
        "cnr_id": "comfyui-kjnodes",
        "ver": "37659859825cea55940a58110525795ce5deb8be",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        720
      ],
      "color": "#1b4669",
      "bgcolor": "#29699c"
    },
    {
      "id": 151,
      "type": "INTConstant",
      "pos": [
        -2021.4439697265625,
        -3244.66064453125
      ],
      "size": [
        210,
        58
      ],
      "flags": {
        "collapsed": false
      },
      "order": 7,
      "mode": 0,
      "inputs": [
        {
          "localized_name": "值",
          "name": "value",
          "type": "INT",
          "widget": {
            "name": "value"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "值",
          "localized_name": "value",
          "name": "value",
          "type": "INT",
          "links": [
            261,
            287,
            313,
            317
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "INTConstant",
        "cnr_id": "comfyui-kjnodes",
        "ver": "37659859825cea55940a58110525795ce5deb8be",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        1280
      ],
      "color": "#1b4669",
      "bgcolor": "#29699c"
    },
    {
      "id": 177,
      "type": "Note",
      "pos": [
        -2208.49853515625,
        -3108.927490234375
      ],
      "size": [
        410.9060974121094,
        434.4292297363281
      ],
      "flags": {},
      "order": 8,
      "mode": 0,
      "inputs": [],
      "outputs": [],
      "properties": {},
      "widgets_values": [
        "使用注意事项\n1在视频上传的节点中\nframe-load-cap / 帧数读取上限 这里最高帧数不要超过300\n\n2在这个说明框 的 上边 有两个 数字节点\n分别代表着视频的宽度和高度参数 你可以根据你的视频比例来修改\n但是建议视频的总清晰度不要超过720p 不然 会断连 或者 生成时间超长\n\n3视频的生成时间 9秒钟的视频一般要20分钟多 \n\n4在我的粉丝群或者镜像群里 都有个群公告里面会有一些注意事项一定先去看 后来用 \n\n5当前工作流我已经确认 720p清晰度的情况下 可以确认能跑通 30帧的十秒视频\n用时21分"
      ],
      "color": "#432",
      "bgcolor": "#653"
    },
    {
      "id": 107,
      "type": "PointsEditor",
      "pos": [
        -1142.3701171875,
        -3687.6083984375
      ],
      "size": [
        765,
        1580
      ],
      "flags": {},
      "order": 18,
      "mode": 0,
      "inputs": [
        {
          "label": "背景图",
          "localized_name": "bg_image",
          "name": "bg_image",
          "shape": 7,
          "type": "IMAGE",
          "link": 293
        },
        {
          "localized_name": "点位置",
          "name": "points_store",
          "type": "STRING",
          "widget": {
            "name": "points_store"
          },
          "link": null
        },
        {
          "localized_name": "coordinates",
          "name": "coordinates",
          "type": "STRING",
          "widget": {
            "name": "coordinates"
          },
          "link": null
        },
        {
          "localized_name": "neg_coordinates",
          "name": "neg_coordinates",
          "type": "STRING",
          "widget": {
            "name": "neg_coordinates"
          },
          "link": null
        },
        {
          "localized_name": "BBox位置",
          "name": "bbox_store",
          "type": "STRING",
          "widget": {
            "name": "bbox_store"
          },
          "link": null
        },
        {
          "localized_name": "bboxes",
          "name": "bboxes",
          "type": "STRING",
          "widget": {
            "name": "bboxes"
          },
          "link": null
        },
        {
          "localized_name": "BBox格式",
          "name": "bbox_format",
          "type": "COMBO",
          "widget": {
            "name": "bbox_format"
          },
          "link": null
        },
        {
          "localized_name": "宽度",
          "name": "width",
          "type": "INT",
          "widget": {
            "name": "width"
          },
          "link": null
        },
        {
          "localized_name": "高度",
          "name": "height",
          "type": "INT",
          "widget": {
            "name": "height"
          },
          "link": null
        },
        {
          "localized_name": "规格化",
          "name": "normalize",
          "type": "BOOLEAN",
          "widget": {
            "name": "normalize"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "正面坐标",
          "localized_name": "positive_coords",
          "name": "positive_coords",
          "type": "STRING",
          "links": [
            210
          ]
        },
        {
          "label": "负面坐标",
          "localized_name": "negative_coords",
          "name": "negative_coords",
          "type": "STRING",
          "links": []
        },
        {
          "label": "BBox",
          "localized_name": "bbox",
          "name": "bbox",
          "type": "BBOX",
          "links": []
        },
        {
          "label": "BBox遮罩",
          "localized_name": "bbox_mask",
          "name": "bbox_mask",
          "type": "MASK",
          "links": null
        },
        {
          "label": "裁剪图像",
          "localized_name": "cropped_image",
          "name": "cropped_image",
          "type": "IMAGE",
          "links": null
        }
      ],
      "properties": {
        "Node name for S&R": "PointsEditor",
        "cnr_id": "comfyui-kjnodes",
        "ver": "623b5913dc7f240fd8b26422e99f8849a21c5473",
        "points": "PointsEditor",
        "neg_points": "PointsEditor",
        "imgData": {
          "name": "bg_image",
          "base64": [
            "/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAgGBgcGBQgHBwcJCQgKDBQNDAsLDBkSEw8UHRofHh0aHBwgJC4nICIsIxwcKDcpLDAxNDQ0Hyc5PTgyPC4zNDL/2wBDAQkJCQwLDBgNDRgyIRwhMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjL/wAARCAUAAtADASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwBy8GpD0qOng5WtDMbRRRQBNaf641fqha/601foAKaadTTQMDUZqQ1GaQDKSnUlAxKSlooAaaQ0ppDTENopaKBCUlOpKAEpKdSEUAJRS0UAJRRRQAUUUUAFJS0lABRRRQAhpKU0lABRRRQAUlLRQAlFFFABSUtFACUUtFACUUtFADaKWigBKKKKAClpKWkAUUUUAFJS0UANopcUYpgNopaSgAooooAKKKKACm06igBtFKRSUAJRRRQAlFLRQMSilooASilooAbRS0lABRRRQAlFFFABSUtFACUUtFACUUYoxQA2inYoxQBapc02igQ6igUUAT2f+tb6Ve7H2qhZn/SMeoq+fut9KANu28NXN1EJI2+U9OP/AK9Y95CbS/ms3P72I4YEV6b4fH/EtX6Cue8Z+HJrm5TVbGMu6rtuI16lR0YeuP5U5tJ2McCpTpc9Sd215HHGozS5zSGpNxlFOptAwopaKBDTTTTjTTQAlJS0UxCUlLRQAlFLSUAJRS0lACUUtFABRS0UgG0U6m0AFFFFMApKWigBKKKKACkIpaKAG0U6igBtFFFABSUUUAFFFFABSUtFADaKdSUAJS0UtIBKKWigBKKWigBtFLRTAbRS0lABRRRQAUUUUAFFFJQApplOooAbRTqKBjaSn03BoASiiigAooooASilooAbRS0UAJRS0UAJSU6koASilooASiiloASilpKAHxl/LXePmwM1IDSUCgQ4U6m1raLo0uptvO5YumV6sfb296ai3ojGtWhRjzzehRtP+PgfQ/0rQPRvpXdWPg2yjQeZbxf8CUOfzOa4zxIq2HiqexgVVgEKttAxg4FJtLqaYZVa6lLkskr679Oh6R4f/wCQav0FaMc8UrOscisUO1gD0PofSs7w/wD8g1foK8x1a6ubbxvqbW1zLA/mE7o268L1HQ/jSn8ZeWUY1MK5SduWN/xS/U9A8U6RYvpF7emBVuI4WYOoxk47+teYW8plhDHvWpdeKfENzYTWMzwTRyoUZzGA2D9KyrVCluoNQjrnSpQoOSknJvpfa3Z26k9a1hoX27Q77UvtOz7KHPl+XndtXd1zx+VUrB7dL+Brtd1uHBkAB5H4V6DplxoUmg38tnbulim/7QpBy2F57+lUcp5tFFJPII4Y3kkPREXLH6AUOjRsVdGVh1DDBrWutUs7XXre80K32xxR42SqxDP8wPBOehHetG48dS3emz2tzYRF5Y2TekhAUkYzgg9PrQBm32g/Y/D1tqv2nf57BfK8vG3IJ6556elYyI0jqiKSzHAA712Wt/8AJPNM/wCuifyauPg80TI0IJdTlcDPIpoC/wD8I9q//QOuf+/Rq3pfhS/vbzybmKe0jKk+a8JIz6dRWnpeseJdS1CO1a68gPn52tQQMAnnj2pmp614o03UZrQT+aIyMSLbqAwIByOPekBmal4V1Kyv3gt7ee6iUArMkRw2R7Z+lUzoOrgEnTbrAGT+6NdHo+q+JtV1AWzXIgUqWMjWykDH4Cq+oa94ltb24tVnMqxsU3i1ADe/SgDk6Sl2lMqQQQcEHtRVEiUlOpKACilopAJRS0UAJSU6koASilooASilooAbRS0lABRRRTAKKKKAEooooAbRSnrSUAFFFFACUUtJQAUUUUAJS0UtIBKKWigBKKWigBtFOpKAG0lOopgNopaKAEopaKAExS4paSgAxSUtJQMKKKKACiiigBppKdTaACiiigAooooASkp1IRQAlFFFABRRRQAlFLRQAlFLRQA2ilooAlpRWl5Ef9wUeRH/AHBQIpQRG4uYoVODI4XP1OK9d8PafHbWqusYXgBR6AV5rZwxpqFsyqARKn8xXrVjxYQ/7tNyahp1OV0+fFRctopter/yPPNf8f30mpvY6KyxRIxQylQS5HcA9BXNzzX1/qbX1/IrysmwkKB9OgpRpsmm6hd29wmJ0fGT3XsfxqzHE88yRRjLOcAVnGHVnu43FQpc1GikoJWbtq+rbe+vkep+H/8AkGr9BXlmuf8AI7al/wBdD/Ja9V0JdunR+4ryXVJ1uPGOpSL93znH5YH9KqfxnFlH+4Tf9xf+lRFoopaDIdbwSXVzHbwrulkO1VzjJrvtE0O9t/DWpafcIsU9zvCAsCBlAoJxnvXBW88lrcx3ELbZIzuU4Bwfoa7XStTvrzwjrFzcXLvPGsmx+FK/uweMY7mgZz0lvc+ENctmlMU0yJ5uFJC/NuXGcZ7GtK88YWWo2s0V3o43tEyxyDbIVYjg8gY7c1laDfadbXUs2sRPdAoAm5d5zn3NbT+KPDUYxFoJIHTNvEB/M0gDW/8Aknmmf9dE/k1cpp99Lp17FdwBDJGSQHBIOQRzgj1r0e88Rrp/hy01OKzykzKqxb9u3IJ649vSvNbq4a8vri6ZQpmlaQqO2STj9aaA7az1/wAW6hbi4tNKtZIicBsbc/TLjP4VOuo+NwMHR7U+5Zf/AI5UqRSTeDdNWPVl0w4XMzHG7g/L1H1/Cs37Dcf9D5F/39/+2VIF06j43II/se0HvuX/AOOVUv8AxL4q0uNJL3TLSGNztDEFhn04c4pv2G4/6HyL/v7/APbKs+IUaPwIFfUFv2Ei/wCkKQQ/zH3PTp17UDOCnne6uJbiXHmSu0jbemSc8fnUdGKKskKSnUlAhKWiikAUUtFACUUtFACUUtFADaKWigBKbT6bQAlFLRTASilooASiiigBKKWkoAKKKKACm06kIoAKKXBowaQCUlLSUAFFFFABRRRQAUlLSUAJRRRTAKKKKAEpaKKACkpaKAEopaKBiUYpaSgAxRiiigBKSnUlACUUUUAFFFFABRRRQA2inU2gBKKWigBKKKKAFoopaQDaKWkoA2aM0zNLmgQ6vRfCusR6hYi2kk/0qIYKnqw/vD/PFecZpUkeKRZI5HR1OVZDgj6GgFa9z1fU9FsdWVftcAZ1+64yGH4iqdr4WtLVy0ZG3uMHP5k1xcXjbXbRMMILtR3ddrH8uKr3vjvxDcoVggjts/xIqsf1NJTcdjaWXU8Tb2ko2821+HX7jsvFfiW38PaYYYSPtkq4iQHlf9o+grzCwiZY2lkOXkO4k1HHbTTzm4u5GllblmY5Jq+AAMDpSUW3dnXXrUaNH6vh3e+rla17bJLsvxCiiirPPJLZoVuoGuFLwLIpkUHkpn5h+VdTd+JdHg0G60/SrGaMzqy/OBgbhgkncSeK5GikFxAOKKWkNMDoNU1m0uvCdhpsTObmF1ZwV4wAwPP4iueApaBSA6q08QaNNoNvpusWU8vkHI8vpxnBB3Ag4OKZ9s8E/wDQLvP++m/+LrmCM0m2lYdzqftngn/oF3n/AH03/wAXUWta/pk+hR6VpVrLFEJAx8wdBnPHJJya5rbRtp2FcBRilxRimIbikxT8U3bQA2ilooAKSnYoxUgJRS4oxTASilxRigBtFFFMBKKWigBKKKKAEopaKAG0U6koASilooASilooASiiigApKWigBKKKKAG0tLRSASilxRigBKKXFGKAG0U7FJigBtFLSUwCiiigAooooASilooGJijFLijFACYoxS4oxQIbRS0UDG0UtFADaWlpKQCUUtFMBKKWigBlFOIzRQA2inU2gAooooAKSn02kM1KKSlpki0lT2Vq17ew2yMFaVwgZugzUs2m3Eeqvp0amWdX2AIOppAU+KMCtGw0e4vdUOnt+4mAJIkB4xVKOGSadYYkZ5GOFVRkmgCLFLitWHw7qck6JJZXESMwBcxEhfc4p954Z1S1u5IUtJp0U8SRocMKLgY+KMVPc2dxZSCO5heJyMhXGDir9loF3fWP2xJbaOHfszLJt5ouBkUVuf8ACMXP/P8Aad/4EiqGpabPpV39muChfaG+Q5GDRcZSooopiDFGKKKADFJS0ckgCgBKKmltbiGcQyQSJK2NqMhDHPTimTQy28pimjeORequMEUAMooooAKSlooAbRS0YoASkp2KbikAUUuKle2mjhSZ4pFik+45UgN9D3oAhoqa4tZ7Up58Lx713LvGMj1FQ0AJSVPNbT25UTwyRlhuXepGR61DQAmKMUuKMUwExRilxRigBMUYoooAMUmKWigBMUYpaSgAxSYpaSgAxRiiigAxRiiigBMUYpaSgAxRiiigAopaSkAUUUUAFJS0nagBtNpaSmAtLSU8dKAExSU6igBtJT6bQMSiiigAopcUYoENop2KMUDG0lOxRigBtFLSUAGKMUUUAGKMUUUAGKbilpuaAH4oxSA0tIBuKKWkoGFFFFAGlRRRTJOg8MajHb31vamytpGlnXEzjLpkgcVoa2pv9Y8mSKHT4xOyrehCC7Y4BP5c1neGb6K3v7a3+wQyTSTqBO/JQHA4Hr71a1QpqevXkOo6sbaGBysSMpYfgB/OpKNHTpNSHii2g1ONPNhhdVmVeZRjqT3rkrCITX+DepZlcsJmJGCPcV12gnSTq8Qt9Ru7y4SMovmIQqqB79sVyGpPZyXZNjDJFCBjbI2ST60Azq0nQaNLZyeKIjcGQPHOJ2DAdwT1xSWc8dtY3cb+KYpbiZQkbvcMRGO5GT1q3eTfZ0tRHe6VbhrdGK3KDcTjr9KbY3LTXsMb6lokqs4BSNBuYeg96BnL6jZPJc24j1VNTnlOwbZCxHoCSfet+x064TQxp1/o11MomMuY3Qc/nXNavmPW7zYSm2d8beMcnpV/RtYtrS0vYr6e+LXChFeI5KrznGTwaBGr/wAI/Zf9C7f/APf5P8ao+JrLULy5fUGsJoYEjUMXK8Y+hqL7Rof/AD+65/32P8ag8RWx07UPskV1cyRGNWIkkJ5OeD29KAK93oxtNItdQN1E4n/5Zr1X/Pesur1xpN5bafBfTQ7beb7jZH1HFUaYjbt9Bi+wRXl/qMVmk3MalC7MPXAqHVtFbTI4J0uEubacZSVBj8CO1a9xY2uk2Fi0emfb57lA7SvuKDPYAVZ14G30LSDPapb7Jy7wx9FHJx9f60gMn/hHIraGJtT1OKzklG5IvLLtj3x0qpqOlXOjXcBLo6Ph4Z4+Q3P/AOqtXxbZXNzqqXkEck9vPGvlMi7h06cfn+NLrga00HSNPnb/AEtMyMvUoD2P54/CgCLW/wC0YfE1oJ71ZLgCPy5ViAC5PHHeoNZsr+78TNaTTpPcttUPt2LjGenYCr/iX/ka7L/di/8AQqk1DTo9U8eSWszFYyFZsdSAgOBQBRXwzZvc/Y01yA3nQR+Udpb03ZrNttDvbrVm01EUTISHJPCgdST6V0WnANr6W9poEUMUMoBml3blAP3sk4z6VPZOjeKNbtdwSe4iZYmPrjp/X8KAMdfDVtcu8FjrNvcXSgnythUNj0bODVDTNDudSvpLYEQ+TkzPJwIwD3q7oGlX6+IbffbyxCCTdIzqQAB159/61r2VzDqV34hsrWRRNdZMJzgPjIOD/ng0AZVt4Xt9QuPJsNYhnK58zMZUqPUDPzD3HrVGDRTPYahdCcAWbYK7Pv8AP14rb8J6Pf2mtrPdW7QIisP3nG4kdB696NJje40jxBbwqXmLAqg6nk9KAMHSNIbVjchZhF5ERlOVznHapNO0MXVi99d3sVnaK20Ow3Fj7AVteFNPureDUriaF442t2Rd4Klj9DVa10+1svDcWptYm/nmcqFydkQBI5x9P1oAz9Q0JbbTRqFnfR3lru2MyoVKn3BqfUlv/wDhF9Nea7ElqxIji2AEYyOT371q3iOPAl072EVl5kqsI4wRkZABIJzVLVf+RK0b/ro/82oAveINMiu002e7vo7OBbVUDMpdmb0Cjn6n3rnNW0OTTI4bhJ47m0n/ANXNH0J9CO1bviuxuZbXS7iKF5Ixbqh2jO04zUOoK1j4Is7S5yk8s5lSNuoXnt26j86AGa3bXl7qemW+o6gjefENjiLATPqPc4rGutJnttaOmfel8wICB1zjB/WtrxiSsumEdfsiVtW3kXq2fiWZlJt7dhOO5den8z+lAHMP4al/txtMiuo3aNQ0srDaqf5yKli8NWt6ZItO1mG6uEUt5flFN2PQk80/Q7GLXNRvbq9EkxjRpjEjYMjHsP8APpWz4Xc3OqeZHokFpEgOZcNuHsCepoA4JgVYqwwQcEGkqS4/4+Zv+ujfzqOqEJRS0YoASilxRigBKKXFGKAExRilxRigBpFJTqSgAxRiiigAxRiiigBMUYpaSgBcU3FOoqQG4pMU6imA3FJin0lADKSnHrSUwFAp1AooAMUYoooAMUYoooAbijFOooAbijFLRQAmKSnUYoAbSUtJQMKbTqKAG0U7FGKAG0UuKMUANpnepKQjNACUtJilpDCg0tFADaKWigDSop1LTJL+kapHpcrSPYxXMmQ0bO2DGR3HFVLu4e9u5bmYDzJWLHA4qPFFAF3SNSOkX4u0hEpCldhbb198GqJOSTjGTmlpKAudBL4paRYVOl2L+XGE3TJ5jHHvxge1Ng8UNDOkn9lab8pz8kO1vwPY1g0tKwXJ725+2Xs9zs2ebIz7c5xk5xmoKSigDXstXs7SCNJdGt7iVDnzWcqTzxkYNU9QvpdTvpbubaHkI4XoABgD8qpnqKcKAJJLmeWCOCSaRoos7EZiQv0FV8VJTO9MC7Bq+o2sIhgvZo4x0RW4H+FQy3lzPbpBLPI8SsWCs2eT1P61BRQBcttVv7OPyra9nijznarcfl2p1p5d9qG/UL1o1b5mmkBck+lUaKQzZ8RarFf60Lq0ZtkYVUfoTt7j05rOlvLma6F1JPIbgEHzN3zZHTmqx7U7tQIuyazqc2zzNQuHCMHUF+MjoarS3Es1wbh5XMxO7fnnPrmoqKAL0+s6ncwtDNfzvEwwVLcH/Gl0j+zjdMmoSSxKV/dzRk/I3qcVn5pKAOtsLix0i5/tC61v+0JY42EEaszEk/X7tc1FfXFtctcW88kUrZyyHB5qvRQBeOs6kzs7X07OybGJfqvpUdrqd/Yqy2t5NCrHJCNwT9Kq0UDuWpNSvZopopbqV0mYNIGbO4jGM/lUcl5cy2sVs8zGGLJRCeBmoaWgRdTWtTjYMl/cKQgQYboB0FVbm5nvJjLcTPLIRjc5yaYaSkBLc3lxd+WbiV5DGu1dx6D0rZnvrW28KRafbTh555PMuNoPy9ML/L8qwaKBj7e5ntZ1mt5XikXoyHBq22t6o8yTNf3DSJnaS/3c8HFUaKBCMSWJPU8mm06m0wG0U6m0wCinUUANop1NoASilpKAEopaKAEopaSgAopaKAEopaSgAxRiiigBKWkopALRRRQA0gGjaKdSUAGKMUUUwDFGKKKADFGKKKADFGKKKADFGKKKAExRilpKAG4oxS0UDG4oxRRQAlFLSUAFFFFACUUtJQAUUUtAxKKWikA2kp1IRQBqUUtFMkSitDSNMbVb9YAxRAC0j/3VFa0viC005zb6TYwGNeDLKNxf3oA5mg11VvNYeJQbaa3itb8g+VLHwGI7EVzM0LwTPFICHQlWHoRQBFRTsV1r2EFtZ6XZT6dNczPG0r+SPnGSMZPoM/ypXGchRXcanpVofENrFDp0se6ZCZAoELKBkjAHXArO1vRYCLzU4L618kSYWKId/wC71xnvRcLHMYzS119jocz+GZI1ktPNupEKOX6DAOM469sVFpejSxS+RPoqXiibYbgTFVUZweO+OfSi4WOVpMV2WradfE3FnYaHbpbFsCUKC7D1BJ4rM8Nae8mpWt08atb+cYWDY+9tJxigLHPkUlddpltbQ6gIL61tZlvtz20jHIDAkbDxx/8Aqq5bJaYupb/QLW0t7bIdyclm7BRjn/69FwscLRW14cjiuPEluskSNE7NmNgCMbTxis+6tplnlPkuEDH+EgAUAVaK6HxDYtJe2EVna5d7SNisSdSc88Vj3thc6dMIbuIxyFQwBOeDQIrYoxRRTASilpKADFIRS0GgBKWkpaACiiikAlFFFMBaSikpALSUlFAC02looASilopgJTadRQA2inU2gApKWigBKKWigBKKWkoAKKKKACkpaSgAopaKAEpKdSUAJRS0UAJRS0UAJRS0UAJRS0UAJRS0UAJRS0UAJRS0UAJRS0lABim7adSUDEwKMClooEJgUmKdRigYzFGKXFGKAExRilxRigBuKKDRQAtJRS0hiUUtFAGlRS0UyTofCw8xdTt0/wBfLbER/X/JFc8QVJVhgg4Iqe0upbG6juYG2yIcj/A1uTXmgao3nXkM9rcH77Q8q3vSAzdBill1yzWIHIkDEjsByTRrzpJrl48ZypkP+B/Wtq11jRtKkWOytZXVztlmc4bb7f5FZet6QLJkubeTzrOfmOTOT9D70DMu3lWG5ilZBIqOGZD/ABAHpXbXckWqX+kvPJcwPcwfIbZsYJIOCfSuFrtkkt7aDTL+aVB9lsNyITyzHAGPz/WhgiS+1iKz1Nr8WmoMwby/342wqOhZffj9TVLxHAthpaW6upW4u3uFA/uY4/nU0sLzaTBZapqcQeS4Mzu828+WF7VT1S607WdPd4GW3lsfliSQ/wCti4Ax7+1IZe06zM1noKxKGgjlaeeQYIVhyAT2Pam6bPCy6jewXxe9dZZkiJJSEZPOOmTniqmn3tt4d0pZS6XVxeEFoVf5Vj6HP+11H/6qjS4s7DRr67tsI98TDDAH3GNO+70//VQBY0+QT+G/+JlqM0SvOVhnDNuRsEncc8qf61D4cvkN5Yaeitlbl5Wkzw3yEDjrVeXH/CFQf9fh/wDQag8M4HiOzJOBub/0E0wuXbaa2kidLi1vtQkgnk8uCMYiTLE5JHPP41p6hcXdzDBFq2lNcW8yiSMWgcPD2wc9T+VZVna3pa4ltNYtbQPK2VafYxwT1GK2dQN9PFaC1160jaOILKftIG9+5pAYuhrbp4xgS1EohVmC+aMN905z+NVLzxDq8pnge9YxNuRl2LyCSMdPSrejRCz8WRm6vYHKbnaZXyrEj19eaiurDRYFlaTVjPOwYolumVDc4y3TGaYi/wCIdYvrFLG2tZzCjWkbMUA3H8a5N5HlcvIzO56sxyTXV6nYQ60llcQanYxhLZI2WWXaQRWZ4je2WSytbaaKb7PbqkkkYGGb69+1ITRjUUtFUAlJinUUAMpDTqSgBKKWkoAWkpaSgApKWkoAKSlpKACiiigBKKKKACikopAFFFFMAptOooAbRTqKAG0U6igBlFPwKbQAlFLTsCgBlFOxRigBtFLRQAlFLRQA2inUUANop2KMUANopaKAEopaKAEopaKAEopaKAEopaKAEpKdSUAJRS0UANoxTsUYoAbRS0UAJSU6kIoGJRS0UANxRinYoxQA3FLiiigY2nUyloA06KWiggSlp1JQAUrO5QIWOwHIXPApKKAuJijA7CnUUDG4pcU+igCOkqTFNoAZRS4oxQFxMUYp2KMUANxRinYoxQAzFLilxRigBtFLRQAlFLRQAlFFFADaKdTaAEoopKACkpaSgApaSikAUlLSUwCkpaSgAooooASiiigAooooAKKKKACiiigAooooAKWkooAWkoooAQikp1FADaWkPWikAUUUUwCiiigAooooASiloxQAlFLijFACUUuKSgAooooAKKKKAEopaKAEopaKAG0U6igBtFOxSYoAbRTsUlAxKKdRTAbRTqSkMiNFOPWm0AatLRTqCBtFOooAbTqKWgAooopiEooooASkp9GBSKI6KfgU2gAopaKAG0U7FJigBtFOxSYoASilxRigBtJTqSgBKKWimISilpKAGUU+mUhiUUtJQAUUUUAJRRRQAlFFFABRRRQAlFLRQAlFFFABRRRQAUlLSUAFFFLQAUUUUAFFFFABRRRQAYpKWkoAKKKKACiiigAooooAKKKKACiiigAooooAbRTqKAG0U6igBKKWikA2inU00wEopaKAEopcUYoASm0/FJigBtFLikoGFFFFADD1ptPNJg0Aa1FLRQSFFLRQSJRS0UDEopcUlAwxRiiigBKKWigBKbTqKAG0U6igBKSn0YFAxlFLRQA2inUlACUlOpKYhtFOpKAEopaSgBtLRRSAZRTqKBjKSn02gBKKdSUAJRS0UAJRS0UAJRS0+JkWQeYuUPBx1oAjxRinEYNJQA2kp1JQAlFLRQAlLRRQAUUtFACUUtFABRSUUyQopaKRQlFLRQA2ilooASilooASilooAKKWigBMUYpaKAEopaSgAopaKAG0U6igBtGKWigBtFOpKAEopaKAEopaKAG4pMVJSUAMpKWigLjSM0mKdRQM1KKKKZmFFFFABRRSUALRRRQAlFLSUgCiiigApKWkoAKSlpKBhRRRQMKbTqbQAUlLRQAUlFJTASiiigQlFLRQAlJS0UAJRRRSGIaSlooGJSU6koASilqTyH2bi8Q9jItAENFP2HPVT9GBo2HOKAG7G2hscGgVahMsSNtG5CMMpGQaiaNQhcts9FIzmlcrlEQI7jdnHeltbZrppMHCxoXY4pjK8R2yIy7hkZGKdG8kUbBGwH6+9HMHKRU2n4qSWGOPG2YOSAflFO5LRFijFGaM0AJRS0lABRRRQAtFLRQAlFLRQAlFFFABRRS0AJSU6igBtFOxRigBKKWigBKWiloAbRTsUYoAbRTqSgBKKWigBKKdijFADaKWigBtFOpKAEooooAKKKKACkpaKAG02n0lADaKD1ooA1qKKKZkFFOooAZRT8Cm0AJSUtFAxKKKKACiiigBtFLSUDCiiigBKSlpKAFpKWkoHcKbTqbQA2ilNJQAlFLRQAlJS0lACUUUUANop1NoAWijPtSikMSkzSkZFUpb+FJfKjPmzdkX+pouhpNlvdTC8aDLuq1LptvLeXOZWjEa/eVOf1rpYNLsnO5reIr/AHmjGTWE68UzaNFvcwLKNbtsRSKzegrUOnXHlgCUjPRBXQW9pHGg8mBYx2wMVK0BcEFfxrnlXfQ3jSRyX9nNG5bzpUb/AGjmrdvZwKd8pBHfFbjaZvb5uh9azL1FtTtVk69CKwlUbZsoopXq2VzcqvnMrKMB2GR9Kbc6YjSecZjM3fauKz9Suz5OwIi89QKx31pI2YGURjjKqaqNZpB7JHRHTvMz5R2v6Gqz2MqkiTen+3jIrPs/EEW7/Wt+ddbY6jHMoBIYGq+tPqT7BHOO2wbEHHcnqTSqIGXD5Q+qjNdVPpNncjzFiCt6rxWZNoeW/cy4/wBkiumGIjI550GjFlgeLDHBRvusvINRYrQuLC6twVaNinqvSqRraM09UYSg0NopaK0ICilopDEopaKAEooooAKWkp1ACUUtFACUUtFACUUtFACUtLRQAlFFFAgooooAKKKWgBKKWigYlJTqSgBtFLRTJCkpaKB3G0UtGKAuJRS4oxSGJikxTqSgBtFLRQBqUUUVRkOpKWikAlFFLQMSm06igQyinYNNoGFFFFABTadSUAJSUtFAxKSlxRQAlFFFABSUtJQA2m06m0DCiikoASkpaSgAooptABRRRQAU2SeK3jMk0ixoOrMeKiuruKygaaZsKo/P2rCButZvI1Fv5k7HEcP8MY/vN71MpKKuaRi2x9xcX+ryIlrG8dtI21CPvSV2GkeFIdLsTJdFDI3Leoq7pum2+iwiSd1acD55ewPt6Vk32stezoIjujaQKPevPqVm9jsp0joLW0HAjZIbcfw+taMUsayJFGMn1rh7zxHKkzxqyxovy5HVqbaa+3lbPMPzf6xq5mzo5D0xZFC+9QPeRqxUct6VydtryxWYlBfDtsjHUn1P0qtqmufYFECSf6S4Bdu657fWi5PJY7WC53Phn/A1U1HTkkkd1GS3PzHFchpuuTO4Vue+D1rq4JVuYSwO84pCaszitbeNC6Kprh76FoWO7/Wtzt7gV6HqFhPNdm5I2hGyF9fY5rz7Xt8N9I8v+sY/hTjuaXLOjO7ynenmRYI+XqD2Nd9onyIu5K810jV30+5WRlWRR/C3DEe1er6RcW0tkt1GzNBJ/CRzGf8ACqlEaZ0FpIqx7qbNNDI2W2of7w/rSK8UcRV2Vvp3HrisO8njL7YZPl71F7Inl5makk01s2JYQy/3kNUrkWF4CHTJ9uG/OobXUxGvkzHMfY1Lc20JG5V+Vux6H6GiM2ndA6JmT6ZEznyZcP8A3JOD+Bqg6CBissciOPofx9xWhPCBw4Lx/wB2Tqv0NVGkcLt+eWHsT1X6Gu6nXbVmzmqYdbjJRwrBkYEdVGPzHrUVKRt6H5T0pK7EzjasLRRRTEJS0UUhCU6kpaYwopaKAEopaKACiiigAooooASiiigQUUUUAFFFFABRTqTFABRRg0uDQAyinYNGDQA2ilopiEpaKWkMSilooGNNJTzTaAEpKdRQBp0UuKMVRiJS0YpMUDCijFGKYCUtJRSAWikooAKbS0YoASiiikMKSlpKAEpKWkoASilxRigY2iiigBpptOPSmmgAptOptAxKKKSgAooptABUM86woWZgAOpPQVNiuabUF1O+nggHmsMRwJ2LE8ufYClJpIqMW2Uru7k1rW47e3ieaMn93Gv8WO5rvLJU8PW8zSmM3RAMgH8A7D61UWGz8KaVJNZxRm9dMK38R9WJ/pXKDV/KjmheQs8YEjZP+slNcNSod1KmdB4k8QP5Qt0G2YjceaybPU1t9PkKyK7W0Rfcf4pG4Fc09xLMzySOXmfuacC/l7H/ANVu3NXLa51RRciuXdPMmzinxXm98KSU7lewrKlmaTCJ27VoWbeRolyG2+ZPKqH1Cjn/AApcppc1E1o2c0c7jKx/dQ9D6VkT6rPd3MlxO+5mO4/4Csq7uGnm2q+I4+pqhLdEnGMIOgqlEiTOog1h4pBtfazcEg9F9K9A0LxKsCRxfeXGPc14vbXLK/mFs11Wi3HlTLPNKvmOfuemehNVyGTdz2O6hOo2iSOWCEfcXpXHa54YS606dioVI8uTitzRbtrj/RmnZ9o5wNoHp9afrN0k8FzbWf3YY9ryds9/rStYEeO39s9pLEtwhaNh+7l45Fdl4KuHt2jEcrPbTfK7HOBj+Rrkbv8Af/f+bbXYeD7FPs/+gPtuMhnhk7/h/UVe6Fc6rVGMJELn5esbq3X39qwbzzvtG+F9zL97tn61c1bUEjj2zQr5W7Ei94z649Pesm5uJWtQQ28D/Vzdx9fUVzzRvBluz1BZ5PLbiQdV9K1orvEfkzfPCeh7r9K5JHS8jE8a4mT7y9617S5NxDubqOv1rnnodMbM2pGZRhvmQ9GFUiiocxHKd1qvFemGXynP7tuhqWQEHcp4PpURqyTHKkmhf3bpycN2Paoab5oP7p8B+v196VY3Y/IC1exha6ktTy8TQ5dRaWntEI/+WmW7gDgUyu04GhaKKKYgpaSloAWikpaACiiigAp1Np1ABRRRQAlFFFAgooooAKKXFG2gAopcUYoASilxRigBKKXFGKAG0UtFACU2n4pNtADaKdto20ANooooAKKKKANSiiiqMRKWiigLiUtFJQO4lFLSUDCiiigBKKWkoAKKDRSGNooooASkoNJzQAUUUlAwpKWkoARqaac1NNACGm0402gYGkNKaQ0AJTaUmoZH2qTQBR128a20xliP7yQ7B/U1R8DRWsE97cPKkhSMAsOijqQD3qjNbw+IvtK3WoGztVbClRuZjj09KyXvodI0dbGykbbIzF5e7Dp07VzVZHZShbcv69qU99fl3kKBmyqjps7CueMrzXbJGpaR2yXqFZslSSS6jC5PIrXskjsohhQ0rDJJ7VySOyKJUtRCPm5boKbIvybfuZ/HinSzuz8EFu5boopsa+cflYhP4pW6t9KzuaWFWOxW3HlxTtjmSSRwMn2AqjfXjNGkSAKem1ewqbULlLePCDc3ZR2+tZs0xfyZMLuCYJA6mriiZETMolMSt+7j++3941QeXzZTt+52p9xIVBRT15NRwJgb2HB6V0RgYSkXraJFCyzNtjz6ZJrpNNl0xLiOYW12xByWaYD+lc3bRLLJl/ujtWgLtd4gj4b1HalKIKR6d4fvrZHkdN0ETAbmkbJJ9vU1uT26X+jS2lkhWPG5z0LH3Ned6Rv2BPu8qWmm/oO9elaM8P2CV0dmXn5mrFxLR5rq2mw2dykL7kd1y23Hyk/5zWv4Y+2QTxom2+RT8vzbJEHse9Zmr/bLnUTcMilpDuDL6dK1NOuo7cRvcRefboeZFXEsJ9fpQtiTf8Q6ZFqMa3SCQSqMNjhvow71xtpLJHvjjG5AdpB/hPpivRGP2izSXetyn3o5F+V65rVLK0lm+2WY3XKcMq4R2+o6Gs5G0DJZ7Zpgdhtrsf8ALROVk9iKuW0gjYP8rI/3tvQGhLSHULZzB94feVvkdT9Kpx2s0TPlg4b/AFidCD6isJq6N4PU1buLzISF6jlaZZ3JZQpOSOoPanWkjSIYpFKyJwQapToYbslDtPb3rjkjrjsaE8azLxww6VHFcfOYXP7xf1pYpdygnhqV4N8qSYwy9/WqozdOV0TVgpxsydX45p3UZFRheck08V9HTmpRuj5ypFxlZjqKKK1MhaKKKACiiigB1FFLQAlLRRQAlFLRQIKKWigBKKWigAooooAKSlpKCQooopgFFFFABRS0uKBDaKdijFADaKdijFAEdGKdikxQO43FGKdijFA7mpRS0lMxCiiigBtJTj1pKBiUUUUAFJQaWgYlJTqbQMSlpabQAUHpS0lIYyjFLSUAJRS0lACUUUUAMammntTDQMSkoooASkpabuwaBkbHArC1zUCkTwqeVTLVr3s6wws57CvPtVvZGkG0/vHO4/SolKyNKcbsraab2/u1itQu0HLF2wMVnaiSt4kBPCA9OnWt7StYXQrxSLaCX5h5nmLkE+3pWfrt3BrmvT3VlHsikYlF24x64rllqzuWxDpirJJJM33E6+59KsG7JdsHjuaryOkFutrH948vTYIkb5n+4nb+8fSspI2iy/aRmY+dLwh+6v8Ae/8ArVauZlhRWbmQ/cTsPwqskr/6xvlXsO34VVv5RFAXzmRuAT1qOXUu5n6het9o2/3eWPv6VXiuR5MrN83p9faqjqXBcng8E+tWVjMcPAy3/oNdMY2OecrjCn3Wl6Ht3NSr83zHp2HpUDZJU1Z8tiFVfqfarsY3J45GEZVPvHvWhp7SWeZE+WQj7/U1VtYC0qrjPc1vWttG0ZfBYfwgDrUsqJseF9LfUbszTsxQcnPevT9PsUSxMYGAQcVz+iWq2enQRsm2aTEjc9B2FdXA4CDArCRqYM9lE75MYyBjGKr/ANmJ128enrW1dIDNkDrTAlCjoIwvsVxYlpbJyo6tETkH1xVeeexuXEssTLKOGxw1dE8XcVg63ZZi+0RqFkU5bA61Eo6FwlZiNBHOBNHIpxwGJBNNm09ZoMyFmH94Y49qxLaS4jl32/3uuz19a04rrf8AvPu7vv46D2YdvrWDR0pkcXlO+2C5ZJE/5ZTDH5HpU19DIYxKYvnXrjkH8aS6sBcr50Zyw6MpqrZ3b2reTI0isvAArnmjogytHdxyHGSDVtbmZRwdwq3eWkFyMstuT/eb5W/Ais77Ulo/lw3AgkH94bgfxqLF8xoRSmRclGzUuaoSXl2cJMX3N9xh0NWLeTzF2tw4612UK7g7M48RQVRXLIpaaBipEAZwGOATyfSvZi7o8SSsxKKfK259yrtXoB7UymIWigUUCFooopiHUUlLQMKKKKBC0UUUhhRRRQK4UUUUCFooopiCilooAbijFOooC4lFLRQIbRRRTAKWikoAWm0tFAxKSnYpKANOilopmIlJT6bQCYlNp1GKRQ2kpaKAuJRRRQNMKbTqSgoKbTqbQAUlLSUALTadTaQxKSlpKAEpKWkoARulMNPbpUdAxKQ0tNNAAaic7cmnmql5L5a59Bn6mgaMbW7sCMoG4HWuKZnlluLmN/miTIra8RT7LZv7+a5RLkxj/abO6sZnXS2I5JCbZED5eRtzfWujl0+PTbiWVeEghTHuxGTWJpMAvtRghfdjf+g611HjedI44raDq2C7fQYrBnQjmIgXncvyT8zH09qnmu0tUA2gydl/u+9V42aC3Axl2OcGq+UhbzZD5kvYHoKm1y0zRty+37RctyegqlfXAkDSHoPlFV5LqSeUEn8KbMAUwelNRIc2RCQhCehP3R6VaRSEAxVeJPMlHoK0Quxc1qjJsSOzjmZSW8n/AH+hqy1i2/c01uqLx8r5z+FU5GJkT1qVFJ6njNMk1bBrWNyTmZzxt6D/AOvXRLd7jBbRxRxmVgNiDAxXMWKATByPlFdp4YsDdXpvH6RjCcetRItHZWsRkdSw44/Idq2UqtbRBVHFWaycS7iMM5pgUCpcUyqSFcYap3MQdGUjgir1QyJmlYLnHSacZLl4El8iY/NDITwCOx+tENzDLdtbXsbW14nyscYP/wBetPVoSpEqD5lOapanp1vrlkt0DiVQNsw4ZT6GsZRN4yNeO2t44+X/AOBKMfmKbJZ28yfNJG6+q4yK5WO91bTG2kG4X8/zHUGtS18QWt0fLudPMb/7tcs4nTCRK2mtv8ozLIh+63daxb7SjGxSRtzDp71uyG08zf8AYt3+61PS9tyDCLdYvxGfzrA2OdQSRxbMbP8AaatLTPO8smWTzc/dp8trN5m6KJSp/vNVjTreHLZm8p/7vUU0wJWpKuSWwT+INxVV0Kn2r2cPO6seLiqdpXRH3p1J3pa6zjYopaQUtMQtFFFABS0lLQAtLSUtIYUUUUEBRS0UAFFOooGNpaWlpiG0U6igQ2inUUANop1FAhtFLS0wG0lPpKBjaKfRQFyOg0/ikxQFzToooqrGFwpKWkoATFJS0tJoaYyinUlAxpFJTqQikUNopaSgYU2nU2goKSlpKACm06m0gG0Gig0wCm06m0gENR1IaZQMbTTT6YaBjWOBWXqbblq/M3y1karIsNrJJ/DGuPxoKW5w2sXMl1ePbgrgSfe9gOayVtze3UEUR+eR/LVf61Lduvkl1P70vk/Q07R5EttWim/ug7frisZHVDYv6U8dt4knVD8kMTxIfU9z+JzRrEjXl9EoBYJGM49OaxNMlYahvJySST71fvbpkyqNhn6/T0rGSNoFGSbLvJ0XOFFVCWkOR0pZeWC1I6+TGB36UJA5DrEwmfbMv/AvSrElqJopWjIBTBx6iq1iimX5q0Ibi1RypSRSeD9KszuQW8YTHHNPdzuIqx9kR3Lx3Uaqem7inLYqDl7m3Y/79NDKIiMjFmYKi9WPapo23PgDCjpU7WolYKbpGUdEiQmrdrZwRyBirMPVv8KVxWNDSbCS7aNVGEP3mr1LQ7AW0CIBwozWJ4a0tkQTuF5+6PQV2dvGEQCoZaJlUYpcUqigigGNppFPoNIRERUb9KlNRsV7kUDM+7i8xGBHWuYeSXSbs7F3xvw8Z6OO9ddJJGOrisDV1hmhYowLDmokrlxepNFYQahbie1lEkZ/gc4ZPbNVptFlV8pJKij+8obH6VzVtqV3p85lgLFONwz0rctvFYuRhLlRKOqNxXPOJ1QLsVtlfLN1/wCQyKkHh9JT5iPLK/0wKjttfEuBKyK/ZhUw1+TLR75WT8q45ROiJZfTLy3VGd41j9DTIdOsnuvMC5b+8OlULzWm+VvL+T/aNNtp4bsgJcuj/wBxh8v4EUkijamWLeUjI2jiqZDI21sFPSpPLIjDkfKeM1BIxZ+vA4r08KebidhssJjIIIZTyCKZTwx2lf4T2pm3mvRPLHUUUopiCiiigBaWkpaACloopCClop1ABRRRQIWiiimAUuKMUuKBCYoxS4oxQITFGKXFGKBjaWiimISilopk3EopaKBXCilooFcbRS0UBc0aKWirsZ3EpKdRSsNMZS0tJSaGJSUtFAxtJTqSkUmNIpKdSGkMbRS0lA0NopaSgoSkpaSgBlBooNACGm0402gBDTKeaZQAlNbpTqa3SgZVn6VgeJH2aHcZ+8f8a3JX+fnoK5fxfNs0sp/fakWtzgxuluEQZw3AFV97ByF6ZxUgkMciOOqOrfkaddbbfUZ12/LuJA+oyKxZ1Q2GWDN9sPHTk1KCZGZ39OKTSk/1jN95lxViSNY12/7YFQVcrLHvkyegqO7PRfTmre3YmagmQFSxqhCQMIE3nqajN6xc/KhHuKhlf93gtxUagE5FJjNSC8hICSQgg9RnArRhispWBiMcbHoJBkD8aw4Y8kE1c3KiVIzZ+xS/8tNRs44/RHP8gK6LTdHht3i3HczHl26Ae1cHZq95qUMaDcC3SvTLOwubh0LSLGFJFK5SOmh1Oys41TzBwOgpreLoVbbDA7+/SqC6bYxMDM+cdzU8bWoGYEUgHHSkXYsJ4iu5n+W2K1ft7+6l+8oWs5JgX+6KvQPQJo2IZC689akY4FQ23SpJOKBWK802wVhXjzSMQshFaN3LjNZErlm+9he5pAkZVzYSyn57o1Tl0dtny3TfnRqOu2VojlZGlZT0FYc3i+Lfua3ljXHWqsVYueXcafc7lkLKfl3DrmpHu/78Uazf3pIgR9D6GqQv4NStGw2M/nVW21jzsQXUXnhemfvce/esqkNDWMi//aELPtuLSKCXsYyQD71p2mpRyMELBsd81QtrS0vE8uKdWA5WOY/Mp9jQ2mT28wMaHiuCpA6oTOkVI7iPYSNrdjTLGCSym2yKZEOQp9Kp2U8iMglU49MVrod8m5Wx7HpXLtI6OhfDQogYTO5/554xUDMGOQMe1OEDyRl4xlh2HWple1mh/eKYpR1I6GvVw70PLxK0aKlFPaMo3OCvYjpRxXprU8tiUopKUUyQpcUCloELRRRQMKKWikIKdTadQIWloopgFFFFAhKWkpaYC0lOooENopaKBBRS0UybiUUtFAgopaKYhMUYpaKYBR+FFFBNzSooopmVwppFPpCKCkxlJT6bQVcbS0UlSNMSkp1JQUmNopaSpK3GHrSU+m0FIQ02nUEUDGUlPNMoGIetNNOPWmmgBDTacabQAhplPPSmUAJTT0p1NbpQMz7nqa4zxjN+6Ce+a7e4QFc1594sYvO3pnFKRpDc5lTbrG7Sly+PlVemfc1WmlaVy7dcAVIy1Ey1idSJ7GXZIPQGpFuPNLE/3s1QDFDxQkm2kI1UbecVBefIuKS2cl60dY0PULbSF1Ga3ZIWbAB649SPSgZzfLvz0qxGOKqqcVZjY7aTGWUlCL0yaSSUsMetJHEzjOM1LbyPBOGXGQO4zUjNrwVbeZrPnfwxIW/E9K6jWdfSwjVIX+ZcfnWVoVzFp+my3ToA0h4A74pE0S4v53u7iFo0Y8LSsaIhuvEV1dW6y4ZV/wBo1oSJqFhY21xFdbvPTftUdPrUs2jxzW7wup29mxSQ6ZMm1NzMq8DdniumNNWuYTrSua+h6tdSuiX0BjVvuy9mrsIQeDWHuaewis4bfhUwGc4/EV0NpE6WsaygbwBkg1hNWZvTm2i/bHirEv3KpRNtarBfcntWQ2Yt6/7zArmfFFxJbWkNuh/12ST7V012n7+oL/R7bUokM4YlRxg4qluSzzZ54Rpy2VtakyvKGmkfB3ew9K3bLTLS60mUSxqTnAzVyXw1FDNuiDfnUb2b28SoC+0dq6eeFjJwm2cFPY3Nnel7Mlo1bBA9M1BdGWC8Eo+VlP6V2D2rb/lj27jXM6t8l/Pu7NWU2mawTjuWILoSgkHBHO09K37DUpfLCE7l/utXI24Dncpwy1dS7WI5kcg+1cdSmdNOR3lpLFPxsKN6GtFIsEAdK4jTr9S4Mepoo/uOcV0UFzeO/wAl7a7P+ugrz502mdsZaG+luY7gTRE5FPuoWDCRfuv1+tQWEzm3ZnmVv92popJGR8/MNwPzV34fY4MTEYUZMK4xkZH0ptOcpIxkBOTxg02vShseXIKWiirM2LS0lLQIWlpKWkIKdSAUtABRRS0ALRS0UxBRS0UAJS0UUxBRS0UCEopaKYgop1FBI2inUUybhRS0VQhKKWjFAhKKdS4oJuXqKXBpKozTCiiikykxMUhFOpMUirjKSn02gdxKSlpKktCGkp1NoGhKaRTyKbUlJjDRS0lBSEptLRTGMNNp5plAwNNpxpDSAaaYaeaYaAG1G5qSon60DIJfuGvPfFIxcyL6PXoUv3DXnvinm6c+r0pGsNznHtpPJEuxwh6MRwfxquyGvonwxFpWq+DbTTbiEG2liUle6n61xvjT4WyaVbNqGlM09sPvpt+ZRXNzHY4nj0g+ap9N0y81a/js7GB5p5PuqoqSSwma6WFFy7sFVe5Jr6H8D+DrfwtpKEoDfyqDM552n0FKUhcupzXhX4Yx6N5d5q7LPeKcrCPux/4muk1TTree2aKVAyMMFSOMVuXUp3kseayJ3aeTavSo5jeMDyWw+G4uLmSW6kZYPMOyNeuO2TUvizSrHRtHFjaxRxySOM924Ndj4i8RW+jwGONQZyOFFeZX93NqN0087FiTwPSqUgcbENrat9mYVQZdsmK3Im/clF9KypI/Lc7vWi5m1qd7oGlrJpNu4jVm966ELKm2Pyt1VvBm2bR4vYV0/kUjeOxjmOU7VjtfqScCpFsJXlDvtVe4Fa6wVNHAKLsHFPoVLezCkECrwiIWp44gO1TeWKTbZDVigylTmnI+eKluF2g1UVsGkJIrXq/NU1uMx0XS7o92KWx+aOmDQ2a3Rh05qhJbcdM1sSLxiqrpTLiYM9puzwK8y8RfLq1wnrivX7lAEJFeO+JXDa9cqD0xTCWxjxyyROOa1IbhJhiWNSfXoaw3lZTyM1JHfOvRRU2Moy1Ns2Udwf3TFD2DCtPQdHmub5baWdUQ/wAR5FZuiXdncNLFeuVcgGL0z7/pXW6Zaxz28hMbRzqAyHcDke2K56kTqhUOq0/R4rCJoopRJJnHzZzWg5SOJoA37yX7x28AegrN0G3eeI3cztvUFRnPOKmmm23BRffk1kqnLKxU4OY0oUPI4oBzUkjOY1JOVY9himxhxC2U+UnG416VKomjyqtNp6i0lFIpzW9znaHilFIKUUEBTgKQU6gApaSloAWilopiFooooAWilopiG0UtFMQUU6igTCiloqiQopaKQgpKWimSFLilxS0yWNop2KMVRDY3FLinYox70WJuXaKWimTcTFJT6bSGmNpaKKRaY2kp1FSUmRmkpx6UlFikxtFLTaVikBpppTQaQ0xp6UynmmUFpiUhp1JQO42mVJSUDGU2nmmmgYw0w9aeaYaAGmon61KajYZFA0V5fuGvNvE0ub0j/aLV6Ldy+VGa8l1S7NzfO2cjPFTI1hueh/DnV2e2Ni0mPKOV+hr27SZ47ix8uXDHG1ge9fMXg2+Fn4ghDNtWQbc19BaVe+WivnPrXDU92Vz1F71Oxy1r8PIrDx/NdtHm0i/ewA+pNd2wwpNaSGHUIdynEmODVC6QxxspHIqJSIj5nN3wNzcmNeV/irmvFGr/ANl2/wBntBmQjlv7ta2pXktnbsIkLTOSAa8/8RT/AGKzkac5lkGASeaIm17HE3+oSXV7JLM5Zye9JDMHGO9ZUrkyE+tTWjkSjnrWiI5jehPNQ3URc7gOBUkJ7+3FLeSiGNVPVutMh7nafD66CxvbseDylegqK8x8Lf6P9lkXoSc16dG2VBpGkNiQLmpUTFCLU6LTKYqJipQooVeKfigxbMq7fMmBVdRk1PcJ+9asWTUJvtDItu/ljgMe9SXHY3LgRfZDiqOmSBnZRWXPcztGVTO49K0dGheMIXxuxkmmTI03TP1qrIlaDLVaVeM0wjIyLw7YmzXheu3GfEV2/wDDuxXt2rPstn+leDai32nULqRf+ehoCb0H+VHcJwcN61XazlVuBkeoqurOvQkVetb2SLGcN7GmZD7SNI51d/8Ax5sCu70X+0NVdIYfLjT+8vNYMV7pdwE3whZa6LRtbgsnXymXaOcLgZrKoaQOtt5JNItzDNcK7kYbHSqlw73ZItplB/iFVNavlvGhW2izLIPwGe9bFtYRR26AhfPWPkLXHODbujrjNJal7S9OuI7JDe8IGOO+aaY/3DJvbfuzUcV5cRweQjuU6jc26mTBZjulZ2z1G7ArppKaWhzVXCW7IZJkV/KQh5O4U5x9akRMChI40UBEAFPrsp827OCpyr4QFKKSlFbHMKKKKdQAU6m06gB1FFFMQUtJS0ALRRRTELRRS0yWFFFFNEsKWiiglsKWilqhBilxS0UENiUU6gVRLYUU6jFMzbEop2KMUyHIu4pKfSUhJkdLS0hFIpMbSU+koLTG0lLRSZSY3FJT6aRSLTGGm08immhotDabT6SpKQ2kxTqbRYpDaSnGm1JQ2kpTRTAaetNpx602gYw9aaakPWozQMY1Rt0qVqik4XNIDi/Hmr/Y7ZLOJv3s3B/3a87TJGa0vF96114guMnJjIQU99OFlofnT/65mGFqJHRAzFleKRZEOGU5Br2nwT4qh1a1WFn2XEYAZSevvXibc1JYahcaZfJdW7lXQ9j1rGUeZHTTqOLPqa2uWjcMrcdxW9FLHfQ7WwHxwa858K+IINY02KYMNxAB9j3rrIJ2iYEHiuZxsdEkpK5ma9prREnHU5U14v47uS80St1PI/SvpOK4gvojBMind1yOtcj4j+FOl6wrSwStFKM7VPK0R0I5rbnzG3WnxEq4Ir0bX/hPrOmMzxW5mi7NF8351xEml3EFwY3jKsvXIxWqYXL9qyrEZHOEUZJrIur57m58wcIOAKmumkcLCPlReo9aqtAR0piO38PXfNv/AHFNerWkm9AfavAtI1A2UwDk7a9g8P6iLi2Q7sg1JrBnXR1aWqUEm4D1q4lK42TCnE8UwdKXNMxbIJrdJDkjmq01rH5X3atTzLCu5zxWDfasDwrYFAR5nsWVs4iM4qaJBGcAYrmZNX2SY3MQKv2OrJMQrN1oNHTn1N8PUUp+U1GkoYcHNQXUhWMnNBimcx4rvfs+n3D57GvFLVvOnmBPzSEkV3vxC1Mi1Fuj/fPNee2h8u5jc1QpSFIG5l700Rk9BzUl6vk3TH3p9u+WDKeaYhbSVo5MGr81wu1X8sEUwxBxuC/OOoqRJo3hkjdACRSepVy1Z64kDpIEkEkZ+RvNPA9MV6noupw3tsL9OWPytj37V4b0J9q7zwDqRZprFjw2CoNTKCK5mehOiiNNpOTSLR/B97kcULW9NaHLUeotLSUvetTnkFKKKWgkKdSCloAUUtApaAHUUUUxCUtLRQA7tRRRTEJS0UUyGFLQBRTRLYUuKWloEJilApcU/FUQ2JSUtFNEMKUClFLTIY2nAUUvaqRlJhRilxRVGTkXKKWipHcZRS0YpGiY09KbT6b3pFISm06m0FpiUGlpKVi0NNNqSm0i0xlJTqSkykNNJTqbUlDDTakNMoLQ2m0+m0DGnrTakPWmd6BjaYakPWozQMa1VrnPkvjrg4qy1V5WHT2oEeHa4CfEF5/10reluLXVPLmeQiGP/liOu73qn4iton1+5NsQ65+ZgeAfT8Kxw7RP8rMB3AOMis2dcPhRb1F2ubt5QhXPaqDKQeRXb6YmlahpIgtYwgH+sU/eDe9c9q+mtaSYxwTwagZseA9aNhqP2V2xHJyPY17fp16LmMDOSBXzHG7wzpKhwynIr2rw5qhn0y2uY3zuUZ471m4nRFnoasyn5TWhbajJHhXOR71j20yzwo4PUVaFYuJpp1OkgvIpRjI57GsTXvA+i6+jM8IinPSSMYNRo5U8HFXra9dSATkVL90hx7HjfiT4Walp5eS3j+0xf3l4NcJNpMsEjRyQyKw6givrSKZZVw2DntWXq/hTR9ZVvtFsoc9HXginGZPMfJV1aNG2QCK6TwjrktlOts7Exk9+1ema78ITh5dPuPNP/PN+teZ6h4bvdHvSJInjIPXFVcpM9c0+7WRAQwINbUT5Uc15p4e1dlRYpm/Gu8tbjdGOaDVmoGPrVG+1SGxBMrgVZRty5qC8sbe8QeYgJFFzM4rWPFBeQrArMfUdKxvtSyLumnIPoq5NdPfaQgypi+WqS6dHGOg/KqsejSguXQ5u8uAYibbzXfHG4bRSadcaizJ+5UMT/erbn0+PP3c/hVvSNOzPvI+VTkUWKnDS7Z01vuSBA/3sc1m6xd+VAwB5xWjK+xCa878b62LSzdVb94/AoPLluefeI9QbUtXZgcxocLVS8gaCGFqrQZd13cknmtO+ZJlSL+JRmrM2N1KISQwyjuBmqEB2ScHitZlzYoG7Cs5odnNIEbFhsZst0x2p08KOm5B2x9RVbT45PLMsf3U61ZuAU5TO3uKk0MaWIxZ963vBTmPxFb/3WyDVG4jWSNSK2/CGmt/ayS/wohP4mh6iPTKelN24wPQU4da6YKyOOo9R1LSUtUZMWlpKWgQ6lFJThQAUtApaAFoopaYgp1IBS0CCiiiqE2FOpAKWggWilopolhTqKWqJCilooM2IOtPFNFOqiGFFLRTRDYUtFOxVIxkxMUYpcUuKswbL3FNp1JUFpjKKUikoNExpppp5pppGiYw0lPxSVJohlBp1NoLTEptPptSWhp60hp1NoLGmkNPNNNTYpDDSGnGkNSUR0hpxFIaZQ0imHrT6aetAxp60w08immgCN+RXHeKdZlS4i0bTn/02bh5B/wAsl9a6XVLk2Gk3NwDueKPIz61xPgrS3u3vtXu/3kxkCrnsepoKiXLHwpZ2to0flySPIPnkPBJ9q4++0FrG8ME7bVb/AFcmOD7e1etjis7U9Kg1GExyjGehx0qZI1izyHzLrTLwSwu0UqHkA8Eeh9RXUxXEPiPSSQQl1H96OqWo6fJFK+nX5/eAZtrgjqPQ+1ZOgyS23iC1UfKTJscH071kakN1bPbyFWUgivSPBD7vDFv7EisPxRpQFqbqMfdPIxUfgzWY7VW0+ZioZgYs9Ae4pMcWesaTeeWfKY9ema2xc1xKzbsYOH7Gta01IECOU4cd/WsWbnVxyq4GDUynmsS2ugSMGtSKYMBSGaKTMpBBxWhb3ZIAY1jK4xWNrni7TtAG2eXdN1ES9fx9KlxuS0d35yAZJrD1tdB1O2eC+MTE/wAWORXlc3j291iRo0cQxj+FDz+dXLK3mm/eyHGe5p8pNjL1Lw3Pp9082nut1bA8bD8w+orW0vUSVXJww4INa1uYEGwSLu7jNU9V03cftVp/rQPnUfxf/XqdjZG9bThlBB4q4rA1y2m6krIFY4I4IrehnDAc1QizLAsy4ZQRWbJosbOTuataN8044oGpNbGJ/YkSt1Jqb7PHBGAigVoN1qldtgUwc5PqY+qXiwQMSegrwrxTqrajqjgNlENd54818WkD28bfvn4HPQeteU/eO4nJPeqSMmyzbKTwo5qdVCTsWOWzUSuYosr1PekV+Mk81ZBoS3C+QIx1JpJRugTPUiqZYlhVsN5iDsBSZSH2skkKLCjYVmyR61bupvLkAU5OORjoa3tK8OyGw+1qis7DGWIAFc7qdtNaXZjmXa/X61Bp0J9OC3M8ay/Km75q73RtIghnM0c/7tlzt9DmuQ0Sy3BS4+9Xb6TB9klFt95GBZWoJlsbK0tNHBIp1dS2OKW44UtIKWmZi04daQU6gBwpwpopwpgKKKBRQIKcOlNpw6UALRRRTQhaKUUUEsKKKdTJuJS0lPHSqRDAU6kFLQQ2FLRS1Rm2GKWiimQ2LRTqKtGUmNp4opapGMmFFLRVmMmX6ZT6SoLTGUhp3eg1JoiM02nGkNI1Q2ig0UjRDDSU402kaISkPSloqWWhtNIp1JQXcbSGlNJ2qWUmIaaacaaaRaGGmmpDTDQO4w00080w0DTEppp1NNAyjqlqb3Tbm2H3pIyB9a5PwfOLae705+HYiZPcYwf1FdwRXKa5oEguVv7FjHKjbgR0BPUH2NIqJvEEU1ulZ2lawt9CY5wYruPh4m6j3+lWLq5WGJnZwqqMkntQWZHiOyt7rS5DcDHl/OrjqprgPDNrLqXiJbl+VjbfIT3rX1jU73xBKNPsonZXOOB1rodK0iPRLQW4w0rANIR6moaLUie9Mb2rwuNwcYxXmF+BFeyqvADHFeg63dJaW25TmaQ7Y07sa85vkkjuXSX7+eahlxOx8NeInuQLOdszKuUY9wK7G2uo5QA5wfWvI9K1RtKneVYlk3rtwTit+18YxeYBNA0Q/vK24fyqbG0ZHqFtcvA4O7cldBa3qsgO6uA03VormJWjkDqfes3xnrsun6ULS1l2vcnqDyFHWs2iuY0fF/xNkidrHR5RleHmHP5V53bG91a/2iV5Z5OrMck1kF88nrVy21Ga2QxxsEDHLEDk1fKQ5nfWP2fw+qK8bz3R5AxnJ/ya0v7VupcPdSeUh/5ZL/jXEN4kn+yCN5i34c/nWRdavPcE/OQPrRyi5j0u68Z21gMFh/upyaSy+JGnvKEcSJ/tMOK4HSvDmp63IDDEyxnrI4wK76w8DaVZoBcxCeXuckVm4jUie61KySRdQglKRynJXGRWtpmvQyKAsyk/Wud1PSJLUPGu57R8eX/0zNZ0Vi8ZBUgH1BpWLUj1e11IMBk1fW5Vhwa8utZbuIgCYlfetGPUruPo5osO53z3ChfeuS8SeIFsrWRkYFgDWbLqd5L8pc1iarC00Pzck0Aeb6leT6neyXM7Esx6Z6VVUfNzVq6i8q6kTHAPFVicNWiM2W/LDRLVaUPG20gj0pRMcYzVqO7JTZLGJE/WmIpq7ZrX04l5o96jYp596oyRQMN8bFf9lhU9tKFOHlCgd6TGnqdi19/o22IABfur2JrIh0+61G9mluMscd6z4NSZJP8AW8V22iriwhMg++27dU2NWx1jaRoIFI2SBdtdnolhbTBkaX96Vyhb19Kxns1ni8xD86t8rCr8kE1oLd/4mUMrVVjG5YZdkjK33gcGlqS5dJJEdR8xTLH1NR1vHY557jhS0gpaZkOWnUL0ooAcKcKQUopgLRRRQIcBS0dqWgQUlLRTQmFLRS0CClpKdTIGinijFLTRLCnUgp1MhhS0lLVGbClooqjJjqd2ptOqkYyYlKKAKUVojGTFopaBVGE2XaQ06kxUFpjaSnEU3FQbRZGaDSmkpGyGGkNOIpCKRomNpDTxTKRomIaKKKTLQ09KSlpKC0hpptOPSmmpZSENNNPPSmmpLQlNpaSkUhhpppxpppjQh6VGalpjdaBkZqJ6lNRuKQzntb06GeDzFUpIvIkQ7SvvXOG3vLl1bU53NkDtEyrjI9WFdtfxGSJUHR2Ab6VBdwLLC1gFCiQfvW/up3/E0ikyK106002ILbQquRknufxqldzLCks8p4HNbEyqoAUYAGAK5y+U39/BYgZjzvlPsO1Isp21oZ5hqd0MvJkwoTwi1xfiNdusz/71dzr+rw6VAQirJcsP3cfYf4V5tdSzzzNNOxZ2OSTUtGsSuTgUkbZNNc9qI1+cVmWXrLULqwuA8ErIfY8Vc1vVm1WWF9u3bHg/WopLOOTY6P8AJL/q2/un+6aourRsUcYYUAJSE8UUlUTceiGQ13GgaXp9rCs06x3EpHfpXF2/DV2mkaNfzIrf6pP9qkFzpJddNrD+6ARR2FZEnjOQS4x+tdBBo1mYxHdPn/aFYGqeAHmcyaVepKf+ecvB/A1mzRGpaeI4ryMI+Cp4cE1aW0T7yHch5BrzG6sdU0O5IuYJoGB+9j5T9DXa+E/EEN6os7g4kP3c0ijoEth6U/7KPSrscY7VJsqWUjM+zDPSq15b5hJI6VtNEDVW7h/csaAPH9ej8nU2/wBqsZvvGui8Ux7b5awPlT5mGatEMfBbGQ5Y7V9TU7RWi/6uZg1VJJWfpwKiyfU1RJbaQ9CQwqW3SOV8Mvy1RQnNX7YZGKBmrYWVhLMP3+z/AGWWu5stOiihR7Sfy2IwyfwtXnETmC6Xf6811+n6gnlKrHKH9KQzuNGbDGKXazGtDUkf7NbonzKsvy/TvXNadPC8qMJPKjHJkb7x9hXY3Um8wOibUjX5t3X2FZTqlqBmmMr19SKUdaoHU8SnzUYgn76jP6VchminGYpA3t3H4V1U5Jo5KsXclFSCmCnitDFjlpaKKBDhS0gpaBBTh1pKUdaAHUUUtAhKWilxTEFFLS4oJYYp1GKdTJExRS4oHWmiGLRS0VSRmwooopkMWlApe1LVGTClpRRVoxkAopaKtGEhadSCnVaOeTLdFOpCKzNUNptONJSNYjSKaRTzTahm8Rhppp5FNNI0Q2md6kptI0Q2iiikzRDaSlpKGWhppp6080hqWWNptOpKkpDDSGnGm0DQyg0pFIaCxtMYVJTWGRSAgNI3SnHrTaBkUnCkbN1VYIBAGJffI/32Pf2+lX8VXkXax96Q0UNQlEUQfP0rGfytMtDey8MEZ5M/xE9B/StK5H2q8jiB/dw/O/17CsDxzJjRCP8Ans4Wgu5y1hBL4i1qaedyFYl3YjO1B0A9Koa7GqSxMqhQ4LBQOgzgV1eiWzWvhaSVRte6fk99tct4kkDaoIQMCGMIfryahmkTGSNpZdqqzMeAFGSTWzYaFcTXXlRyIki8OTyFPcfWpPDiy/aJRbRBrhgFRifudcn610esOPDehxeRgXDnAY8nJ6mlYswr3QdTgQiZhNF38vvWbfpKEHnxsJF/jP8AEKqSaneytukuXZvXNQvczyjDyMw9zRYAqzZ2ct9crBCBuPUk4AHrVUHipFldAQrEA9cUiTs7W70Hw1EANl7fD70mMqP92qN144v5yfKjVR2J5rlySeTzV3StOfUb1IU+UfxN6CgZPJ4j1STP78r/ALtOg1HW5Pnie5b/AHVNdvaaR4f0uIH7OJ5v78v9B0rTj1sIuyCIBOwQYqGi7nF2/jPVbOMW+oxC5g6PFcIcEUk9nEyrq+guRChzJAT88J9PcV3ckcGrxm31CwWRD3YfMv0NcDcxXPg7xBhJCYXO72dD2NDRSPUNOmaazgkkGHZAWHoavZFc7HrFvF5YH+rdQ6EHsa0YtUt2QMXHNZM0Ro4qvd/6hqbHqNq7bfNUH3NF4wNuSCCD3FSM8n8Vj/ThXPrGZEbaMkDOK6fxQobUFHrXMeYYbv5exrVGbINjE9MCl8urdyBkYGCRk1XPFUSIFAqZJDG2R0qEtxShs0DRqPB58Syr1HWtXR0eSExufu1i2kjIMk/Ke1a+nXCQvJz8v3ty1JaO90C503T2T7Wfn3Dy/lzzV291i4vBIbeLyolbo/3jXG6dcrv85yGkdvlb+7XSW90sML7vmk55Hv6Dua55x1uaRY6KQsgEigGmSIhOQDn1qLcc5FKSSOauN0RKzLlpqk0EoWbDxf3j1Wt9TkAg5BGa42U1e0nVjasIZjmE9D/drphUb0ZzVKXVHUClApFIIBBBB5BHenVscwopR1pKcOtAC0UUtAgpaKWmIKKKWgQU6iloJYDrTqaOtOpkCUtFFNEsdRRRVozYU4daSnUEMWlpKWrMmOFFAoqkYSClpKWtEYTHiigUVaOWRfptOpKxNkMpKfTaDaI2mGn00ipZtEaaaacaaak2Q2m08U2kaxGUppaQ0mWN70hpe9IaTKQ2ilopGg09DTKfTKkpCGmmnGmmgYlNNOo7Uixh60006mmgCsetLQ3WigYlQzvtUt6VMelVbpd0QX+84FA0U7W3KRZb778mub+IEX/EihkH8Ey12O0Ba5Pxz++8PvFH/AVlb/ZApFIijvLWx0G2VmBk8oYjByf/AK1cSNs+ozzsPnCvKfbArs/DtrayaJBLHGpd49rseSSPeuajtX0jVZ0v4mWKUGPd2x/kVLNok/he6trOOS4nB3lsAAVj+Jtf/tm7RIs+RDkKT/ET1P6Uuv6xAc6fpi7LcZDuOrmufAwKQCilxQOlG6pGPpaaDT1oAQCus05Y9F09Z5eLiUZx6Cufsmiil82Ubtgyq9iaknupr6bcep6CgDUj1CbUbzYpIFdlp5t7RUQt8687qyNB0SSK2DeQTK461uw6Fdud/lmoZaNWHV1+6gDfhVTXtNsvE1gIZiIbuMboX9/Q+1WIdNhtsNNNHGfdqtiHTJvk+1xs3+yeazLPNWhu7a3jtZUKz2xKbT3Hbn86spPdpGCoO76V0viu3FraxzzIXCNguvdT6/lXPw3aMMJSZSYkXibULSQLPAssY65GK1oPEGnalGIopmtbg/wvwM02ylLR/MAee4qPU9GstRtyWhVJR92RODQO5y+syM9+fM4YN0rHgt/N1Jv7q/MamnFyl5JBcMWaPgE9cUlrwlzIPvBMD6k1SEyvzKzP2J4qpId0laUyCC346ms3GB71SIGk4GKfCu5gKiPJq9p1ndz3ANpzInz+mMdyaYBksNqdqsQM8SkHjIwabLD5Llt++Q8ykDAz7Uq4cKW5FIpG7p0chgEg+5nrXV20RMS7hzWX4d+zytHbqPOWLPmr2wOtdFb4+yeefv7hWMy0OSGOH55fm28+X3P1qtJJuZnbvTpX6n86qyOWPFJMGhJGzUNS7C1MZCDVGZraLqxtyLWYkx9EPpXUds15+Ritrw/fyLdC0kbMb8R+xreE9bGFSn1Onp9IBilrc5wpaSloELTqbSimAUtJS0EMdS0lLQJgOtOpo606mQFOFNpwqiWLSjrSUvemiGO7UUdqKaMmFLSUtUjNjhRQKKtGEhe9OpvenVojnkOFFAoq0c0i7RRRWTN0JTadTaRrEbSGnU00jaI00w08001JrEbSU4U2pNoiUhp1IaRYymmn001JSG0UUUGiEplPpKVxkZpDTjTTSZYhpDTjTTSAaabTmptBSIJFwaQVMy5qPZQMYRVeccRH0lFWiKr3IxCD/dcN+RoGIRWbqlrHIpeRN0LxmKUAchT3rUxk1XvZoba2ee4lSGGPl3c4AFBSPMdK1T/hFLi+sL0M8afNFj+L0Fc1q+u32sTFrmdigPyxg4Cj0q/4p1uDWtS32sQWCJdiuR80nPU+nsK58pUM2iNHSjNLtoxUDEJpmacRSYoAkXpUq1ApxxViJGkkVEGWY4A96AJYIZbiZIIY3kkc4VVGSTXoug+E4NK23Opssl0OVhTkJ9fU1k2V3Z+GYCsAEmoEYklHYegrMvfE13PkK3lg9dvegD0DUPFdlp8DBGRm7IK5tvEer61k27fZbVSQZCf6d64Z5HmYs7Ek+tSS3szoIg7CMds1LRSZ1g1LRbKYtNLcX8mfvSE7fyp0PjJIJgLaxgiUdCiha4wZxz1rS03Q9S1Iq1vbPsP8bDApWKuemab4ia5AjuNjow5Uiman4Ztr2P7VpKJBc8kxA4ST2HpWFp2h6haAfaFAK9cc5rprKSdBtPQetS0NM4WPUDZXDJOSkoOHRu1bUOoieIAECrPjrSY9Q0salBEPtlvjzCBy6ev4V5gLiQLhXYD0zU2KudBfGOfVJJM9qyLaXyvNQ/xMKptPKTyxpUJJyTVJCZo6kNgRD6ZrMbmrNyxlmU548sYqEpVWERKmWFdHbIIdIKWz/O3+s29/Yn0rCjXmtC3f/RnDvtTcPlXq1ICOeV3GHOT6/wBKQHEMf+7TGOTVi1hNwEjX7wGKllo6nwhex2ZuXkj2IkD7/V3PCj8TW7b3JkhMYR964X5vXvWHBb/YdPWLH7xmV5G9x0ArTs4775v77tu2stYzZqoEslxJGceS2G71JDA8nz4ro9N0yd7eVpoVC7Q2w859wahuLdIY1kjGVIyR6VKYpRsZksMce3GenP1qs8eeRVmeRdpd3VUUck1hS3V1f5Fkvlw/x3D9Poo71qZC3t/BZttclpDwqIMkmksWuI76G5O5ZPMHlxAZINFjpn+lLHZRS3V7McAnk59fYV6L4d8D/YpUvdSkL3anMaoeIz/U1RJPRWtfW/nRtJsCzR/6zHRh61k10xldHNUg4vUWiilrRGQ6iiigTFp1Np1BAUtJS0CYtLSU6mQwpaSlqlsSxaUdaSlHWmjNi0tJS1RlIWiiimiGOFL3pBS96tGEhwooFFaI55DhRRRVo5pl2iiismdCEpDS0hpGsRKYafTDUm0RDTDTzTDUmyEFJSikpGkRKSlNJQWgqOn0ypaNEhKDS0lIobSU6kNIYymmnnrTaRSG0mKdRSKQwimEVLim4PXHA5P0oKIzTkhd/uozfRa1bCxhuRDOg8yGT++uP0rUEMa2yBQR+99felc1jTdjm4dPkn3EMo2/eU/eFQXNg6yeVjca6y2ij/fypGu6Rzub1xxVXUrbfGJlba6VPMX7M8y8Y61f+GbJZYLESb+PPY/Kh9Md68j1TX9T1ty1/dPKmciPoq/QCve77SUnWYpBHKJjmaGUkrL7c157qHgG01G7Uab/AKK3mDzbeXkbf9k/0o5h+zPN+tIa9J1fwDp1xJNa6QZbe9iA2RTPkTH0yehrz+0029u9TGmxQN9rLbPLbjDelQ2NaFXFGK09V0DU9Gx9utWjU9HHzKfxHFZgNADSKaRWgdK1D7Ab/wCxz/ZB/wAttny//qqhmgBo4qaNyrBlOCDkGr2h6LLrl8baKVI9qF2ZhnAHtT9W0qPSp0ijuhcBgfmCFcH0oAptI7nLMSabmiprS0nvZ1igjZ3bsKAIu1OhheeVY41LOxwAOpNdXaeB3dQbzUIYc/wLy1dDp/hbT7BMwzmSbGA5PIpMaMvRvDcVqEmulEtx1CNyqf411cMoVQuAMdh0qmbDaeGLfWp0DoQrAY7cVDkOJqQv5nBPHera20TfNWdHMwwAKvwSEg9MD3xWbZoLPplveW0tvMuY5VKsD6GvCtW06XTNUuLSRcGNyoPqPWvfVkwK8w+I8af8JHDIB80kI3H1xRGQzhQKfGp7CrNzavDkPGUcdQRjFRWsvkTBiMitBE9okUkjeccKFNQwqJJcMjOo5IU4yKW/MYum8r/VnpU1lNChAJ25HJNMRLKZJhtVBHGvSNOgquUKnirBvITNiNd1OMLTnIXHbHrQCKiI8kgVRkmrSwvBJlsgg11OjaYml2hvpQrSopb6Vz8zvO7PIfmc5qGWjY0zVZfOjVvmUdjXoNkI7ry2MW8f0rzjSIozcJHjfur13RtMUaYJZJE+dvk+griqxOqnLSxo2EfmW7wI/wDyz+9XLaw10s4t7eH+HaWbgf8A1xXWQNBbXDsWBVo+lZ02i6prdzvhjSK36CSRuceoHephoxzV0cVLpsaHztTuvOb+GFVwg+g6t+NbGn+FNR1d0kmxY2n+0Bux/sr2rvrLwpp+iyxzMPtUrcGWTqv0HQVtyW+yuw5jF0rQrLRoFjs4grD7z9Sx9zWoy74mI/1i80qrhsdq4zxl8QrTwtOtvahbm96so6IPf39qBHQ3NwLWMTqoYtwVPeuec7nZsAAnOB2pwv31CGO5Y8SqHwOgyM0yumktDmxE03YWlopa1OUWlpKWmAlOptOoJHUUUUCFpaSlpkMBSikFKKpEMcKO9Ao700QxaWkpaoykLRRRTRmxwooFFWjGSF70Ud6KtGEkOpaSlrRHPNF6iilrFm6QhoFFJUmsUNNMNPNMNI2ihDTD1p5pnekaoKbTqSkaRGmkp1JQWhtNNPNNNSWJSUtFIoZQaWkNJlDDTacabSGFJS0hpFIKktpVhuUd/uZw30NR008igpHQtdw2b2lvJIqs0gWNP7w9v0pbi9t7K233NxFDGrbt0jbRXmfi/VpfDdl/a1nbrJfPIESeQ7hD7hT3NeN6lrGpavO01/ezXDMc/O2RUnXGWh7lf/FTQ9Ml2QX7S+XKxaKBA4kBPqeBWdcfG7TGXbHpF24Oc5kVcV4hilqWiuY9Mn+KVhP5aN4cLRQsGiU3BBUjv92qWp/EHT9UkEkmhTRuv3DFeMuPrhea4CilYm51sfjmSK8ju1sz50f3W84/yxV+Hxb4bk1ZdXu9CnW/D790M2FLetcHSZpWEdfL49v01O4ktUT7BMxP2Ocb1GetPXWPB2s4Or6O2mzH/lpacp+IrjaDzQB6HqPjPR7M2MWmtJeQxoYZVZNiPF6YPesb/hLdO0sf8SDRUgkf70twd7L7CuUwKaaAOnTxzObgTXOl2ckg+68Y8ts/UVjarrMusX7XM0UcQPRUGAP8azSKBQBaFPikeNtyOynplTioU6VtadrFtYRqDpVvO4/jk60AUvtU/wDz2f8A76rRsdaubXHz71/WteHxbYf8tdDtP+AqP8K1LbW/DF5/rdNijf8A3B/SgaK9lr0tymArge7Vt28yuN3mc+hNSxWmkTw7rXy1z0ANMazEPUfSsmXEtRynocH6Vdgl5HNZCnYepxVuCUA9KzaKNSScItclrf8AZP2tLu4d/tsX+rXdwRXShhIMY/A1wvxE07yo7S/QccxSfXqv9aI72GZF9cJeNOzn95Icis3TfLS8h+1RK8WcOD6VmxXDpMrMT+dauxHwwrdIRN4k0iCwnWeyl82ylPyHOSp9DWCfauw+1RyeHrnT3XLSMrRnGcEVhPpgVcgk0hFCJthUrXRaOjzTieZuE+6tZCWLg/dratbm3srfdI/7zHCjrSGaWr37JpbqMqnCgetc3b+ZeTCJGUEjjNJqGpfa7lCUXy4zlUPQ/Wt648UW+pRweVo1tZvGuzdFzkD60mikyK2iaylUwyFmBG1vXNen6Dp+qyoIbopZwqMnfkkk9sdqy/BE3h6+kCX7W6zrkqsvyZPbBrtbi2jk8x7SfZc8Rsu7O73Fc9VG8GXINL23cRhKyKq4ZpPut7e1dPaW0yRkhNjD+EtlT9PSsTTtSstBt1h1O4jjRu8nBJ+lb0GoWpXzLaYPEecA9PfNZxQpzeyHN8wKSIQfQ0x7iC2gLXUqxov8bnArD1vx9oGnRPm5E06ceXGec14x4w8cX/iGUoCYbT+GNT1+vrWiZlc3/iL8SZSz6Xok4SLGHuI+CfYeleQTTmSQyOWLHqSc0ty5MzZPU5qqzEmumMSZSPd/Cdx9q8K6dL38oKfqOK2K5T4cSmTwhCD/AAyyAfTNdXW8djjn8Vx4paQUtUZhS0lLTELS0lLQSFLSUtAhaWkpaZDFFApBSiqIY6kopaCWhaWkpaozaFoooqkZNC0tJS1SM5IXvTqbTqtGEkFLSUVZhJGhRRSVibpBSdqdTe1BokMNNNKaQ1JqkIaQ9KWmUmaJCUUtFI0sBphp9NpFoSkpaKC0iM0hpxpKRaQlIaWkqRjTTTTjSUDGUjU7vSGkUhtJTqSkMwvFdh/aPhbUINm5xEXQf7Q5/pXgLDBr6WlAaGVSMgoQR+FfN10uy5lX0YikbRIN3vSE009aWpLHClFIKUUgFooooAKKKKYCUw9afTSKAGGm0+mmlcZJHUyDJqCM81YWkBcisHnH7qWMt/dJxUh0jUEG8QMyj+JOapgE10GmTXUYXa7bfQmgDNtpru1kACyAjtXU6ZqlwyKsuf8AgXerkUyyKN6Jn6U4wRl94VfyqGaWLQkDgMetWIXxVJRirCHaoqGhmnBJgg1F4h08ax4dubYAF9u6P/eHNMgetG3fI2noagZ4C6tHIyMMMpwRVu0uWX5SeK3PHOjf2brkk0S4guf3i+x7iuXUlTkV0R2JZuR3ihsH86sx6lCfkdMD+8KwBJkc9akR6GgudFM0SQM27kj5MdzWCzEsSxyxqyJ0MEYBdXV8cjI2+oqG8CC4by3Dr/eHelYdyu571etP9Sv41QfpV2z/ANUKLCuWJWyin0NaGn6jcRR/uppVZTkYc1mMVZ5Y/wARUlgxDlTUSRcXY0ptVu7qUzTzySP/AHnYk1ci8Y6zaWE1lb3rR28vVR29hWW0DSZEJDMOWTODj2pbDSLnUVlZPlCdNwxmocEacxX+1PI53P16kmtu30SW4smWX5ZEcFGXkMMCrWieGktibi+2vIOBGOV/H1roFhRIvLUBR6AU4xsRKR594jtfs18rjpIufxrEzXaeMLbOmLMBzHIBn2NcXWqMnqet/C5s+Gpl/u3DfyFduetcF8KWzoV4vpcf0Fd6etax2Oee46lpKWqMhadTe9OpgFFLSUiWhaBRQKBC0opKKZLFFKKBRVXJYU6m0tUS0PooFFCM2hwpKKKtENC0UUUIykhaKKKtGUkLRRRWhhKJpUUUViapDabTjTKRokIaaacaDQapDTSUppKlmiQlFOptItDaSnGkoLQ2kNKetIaksaelJTqbTKQlJS0lSAlFFLSLEphFPppoGRmmmnmm0ANZcqR6givnHWIHttYu4X6pKwr6Pryz4leGmRxrVuv7snZOAPuns1Jo0izzTFOpMU6oZqhopRSClFAhaWkpaYBRS0UANopaKAGMKYaewppFS0Mav3qtJVVfvVZSkM09NiWSUM/QV0kEMefl5NcvaS+U3XituzndSHQ8Uho2FQdRnNTLIyiq8bOy5LZNWEXjkkH2qSiVZPWpgarhfc1InFSxl2J8ACr8EnbvWSp5q7A2CDmoaGQeKtLXVfD1xtG6eEeZGPX1FeMV7/EQwIPIPBFeOeLdL/snxDcQquInO+M+oNaQethMxwKcCRSCitDMsRvmum0LSLDxJvspb9bS+Vd0W9SQ1cpGSDXoHw0udDsrm91DVQv2i2UGAu+Bz7d6ATOV1Hw9qemTtFcWsoVWIEgQ7WA7g96pW8gQ4PSvfdW1oxeEzqemKLxJQ0qI3zYxwSvp9K8AlkEs7yBQodi2AOMk0FJksoYP5idKu2ESXRf96qSKMhT/ABfSqUPmOwRVLZ7Ctez0a4dxMF2Ffepki0zRi0i3vJBufy3X73vXWW9v5MCoI8AVgWsdz9raa52szDHy10MEsOzaU5rKRoh4QDpS7atx2Nw0CTiJvLkzsY9G+lWrPRrq7DMsTiND87hScfhUXAx/FHh25h0KUOUZbiHchU57Zrx+vqHTtIM2mSWc8yXVrjEUkZOYz3BGK+f/ABp4bn8NeIpraRR5TnfEw6EVcZESidl8Kf8AkDX4/wCnn+ld+eteefCiQNY6pH3WZX/Aj/6xr0I9a6o7HJPccKdTRTqozHilpBS0CCiiigQUopKBQQLS0lLTBoWkooqiWhaWiihENDqdUdPpktBS0UVVyWhaSilp3M5IKKSiqTMpIdS02lq0zOUTSppag9KbWZSQ4mm0tNpGkUIaSlNJSNUgpKdRSKsJTKdTaDRBSUtIaRSGnrSU402pKCk7UtJQMZ3pKeRTD1pFoWkoooGIaQ0ppDQMaabTjTaQCEVDNDHcW8kEyB4pF2upGQRU9RmgDxHxv4S/4R25juLdi9nOxCgjmNv7prk69/8AFekrrXh25tNoMoHmRn0IrwJl20mjaMhlAooFIY6ikpaAFopKM0ALRSZpaAGmmsKcaa1JjGqPmq7ZwLcTrG8yQqerv0FUxnNTxI0jBVGSe2aQHUQaRomMSawH/wBxcfzrVg0/To4v9Gut3+81ch/Y2pfw2j/8BYVat9I1dMbbWVfxFIpHUpEqf8tkqTKj/loKyYo7mADzm2v/ALuTV6PeR/CP+A1BRcRhn2qUbWHBNVo+uDU4yvSkMlWrMB4xuqqtSrUsZpwzAYGa5v4gaYL3SY9QjTMlucMf9k//AKq2EbmrhiW9sZrWQZWWMoQaEB4eBRWhc6ZNbzvEy8oxU8VB9kfPStjIiFWIX2OGUcj9aclo5q5b6a0nagLHdfD/AMSwWDvYXT7bSYllbGSjen0Ncx4q0uwi8RTDR5VktpCXCbs7CTyuav2GhfuyGIKsCDxVqbw3JYyCRIwSvagaKOlac0YUqOe5roo4FVeetJBAI1GBxU9ZtmiGiJfSpFUClWjpWbKTNXT9au7CW1ZX3x25ysT8rz14r1Kw8U6LLaJILqOJj95GGGU+9eM78Ub6mwz0qfxdp0GpeXDDmAnDvHxk+uO9Yfj3Q7fxhoymzdPOhJaOY/d/3W9M+tciJcGrdnqlzYTia2fa3Qjsw9DRYdzB+G0M2n6rq1ldRtHMFT5T7Fv8a9GrOSfSrzVTqQU2t9JH5cij7kmP8/rWj3rrpy0OOruOFPHWmjpS1ZiPpabTqYCiilFJQSJS0UUCaClpKWmIKWikoJHUlFLTTE0FOplLmrTJaH5pabSg0ENC0CkoqiWh1JSUtMzaClpO1FNMhxNHNNooqRqIUUlFJmiQhoNBooKFoopKkoSm0p60lBYUhpTSGpKQhpKWkoKEoopaCkhtNYU+mUDQ2ilpKQwpKdSGkMjNNNPIpppDGGmmnmmmgBvevFfiDoR0vXXnhTFtckuuOx7ivaqxfFOiLr2hzWvHmqN8Rx0YUyos+fzQKkmieGV43GGUkEHsaZUmgUtJS0AFJRRQAtBooNACUhFLQaABRUi9KYoqUdKQyVLmaH/VSuv0NaFrq999zzmZfc1nRxmRsdq0rW1RetIZrQ3LzDO9lq9DJngtk1nxIoAA4FWk+X7vSpaKTLynBzUm8HoaqoxYVICR0x+IqWhplpHwMZNSo5qorcVKje9RYZcVuc1et5MEVmIatwtg4pjKer6fE1/9o28SD8z3qkdMtm/5ZDNdJcRi5tOB8y8is0RgCgDNGjwH+CnjS0T7iCtEcVKrpigCXRmigl8udflfHzehrqREFJDDpXJjaTkV0WnXf2m2KH/WRgZ9xUMDCvbb7HePAB+6cboz/SqhBU4Nb+pWwv7FnQ7Z48mPv8w7VhbxNCJQMZ6j0NFxjd2Ka0lR7s0hpgOLk0m80zNJuoEP3n1pfMNQFqb5gFFgLgmNb+jamJGFtM3zn7hPf2rlPNpyTYYEEgjoaa3JlFNHo1LVLS79dQs1l6SD5XHv61drqWxySVmOp9Mp9MQUUUtAgooooAKKWkpktBRRRQKwU6m0UyWh1JSU7NCYmgp1NoqrktDqXNNzRmnclodRmmZpc0XJaHZpN1NzSZFO5PKaVFFFAWClpKWkVYDSGg9KQ0ikgooooKSEPWkpSeabUlWCg0UGkWkJSUtJQNIKKKKBjaQinUlAxKSlpKQxtJTqbSGhDTSKeabigYhpppxppoGRkc001JTGFAjyX4leHxaX41WAfublsSAD7r//AF/6VwFfRt/YwajZTWlygeKVSpBFeB65o8+h6tNY3A+ZDlT/AHl7GgtMzqM0UUigooooAWg0UGgBKQ0tIaYEkS7mAyB9avLYsy58xPzqlD1qwrFTkGpGaFvYN2kXNWfskydxWYk8i96tw38g4bkUAaCRzKvIyPap0LjGSOaofa/MGOlTwzBTzzUMpGnGeOCKfvZeuKqxuM5xVkFSM0mUiZWjPAb6ipo8VVG33FSocd6kZeWpEbFQLIpFPU0gNW0kyPLP8VUZPkcrUkLlWBHUU2+5ui/97mpGR5pKZu5pd1AChypqxa3rQTBgcVUJptAHTyTorsQeD/OsK5CwXjBD+6l5H17irEUpktwP4gODVe/JmsndBgp8wHvSGV2Uo3tTC3NNE/mwqQe1RM+KoRNvqNnFQmTtn6k9qjMgHTketAiUvTC1QmTmmGSqAmL0ByKrtJUbTGkB1Hhu/wDI1BY2bCS4Q/XtXcjrXkNvcMsoOcEcj616tYXP2yyhuOu9AT9e9awlpYxqRvqWqWkpa0MApaSloAdRRRTEJRmlpKYmFFFFAgooooAKKKKBWDNOzSUlArXHZozTaKYrC5pM0lJTuKw7NJmkpKLj5TVoptFMzsOopKKVx2E60popKQ0gopKKRdgopKKB2FpaSigoKSlpKQwpKWkoASkp1NoYxrUlK1JSGFJS0lMaENJSmkoAYabTjTaQwNMNONNNAxpFcz4x8NRa9pZkVf8ATIAWiYDlvUGunprc0AfNUiNHIyMMMpwRTa9U8d+DTeFtV06MeeATPGo+/wC4968tZSvWkWNooopAFFFFAC0lLRTAfF1NSg1BH1NS0ASg08GoQacGoAtxvVuJ8VlByDxVqGbPBpWKTNiKWrccnY1kRS44q/FKNo+XOahlJl5XB4qVG7VVjP8AFU4PcflUtDLkZyKnQ1Uif8KtxFcVIy0h5p16MW6SHtwaiFOuWJ0+XP8ADyKTQyj5y5605ZAR1FUhIoGc5p6TL6UWEWi+aaWqEvTS+adgNCyuAr7SeDV9nBtQGXoxX8K5yKVlmFbsQEk21mABjzz7f/rosBhbzFJNET9xzj6dqY09Le4TVMn7kifqKqTSYc1QErTknimtK1U2nA780z7QfWkIuGSmGSqxuKaZc0DLPm+9RtJz1qEtt71G0gJoEWo5PmHNel+Drw3Gj+UWz5L4x6Z//VXlKyYOa7/4e3G/7bD3AVx+oqokz1R3NLSd6WtkcwUUUUAOpabTqYgooooASiiigAooooELRSUUAFFFFArBRTaKY7BRSUhoCwu6m5pKbSHY2KKbS1RhYWikopDsFFFFBVgpKXFGKQ7CUUtFMdgopKWkMSiiikAlJS0lAwpKWkoGIelNp56Uw0AFJS000DQGkpTSUDEPWmmnHrTTQMYaaacaSgCNqbTmpDQAleceNfBKlX1TS4/m6zQjv7ivRSKSkUj5vYYNNr1Lxh4GF1v1DS4/33WSEfxe4968ukieOQo4KsDgg0DEooopALRRRTAOQcipAajpwOKAJKM0lFMBc1LGxFRU9KALaS4rSt5cgCsYHmrttLxioaKTNmNvepkP8WapwNkDJq2rKOKlopMtRtVyE1nJItW4ZE96loaZor0p03/HlP8A7hqOM5FSS/8AHrKP9hv5VLKOaRt3KGpo5MferMFwR9/5mp/2s/3aYjTM/vTDNVD7RR51Ai35+yRWxW5ZOkklvk5zx+FcjdXBjRWA71t6ZcK4tWB5D07AQa83kyxP/ddlrKnm3BWB5NaniflJPVZN1c9NJm3VulFiR7SkDrURuKqGUn3pm8+tVYZe8+jz6oeY1HmNTsIv/aDSefVHzDR5jUrDL6y89a7r4bPu1S7GekQ/nXnCyEGvRfhgN19ev6RqP1NBDPS+9LSUVsjFi0UlLSAWlptLTELRRRmgBKKKKB2FopKKBNBRSUUCsLmjNJRQOwuaTNFJQFhDTaU9aSgqwlGKKbSA16KOKOKoxsFLRRSHYKKKKB2EooopDFopKWmAlFFFIAooooASiiigaQlFFLQUNPSm049KbQAlNNOooAbSUtFAxh60hpT1pDQAmKQinUlAETCmYqVqb2oAjNNpxptADT1rjvFPgmDWt9zZIIL0DPH3ZPY/412J60w80DPnq9sLnT7hoLqMxyKcEGq1e7634dstdtwlymJF+5IByteN6/ok2g6o1rKyuCAyOvQikNMzqWkpaRQlJTqKYhR0pc0ylB5oAeDTwaYDTwaYD81LC5DVXp6nBqWNGzDLwOatCTiseKQ7etWBOwHWk0CZf841YgucdTWR559aUXBB60rFHV2t1yATWh5ilG6EbTXFR6k6Eck1tW+oE6ZcT4ztU/yqXEpM58uuc03zhWeLgml86lyiuXxLTvOrPE1L53FXYm5YuJ9yYrU0ufZDC38O6udeUnvWpaTf6LGlFh3LmvXe8SfNncawpJs2u3vmrWovuQD3rMb7tVYm4m6m7jRRSANxo3GiigAzRmkoqrAKGIr1/wCF9qyaJdXT8maUbT6gD/69eQpG0rqiDLMdoHqa+hdDso9L0W2s0ULsQZx61LQGietLmmdacOlWZi0UtJSELRS0UwCiiigBKKWigBKKWigBKKKKAEooooAM0bqZRQMCaSlNJQA2kpaSgZr0UUUzIKWkpaQBRRRQAUtJRQMWiiigBKKKKACiiigoSiiigBKKKKBiUdqWkoAbSUtJQAlFFFACGmnpTqQ0gG0lLSUAMam09qbQBEaYalYc1GaAGHrTKeetMpgFePfECwuLfX2uZF/dzqGRu3AwRXsJrj/iHYfavDLzgfNbOr++Dwf5/pSGjyKnU0UUix9JSZpc0gFIpB1pQaUrmmIXFLTMstLupgPpw60wGnA4oAsI2BS+ZUQagmgCbzDTPMOaZmml6QEpkNTrfsmmzQA43kflVAsajLkigoNxpNxpuaM0gHbzS7zTKB1oAeSa07V/3C1lVoQcQiqsSMunLtVJz2qedutVqAFooopDCiiigAoorT0LQ7rX9SSztV68vIRkIvqaAOi+HOgtfat/aM6Zt7blc/xSen4V68OKq6bp9vpWnQ2VsgWOMenJPqatUyR4pR0pBSjpTELS0lLQIWlpKKAFopKKACiiigBKKKKAEooooAKKbRQAUUlJmgBxptLmkoGNpKWkoGa9LTaWggWiiigBaKSigBaKSigBaKKKACiiigAooooGFJS0lAwooooEFJS0lIBD1pDSnrSGgBKSlpKAG0lLSUANooooGNNNp5ppoAYelRmpTUZoAjNMNSGmGgCNqzNds21DQb61QAvJEQoPr1FahGaj6GkSfPDIyMVYYYHBFNrsPHug/wBm6mL2BMW9ySTjs/cVx9BqJijOKWigADUeZSYpuDQBJvozTOaQMRQBKGpwaos0oagCYNil31Dupd1AEpamF6YWppagBxYmm5opaQCUtJS0wEooopiHDrV9P9SKpQpvcVcf5UAFAFOVtzYqOnN9402gBaKKKkY2lopaYh0cbyyBEXLNwo9TXuHg7w8nh/R1Vwpu5wHmYdvQfhzXCfDnQP7Q1JtRmx5NqQVUjqxzj8sV65jAxQMWlpKKogcKUU2loEOopAaWgBaKSigBaKKSgAooooAKKbRQAuaM0maM0DCkopKACiikoAKKKKAEpKWkoGalOptOoJFpaSigBaKKKACloooAWiiikAUUlLSEFFJS02AUlFJSGJRS0UwCkoptABRRRQAlJS0lACUlLSUAJTadTaBgaaacaaaAGmoz1qQ1GetAEZpppxppoAYajbpUhqNqAOb8Z6VPrGhNDbIHuI3EiqTjdgHI/WvHriCS3maKVGR1OCGGCDX0ERXmHxE1SKS//s0WarLEAxuCfmORwB7fWkUmcRRRRQMSilooASkpaKAG03NPpKAEzRmlopAFFLRQAUtJS0AFFJRTAWkopaBFq3TC7qWZ+DUkKfuagn6VQEBPNJRRUjEooooEFPjjaVwiDLNwB6mmV0ngfTBqfim2VxuihzK49hQB634b0lNF0O3tQBv2gyH1bvWtQBxRTEFFJS0xC0UlLQIWlBptFAx+aM02ikFhc0ZpKSgB2aM02imAuaKbRQAUUUUAFFFFACUUUUAJRRRQAUlLQaBmmKUUgpRQSPooopALRSUtABS0lFABRRRQAZpaSigBaSikoAWikooASiiigBtOoooGNop2KbQAhpDSmkNMBKbTqSpASm06m0wEpDS0hoAYajNSGozQAw009acaaetADTTDTzTDQAwjFeUfEi7M2vx2/lqPJiHzjq27n8vSvWa4H4m2MbWFpeqn7xHMbNnsef6UDR5lRQRRikUFLRS0ANopaSgBKKWigBKKWigBKKWlpAJRS0UAFJS0UwEqSJC7gVHWjZQ5XcaYiXaI4sVmzPlsVpz8L+FZDHLGmAUUUVIxKUUlKKACvSfhXZELfX7D7wES+3XP9PyrzYda9j+Hlt5HhgNtwZJCaAOwHSlpF+7S0yBKKWigBaKKKAFoptLSEJRRRVDFopKKAFopKKACiiigBKKKKACiiigBKKKKACiiigAoNFBoA1BRSUtIQuTTs0ynUALRSUUALS0lFAC0UUUAFFFJQAUUUlABRRRQMKKSikFhaSiigBabS0lAAaQ0ppDTAaaSg0UAJTadTaAG0hpaQ0gENRtTzTGoAjNNPWnGmnrTAaaYaeaaaAGnpXO+L2sf+EduF1AExtgIVGWD9iK6I9KytatYLzSLqOeBZlWNnCnjkDIOaBnhRpMUv+cUUDExRilooAKSlpaQxKKWigBKKWloAbRS0UxBRRRSGFFFFACjqK2bRMRCsm3XzJkHauhgQJavJjpQBmX74XAPJrKPWr9+fnFUabAKSlpKSAKBRQKBBivePCtv9m8MWKFdrGMEivD7OBrq6igT70jhR+Jr6Et4lgtooVGAihQB7UwJx0FOpo6U6gkSlpKKQDqKKKYBRRRQAlFFFMAooooAKKKKACkoooAKKKKACiiigBKKKKACiiigBaSlpKQGlS0lLQAtKKQUo60ALRRRQAUUUUALRSUUCsLRRmjNACUUUUDCiiikAUlFNoAfTaKSmAtFJRQAUlFJQAlJRSUgFptDU2gANMNKaQ0ANamGnNTDQA0009acaaetACGmmg0GgBtcv44vPsnhqdY5vJlkYIvuO4FdRXnfxOkGywj/AI8u22mM84PWlpMc0UDFpaKKACkp1JSGFFJiloASlpKWmIKKKKACiiikMKKKKALVin78+wrdb5NPP+1gVj6cnzufatq9+S2hT8aok5y7YtO3pVepJm3St9aZQxiUUUVIBS0lL3oGbvg21+2eKLKIjID7j9BXuVeTfDS18zXnuMf6qMnPpXrFMkfS0lLQISlpKKQDqWm0tAC0UUUwCiiigBKKWkoAKKKKYCUlLSUAFFFFABRRRQAUUUUAFFFFACmmmnGmmkBp0tJS0AFOHWm04daACiiikAtFJS0AJRRS0AJRRRQAUUUUhhRTaKYDiaSikpiFzSUlFAC0lFJQAUUUlABTaUmmE5pABNNJp1JQA2mmn000ARE80hpTTTQAhqM1IaZQAh60hpT1ppoAp6nef2fplzd4z5SFsGvE9Z1e41q/N1cbQ2AqqowFA6V6p431CKx8MXKvy1wPKQe57143TGNooopDCiiimAUUUUAFBpKdSGJRRRTELRRTqBjabTqSkAUnelo70AzU07ov1rS1Q4C/7KVn6cOI/rVjWJOJKoRgN1oobrRUsYUlLS0AJigdaKB1oEel/C6P5L6X3C16GetcH8ME/wCJddN/t13lMB9FFFBIZopKWkMKdTaKAHUZptLTAdRSUUCFoozRmgAoozRmgBKSlpKAEopaSgAooopgFLSUtIAooooASkNB6UlAGpRSUtAC0tJRQAtFJRQA6ikB4paQBRTaKBjqKZmigBaSiimAtFFFAgopKDQAUUUUAFJS0lADaKKSkAE5ptBpKYBSUUlIYhNMJpxqM0AJSUtJQIRjTaVqbTADTCM081keINWGj6NPeHHC7Y/dz0oA808dauNT1vyY2JgtRsUZ4LdzXLU+Ry8jOxyxOSaZQMbRRRSGFFFFMB1FFFADaKKKACiiigBadTaKQwpKWkoAKKKKYjb01eI/rTNXbIl+uKs6YP3kP1qnq332/wB81QGSaSlNFSwCiiigAooopAep/DI/8Sy7H/TSu7rz74YH/Q7of7Veg0AKDS02imIdRRRQAtFJS5oAKKKKAFopKKQC0tNooAWikpKYDqKSigQtFJRQAUUUlAC0tNpaACim0UABpKU0lMDUooopALS0lFAC0UlFAC0UUUAFFFFABRRRQAUUlFABRRSUALSGiigAoopKACkJopppDDNJmkzSUALSUUlAgNJS02gYjGmUrU2gBKSlNNoARqSikoEKa8o+IOs/bNTGnxNmG2+97t/9avQfEWqpo+iz3bHDD5UHqx6V4Y0jzTSSyNl3YsSaAGGkoakplC0UmKMUAPoptFADqKbRQAUUUUAFFFFABRRRQAUlLSUAFFFFAHQ2fyNH9Kz9RPzj/eq7Yuj43/3Koagfn/GmgKBopDRSAWikpaAFooooA9C+F03z3cX+yDXpdeSfDabyvETxf34jXrdABRSUUCFooooAKcOlNpR0oAWlzSUUALRSUUAFFFFAC0UUUCEoptFAxaXNNooEOzRmkzRmgB1FNooASiiimAUUlFAGpRSUtIYUtJS0AFFFFAC0UUUCCiiigAopKKAFooooASkoooGFLTaSgBaKSikMDTSaUmm0xBQaKDQISkopKQxKQmlNMJoADTTSmmmgBKaetLTaACkpa4vxf4wTTEksLPa90ylWfP8Aqwf60COU8da8dU1RrSJv9Ftm28H7zdzXJ0EksSTknmigobTqbTqYDaKU9aSgAooooAKKKKACiiigAp1Np1ABRRRQAU2nU2gAooooAlSV4zlWIpksrSMSabSUAJRRRQAUtJS0gFooooA3vB1x9m8VWT/3jt/Ovb6+ebOZre8hlzhkkUivoKGTzYI5B/GKAH0UlFMQtFFFIQuaWm0tABRRRTGJRRRQAUuaSloAXJpM0UUwEooopAFFFFAC0tJRQIWikpc0AJSUUUwEooooA06WkopDHUUlFAC0UlLQAtLTaKAFopKKAFopKSgBaKSigYUUlFABRRTaAHU2ikoAKSlpKQhKSlNJTAKSikpANNNJpTSGgBKDRSGgBKbTqjkdY0LscKoySewoAyPE+sroeizXOf3rDZEvcseleIyyvNI0kjFnY5JPUmt7xh4gOu6qTFkWkXEQPf1P8q52gBDSUp6UlMYUZoooAXqKSlHSloAbRTqKAG0U6igBtFOooAQCloooAbRRRQApNJRRQAUUUUAJRRSUAFFFJQAtLSUtIAooooAf1GR1Fe7eH7n7ToVnJ/0zFeEKecV638Pr37ToPkf88GK0wOv4oopRQISlzSUVIC5ozSUUwFooopgFFFFABRRRTAKKKKACikopAOopKKBBRSUUwFpabRSAWkoopgFFFFAGnRTaKQx1LTQaWgBaKSigBaKSigBaKSigAooooAKKKKACim0UDFJpKKSgAooopCA0hoNIaAEpKKSgBCaSikoAQ0lFIaACkpaaaAFrzbx34p3s2k2UhG04mkU8N7Vs+NfFQ0m3Nlan/SpVILD+AV5GWZmLMSWPJJoAQkk802nU2mMKKKKAHUUU2gB1NoooAdRRRQAUUUUAFFFFABRRRQA2iiigAooooAKKKQ0AFJS0UgEpKWkoAWlpKKAFooooAUda7L4ean9k1prV2+S4XgdtwrjB1qxa3L2l1HPGcOhyKYH0HSiqGkX6alpdvdIch0BP1q+KRIUUlFAC0UlFAxaM0UUwFzRmkooAXNJS0lAgopaSgYUUtJQIKWm0UAFFFFMAooooAKWkooAWikooA0qKSlpAFFJRQMWikooAWikooAWim0UAOpKSigB+TSZNNooGLRSUUALRSUUCCikpKQATSZoNNJoAUmmE0ZpuaADNGaaTSZoAcTSE0hNNzzQA89KxvEWuw6FprXLMGmYYiQfxGtWWQKhJP1rxbxbrp1vVmkVs28XyRfT1/GgDHvbyW+u5Lidy8khySar0UUAFFNp1MYUUUUAFNp1NoAKKKdQAUU2igB1FNooAdTaKKAHCim06gAptOptABRRRQAUhpaKQCUUUUAFJRSUwFopKWkAUUUUAFLmkozQB6H8Oda2s2lytwfmjzXpINfPdjePY3sU6EgoR+Ve5aPqKalp0NwjZ3Lz9aBGlmkzSZpM0AOopuaM0APopM0ZpgLRSZozQA6ikzRmgBc0maSkoAkzTc0UlAhaM0maTNAD6KTNGaACijNJmgBc0lGaM0wHZozSZozSA0KWkooAWikooAWkopKBi0UlFAC0ZpKKAFzRmm0UDHZozTaM0ALRTc0ZoAWikzRmgAzSZpC1JuoAKTNFJQICaaTQTTKQDiabSUlAC00mjNQ3NzHa28k8hwkaljQBx3j7XmtbVdPt2xJMDvYHovpXl5Oav6xqUmqalPdyZzI2cegrPoAbRRRQMKM0UUwFzRmkooAKKKKACiiigAopKKAHUlFFIYUUlFMQtKDSUUAFFFFABSUtJQAtFFFIYlFJRTEFJS0UhhRRS0AJRRSUxBRRSUgFr0H4d6tskk0+RuD80ef1rz6tDSL19O1K3ukOCjc/SgD3jNLUUMgmhWVfusMipM0CHZNGTTc0ZoAKKTNGaYDs0ZpuaM0AOzS5pmaXNADs0ZpuaM0AOzS5pmaXNIQtFJmjNMB9FMzRmgBaSjNJmgB9FMzRmmBJRTM0ZpAadFJRQAtGaSigB2aTNJSUDHZozTaKAFopuaM0DHUU2igBaM03JoyaAFopM03NAD6aTSZpM0ALSUmaQmgQuaTNMJpM0AKTSZozTSaQC00mgmmlqADPNcX8QtV+zaXHZRt81w3zY/uiuzJzXjfjG/a/1+Xn5IiEWgDn80hNNpaYwooooAKKSigBaKSloAKKKKACkopKAHUUUUxhRRRSAKKKKQBSUtFABRRRTEJSUtJQAUUUUAFFFFACUUUUAFLSUUALRRRSGNooooEFKp60lKKYHsHgfVDfeH4o3bMkGIz/Sumry34d6h5GrSWrn5Zl4H+0OlepUgCikzRmmIWikzRmgBaKTNGaAFopM0ZoAWikzRmgBaXNNzRmgB2aXNMzRmgB9FJRQIWkopKACikopgLRSUUAalFNopDHUU2igB2RRTKWgB1FNooGFFJRQAtFJRQAUUmaM0AFFJmjNAC5pKM0lACE00mgmm0AFGaSjNAhCaaTQTSUgEJpM0UmaAK2pT/ZdOnmzjYhOa8LnmMsrOxyzHJr1fx1dG38OuqthpTt/CvIaAFopKKChaKKKYhKKWigBKKWigAooopDCm06koAWiiimAUUUUgCkpaKQCUUUUwCiiimIKSlpKACiiigApKKKACiiigAooopALSUtJSGJRRRTEFFFFMDS0G6FlrFvcMcKrDNe5o29Aa+fYyQ4r2zw1dm80K2lZstsGaANU9aQHFKetJQIdRTQcUuaAFopM0ZoAdRSUUwFopKKQC0UlFAC0UlFAC0ZpKWmIWikooAKKKKACiiigDQpaKKRQUUUUxBRSUUhi0UlFAC0lFJQAtJRSUALSUlFAC0U3JoyaAAmkzSUmaAAmm5oJppNAh2aM03JpM0AITTc0E0maQATTS1BptAHD/EW5/wBFtYP9otXnFdr8Q5P+JnBH/ciH6muOoAbRSGlpFCUUUUxBRRSUAFFFFABRRRTAKKKKQwpaSigBaKSigBaSiigAopKWgAooooAKKSigBabS0UgEooopiCilopDEpKdSUAFFFJQAtFJRQAlFNoHWmIlT7wr1D4e3fnaE8RPzxSYIry0V3Xw2uAL29tyeXRWX8M/40AekZozTaKYhaKM0ZoAXNGaTNLmgAzRmjNGaADNGaM0ZpgGaWkzS0AFFFFABRRRQIXJo3UlFADsijIptFADqKKKANGikopDFopKKAFoptFAxaKSigBaSikoEFFNpKAHZozTc0ZoAM0UmaM0AFJmikoAKSim0AFNJpaaaAEJphNKTTTSATNJmkpKAPNfiH/yGl/65LXI12PxEH/Ezgb1iA/WuOoAbRRRQUFFJRQAUUUUCCkoooAWkopKAFpaSloGJRRRQAUUlFABRRRTEFFFFIBaKSikMWiiigAooooAKKKKACiikoAKKKKAEooooAKKKKQDKUdadTe9MY+ui8E3P2fxJCM/61Stc5WjoEv2fX7KT/poKaEe25pajU8CnbqZI6im7qdQAUuaSigBc0uabRQA7NGabS5pgLmlpKKAFopKKAFopKKAFzS02loELmjNJRQAuaM0lFAGlRSUUihaKSigQtFJRQMKKbRQIdkU2kooAWkopKACkpKKAFozSUlAC0hNBNNoASkzRSUABNNJoJppNIBSaYTSmmk0AJSUGmGgZwHxD/wCPi1/3TXD13HxB/wBdan2NcOetABSGg0tAxKK1vD+hXHiHUxZwME+UszkZCgVc8S+EbzwzNCJ3WWGYZjlUYBI6gjsaAsc7RXY+E/AN74otpLlZkt4FOFdhncfTFZHiLw5e+GtRazvVG7G5WXow9RQFjFpMU40lIBtFFLTEJRS0lABRS0UDEopaKAEopaKAEopaSkAtFJRQAtFJRQAtFFFABRRSUAFFFFIAooooASiiigAooptAwpe9LSd6ACrFq7JdxOvBVwRUFKhKtTA91t38y3jf2FS1Q0ifz9Lt5P7yCr1UQLT6jpQ2KAJM0ZpmaM0AOpaZRQA+ikBooEOopKKYx2aM02igB1FNzS0CFopKKAFooooAXNGaSigDSoptFIY6im0UAOptFFABSUUUAFJRSUALSUUlABRRSUALSUZptACUlFJQAUlFJSAQmkNIaQ0AFNJoNITQA0mmE04000xnDfEFcizb/erg69A+IQ/0WyP+2/8AIV5/3pAJS0le4W2gaff+EILAQRFXtxsfbgh8cHNA0cp8KZ4k1S7t2OJZIxs9wM5/pXUfEoQ/8IoPN+/5y+WfevI0a40u/wB0bNFcQPjIPIIq9rnibUtf8n7fKrCEYVUXaPcn34oKPYPhdPBJ4NjijYeZDKwkXuM9K5z4zS2xbS4wubgq5J/2cgAfzrz7RPEmp+Hroz6dcbCwwysMq31FVdU1a+1m9e71CczTNxk9AOwFAFSC1mup1hgjaSRjgKoySam1DS77SphDfWstvIRkLIpUmvUfg3pFs/23VpBuniIij4+7kZJrZ+L9tC/haGeRR5kcoVGxyAeo/lQI8INFKQM0YFAhKSnUUAJRRRSAKKKKACiiigAooooAKKKKACiiigAooooAKKKKQCUUUmaAFopM0ZoAQ0tFGKBjaKdTaACiilxQITvUi0zFPWmB694al8zQrY/7IrXrC8Jf8i5B9TW4OlMQ+lptLTEPoptLQIWlpKKAFopKKAH0ZptFAEmaM02igBc0ZpKSgB2aM02imA6lptFADs0ZptFAGjRSUUhi0tNpc0ALSUmaKAFopKKACkoNJTAWkopKQCZpM0NSUAGaTNLSUAFJRSUAJTaU02kAGkNBpDQA00ylPWkNMBDTTSmmmgZyXjtPM0yF/wC45/WvOT1r1nXrYXdjPbMM5Q4+teTkUgEr0Twn47tbLT47DU98axDEcoGRj0Ned0lIZr3sraprVxJbxsxnmJRRyTk13Oj/AAsaWJZ9XuvKDciGL7wHue1Xfhl4fhjsDrM8e64lbEO7+FB3/H+leg7dxplHDz/C7RHjxBdXcTYxliHGfXHFcdrHw51jTlaW22X0A6mL7w/4D1r2kpihUzTKPEfBvi248IX8u+AzW8nyyxZwQR3HvTfGfja68VzRq0Qt7SIfJEDnn1Jr0jxj4Ottc0+SeBEjv4gSjgY3+x9a8NkBV2U5BUkEH1pCaI6KKKCAooooASiiikAUlFJQAtFJRQAtFGaM0gFopKWgAooooAKKKKACkpaKBiUlSRxvK21FLH0FbNj4R1a+KlINiH+JzigDCpQM16BYfDWR2DXVwQD2UV0tn8PtMtyG8ve3q1K5XKeOrCz/AHVJ+lWY9Kvpf9XaSn/gNe5W/hixixi3Tiry6WicIiAemKVw5TwmLw1qkw+W0kH1qUeD9XI/492r3VbEL/AlO+yL/cSi4cp4K3hPV0P/AB7Map3el3lkf31tIi+pFfQMtnE6kMgrLutOUZZASPSi4cp4LUkUbSyKiDLMdoHqa9H1nwpZXRaSOMRSnuvANQaP4PSyvFuZJN4UcDHeqTE4nQ6PaGx0qC3P8KjP1rRFMUYGKWqM2OzS0ylpgPopKWgBc0uabRQA/NFNpaAFopKWgBaKSigBwNLTaXNAC0UmaWgAozRRTAXNGaSigDQopKKBhS5pKKkBc0ZpKKYC5ozTc0ZFMAzSE0hNJQA8mmk0maM0ABNNzQTSVIC5ozSZpM0wAmmk0hNJmgAJpM0hNITQApNITQSKaTQAhNNJpSaaaACkpCaQ8An0FAFORDJIc9c1ymu+DmcSXVgPmJ3NF/hXZQKGOTWjFAGHIrGUtTeMdDwSRGikKOCGBwQabjmvatZ8GWGtR7yPKuO0idfxrzzV/A2raWzOIjcRD+OMf0pqRDid38PvFVrc6bDpNw6xXEK7Y88Bx/jXe7lHU18zAsjd1YH8RWh/buqiLyv7QuNnoXNaIZ9B/b7UNgToce9TRzxSDKupHsa+anu7h3LPPIxPUk04X94nCXUyj2c0wPbPG3iy20LSpY7eVXvZl2oufu+pNeEuxZixOSTk052ZyWdizepNRGkSFFLSUEhRRRQAlFFFIBtNp1NpDCikpaAHUU2igB1FNooAdRSZozQAtKM03NdDoHhq41WVXKlIvU8UBYybSxub6TZCm6ux0jwE8+Hujk/3RXb6R4ftrGEIqCuigt0RRgColI0UTC0zwrY2aDZEMj2reiso0UAKB9KtJGBTwAKi5aiRLCoHSnbAKk70UrlDAooIqTFGKLjI8U3FTYppWi4FaReapyrjPoa0HU4qrMnFFwMG+h+U4+tVrd90WO4rUu4ztP0rIh+SV196qG5lUWhZzS5puaTNbmA/NLmmZpc0wH07IqPNGaBEmaM1HuozQBJRmmZpQ1AD80uaZupc0AOzRmm5pc0AOzRmm5pc0wHUU3NGaAJMmjJpmaM0APyaMmm5ozQBpUV5F/wkGpf8/wBc/wDf3/61H/CQal/z/XP/AH8/+tSua8h62TzRzXkJ8Qal/wA/tz/38/8ArUv/AAkGpD/l/uf+/poE4HrvNHNeRf8ACQal/wA/9z/39b/Gj/hIdSx/x/3P/f1v8aBOJ63zSV5H/wAJBqf/AD/3P/f1v8aP7f1I/wDL9c/9/W/xouKx65RXkf8AbF8et7c/9/W/xo/ti+/5/bn/AL+t/jU85XIetmkryM6xff8AP7c/9/W/xpP7WvD965mP/bQ0c4ch67RXkX9pXP8Az8Tf9/D/AI0f2lc/8/E3/fw/40c4ch62etJXkn9o3X/PxN/38P8AjSHUbn/n4m/7+H/GjnDkPWTRXkf9oXP/AD8Tf9/D/jR9vnP3ppj/ANtG/wAaOcOQ9bpD0ryP7W3/AD0l/wC+zTftP/TWX/vo0c4ch62aQ15L9p/6ayf99Gj7T/01k/76NHOHIerluaTzFH3jivKfNj/vSf8AfRo82P3/ADNHOHIepGePP+sWkM0ZBHmLz715d5sfvVrTpU+3Q8/xUuYOQ9JthwK14BxWTan5RWtb9Kxe50LYvRCrCrkVXiqyhpAY+qeENH1jLXNoom7SR/KwritV+FF0oaTTbyOUD/lnJ8rY/OvU061MBRzE8p84aj4b1bS2K3djMmD128VlMpU4IIPoa+pSobhlBHoRWVqHhTQdTBNxpkG/+8o2n9K0jMTifNh6GmV7fffCXRrkk2txPbE9vvj8uKwLz4OXqEm21KB17B1Kn+dPmuS4nl9FdrdfC3xJBkxwRzL/ALDjP5Vjz+Dtdts+bplyMdcJmqTIcTCoq9JpF/D/AKyznX6xmqjQupIZSPqKdw5SOin7PemlSKBWGUhqTFJsJPHNIRHRV2HS7y4x5VtI2f8AZNaFv4U1GXl1EY9+tA7GFRW/c+GJYY9yuGasWSBonKuMMKCuUioowRTlikc/KhP4UCsNxTo0eR9iJuatKy0O5u8E/KvpXdaJ4ct7MA+WGapuVymT4e8IGZllukJz/B616XY6dFbwqiKAAKbZ26ogAAz61pRLgYrOTNFEfDHjHFWlGKZGtSCkVYWlB5pe1FAwFLSCpFXdQDEp22pliA61IEHpUcwFcR0eWKtbR6UbB6VHOVYptCCKgkgz2rRKj0pjRg0ucqxgXVtweK5i/uEsJzLPxHiu7ngDCuC8a23+gyfStac9bmdSN1YonxLpn/PV/wDvim/8JNpn/PV/++K4Au1M3vnrW3tTH2Z6F/wk+m9pJD/wCl/4SjTf70v/AHxXnfmt60ea3rT9qL2Z6J/wlGm/3pf++KP+Eo03+9L/AN8V535zetHnN60e1D2Z6H/wlOnZ+9L/AN8Uf8JVp396X/vivPvOb1o85vWmp3GoHef8JdY5+5L/AN81IPF1hj7kv5V5/wCc3rR5zetHOHszv/8AhLrLPEcp/CgeLrEn7kv5V595zetHnN60c4ezPRR4ssCPuyf980N4vsF/glP4V5357+tIZnPejnD2Z6D/AMJnYf8APOX8qP8AhM7D/nnL+VeeeY3rR5jetHOHsz0P/hM7D/nlLR/wmdh/zzl/KvPN7etG9vWjnD2Z6H/wmlh/zzl/Kj/hNLD/AJ5y/lXnnmN60eY3rRzh7M9D/wCE3sR/ywl/Sg+N7P8AhtpT+Irzvc3rRvI70c4ezJKM0UVgai5NJuoo20ALk0ZNGKNtABmjNJtoxQA7dRupuaXNAC5NGTSUUAG40bjRijFABvo303FGKAHb6N9JijAoAN9Jvo20baADfRvpNtG2mAu+jfSbaNtABvNS20hjmR89GBqHFKpoA9a0yTzIFf2rdt+lch4buvO0+L6Curt34oA0kNWENVENWENIZaVqlVqqq1TK1AE2akU5qIGnA4oESUtR7jRuNO4h5pjCjcaaTmncZG8at/CPyqs+n2z/AHreJvqgq3mkNFwMyTQ9Ml/1lhbn/tkKrSeFdFb/AJhlv/3xWwTzRmi4jAPhPRQc/wBmW/8A3xQNB0+IfubSJPoorcc5BqA8ClcdjGlsEVc+Wv5VnT2qAEba6GcfIazJ1Gyi4WOZvLPGTjiuE8QWqx3IYDrXpF590/SvP/FB/fLTuBh2sIlu0X1rq7awRQMCuY03/j+i/wB6u8tIs4p3JsW9PsQoX5a6K1tsAYFU7KHpW3Cm1RU3HYlhjxVtFqKNeKnSkMkAxS0lLQA6gUlPVaYx6KSasxpgUyJe9TpUNjHBaeFoFKDWLZYbaTFBams1SMa1MalZqYTmhjGP0Nct4qtRNpswIzlTXUtWZqsKzWcikdRVRdhNXPnyQ4c1HmrOoReVezL/AHZCKq1uZhRRRTJEooooELRRRQAlJmnUmBTGNJoBpxFAFIQmaM0tFAwooopjCiiikISkpaSncAJ4puTSk4FQSzbaAL2RRkVFupd1ICTIpc1Fuo3UAS5p2ag3UbjQBPTai3t60b2oAloqLc1G5qAJc0m6odzUbmoAm3Ubqr7m9aXc3rTGTbqN1Q5b1o+b1oET7qN1V9zUbmpAWN1Juqvuajc1ArFjdRuqvuajc3rQBPuo3VBlvWk+b1oAnzS5qvhvWkw1MZ2nhO+VWeFm+ld/ay8CvF7Gdre5R88Zr1jS7oT2yODzjmgDpo6spVG2l3KPWrYpDJw1So1VVNTK1AFgNTg1QhqcDTGTZozTN1G6gTHZpu6kzTc0AO3GkJpM0ZoEJmm5oJpuaQCsaiY05jUTGgqxBMazrk8VfmPWs64oCxj3v3fwrzrxMf8ASgM16HqB+Q15tr583UmH92mhMo6b/wAhGH/er0rTo8sOK8301P8AiZQf71eo6anAqiWbVrGOK0UFU7fpV2OpsO5MnSpkqJRUi9aLCJKWhF3NVjygBTsFyEGp4xmmeX7VLEDSkNMnUcVMq4FNVO5qQNx92udlXExxTMmpN3tTGQN0pFJjSfekXFPKBabgUrBzCMoNRlTUvFG1WphzkOwkVTu4z5ZBrQKhelRSoJFwRQHOfPHiOPyddvI/+mhrIziu8+JWnwQaxHLGuHkX5q4FhhjW62uQO30m+o6MUxD99G+mbaNtAD99G+mbaNtAD99G+mbaNtAiUPQXqLaaTafWgCXdRvFRYPrS4NAyTeKN4qPBowaAJN4o3io8GjBoAfvFG4VHg0YNADZZdoqo5LnNW3jDCoWiI6VSJZo4o21JtpdtRcsix7UY9ql2CjbRcdiPb7UbfapttG2lcCDbRtqfbTSlFwIse1GPapdtG2ncdiLHtRj2qXbRtouFiHFGKl20baLhYixRipdtG2i4WIce1GPapdlGyi4WI9vtRtHpUu2jbRcXKQ7fajb7VNtFG2i4WIttG2pMUmKLhYZtpNtS7aTBp3AYFruvCmoF7cRM3K8Vw9a+g3Rtr9eflJouB6xay4I961Ebctc5ZzhlXBrbglyBQIuLUi1Epp6mgCQEinh6joFMCbdS5qLNLmgY/NGaZmjNAD80mabmkzQAE0wmlJqNjQAM1RM1DNUDtQA2Vqo3DcVNK1UZ3oAyNTl2Ka8xuZjLeyux5Jrt/Et15djKAeTwK4IZJLHqaok9A0bU4PEUQ0+8sLcS28e6G4j4bK+v1rqNOsSbcetebeEZPL8RWw/vgr+leuWQ2RCghiw27J948Vp20SkZZfl7VAIQzht3y9xUzNu4DbVFPlFcmeAHlPyqNIn3/NxSLlV3K5qQzKQuetPlFzEhdU4Xk0ws7HljUW7Cs1A3HBp2FuW4mYcNVyLGapJ90Z61KpbduU1zVZG0FoXc/nTDIR2qJZiDhqlBDDNYXuVYeh39aCdit69qYpxmnBN33qBgGEgX170yQfNgdKc0I6ocUzDdG6UAIn3uelRyOVXA9c09sDgGoyoPU0XAfvyARTS1RjKN6qac1UiTyj4n/wDIXT/rl/WvO8V6P8Tk/wCJnAf+mdefFa3XwgQFaNtSFaNtFwGYFGBTttG2i4CYFJtp+2jbRcLEe0UbRUm2jbTCxHtFG0VJto20BYj2ijaKkxRikBHtFG0VJijFAEe0UbRUm2jbQMi20bak20baAI9opCmal20mKLhYsLg0/ZWZb3XlH5vmWtSN1kUMpyDVNEJi7KNlPoqCxmyl2U/FGKAGbKTZUmKMUrAR7B6UbB6VJijFFhkWz2o2VLijFFgK+0+lG0+lT7aNvtTAh20bal20baBkW2jbUu2jbQIh20bal20baAIttG2pdtG2gCHbSYqXbRtoAjxSYqTbRtpgRbafETG4I7Gl2mkAoEd/oF6J4FBbkV1Vs/AryvRb1rW8UE/K3Fej2E/mIDmmBuxvmpgapxPkVLuoCxZBpytUKPng08GgLE2aM0zNGaYD80ZpuaM0ALmm5pCabmgBWNRk0pNRsaAGu1V3bvUjmq8jdqAIJXrKvZtoODzVyeXGcVy2vaqlnA7k5foBmgDmvEt8Z7sQKeF61irxUQkM8zSMeSanA4pkmhoUvk67ZyejivZ4JPLjGRXiNl+71C2I/viva4MOBn0pxIZe85UC7j16U4ktgLyDWeVNw3XCjpVm3leCQB+R2NaGZYGYw4fpTfJlk+ccYHAqVVEhaST7vYU8zY4RaAIFdoyVkBq2jgrlaYk0cp2kc+hqRYgp+XoaUthomjXccnpVlRjgLmoAwUYFKGb+9iuCo9ToiixtDcFcN60gV0bHaovNkX+LP1qZJ0Iw3DVCZTJsqnXrTCWb/ZWjAMyhulJM+MAUxDvnT7rZHpTlYSDB61DHJhhTtyicseBjmgCOQBGxULPRIxeQ+/Spoohj5lpAQbwwxT8ZXBqOeMxsGXoacr70yOtWhM80+J0R+1WZ9jXnZHOK9O+Jifu7OT/erzJvvGuhfCIZto207FO20DI9tG2pNtG2kBHto21JijFAEe2l2U/FHI6UAM2e1Gz2p+Woy1AEfln0o8pvSpdxo3H1oAi8pvQ0eU3oal3mjeaAI/Lb0o8tvSn+YaPMNAEflt/dpPLb+7Um9qNzetADPLP92k8s+lSbjSZJ60AY0kbRsUYEMO1SQzvA2VPHoa0rqFJY+fvetZ0UWZCpHStrmFrG2KWlVeKdiosajKKk20baQDMUYp+KMUBcZtoxTsUYpBcZRT8UYphcSiiigdwxRThTsUDuR7aNtPxRikIioqQqDSbaQ7kdFOxRigBlFOxRigBlFLijFMQ2kFOooGKMqcjrXXeHtX81ViY/vE4NchUDyPaXIuYm2uP1pge0W04YDmriyVxHh7xDFfRqrNiUdRXWRTBgOaANBW9KmR88GqCy1OsgNAFynVXR6k3UASUE0zdSFqAFJpuaQmmlqABmqNjilZsCq0kuDTAWR8c1RnmABGeaLi5Cg881z2q65bWUbNJIMjtnmgBdW1WKyhZ3YYxXmGqajNqNwXYnbngVNquqy6hOSSQmeBWbWkYkSkPt/virlU7f/XCrlTJEx1LNlJ5eoW5I/jFezQnzISfevFof9dGfRhXsVpL/AKMPoKIiki2ZUQKCefQVNEySOuHyueh6ioLe0M8bO3U9KiIeI46EfrWhBtSMWmVP4VGTTDOA2FFRwy+ZIM9WTH400J8pPfNAFhsHY+35gR+VXFfiqKtkAVZToKyqysjSEdSwo3Nmn4NNiqbNcL1OlaDKTrSse1NpMLj1dlZTngdAalZg3zDrVelBIoTJZMMKc1GX3MPTP50wuTTc0xltItsu7tTZJmZ9kX4mlWTNuT3AqJcRxj1PU1SRJIrBlMcg+bsarkbGx7U9juCsOoPFNn+8DVJCZwvxK5srP/eYfpXlrfeNep/Ej/kG2p/6aNXl9br4RAo4pcUAU/FIYzFGKfto20AR4oxT8UYoAZijFPxRigBmKMU/FGKAI9tG2pttG2gCLbRtp+KMUAR7aTbUmKMUAM20bafijFMQ3bSFafRQBWl+Y7aWG3w2akSMk5PWrCJtHvVCFXgUtLijFIBKM0uKMUCEzS0YooAKKKKBiUUtFAhKTFOpKAFApaSlpFBRSUUgFpKKKAG0lLSUDCm06m4NMApKWigQ2ilooAbUN0m+E1YppGRz0oAyI5XhfcjFWHcGuy0bxs0ZWO+BOBjeK464j8uUihLaWRN6rla0IuexWmu2V4qtDcKc9q1YblSo5rwYMV4rY0zxPqGm4USGVB0VzSaBTPbEm9DU6yZrz3T/AB5ayAJchopD2HIroLfxFYyIGW7jOfelYpSOlDCgtWH/AG3Z/wDP3F/32KrT+K9LgyHvYyR2BosO50TPUTS4rkJPHemj7jO1U5/Hlp/DHI1Fh3O0luQOlZGo6xBaxFpZFWuGv/Gd5OhWELGD3HNc3d3lzdOWnkLE+pquUXMb2seL3nkKWnT++a5lpJbyYvJIWc+tM2k1YhQqNqplj3rSxlKZE9uyfeqs/BwK2RaRrFulcn/ZFZ03lg8L+tFiCK2/1oq53qvapyWqzUSNIig4r13TG822T6CvIc16xoh+WAf9MxTgORu+e6YWNfkHWrQjiuY43H1qrHKFYIejdaswKIklHRQcrVGRWc7ZWx2Y1IkhK1ERkbu5p8S5pMpItwLubJq4o5qGBcLVlR81ctV3Z0RVlcevy07dUbHmkBrAslzmjFNp1AhMUE0U2lYApRTKUGiwEsbYJU9DSydhUWacHBGD1q47EiimvSk4FRMcmrRLOM+I3/IJtT/00NeYHrXp/wARP+QPB/11rzA9a1XwgAOKlU5FQ1InSgCTAoxSUUhi7aNopKKADbSbaXNGaAE20m2l3UbqYhNppdppdwo3CgBNppNpp2aM0AN2mjaadmjNADMH0owafRQBHikqQikxQBIsWKlCCnAU6gRHtFG0VLto20hke0elG0elOxRigBu0elG0elOxRigYzYKNgqTFJRckj2CjYKkxRimMi2CjYKkxRigCPaKNtPxRigBm2k21JijFICPFJipMU3bQAzFJinkc0mKBjcUmKfijFMBmKTbT8UlAhu2k2040UAN200in0wmgClfR/KHHbrVdI51TzI2GPrV+dDJEVHU1jlSGIPUVpFkSROziY7sYcfeFKFVvlzhu1MRVkcBm2t2apUT9/wCXJhZB0561oZDQCpYH7w6U9bl9uK0I7WGF90mGY9OeBWlbDTPK8mFV2j7wbqxoAwF8x03OQsfrmkPl/wACsx9TW3eaXG0BEL/ITuUcYB9Ky3LW0O1ocMKCiox2/ejahjui3Rg9duOvNW43e6tihXrwX6YpyXUFrD5cKeYR0J7n1oAYNOnRYpSMqcFl7ioJYXWeQnofuims90TmS42tnoxpbm1vFi87zFK98NQSSW1s7PkjnsK0XEVhbsX2mTuff0FQ6ZGY7X7TKfvZ2+3vVC6mFzIZXGIx90f3jQBDPfSTEgDAqvyfvGp5bt5U8vagT2FV2oAt2n3DU9V7T7pqxUS3NY7C16focubWGT/YWvL69G8PS50q3P8AsiiLFI60xbonkH3lwRVmZsRFB1IGapW8+6LB6Hg055SQ3PzE1ZmSN9xamgWqok3FVNaFvGMZqWWi1HwBUqsM1FjHApa45bnQtiU9aSmBiKeCDUgLml3Gmk0lAx+40uRUdOAPoamwgozS7H9KPKc/wmiwDC1AOaf5En904o8oiqQCM1MJp7IcU3bitEQzg/iFP/o9vB/tFq86PWu7+Ih/0mD6GuE71otgClBptJupsRJuo31Fuo3UAmS7zRvNR5ozQO5Luo3VDuo3UAS5pai3Uu6gQ+kzTd1JuoAfuo3GmbqN1AD9xpd1R7qN1BJJvo31Huo3UAP3mk3UzJpuTQBqilpuaUGpLFopKKAFopKKAFopKKAFoptFAC0UmaM0AFFJRQMWim0UALRTaKAFzRmkJpuaAFJpM0lJQIdSUlFCBBmm5p1NNAxKTNLTaYhKKWkpAN71mXibZyR0NalVL2LcmRVxZLRREbkdKtLbS3KW2xf3xptrcCNv3gJArVivQIv3C7Cf4u9bGIq6QsXy3Vyinpjqali0uyby9tw/yn5vl4I9arIodmd2JNL9qV38pRjb2oGTvpRj+eK63fNgDvUUpeF2S5jaSNe46ipEu9nEhx2FPV2z8udvfPegDDJkvLr7PCSELcAdqllkgtnNtZjOPvyf3jW2EtppPNKiK4/vL0NZr6SwkLQHOeSpoApNbCRdzH56fZQSBZCclXGNp9KsxafL526YkIO1PuJo4gVj4AoAzbi6ab9yPlAO0AdMVFM+4hB9xOBRNHlg+cE8io2Xb3oCw0gVG1PJqNqBFu1+6asVXtPuZqxUS3NY7BXe+GG3aRH7ZH6muCrsfB91GbWS2P31ct9QaSCWqO1tmO2pe9MtmVVq0rx91rQyI05lX61tW6HYKoRSx/wxirsc0uwbVWs5lotCJvSnfZ3NRCaf/noaXJY5Z2JrlZ0LYmS3Xu4qQQxLy0lVcnsaMetTcC1/ow/jo3wD1NVqMUAWftEI6RUfax2jqvjikpcwExvGPGym/bJewXFQ0lFwsSm5lPYVEZZvUflRRn3ppgN8yYdxVd7+SM4dRVrNV5oVkU5HNaRIZ5/4+nWW5t8Hkqa4mt7xZIz6wQT91QAKwT1rYkSm96fSUDG0U6ikIbTqKKYwxRinUYoAbijFLS0ANxRinUUANxRinUmaYCYpCKdmkJoJExRilooAKbTqKANClpKWsywooooASiiigAooooAWiiigBKKKKACiiloASiiigYlFFFAhp6UlOptMApKWkpAFJRRQAYpCKM0hNAxDRRRQAhFJSk0lABTHUMpFOzTTTEY0vySspqaK4KoAOgo1CPa28D61VjbHXoa2RkzUinOctwDTnZWfcByO9UkZ8gbiV7A9qtxttwSAQetMkmZ0ZldYj055zz61ZikI+ZjlfSqSyJv6cU+R+MjgUgJmuQsucVJ9rLfdqisyBTujDGkWbjJwtMZanuZJNqMQB7DFUZzn7tNkk3nO6mbwo+9TENPPXtVdzk1JI+fu1FQIYTTacw5phoA0Lb/U1JTLb/UipazlubQ2G1s+FpfL1dB/fBFYxq9o0nlapA/vSQ2j1WD7tWVPFU4G+SrKHNbHP1Ltsma04xhcVRs0+Wry9K5arOiCJKKbk0ZNczZqOpaZk0tIB1FJmjNMdh1JRmkzSCwE0hNITTc0BcKTNLmkzTRIuTSUZozxmtFuI8i8Vf8AIen/AN6sI9a19fk87V7h/wDbNZBrpM0FJS0uKkBtNp5FJQA2nCilpjCiiigAooooASilooJCkpabz6UwFopM+1GaADNGaSigBc0ZpKKANOiiisywooooASilooAKKKSgApaSloATNGaXFGKAEzRmlxRigYlFBooATFGKWigBMUm2nUlADMGkxUmKTFAiPFGKkwKbQAzFGKfijFAyMik20+igCLaaNpqSigCPaabtqakKg0AUrmPzIXXHNY3KsVPUV0jIOcisG8j8u4bHetIMmS0EWUgcVOJdyBSarLT9vpWpgWFZOcvipI5McBtwqn5RanLBJ/DmgC27Rg5PSmNNDs71EtpK3UHFSLZleooArls9OlGCasGIDtTCMUwISMU2pXqOgQxqiNSN1pgGTikNI04V2wrT6RRgADtTqylubLYSpLclJ436YYGmU6pW5R6pZyB4FPtV2PqKx9HfzNPif/ZFbEP3hXQYdTagACDFWF6VBD90VOK4qm50R2FopKKxKFp1MpaQx1FIDSUAPpCaKZQApNNNBpKYC0lFFNAFI/EbfSlqtqEnl2cz/wCyatbknj2pvvv52/2jVLFWLgl5nJPJOTUFdBmJilopakYmKQilooGJtpdtLTqZI3ZRsp9FADNlGyn0UxjNlGyn0UhDNgpNtSUlAEe2kKVLRiqEQ4oxT8UYoAjop5Wk2UAX8UYpaKzNBMUYpaKBCYoxS0UAJijFLRQAmKMUtFABRRRQMKSlooASkp1JQAlFLijFAWEpKdijFAWG0U7FJigLDaKdijFAWGYoxT9tG2gLEVFP20mygdhtFO20bakLDKKUjFNoCwjdKydST5g9ax5rP1FMwk1UdyZbGQGwalWSoKUHFdJzsvxNWjbuKxEkI6Vetpjkc0wNbI9KglXBqSNwy80SDgUyblCTrUDdasyLzVZ+tAET1HUj1EaBjGpYV3zKKRqnsY/3u4/hUlIvAYpdtLS1g9zdDMU7FGKWkM7zw7Lv06MegxXS2aguM1xvhV/9GdfRq7Ox5YVv0MOptRrhakqNPuipK4qm50LYXNGaTNGayGLmjNJmjNMYtLTaWmAppKKSkAUhooNACUUUVSEFZmvy+Xo8x/2TWnXPeLZfK0aT/aNaR3IPLnJ3Z/OmU5qZWrJQ6ikoqShaKSjNMQtOpmaWmIdRRRQAZozRmjNABRS0UAJRS0lABTadkeoPFNpgJRS0UCEoopKBF6looqDUKKXBowaAEpaXBpdtAhlFP20baLjG4oxT8UYoCwm2jbTsUYqR2G4oxTsUYpjsJto2ilopDsJtFG0UtFIBu0UbRTqKAsN2ijbTqKAsM20badSYpDsNpKftpNpphYbRS7aNtFwsNxSYp+2jbSuFiIimEVORTCKLhYhIqveJm2eru2oZk3KynoadxSWhy5FIKc/DEehptda2OWW44dasRPtNVx1FSLVEmpBL71b3bhWRBJtcVpxOCtMgbIveqki4NaDDINUZhQMrtULdamaoWpARPV2yX5M1RY81pWikQDNTLYuO5PmjNB70VgdAmacKSgdaAOl8Ky/vZk9q9B077grzXw1Ji/P+0tel6cPkFa/ZMXua6fdp1NX7opa457m6FopKKgYtFJRQMdRSUtABSUppppgLSUtNpAFFFFUhBXKeOZcaUqf7Yrqx1rivHcn7uOP3raG5BwTdabipDTcCrYkNxRS0lIYUUtFAhKKWimIKKKKACikooAXJoyaSloAMmjNFFACUUUUALRSUUxhSUtMeRUGWOBQS0aVOpAKdUGqQUU6jFK4WG0tLS0XHYbS4paKVwsGKMUtLilcqw2in7aULSuOxHRU22jbRcdiCinkU3vRcLBto208Uu2i4WI9tO2U7bTgKVyrEeyjZUmKMUrhykOz2o2e1T7aAvNFw5SDZ7UbParOwUbB6Uc4+UrbKNlWdgo2ClzC5Stspu2rJUUm0UuYOUrFKYUq2VFN2UcwcpW2Go3jyOauhB6VXvf3drK391TTUtSWjjZv9a/1plB5OaWu9bHFPcKkWox1p69aokmT71aNueBWcnWr9v0piaLh6VSmxVz+GqU3WgkqPUDtUspqsxyaCkJ1NbMKlYlBHas2yi867RMcVvi3wOaxm9DWEdSpRVryKPIHtWPMbWK2KUDmrHle1J5XtTuIv6Bxqa/SvUtN/1IryvSv3Wox16jpX+pFXf3WS0aw6CnUzsKUGudlodRTd1G6oGOopu6lzSAdRSUtMYUlKabQAtJRuoouIKKbRVIB1cB44lzeJH/dFd7Xm/jCXzdVP0rWG5JzNJUoWjbVEkVGKl20baQyKipdtG2mBDg0YNT7RRtFMTIMGkwfSrG0UbRSAr7G9KNjelWMUYphYg2N6UbG9Ks4oxQIrbG9KNjelTUUhkOxvSjY3pU1FMCHy2o8tqmzRuoCxXkIjQs3SsmZ2uJiqn5Ktahc5PkR9+tFpajb70xM3RTqUKaNprE2Cil2mnBTmgY3aaXaaeBSgUDsM20Bak20baQ7DcU7FO204LSGMC0oWpAKXFIqwzbQVp+KTFIdiAimlamYc0FaYrEYFOAp4WnBaAsM2+1JtNSYpcUihm2jFP20bai47DMUuKfijbRcLDcUYpcUYouFhMUYoozQIaVpCtKXx2qJ5aAHYpKi800ebQBLWbrcnl2Df7ZAq55tY2v3GYY4/9qqp/EkTP4Tnj1pRTT1pwr0TznuKKcKQU8UCFVsGrtvJVGrEDYNMDUBytU56nR8rVO5fmmSVZWqCpHOTUdIaNfRIcyvKR0HFbVUNEj/0Mv8A3jWiRXLVlZ2OqltcYVFRlcVLTTWKZtYixQBzTsUYqrisSWnF9Ga9R0kgwr9K8sg4uUPvXqGikm3X6VtB6MxqGxRS7G/umjy2/utWDGgopfLb+635Uvlt/db8qkobRTvLb+635UeW391vyqQFFLSBG/ut+VOCN/cb8qYxpOKZUjI39xqbsb+635UANoo2P/dajY/91vyoASlFLsb+635UoRv7rflVokYTivK/EE3napIa9PuMhD9K8o1b/kJS/WtqbIKO7FG6kPWkpFDt1G6m0UAP3UbqbRTAXcadupu2nbaQBuo3UbaNtMQmaM0u2jbQAbqN1G2jbQA3NGadtpNtACZozRijFABUNxKIYmY/hU1ZepyZnSEfjQIgtYjPMXatdECDAqGzhCRg45NW9lUyEf/Z"
          ]
        },
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "{\"positive\":[{\"x\":313.32886117682557,\"y\":346.103846655573},{\"x\":331.6828530449242,\"y\":555.8637537195567},{\"x\":309.3571186438434,\"y\":1142.1033159234917},{\"x\":390.5273499906991,\"y\":847.2686797376068}],\"negative\":[{\"x\":133.7792652217274,\"y\":260.8020018969029}]}",
        "[{\"x\":313.32886117682557,\"y\":346.103846655573},{\"x\":331.6828530449242,\"y\":555.8637537195567},{\"x\":309.3571186438434,\"y\":1142.1033159234917},{\"x\":390.5273499906991,\"y\":847.2686797376068}]",
        "[{\"x\":133.7792652217274,\"y\":260.8020018969029}]",
        "[{}]",
        "[{}]",
        "xyxy",
        720,
        1280,
        false,
        "",
        null
      ]
    },
    {
      "id": 38,
      "type": "WanVideoVAELoader",
      "pos": [
        -1202.9254150390625,
        -719.362548828125
      ],
      "size": [
        600.9592895507812,
        106
      ],
      "flags": {},
      "order": 9,
      "mode": 0,
      "inputs": [
        {
          "label": "compile_args",
          "localized_name": "compile_args",
          "name": "compile_args",
          "shape": 7,
          "type": "WANCOMPILEARGS",
          "link": null
        },
        {
          "label": "model_name",
          "localized_name": "model_name",
          "name": "model_name",
          "type": "COMBO",
          "widget": {
            "name": "model_name"
          },
          "link": null
        },
        {
          "label": "precision",
          "localized_name": "precision",
          "name": "precision",
          "shape": 7,
          "type": "COMBO",
          "widget": {
            "name": "precision"
          },
          "link": null
        },
        {
          "label": "use_cpu_cache",
          "localized_name": "use_cpu_cache",
          "name": "use_cpu_cache",
          "shape": 7,
          "type": "BOOLEAN",
          "widget": {
            "name": "use_cpu_cache"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "vae",
          "localized_name": "vae",
          "name": "vae",
          "type": "WANVAE",
          "slot_index": 0,
          "links": [
            295,
            296
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "WanVideoVAELoader",
        "cnr_id": "ComfyUI-WanVideoWrapper",
        "ver": "e5ef9752a7e846b232fc05fd993327a2e870a788",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "Wan2_1_VAE_bf16.safetensors",
        "bf16",
        false
      ],
      "color": "#322",
      "bgcolor": "#533"
    },
    {
      "id": 112,
      "type": "VHS_VideoCombine",
      "pos": [
        824.1279296875,
        -1935.6259765625
      ],
      "size": [
        261.6273498535156,
        334
      ],
      "flags": {},
      "order": 29,
      "mode": 0,
      "inputs": [
        {
          "label": "图像",
          "localized_name": "images",
          "name": "images",
          "type": "IMAGE",
          "link": 314
        },
        {
          "label": "音频",
          "localized_name": "audio",
          "name": "audio",
          "shape": 7,
          "type": "AUDIO",
          "link": null
        },
        {
          "label": "批次管理",
          "localized_name": "meta_batch",
          "name": "meta_batch",
          "shape": 7,
          "type": "VHS_BatchManager",
          "link": null
        },
        {
          "label": "vae",
          "localized_name": "vae",
          "name": "vae",
          "shape": 7,
          "type": "VAE",
          "link": null
        },
        {
          "localized_name": "帧率",
          "name": "frame_rate",
          "type": "FLOAT",
          "widget": {
            "name": "frame_rate"
          },
          "link": null
        },
        {
          "localized_name": "循环次数",
          "name": "loop_count",
          "type": "INT",
          "widget": {
            "name": "loop_count"
          },
          "link": null
        },
        {
          "localized_name": "文件名前缀",
          "name": "filename_prefix",
          "type": "STRING",
          "widget": {
            "name": "filename_prefix"
          },
          "link": null
        },
        {
          "localized_name": "格式",
          "name": "format",
          "type": "COMBO",
          "widget": {
            "name": "format"
          },
          "link": null
        },
        {
          "localized_name": "Ping-Pong",
          "name": "pingpong",
          "type": "BOOLEAN",
          "widget": {
            "name": "pingpong"
          },
          "link": null
        },
        {
          "localized_name": "保存到输出文件夹",
          "name": "save_output",
          "type": "BOOLEAN",
          "widget": {
            "name": "save_output"
          },
          "link": null
        },
        {
          "name": "pix_fmt",
          "type": [
            "yuv420p",
            "yuv420p10le"
          ],
          "widget": {
            "name": "pix_fmt"
          },
          "link": null
        },
        {
          "name": "crf",
          "type": "INT",
          "widget": {
            "name": "crf"
          },
          "link": null
        },
        {
          "label": "保存元数据",
          "localized_name": "保存元数据",
          "name": "save_metadata",
          "type": "BOOLEAN",
          "widget": {
            "name": "save_metadata"
          },
          "link": null
        },
        {
          "name": "trim_to_audio",
          "type": "BOOLEAN",
          "widget": {
            "name": "trim_to_audio"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "文件名",
          "localized_name": "Filenames",
          "name": "Filenames",
          "type": "VHS_FILENAMES",
          "links": null
        }
      ],
      "properties": {
        "Node name for S&R": "VHS_VideoCombine",
        "cnr_id": "comfyui-videohelpersuite",
        "ver": "8e4d79471bf1952154768e8435a9300077b534fa",
        "widget_ue_connectable": {}
      },
      "widgets_values": {
        "frame_rate": 30,
        "loop_count": 0,
        "filename_prefix": "WanVideo2_1_T2V",
        "format": "video/h264-mp4",
        "pix_fmt": "yuv420p",
        "crf": 19,
        "save_metadata": true,
        "trim_to_audio": false,
        "pingpong": false,
        "save_output": false,
        "videopreview": {
          "hidden": false,
          "paused": false,
          "params": {
            "filename": "WanVideo2_1_T2V_00002.mp4",
            "subfolder": "",
            "type": "temp",
            "format": "video/h264-mp4",
            "frame_rate": 30,
            "workflow": "WanVideo2_1_T2V_00002.png",
            "fullpath": "/ComfyUI/temp/WanVideo2_1_T2V_00002.mp4"
          }
        }
      }
    },
    {
      "id": 63,
      "type": "VHS_LoadVideo",
      "pos": [
        -1708.501220703125,
        -3422.03662109375
      ],
      "size": [
        379.7261962890625,
        963.4020568253434
      ],
      "flags": {},
      "order": 13,
      "mode": 0,
      "inputs": [
        {
          "label": "批次管理",
          "localized_name": "meta_batch",
          "name": "meta_batch",
          "shape": 7,
          "type": "VHS_BatchManager",
          "link": null
        },
        {
          "label": "vae",
          "localized_name": "vae",
          "name": "vae",
          "shape": 7,
          "type": "VAE",
          "link": null
        },
        {
          "localized_name": "视频",
          "name": "video",
          "type": "COMBO",
          "widget": {
            "name": "video"
          },
          "link": null
        },
        {
          "localized_name": "强制帧率",
          "name": "force_rate",
          "type": "FLOAT",
          "widget": {
            "name": "force_rate"
          },
          "link": null
        },
        {
          "label": "custom_width",
          "localized_name": "custom_width",
          "name": "custom_width",
          "type": "INT",
          "widget": {
            "name": "custom_width"
          },
          "link": 316
        },
        {
          "label": "custom_height",
          "localized_name": "custom_height",
          "name": "custom_height",
          "type": "INT",
          "widget": {
            "name": "custom_height"
          },
          "link": 317
        },
        {
          "localized_name": "帧数读取上限",
          "name": "frame_load_cap",
          "type": "INT",
          "widget": {
            "name": "frame_load_cap"
          },
          "link": null
        },
        {
          "localized_name": "跳过前X帧",
          "name": "skip_first_frames",
          "type": "INT",
          "widget": {
            "name": "skip_first_frames"
          },
          "link": null
        },
        {
          "localized_name": "模选",
          "name": "select_every_nth",
          "type": "INT",
          "widget": {
            "name": "select_every_nth"
          },
          "link": null
        },
        {
          "localized_name": "format",
          "name": "format",
          "shape": 7,
          "type": "COMBO",
          "widget": {
            "name": "format"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "图像",
          "localized_name": "图像",
          "name": "IMAGE",
          "type": "IMAGE",
          "links": [
            252,
            293,
            294,
            298
          ]
        },
        {
          "label": "帧计数",
          "localized_name": "frame_count",
          "name": "frame_count",
          "type": "INT",
          "links": [
            299
          ]
        },
        {
          "label": "音频",
          "localized_name": "audio",
          "name": "audio",
          "type": "AUDIO",
          "links": []
        },
        {
          "label": "视频信息",
          "localized_name": "video_info",
          "name": "video_info",
          "type": "VHS_VIDEOINFO",
          "links": null
        }
      ],
      "properties": {
        "Node name for S&R": "VHS_LoadVideo",
        "cnr_id": "comfyui-videohelpersuite",
        "ver": "8e4d79471bf1952154768e8435a9300077b534fa",
        "widget_ue_connectable": {}
      },
      "widgets_values": {
        "video": "v1e00fgi0000d2vbhgvog65nmtks2pq0.MP4",
        "force_rate": 30,
        "custom_width": 0,
        "custom_height": 0,
        "frame_load_cap": 300,
        "skip_first_frames": 0,
        "select_every_nth": 1,
        "format": "AnimateDiff",
        "videopreview": {
          "hidden": false,
          "paused": false,
          "params": {
            "filename": "v1e00fgi0000d2vbhgvog65nmtks2pq0.MP4",
            "type": "input",
            "format": "video/MP4",
            "force_rate": 30,
            "custom_width": 0,
            "custom_height": 512,
            "frame_load_cap": 300,
            "skip_first_frames": 0,
            "select_every_nth": 1
          }
        }
      }
    },
    {
      "id": 96,
      "type": "ImageCropByMaskAndResize",
      "pos": [
        519.2192993164062,
        -1807.382080078125
      ],
      "size": [
        306.0923767089844,
        170
      ],
      "flags": {},
      "order": 27,
      "mode": 0,
      "inputs": [
        {
          "label": "image",
          "localized_name": "image",
          "name": "image",
          "type": "IMAGE",
          "link": 254
        },
        {
          "label": "mask",
          "localized_name": "mask",
          "name": "mask",
          "type": "MASK",
          "link": 228
        },
        {
          "label": "base_resolution",
          "localized_name": "base_resolution",
          "name": "base_resolution",
          "type": "INT",
          "widget": {
            "name": "base_resolution"
          },
          "link": null
        },
        {
          "label": "padding",
          "localized_name": "padding",
          "name": "padding",
          "type": "INT",
          "widget": {
            "name": "padding"
          },
          "link": null
        },
        {
          "label": "min_crop_resolution",
          "localized_name": "min_crop_resolution",
          "name": "min_crop_resolution",
          "type": "INT",
          "widget": {
            "name": "min_crop_resolution"
          },
          "link": null
        },
        {
          "label": "max_crop_resolution",
          "localized_name": "max_crop_resolution",
          "name": "max_crop_resolution",
          "type": "INT",
          "widget": {
            "name": "max_crop_resolution"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "images",
          "localized_name": "images",
          "name": "images",
          "type": "IMAGE",
          "links": [
            309,
            314
          ]
        },
        {
          "label": "masks",
          "localized_name": "masks",
          "name": "masks",
          "type": "MASK",
          "links": null
        },
        {
          "label": "bbox",
          "localized_name": "bbox",
          "name": "bbox",
          "type": "BBOX",
          "links": null
        }
      ],
      "properties": {
        "Node name for S&R": "ImageCropByMaskAndResize",
        "cnr_id": "comfyui-kjnodes",
        "ver": "c2712d778158eb63bbad2344f61b8d448645431d",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        512,
        0,
        128,
        512
      ]
    },
    {
      "id": 176,
      "type": "VHS_VideoCombine",
      "pos": [
        2017.2752685546875,
        -1786.62548828125
      ],
      "size": [
        852.6953125,
        334
      ],
      "flags": {},
      "order": 34,
      "mode": 0,
      "inputs": [
        {
          "label": "图像",
          "localized_name": "images",
          "name": "images",
          "type": "IMAGE",
          "link": 320
        },
        {
          "label": "音频",
          "localized_name": "audio",
          "name": "audio",
          "shape": 7,
          "type": "AUDIO",
          "link": null
        },
        {
          "label": "批次管理",
          "localized_name": "meta_batch",
          "name": "meta_batch",
          "shape": 7,
          "type": "VHS_BatchManager",
          "link": null
        },
        {
          "label": "vae",
          "localized_name": "vae",
          "name": "vae",
          "shape": 7,
          "type": "VAE",
          "link": null
        },
        {
          "localized_name": "帧率",
          "name": "frame_rate",
          "type": "FLOAT",
          "widget": {
            "name": "frame_rate"
          },
          "link": null
        },
        {
          "localized_name": "循环次数",
          "name": "loop_count",
          "type": "INT",
          "widget": {
            "name": "loop_count"
          },
          "link": null
        },
        {
          "localized_name": "文件名前缀",
          "name": "filename_prefix",
          "type": "STRING",
          "widget": {
            "name": "filename_prefix"
          },
          "link": null
        },
        {
          "localized_name": "格式",
          "name": "format",
          "type": "COMBO",
          "widget": {
            "name": "format"
          },
          "link": null
        },
        {
          "localized_name": "Ping-Pong",
          "name": "pingpong",
          "type": "BOOLEAN",
          "widget": {
            "name": "pingpong"
          },
          "link": null
        },
        {
          "localized_name": "保存到输出文件夹",
          "name": "save_output",
          "type": "BOOLEAN",
          "widget": {
            "name": "save_output"
          },
          "link": null
        },
        {
          "name": "pix_fmt",
          "type": [
            "yuv420p",
            "yuv420p10le"
          ],
          "widget": {
            "name": "pix_fmt"
          },
          "link": null
        },
        {
          "name": "crf",
          "type": "INT",
          "widget": {
            "name": "crf"
          },
          "link": null
        },
        {
          "label": "保存元数据",
          "localized_name": "保存元数据",
          "name": "save_metadata",
          "type": "BOOLEAN",
          "widget": {
            "name": "save_metadata"
          },
          "link": null
        },
        {
          "name": "trim_to_audio",
          "type": "BOOLEAN",
          "widget": {
            "name": "trim_to_audio"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "文件名",
          "localized_name": "Filenames",
          "name": "Filenames",
          "type": "VHS_FILENAMES",
          "links": null
        }
      ],
      "properties": {
        "Node name for S&R": "VHS_VideoCombine",
        "cnr_id": "comfyui-videohelpersuite",
        "ver": "8e4d79471bf1952154768e8435a9300077b534fa",
        "widget_ue_connectable": {}
      },
      "widgets_values": {
        "frame_rate": 30,
        "loop_count": 0,
        "filename_prefix": "Wanimate",
        "format": "video/h264-mp4",
        "pix_fmt": "yuv420p",
        "crf": 19,
        "save_metadata": true,
        "trim_to_audio": false,
        "pingpong": false,
        "save_output": true,
        "videopreview": {
          "hidden": false,
          "paused": false,
          "params": {
            "filename": "Wanimate_00045.mp4",
            "subfolder": "",
            "type": "output",
            "format": "video/h264-mp4",
            "frame_rate": 30,
            "workflow": "Wanimate_00045.png",
            "fullpath": "/ComfyUI/output/Wanimate_00045.mp4"
          }
        }
      }
    },
    {
      "id": 171,
      "type": "WanVideoLoraSelectMulti",
      "pos": [
        -592.1607055664062,
        -1002.6304321289062
      ],
      "size": [
        583.3719482421875,
        342
      ],
      "flags": {},
      "order": 10,
      "mode": 0,
      "inputs": [
        {
          "label": "prev_lora",
          "localized_name": "prev_lora",
          "name": "prev_lora",
          "shape": 7,
          "type": "WANVIDLORA",
          "link": null
        },
        {
          "label": "blocks",
          "localized_name": "blocks",
          "name": "blocks",
          "shape": 7,
          "type": "SELECTEDBLOCKS",
          "link": null
        },
        {
          "label": "lora_0",
          "localized_name": "lora_0",
          "name": "lora_0",
          "type": "COMBO",
          "widget": {
            "name": "lora_0"
          },
          "link": null
        },
        {
          "label": "strength_0",
          "localized_name": "strength_0",
          "name": "strength_0",
          "type": "FLOAT",
          "widget": {
            "name": "strength_0"
          },
          "link": null
        },
        {
          "label": "lora_1",
          "localized_name": "lora_1",
          "name": "lora_1",
          "type": "COMBO",
          "widget": {
            "name": "lora_1"
          },
          "link": null
        },
        {
          "label": "strength_1",
          "localized_name": "strength_1",
          "name": "strength_1",
          "type": "FLOAT",
          "widget": {
            "name": "strength_1"
          },
          "link": null
        },
        {
          "label": "lora_2",
          "localized_name": "lora_2",
          "name": "lora_2",
          "type": "COMBO",
          "widget": {
            "name": "lora_2"
          },
          "link": null
        },
        {
          "label": "strength_2",
          "localized_name": "strength_2",
          "name": "strength_2",
          "type": "FLOAT",
          "widget": {
            "name": "strength_2"
          },
          "link": null
        },
        {
          "label": "lora_3",
          "localized_name": "lora_3",
          "name": "lora_3",
          "type": "COMBO",
          "widget": {
            "name": "lora_3"
          },
          "link": null
        },
        {
          "label": "strength_3",
          "localized_name": "strength_3",
          "name": "strength_3",
          "type": "FLOAT",
          "widget": {
            "name": "strength_3"
          },
          "link": null
        },
        {
          "label": "lora_4",
          "localized_name": "lora_4",
          "name": "lora_4",
          "type": "COMBO",
          "widget": {
            "name": "lora_4"
          },
          "link": null
        },
        {
          "label": "strength_4",
          "localized_name": "strength_4",
          "name": "strength_4",
          "type": "FLOAT",
          "widget": {
            "name": "strength_4"
          },
          "link": null
        },
        {
          "label": "low_mem_load",
          "localized_name": "low_mem_load",
          "name": "low_mem_load",
          "shape": 7,
          "type": "BOOLEAN",
          "widget": {
            "name": "low_mem_load"
          },
          "link": null
        },
        {
          "label": "merge_loras",
          "localized_name": "merge_loras",
          "name": "merge_loras",
          "shape": 7,
          "type": "BOOLEAN",
          "widget": {
            "name": "merge_loras"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "lora",
          "localized_name": "lora",
          "name": "lora",
          "type": "WANVIDLORA",
          "links": [
            289
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "WanVideoLoraSelectMulti",
        "cnr_id": "ComfyUI-WanVideoWrapper",
        "ver": "b2c8cf969fcf60a38884ea2c29af177ae1f28b29",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "none",
        0,
        "lightx2v_T2V_14B_cfg_step_distill_v2_lora_rank32_bf16.safetensors",
        1.2,
        "Wan21_PusaV1_LoRA_14B_rank512_bf16.safetensors",
        1,
        "Wan2.2-Fun-A14B-InP-LOW-HPS2.1_resized_dynamic_avg_rank_15_bf16.safetensors",
        0.45,
        "Wan2.2-Fun-A14B-InP-LOW-MPS_resized_dynamic_avg_rank_22_bf16.safetensors",
        0.7,
        false,
        false
      ],
      "color": "#223",
      "bgcolor": "#335"
    }
  ],
  "links": [
    [
      33,
      27,
      0,
      28,
      1,
      "LATENT"
    ],
    [
      59,
      22,
      0,
      48,
      0,
      "WANVIDEOMODEL"
    ],
    [
      62,
      48,
      0,
      50,
      0,
      "WANVIDEOMODEL"
    ],
    [
      63,
      50,
      0,
      27,
      0,
      "WANVIDEOMODEL"
    ],
    [
      64,
      51,
      0,
      50,
      1,
      "BLOCKSWAPARGS"
    ],
    [
      82,
      57,
      0,
      64,
      0,
      "IMAGE"
    ],
    [
      84,
      62,
      0,
      27,
      1,
      "WANVIDIMAGE_EMBEDS"
    ],
    [
      96,
      70,
      0,
      62,
      1,
      "WANVIDIMAGE_CLIPEMBEDS"
    ],
    [
      97,
      71,
      0,
      70,
      0,
      "CLIP_VISION"
    ],
    [
      100,
      35,
      0,
      22,
      0,
      "WANCOMPILEARGS"
    ],
    [
      185,
      102,
      0,
      104,
      0,
      "SAM2MODEL"
    ],
    [
      187,
      104,
      0,
      100,
      0,
      "MASK"
    ],
    [
      198,
      100,
      0,
      108,
      0,
      "MASK"
    ],
    [
      210,
      107,
      0,
      104,
      2,
      "STRING"
    ],
    [
      219,
      73,
      1,
      120,
      0,
      "POSE_KEYPOINT"
    ],
    [
      228,
      120,
      0,
      96,
      1,
      "MASK"
    ],
    [
      252,
      63,
      0,
      147,
      0,
      "*"
    ],
    [
      253,
      147,
      0,
      73,
      0,
      "IMAGE"
    ],
    [
      254,
      147,
      0,
      96,
      0,
      "IMAGE"
    ],
    [
      260,
      150,
      0,
      152,
      1,
      "INT"
    ],
    [
      261,
      151,
      0,
      152,
      2,
      "INT"
    ],
    [
      262,
      152,
      0,
      73,
      4,
      "INT"
    ],
    [
      277,
      147,
      0,
      152,
      0,
      "IMAGE"
    ],
    [
      281,
      65,
      0,
      27,
      2,
      "WANVIDEOTEXTEMBEDS"
    ],
    [
      286,
      150,
      0,
      64,
      2,
      "INT"
    ],
    [
      287,
      151,
      0,
      64,
      3,
      "INT"
    ],
    [
      289,
      171,
      0,
      48,
      1,
      "WANVIDLORA"
    ],
    [
      291,
      64,
      0,
      172,
      0,
      "IMAGE"
    ],
    [
      292,
      73,
      0,
      174,
      0,
      "IMAGE"
    ],
    [
      293,
      63,
      0,
      107,
      0,
      "IMAGE"
    ],
    [
      294,
      63,
      0,
      104,
      1,
      "IMAGE"
    ],
    [
      295,
      38,
      0,
      28,
      0,
      "WANVAE"
    ],
    [
      296,
      38,
      0,
      62,
      0,
      "WANVAE"
    ],
    [
      298,
      63,
      0,
      99,
      0,
      "IMAGE"
    ],
    [
      299,
      63,
      1,
      62,
      9,
      "INT"
    ],
    [
      301,
      108,
      0,
      99,
      1,
      "MASK"
    ],
    [
      302,
      108,
      0,
      62,
      6,
      "MASK"
    ],
    [
      303,
      99,
      0,
      62,
      5,
      "IMAGE"
    ],
    [
      304,
      99,
      0,
      75,
      0,
      "IMAGE"
    ],
    [
      308,
      73,
      0,
      62,
      3,
      "IMAGE"
    ],
    [
      309,
      96,
      0,
      62,
      4,
      "IMAGE"
    ],
    [
      310,
      64,
      0,
      62,
      2,
      "IMAGE"
    ],
    [
      311,
      64,
      0,
      70,
      1,
      "IMAGE"
    ],
    [
      312,
      150,
      0,
      62,
      7,
      "INT"
    ],
    [
      313,
      151,
      0,
      62,
      8,
      "INT"
    ],
    [
      314,
      96,
      0,
      112,
      0,
      "IMAGE"
    ],
    [
      316,
      150,
      0,
      63,
      4,
      "INT"
    ],
    [
      317,
      151,
      0,
      63,
      5,
      "INT"
    ],
    [
      320,
      28,
      0,
      176,
      0,
      "IMAGE"
    ]
  ],
  "groups": [
    {
      "id": 1,
      "title": "Reference Image",
      "bounding": [
        -1233.843017578125,
        -1928.8170166015625,
        990.079833984375,
        724.450439453125
      ],
      "color": "#3f789e",
      "flags": {}
    },
    {
      "id": 2,
      "title": "Face Images",
      "bounding": [
        -218.45716857910156,
        -1924.0809326171875,
        1623.2474365234375,
        718.2835083007812
      ],
      "color": "#3f789e",
      "flags": {}
    },
    {
      "id": 3,
      "title": "Background Masking",
      "bounding": [
        -1298.0721435546875,
        -3520.046142578125,
        3074.854736328125,
        1429.7471923828125
      ],
      "color": "#3f789e",
      "flags": {}
    },
    {
      "id": 4,
      "title": "Models",
      "bounding": [
        -1228.357666015625,
        -1175.835693359375,
        1513.7882080078125,
        945.53369140625
      ],
      "color": "#88A",
      "flags": {}
    },
    {
      "id": 5,
      "title": "Result collage",
      "bounding": [
        313.5178527832031,
        -1168.5379638671875,
        1568.4383544921875,
        1004.9238891601562
      ],
      "color": "#3f789e",
      "flags": {}
    }
  ],
  "config": {},
  "extra": {
    "ds": {
      "scale": 0.34522712143931694,
      "offset": [
        3948.2092528249527,
        4929.159489378951
      ]
    },
    "frontendVersion": "1.23.4",
    "node_versions": {
      "ComfyUI-WanVideoWrapper": "5a2383621a05825d0d0437781afcb8552d9590fd",
      "ComfyUI-KJNodes": "a5bd3c86c8ed6b83c55c2d0e7a59515b15a0137f",
      "ComfyUI-VideoHelperSuite": "0a75c7958fe320efcb052f1d9f8451fd20c730a8"
    },
    "VHS_latentpreview": false,
    "VHS_latentpreviewrate": 0,
    "VHS_MetadataImage": true,
    "VHS_KeepIntermediate": true,
    "0246.VERSION": [
      0,
      0,
      4
    ],
    "links_added_by_ue": [],
    "ue_links": []
  },
  "version": 0.4
}
```
