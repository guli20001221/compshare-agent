# Text to Image (Anima)

- 来源类别：内置工作流蓝图
- 镜像内原始路径：`/ComfyUI/blueprints/Text to Image (Anima).json`
- 节点数量：1
- 连线数量：0

## 节点类型

- `a3c0dab6-b250-4585-a0f9-8fb8b074fb2f` × 1

## 原始工作流 JSON

```json
{
  "revision": 0,
  "last_node_id": 60,
  "last_link_id": 0,
  "nodes": [
    {
      "id": 60,
      "type": "a3c0dab6-b250-4585-a0f9-8fb8b074fb2f",
      "pos": [
        -10,
        130
      ],
      "size": [
        500,
        640
      ],
      "flags": {},
      "order": 1,
      "mode": 0,
      "inputs": [
        {
          "label": "prompt",
          "name": "text",
          "type": "STRING",
          "widget": {
            "name": "text"
          },
          "link": null
        },
        {
          "name": "width",
          "type": "INT",
          "widget": {
            "name": "width"
          },
          "link": null
        },
        {
          "name": "height",
          "type": "INT",
          "widget": {
            "name": "height"
          },
          "link": null
        },
        {
          "name": "steps",
          "type": "INT",
          "widget": {
            "name": "steps"
          },
          "link": null
        },
        {
          "name": "cfg",
          "type": "FLOAT",
          "widget": {
            "name": "cfg"
          },
          "link": null
        },
        {
          "name": "seed",
          "type": "INT",
          "widget": {
            "name": "seed"
          },
          "link": null
        },
        {
          "name": "unet_name",
          "type": "COMBO",
          "widget": {
            "name": "unet_name"
          },
          "link": null
        },
        {
          "name": "clip_name",
          "type": "COMBO",
          "widget": {
            "name": "clip_name"
          },
          "link": null
        },
        {
          "name": "vae_name",
          "type": "COMBO",
          "widget": {
            "name": "vae_name"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "localized_name": "IMAGE",
          "name": "IMAGE",
          "type": "IMAGE",
          "links": []
        }
      ],
      "properties": {
        "proxyWidgets": [
          [
            "11",
            "text"
          ],
          [
            "28",
            "width"
          ],
          [
            "28",
            "height"
          ],
          [
            "19",
            "steps"
          ],
          [
            "19",
            "cfg"
          ],
          [
            "19",
            "seed"
          ],
          [
            "44",
            "unet_name"
          ],
          [
            "45",
            "clip_name"
          ],
          [
            "15",
            "vae_name"
          ]
        ],
        "cnr_id": "comfy-core",
        "ver": "0.18.1",
        "enableTabs": false,
        "tabWidth": 65,
        "tabXOffset": 10,
        "hasSecondTab": false,
        "secondTabText": "Send Back",
        "secondTabOffset": 80,
        "secondTabWidth": 65
      },
      "widgets_values": [],
      "title": "Text to Image (Anima)"
    }
  ],
  "links": [],
  "version": 0.4,
  "definitions": {
    "subgraphs": [
      {
        "id": "a3c0dab6-b250-4585-a0f9-8fb8b074fb2f",
        "version": 1,
        "state": {
          "lastGroupId": 3,
          "lastNodeId": 70,
          "lastLinkId": 104,
          "lastRerouteId": 0
        },
        "revision": 0,
        "config": {},
        "name": "Text to Image (Anima)",
        "inputNode": {
          "id": -10,
          "bounding": [
            -330,
            530,
            120,
            220
          ]
        },
        "outputNode": {
          "id": -20,
          "bounding": [
            1229.9999873482075,
            505,
            120,
            60
          ]
        },
        "inputs": [
          {
            "id": "4693f350-6ba0-446d-80d4-3038c661d26c",
            "name": "text",
            "type": "STRING",
            "linkIds": [
              95
            ],
            "label": "prompt",
            "pos": [
              -230,
              550
            ]
          },
          {
            "id": "4a7886a9-4ed7-49bb-afc2-977bb78a303d",
            "name": "width",
            "type": "INT",
            "linkIds": [
              96
            ],
            "pos": [
              -230,
              570
            ]
          },
          {
            "id": "f6c04461-d29e-49e3-8790-07bb662bbbfe",
            "name": "height",
            "type": "INT",
            "linkIds": [
              97
            ],
            "pos": [
              -230,
              590
            ]
          },
          {
            "id": "7a24f998-3808-4837-8bff-52304ad09fb6",
            "name": "steps",
            "type": "INT",
            "linkIds": [
              98
            ],
            "pos": [
              -230,
              610
            ]
          },
          {
            "id": "aaa99698-b222-40fe-b946-28067528a85c",
            "name": "cfg",
            "type": "FLOAT",
            "linkIds": [
              99
            ],
            "pos": [
              -230,
              630
            ]
          },
          {
            "id": "053df9ae-7311-4816-aa23-7fa13c656ced",
            "name": "seed",
            "type": "INT",
            "linkIds": [
              100
            ],
            "pos": [
              -230,
              650
            ]
          },
          {
            "id": "c59194ea-015c-41a7-8edd-ae7ffc220b63",
            "name": "unet_name",
            "type": "COMBO",
            "linkIds": [
              101
            ],
            "pos": [
              -230,
              670
            ]
          },
          {
            "id": "e655aa3b-2db7-4e25-9ea2-61550fa7ae2d",
            "name": "clip_name",
            "type": "COMBO",
            "linkIds": [
              102
            ],
            "pos": [
              -230,
              690
            ]
          },
          {
            "id": "94965a7a-74dd-4f5a-87e3-9f87995d554f",
            "name": "vae_name",
            "type": "COMBO",
            "linkIds": [
              103
            ],
            "pos": [
              -230,
              710
            ]
          }
        ],
        "outputs": [
          {
            "id": "ef85ac0a-2152-4232-bfa1-929cfc913718",
            "name": "IMAGE",
            "type": "IMAGE",
            "linkIds": [
              82
            ],
            "localized_name": "IMAGE",
            "pos": [
              1249.9999873482075,
              525
            ]
          }
        ],
        "widgets": [],
        "nodes": [
          {
            "id": 45,
            "type": "CLIPLoader",
            "pos": [
              -60,
              380
            ],
            "size": [
              310,
              150
            ],
            "flags": {},
            "order": 7,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "clip_name",
                "name": "clip_name",
                "type": "COMBO",
                "widget": {
                  "name": "clip_name"
                },
                "link": 102
              },
              {
                "localized_name": "type",
                "name": "type",
                "type": "COMBO",
                "widget": {
                  "name": "type"
                },
                "link": null
              },
              {
                "localized_name": "device",
                "name": "device",
                "shape": 7,
                "type": "COMBO",
                "widget": {
                  "name": "device"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "CLIP",
                "name": "CLIP",
                "type": "CLIP",
                "links": [
                  80,
                  81
                ]
              }
            ],
            "properties": {
              "Node name for S&R": "CLIPLoader",
              "cnr_id": "comfy-core",
              "ver": "0.11.0",
              "models": [
                {
                  "name": "qwen_3_06b_base.safetensors",
                  "url": "https://huggingface.co/circlestone-labs/Anima/resolve/main/split_files/text_encoders/qwen_3_06b_base.safetensors",
                  "directory": "text_encoders"
                }
              ],
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            },
            "widgets_values": [
              "qwen_3_06b_base.safetensors",
              "stable_diffusion",
              "default"
            ]
          },
          {
            "id": 15,
            "type": "VAELoader",
            "pos": [
              -50,
              610
            ],
            "size": [
              310,
              100
            ],
            "flags": {},
            "order": 3,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "vae_name",
                "name": "vae_name",
                "type": "COMBO",
                "widget": {
                  "name": "vae_name"
                },
                "link": 103
              }
            ],
            "outputs": [
              {
                "localized_name": "VAE",
                "name": "VAE",
                "type": "VAE",
                "links": [
                  11
                ]
              }
            ],
            "properties": {
              "Node name for S&R": "VAELoader",
              "cnr_id": "comfy-core",
              "ver": "0.3.40",
              "models": [
                {
                  "name": "qwen_image_vae.safetensors",
                  "url": "https://huggingface.co/circlestone-labs/Anima/resolve/main/split_files/vae/qwen_image_vae.safetensors",
                  "directory": "vae"
                }
              ],
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            },
            "widgets_values": [
              "qwen_image_vae.safetensors"
            ]
          },
          {
            "id": 8,
            "type": "VAEDecode",
            "pos": [
              880,
              840
            ],
            "size": [
              230,
              90
            ],
            "flags": {},
            "order": 0,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "samples",
                "name": "samples",
                "type": "LATENT",
                "link": 10
              },
              {
                "localized_name": "vae",
                "name": "vae",
                "type": "VAE",
                "link": 11
              }
            ],
            "outputs": [
              {
                "localized_name": "IMAGE",
                "name": "IMAGE",
                "type": "IMAGE",
                "slot_index": 0,
                "links": [
                  82
                ]
              }
            ],
            "properties": {
              "Node name for S&R": "VAEDecode",
              "cnr_id": "comfy-core",
              "ver": "0.3.40",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            }
          },
          {
            "id": 28,
            "type": "EmptyLatentImage",
            "pos": [
              -50,
              830
            ],
            "size": [
              310,
              150
            ],
            "flags": {},
            "order": 5,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "width",
                "name": "width",
                "type": "INT",
                "widget": {
                  "name": "width"
                },
                "link": 96
              },
              {
                "localized_name": "height",
                "name": "height",
                "type": "INT",
                "widget": {
                  "name": "height"
                },
                "link": 97
              },
              {
                "localized_name": "batch_size",
                "name": "batch_size",
                "type": "INT",
                "widget": {
                  "name": "batch_size"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "LATENT",
                "name": "LATENT",
                "type": "LATENT",
                "links": [
                  78
                ]
              }
            ],
            "properties": {
              "Node name for S&R": "EmptyLatentImage",
              "cnr_id": "comfy-core",
              "ver": "0.3.40",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            },
            "widgets_values": [
              1024,
              1024,
              1
            ]
          },
          {
            "id": 12,
            "type": "CLIPTextEncode",
            "pos": [
              330,
              830
            ],
            "size": [
              490,
              140
            ],
            "flags": {},
            "order": 2,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "clip",
                "name": "clip",
                "type": "CLIP",
                "link": 81
              },
              {
                "localized_name": "text",
                "name": "text",
                "type": "STRING",
                "widget": {
                  "name": "text"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "CONDITIONING",
                "name": "CONDITIONING",
                "type": "CONDITIONING",
                "links": [
                  40
                ]
              }
            ],
            "title": "CLIP Text Encode (Negative Prompt)",
            "properties": {
              "Node name for S&R": "CLIPTextEncode",
              "cnr_id": "comfy-core",
              "ver": "0.3.65",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            },
            "widgets_values": [
              "worst quality, low quality, score_1, score_2, score_3, blurry, jpeg artifacts, sepia"
            ],
            "color": "#223",
            "bgcolor": "#335"
          },
          {
            "id": 19,
            "type": "KSampler",
            "pos": [
              870,
              120
            ],
            "size": [
              300,
              620
            ],
            "flags": {},
            "order": 4,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "model",
                "name": "model",
                "type": "MODEL",
                "link": 79
              },
              {
                "localized_name": "positive",
                "name": "positive",
                "type": "CONDITIONING",
                "link": 39
              },
              {
                "localized_name": "negative",
                "name": "negative",
                "type": "CONDITIONING",
                "link": 40
              },
              {
                "localized_name": "latent_image",
                "name": "latent_image",
                "type": "LATENT",
                "link": 78
              },
              {
                "localized_name": "seed",
                "name": "seed",
                "type": "INT",
                "widget": {
                  "name": "seed"
                },
                "link": 100
              },
              {
                "localized_name": "steps",
                "name": "steps",
                "type": "INT",
                "widget": {
                  "name": "steps"
                },
                "link": 98
              },
              {
                "localized_name": "cfg",
                "name": "cfg",
                "type": "FLOAT",
                "widget": {
                  "name": "cfg"
                },
                "link": 99
              },
              {
                "localized_name": "sampler_name",
                "name": "sampler_name",
                "type": "COMBO",
                "widget": {
                  "name": "sampler_name"
                },
                "link": null
              },
              {
                "localized_name": "scheduler",
                "name": "scheduler",
                "type": "COMBO",
                "widget": {
                  "name": "scheduler"
                },
                "link": null
              },
              {
                "localized_name": "denoise",
                "name": "denoise",
                "type": "FLOAT",
                "widget": {
                  "name": "denoise"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "LATENT",
                "name": "LATENT",
                "type": "LATENT",
                "slot_index": 0,
                "links": [
                  10
                ]
              }
            ],
            "properties": {
              "Node name for S&R": "KSampler",
              "cnr_id": "comfy-core",
              "ver": "0.3.40",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            },
            "widgets_values": [
              0,
              "fixed",
              30,
              4,
              "er_sde",
              "simple",
              1
            ]
          },
          {
            "id": 11,
            "type": "CLIPTextEncode",
            "pos": [
              320,
              170
            ],
            "size": [
              490,
              610
            ],
            "flags": {},
            "order": 1,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "clip",
                "name": "clip",
                "type": "CLIP",
                "link": 80
              },
              {
                "localized_name": "text",
                "name": "text",
                "type": "STRING",
                "widget": {
                  "name": "text"
                },
                "link": 95
              }
            ],
            "outputs": [
              {
                "localized_name": "CONDITIONING",
                "name": "CONDITIONING",
                "type": "CONDITIONING",
                "links": [
                  39
                ]
              }
            ],
            "title": "CLIP Text Encode (Positive Prompt)",
            "properties": {
              "Node name for S&R": "CLIPTextEncode",
              "cnr_id": "comfy-core",
              "ver": "0.3.65",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            },
            "widgets_values": [
              ""
            ],
            "color": "#232",
            "bgcolor": "#353"
          },
          {
            "id": 44,
            "type": "UNETLoader",
            "pos": [
              -50,
              170
            ],
            "size": [
              310,
              130
            ],
            "flags": {},
            "order": 6,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "unet_name",
                "name": "unet_name",
                "type": "COMBO",
                "widget": {
                  "name": "unet_name"
                },
                "link": 101
              },
              {
                "localized_name": "weight_dtype",
                "name": "weight_dtype",
                "type": "COMBO",
                "widget": {
                  "name": "weight_dtype"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "MODEL",
                "name": "MODEL",
                "type": "MODEL",
                "links": [
                  79
                ]
              }
            ],
            "properties": {
              "Node name for S&R": "UNETLoader",
              "cnr_id": "comfy-core",
              "ver": "0.11.0",
              "models": [
                {
                  "name": "anima-base-v1.0.safetensors",
                  "url": "https://huggingface.co/circlestone-labs/Anima/resolve/main/split_files/diffusion_models/anima-base-v1.0.safetensors",
                  "directory": "diffusion_models"
                }
              ],
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            },
            "widgets_values": [
              "anima-base-v1.0.safetensors",
              "default"
            ]
          }
        ],
        "groups": [
          {
            "id": 1,
            "title": "Model",
            "bounding": [
              -80,
              80,
              360,
              640
            ],
            "color": "#3f789e",
            "flags": {}
          },
          {
            "id": 2,
            "title": "Image Size(1MP)",
            "bounding": [
              -80,
              750,
              360,
              240
            ],
            "color": "#3f789e",
            "flags": {}
          },
          {
            "id": 3,
            "title": "Prompt",
            "bounding": [
              300,
              80,
              530,
              910
            ],
            "color": "#3f789e",
            "flags": {}
          }
        ],
        "links": [
          {
            "id": 10,
            "origin_id": 19,
            "origin_slot": 0,
            "target_id": 8,
            "target_slot": 0,
            "type": "LATENT"
          },
          {
            "id": 11,
            "origin_id": 15,
            "origin_slot": 0,
            "target_id": 8,
            "target_slot": 1,
            "type": "VAE"
          },
          {
            "id": 81,
            "origin_id": 45,
            "origin_slot": 0,
            "target_id": 12,
            "target_slot": 0,
            "type": "CLIP"
          },
          {
            "id": 79,
            "origin_id": 44,
            "origin_slot": 0,
            "target_id": 19,
            "target_slot": 0,
            "type": "MODEL"
          },
          {
            "id": 39,
            "origin_id": 11,
            "origin_slot": 0,
            "target_id": 19,
            "target_slot": 1,
            "type": "CONDITIONING"
          },
          {
            "id": 40,
            "origin_id": 12,
            "origin_slot": 0,
            "target_id": 19,
            "target_slot": 2,
            "type": "CONDITIONING"
          },
          {
            "id": 78,
            "origin_id": 28,
            "origin_slot": 0,
            "target_id": 19,
            "target_slot": 3,
            "type": "LATENT"
          },
          {
            "id": 80,
            "origin_id": 45,
            "origin_slot": 0,
            "target_id": 11,
            "target_slot": 0,
            "type": "CLIP"
          },
          {
            "id": 82,
            "origin_id": 8,
            "origin_slot": 0,
            "target_id": -20,
            "target_slot": 0,
            "type": "IMAGE"
          },
          {
            "id": 95,
            "origin_id": -10,
            "origin_slot": 0,
            "target_id": 11,
            "target_slot": 1,
            "type": "STRING"
          },
          {
            "id": 96,
            "origin_id": -10,
            "origin_slot": 1,
            "target_id": 28,
            "target_slot": 0,
            "type": "INT"
          },
          {
            "id": 97,
            "origin_id": -10,
            "origin_slot": 2,
            "target_id": 28,
            "target_slot": 1,
            "type": "INT"
          },
          {
            "id": 98,
            "origin_id": -10,
            "origin_slot": 3,
            "target_id": 19,
            "target_slot": 5,
            "type": "INT"
          },
          {
            "id": 99,
            "origin_id": -10,
            "origin_slot": 4,
            "target_id": 19,
            "target_slot": 6,
            "type": "FLOAT"
          },
          {
            "id": 100,
            "origin_id": -10,
            "origin_slot": 5,
            "target_id": 19,
            "target_slot": 4,
            "type": "INT"
          },
          {
            "id": 101,
            "origin_id": -10,
            "origin_slot": 6,
            "target_id": 44,
            "target_slot": 0,
            "type": "COMBO"
          },
          {
            "id": 102,
            "origin_id": -10,
            "origin_slot": 7,
            "target_id": 45,
            "target_slot": 0,
            "type": "COMBO"
          },
          {
            "id": 103,
            "origin_id": -10,
            "origin_slot": 8,
            "target_id": 15,
            "target_slot": 0,
            "type": "COMBO"
          }
        ],
        "extra": {},
        "category": "Image generation and editing/Text to image",
        "description": "This subgraph converts text prompts into non-photorealistic illustrations using a 2-billion-parameter model optimized for anime and artistic styles. It is ideal for generating concept art, character designs, or stylized illustrations where photorealism is not required. The model excels with anime and artistic content but performs poorly on realistic subjects."
      }
    ]
  },
  "extra": {
    "BlueprintDescription": "This subgraph converts text prompts into non-photorealistic illustrations using a 2-billion-parameter model optimized for anime and artistic styles. It is ideal for generating concept art, character designs, or stylized illustrations where photorealism is not required. The model excels with anime and artistic content but performs poorly on realistic subjects."
  }
}
```
