# wan2.2图+文生视频5B模型工作流

- 来源类别：用户工作流
- 镜像内原始路径：`/ComfyUI/user/default/workflows/wan2.2系列/wan2.2图+文生视频5B模型工作流.json`
- 节点数量：12
- 连线数量：13

## 节点类型

- `CLIPTextEncode` × 2
- `CLIPLoader` × 1
- `CreateVideo` × 1
- `KSampler` × 1
- `LoadImage` × 1
- `ModelSamplingSD3` × 1
- `SaveVideo` × 1
- `UNETLoader` × 1
- `VAEDecode` × 1
- `VAELoader` × 1
- `Wan22ImageToVideoLatent` × 1

## 工作流引用的模型或媒体文件

- `caled.safetensors`
- `wan2.2_ti2v_5B_fp16.safetensors`
- `wan2.2_vae.safetensors`

## 原始工作流 JSON

```json
{
  "id": "91f6bbe2-ed41-4fd6-bac7-71d5b5864ecb",
  "revision": 0,
  "last_node_id": 59,
  "last_link_id": 108,
  "nodes": [
    {
      "id": 37,
      "type": "UNETLoader",
      "pos": [
        -30,
        50
      ],
      "size": [
        346.7470703125,
        82
      ],
      "flags": {},
      "order": 0,
      "mode": 0,
      "inputs": [
        {
          "localized_name": "UNET名称",
          "name": "unet_name",
          "type": "COMBO",
          "widget": {
            "name": "unet_name"
          },
          "link": null
        },
        {
          "localized_name": "剪枝类型",
          "name": "weight_dtype",
          "type": "COMBO",
          "widget": {
            "name": "weight_dtype"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "模型",
          "localized_name": "模型",
          "name": "MODEL",
          "type": "MODEL",
          "slot_index": 0,
          "links": [
            94
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.45",
        "Node name for S&R": "UNETLoader",
        "models": [
          {
            "name": "wan2.2_ti2v_5B_fp16.safetensors",
            "url": "https://huggingface.co/Comfy-Org/Wan_2.2_ComfyUI_Repackaged/resolve/main/split_files/diffusion_models/wan2.2_ti2v_5B_fp16.safetensors",
            "directory": "diffusion_models"
          }
        ]
      },
      "widgets_values": [
        "wan2.2_ti2v_5B_fp16.safetensors",
        "default"
      ]
    },
    {
      "id": 38,
      "type": "CLIPLoader",
      "pos": [
        -30,
        190
      ],
      "size": [
        350,
        110
      ],
      "flags": {},
      "order": 1,
      "mode": 0,
      "inputs": [
        {
          "localized_name": "CLIP名称",
          "name": "clip_name",
          "type": "COMBO",
          "widget": {
            "name": "clip_name"
          },
          "link": null
        },
        {
          "localized_name": "类型",
          "name": "type",
          "type": "COMBO",
          "widget": {
            "name": "type"
          },
          "link": null
        },
        {
          "localized_name": "设备",
          "name": "device",
          "shape": 7,
          "type": "COMBO",
          "widget": {
            "name": "device"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "CLIP",
          "localized_name": "CLIP",
          "name": "CLIP",
          "type": "CLIP",
          "slot_index": 0,
          "links": [
            74,
            75
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.45",
        "Node name for S&R": "CLIPLoader",
        "models": [
          {
            "name": "umt5_xxl_fp8_e4m3fn_scaled.safetensors",
            "url": "https://huggingface.co/Comfy-Org/Wan_2.1_ComfyUI_repackaged/resolve/main/split_files/text_encoders/umt5_xxl_fp8_e4m3fn_scaled.safetensors",
            "directory": "text_encoders"
          }
        ]
      },
      "widgets_values": [
        "umt5_xxl_fp8_e4m3fn_scaled.safetensors",
        "wan",
        "default"
      ]
    },
    {
      "id": 39,
      "type": "VAELoader",
      "pos": [
        -30,
        350
      ],
      "size": [
        350,
        60
      ],
      "flags": {},
      "order": 2,
      "mode": 0,
      "inputs": [
        {
          "localized_name": "vae名称",
          "name": "vae_name",
          "type": "COMBO",
          "widget": {
            "name": "vae_name"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "localized_name": "VAE",
          "name": "VAE",
          "type": "VAE",
          "slot_index": 0,
          "links": [
            76,
            105
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.45",
        "Node name for S&R": "VAELoader",
        "models": [
          {
            "name": "wan2.2_vae.safetensors",
            "url": "https://huggingface.co/Comfy-Org/Wan_2.2_ComfyUI_Repackaged/resolve/main/split_files/vae/wan2.2_vae.safetensors",
            "directory": "vae"
          }
        ]
      },
      "widgets_values": [
        "wan2.2_vae.safetensors"
      ]
    },
    {
      "id": 8,
      "type": "VAEDecode",
      "pos": [
        1190,
        150
      ],
      "size": [
        210,
        46
      ],
      "flags": {},
      "order": 9,
      "mode": 0,
      "inputs": [
        {
          "label": "Latent",
          "localized_name": "Latent",
          "name": "samples",
          "type": "LATENT",
          "link": 35
        },
        {
          "label": "VAE",
          "localized_name": "vae",
          "name": "vae",
          "type": "VAE",
          "link": 76
        }
      ],
      "outputs": [
        {
          "label": "图像",
          "localized_name": "图像",
          "name": "IMAGE",
          "type": "IMAGE",
          "slot_index": 0,
          "links": [
            107
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.45",
        "Node name for S&R": "VAEDecode"
      },
      "widgets_values": []
    },
    {
      "id": 57,
      "type": "CreateVideo",
      "pos": [
        1200,
        240
      ],
      "size": [
        270,
        78
      ],
      "flags": {},
      "order": 10,
      "mode": 0,
      "inputs": [
        {
          "label": "images",
          "localized_name": "图像",
          "name": "images",
          "type": "IMAGE",
          "link": 107
        },
        {
          "label": "audio",
          "localized_name": "音频",
          "name": "audio",
          "shape": 7,
          "type": "AUDIO",
          "link": null
        },
        {
          "label": "fps",
          "localized_name": "帧率",
          "name": "fps",
          "type": "FLOAT",
          "widget": {
            "name": "fps"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "VIDEO",
          "localized_name": "视频",
          "name": "VIDEO",
          "type": "VIDEO",
          "links": [
            108
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.45",
        "Node name for S&R": "CreateVideo"
      },
      "widgets_values": [
        24
      ]
    },
    {
      "id": 58,
      "type": "SaveVideo",
      "pos": [
        1200,
        370
      ],
      "size": [
        660,
        450
      ],
      "flags": {},
      "order": 11,
      "mode": 0,
      "inputs": [
        {
          "label": "video",
          "localized_name": "视频",
          "name": "video",
          "type": "VIDEO",
          "link": 108
        },
        {
          "label": "filename_prefix",
          "localized_name": "文件名前缀",
          "name": "filename_prefix",
          "type": "STRING",
          "widget": {
            "name": "filename_prefix"
          },
          "link": null
        },
        {
          "label": "format",
          "localized_name": "格式",
          "name": "format",
          "type": "COMBO",
          "widget": {
            "name": "format"
          },
          "link": null
        },
        {
          "label": "codec",
          "localized_name": "编码器",
          "name": "codec",
          "type": "COMBO",
          "widget": {
            "name": "codec"
          },
          "link": null
        }
      ],
      "outputs": [],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.45",
        "Node name for S&R": "SaveVideo"
      },
      "widgets_values": [
        "video/ComfyUI",
        "auto",
        "auto"
      ]
    },
    {
      "id": 55,
      "type": "Wan22ImageToVideoLatent",
      "pos": [
        380,
        540
      ],
      "size": [
        271.9126892089844,
        150
      ],
      "flags": {},
      "order": 7,
      "mode": 0,
      "inputs": [
        {
          "label": "vae",
          "localized_name": "vae",
          "name": "vae",
          "type": "VAE",
          "link": 105
        },
        {
          "label": "start_image",
          "localized_name": "start_image",
          "name": "start_image",
          "shape": 7,
          "type": "IMAGE",
          "link": 106
        },
        {
          "label": "width",
          "localized_name": "width",
          "name": "width",
          "type": "INT",
          "widget": {
            "name": "width"
          },
          "link": null
        },
        {
          "label": "height",
          "localized_name": "height",
          "name": "height",
          "type": "INT",
          "widget": {
            "name": "height"
          },
          "link": null
        },
        {
          "label": "length",
          "localized_name": "length",
          "name": "length",
          "type": "INT",
          "widget": {
            "name": "length"
          },
          "link": null
        },
        {
          "label": "batch_size",
          "localized_name": "batch_size",
          "name": "batch_size",
          "type": "INT",
          "widget": {
            "name": "batch_size"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "LATENT",
          "localized_name": "Latent",
          "name": "LATENT",
          "type": "LATENT",
          "links": [
            104
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.45",
        "Node name for S&R": "Wan22ImageToVideoLatent"
      },
      "widgets_values": [
        1280,
        704,
        121,
        1
      ]
    },
    {
      "id": 56,
      "type": "LoadImage",
      "pos": [
        0,
        540
      ],
      "size": [
        274.080078125,
        314
      ],
      "flags": {},
      "order": 3,
      "mode": 4,
      "inputs": [
        {
          "localized_name": "图像",
          "name": "image",
          "type": "COMBO",
          "widget": {
            "name": "image"
          },
          "link": null
        },
        {
          "localized_name": "选择文件上传",
          "name": "upload",
          "type": "IMAGEUPLOAD",
          "widget": {
            "name": "upload"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "图像",
          "localized_name": "图像",
          "name": "IMAGE",
          "type": "IMAGE",
          "links": [
            106
          ]
        },
        {
          "label": "遮罩",
          "localized_name": "遮罩",
          "name": "MASK",
          "type": "MASK",
          "links": null
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.45",
        "Node name for S&R": "LoadImage"
      },
      "widgets_values": [
        "example.png",
        "image"
      ]
    },
    {
      "id": 7,
      "type": "CLIPTextEncode",
      "pos": [
        380,
        260
      ],
      "size": [
        425.27801513671875,
        180.6060791015625
      ],
      "flags": {},
      "order": 6,
      "mode": 0,
      "inputs": [
        {
          "label": "CLIP",
          "localized_name": "clip",
          "name": "clip",
          "type": "CLIP",
          "link": 75
        },
        {
          "localized_name": "文本",
          "name": "text",
          "type": "STRING",
          "widget": {
            "name": "text"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "条件",
          "localized_name": "条件",
          "name": "CONDITIONING",
          "type": "CONDITIONING",
          "slot_index": 0,
          "links": [
            52
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.45",
        "Node name for S&R": "CLIPTextEncode"
      },
      "widgets_values": [
        "色调艳丽，过曝，静态，细节模糊不清，字幕，风格，作品，画作，画面，静止，整体发灰，最差质量，低质量，JPEG压缩残留，丑陋的，残缺的，多余的手指，画得不好的手部，画得不好的脸部，畸形的，毁容的，形态畸形的肢体，手指融合，静止不动的画面，杂乱的背景，三条腿，背景人很多，倒着走"
      ],
      "color": "#322",
      "bgcolor": "#533"
    },
    {
      "id": 6,
      "type": "CLIPTextEncode",
      "pos": [
        380,
        50
      ],
      "size": [
        422.84503173828125,
        164.31304931640625
      ],
      "flags": {},
      "order": 5,
      "mode": 0,
      "inputs": [
        {
          "label": "CLIP",
          "localized_name": "clip",
          "name": "clip",
          "type": "CLIP",
          "link": 74
        },
        {
          "localized_name": "文本",
          "name": "text",
          "type": "STRING",
          "widget": {
            "name": "text"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "条件",
          "localized_name": "条件",
          "name": "CONDITIONING",
          "type": "CONDITIONING",
          "slot_index": 0,
          "links": [
            46
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.45",
        "Node name for S&R": "CLIPTextEncode"
      },
      "widgets_values": [
        "Low contrast. In a retro 1970s-style subway station, a street musician plays in dim colors and rough textures. He wears an old jacket, playing guitar with focus. Commuters hurry by, and a small crowd gathers to listen. The camera slowly moves right, capturing the blend of music and city noise, with old subway signs and mottled walls in the background."
      ],
      "color": "#232",
      "bgcolor": "#353"
    },
    {
      "id": 3,
      "type": "KSampler",
      "pos": [
        850,
        130
      ],
      "size": [
        315,
        262
      ],
      "flags": {},
      "order": 8,
      "mode": 0,
      "inputs": [
        {
          "label": "模型",
          "localized_name": "模型",
          "name": "model",
          "type": "MODEL",
          "link": 95
        },
        {
          "label": "正面条件",
          "localized_name": "正面条件",
          "name": "positive",
          "type": "CONDITIONING",
          "link": 46
        },
        {
          "label": "负面条件",
          "localized_name": "负面条件",
          "name": "negative",
          "type": "CONDITIONING",
          "link": 52
        },
        {
          "label": "Latent",
          "localized_name": "Latent图像",
          "name": "latent_image",
          "type": "LATENT",
          "link": 104
        },
        {
          "localized_name": "随机种",
          "name": "seed",
          "type": "INT",
          "widget": {
            "name": "seed"
          },
          "link": null
        },
        {
          "localized_name": "步数",
          "name": "steps",
          "type": "INT",
          "widget": {
            "name": "steps"
          },
          "link": null
        },
        {
          "localized_name": "CFG",
          "name": "cfg",
          "type": "FLOAT",
          "widget": {
            "name": "cfg"
          },
          "link": null
        },
        {
          "localized_name": "采样器",
          "name": "sampler_name",
          "type": "COMBO",
          "widget": {
            "name": "sampler_name"
          },
          "link": null
        },
        {
          "localized_name": "调度器",
          "name": "scheduler",
          "type": "COMBO",
          "widget": {
            "name": "scheduler"
          },
          "link": null
        },
        {
          "localized_name": "降噪",
          "name": "denoise",
          "type": "FLOAT",
          "widget": {
            "name": "denoise"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "Latent",
          "localized_name": "Latent",
          "name": "LATENT",
          "type": "LATENT",
          "slot_index": 0,
          "links": [
            35
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.45",
        "Node name for S&R": "KSampler"
      },
      "widgets_values": [
        898471028164125,
        "randomize",
        20,
        5,
        "uni_pc",
        "simple",
        1
      ]
    },
    {
      "id": 48,
      "type": "ModelSamplingSD3",
      "pos": [
        850,
        20
      ],
      "size": [
        210,
        58
      ],
      "flags": {
        "collapsed": false
      },
      "order": 4,
      "mode": 0,
      "inputs": [
        {
          "label": "模型",
          "localized_name": "模型",
          "name": "model",
          "type": "MODEL",
          "link": 94
        },
        {
          "localized_name": "偏移",
          "name": "shift",
          "type": "FLOAT",
          "widget": {
            "name": "shift"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "模型",
          "localized_name": "模型",
          "name": "MODEL",
          "type": "MODEL",
          "slot_index": 0,
          "links": [
            95
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.45",
        "Node name for S&R": "ModelSamplingSD3"
      },
      "widgets_values": [
        8
      ]
    }
  ],
  "links": [
    [
      35,
      3,
      0,
      8,
      0,
      "LATENT"
    ],
    [
      46,
      6,
      0,
      3,
      1,
      "CONDITIONING"
    ],
    [
      52,
      7,
      0,
      3,
      2,
      "CONDITIONING"
    ],
    [
      74,
      38,
      0,
      6,
      0,
      "CLIP"
    ],
    [
      75,
      38,
      0,
      7,
      0,
      "CLIP"
    ],
    [
      76,
      39,
      0,
      8,
      1,
      "VAE"
    ],
    [
      94,
      37,
      0,
      48,
      0,
      "MODEL"
    ],
    [
      95,
      48,
      0,
      3,
      0,
      "MODEL"
    ],
    [
      104,
      55,
      0,
      3,
      3,
      "LATENT"
    ],
    [
      105,
      39,
      0,
      55,
      0,
      "VAE"
    ],
    [
      106,
      56,
      0,
      55,
      1,
      "IMAGE"
    ],
    [
      107,
      8,
      0,
      57,
      0,
      "IMAGE"
    ],
    [
      108,
      57,
      0,
      58,
      0,
      "VIDEO"
    ]
  ],
  "groups": [
    {
      "id": 1,
      "title": "Step1 - Load models",
      "bounding": [
        -50,
        -20,
        400,
        453.6000061035156
      ],
      "color": "#3f789e",
      "font_size": 24,
      "flags": {}
    },
    {
      "id": 2,
      "title": "Step3 - Prompt",
      "bounding": [
        370,
        -20,
        448.27801513671875,
        473.2060852050781
      ],
      "color": "#3f789e",
      "font_size": 24,
      "flags": {}
    },
    {
      "id": 3,
      "title": "For i2v, use Ctrl + B to enable",
      "bounding": [
        -50,
        450,
        400,
        420
      ],
      "color": "#3f789e",
      "font_size": 24,
      "flags": {}
    },
    {
      "id": 4,
      "title": "Video Size & length",
      "bounding": [
        370,
        470,
        291.9127197265625,
        233.60000610351562
      ],
      "color": "#3f789e",
      "font_size": 24,
      "flags": {}
    }
  ],
  "config": {},
  "extra": {
    "ds": {
      "scale": 0.8390545288824454,
      "offset": [
        1207.279365507181,
        516.6275859229072
      ]
    },
    "frontendVersion": "1.25.1",
    "VHS_latentpreview": false,
    "VHS_latentpreviewrate": 0,
    "VHS_MetadataImage": true,
    "VHS_KeepIntermediate": true
  },
  "version": 0.4
}
```
