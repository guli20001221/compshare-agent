# kontext基础工作流最终

- 来源类别：用户工作流
- 镜像内原始路径：`/ComfyUI/user/default/workflows/kontext系列/kontext基础工作流最终.json`
- 节点数量：17
- 连线数量：20

## 节点类型

- `FluxKontextImageScale` × 2
- `LoadImage` × 2
- `ReferenceLatent` × 2
- `VAEEncode` × 2
- `CLIPTextEncode` × 1
- `ConditioningZeroOut` × 1
- `DualCLIPLoader` × 1
- `FluxGuidance` × 1
- `KSampler` × 1
- `SaveImage` × 1
- `UNETLoader` × 1
- `VAEDecode` × 1
- `VAELoader` × 1

## 工作流引用的模型或媒体文件

- `clip_l.safetensors`
- `flux1-kontext-dev.safetensors`
- `t5xxl_fp8_e4m3fn.safetensors`

## 原始工作流 JSON

```json
{
  "id": "6e26cd71-7200-42cb-acd9-0614a3a6e148",
  "revision": 0,
  "last_node_id": 25,
  "last_link_id": 37,
  "nodes": [
    {
      "id": 5,
      "type": "FluxGuidance",
      "pos": [
        2630,
        2440
      ],
      "size": [
        315,
        58
      ],
      "flags": {},
      "order": 13,
      "mode": 0,
      "inputs": [
        {
          "label": "条件",
          "localized_name": "条件",
          "name": "conditioning",
          "type": "CONDITIONING",
          "link": 30
        },
        {
          "localized_name": "引导",
          "name": "guidance",
          "type": "FLOAT",
          "widget": {
            "name": "guidance"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "条件",
          "localized_name": "条件",
          "name": "CONDITIONING",
          "type": "CONDITIONING",
          "links": [
            4
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.47",
        "Node name for S&R": "FluxGuidance",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        2.5
      ]
    },
    {
      "id": 6,
      "type": "ReferenceLatent",
      "pos": [
        2630,
        2190
      ],
      "size": [
        308.92730712890625,
        46
      ],
      "flags": {},
      "order": 11,
      "mode": 0,
      "inputs": [
        {
          "label": "conditioning",
          "localized_name": "conditioning",
          "name": "conditioning",
          "type": "CONDITIONING",
          "link": 28
        },
        {
          "label": "latent",
          "localized_name": "latent",
          "name": "latent",
          "shape": 7,
          "type": "LATENT",
          "link": 10
        }
      ],
      "outputs": [
        {
          "label": "CONDITIONING",
          "localized_name": "条件",
          "name": "CONDITIONING",
          "type": "CONDITIONING",
          "links": [
            29
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.47",
        "Node name for S&R": "ReferenceLatent",
        "widget_ue_connectable": {}
      },
      "widgets_values": []
    },
    {
      "id": 15,
      "type": "ReferenceLatent",
      "pos": [
        2630,
        2280
      ],
      "size": [
        308.92730712890625,
        46
      ],
      "flags": {},
      "order": 12,
      "mode": 0,
      "inputs": [
        {
          "label": "conditioning",
          "localized_name": "conditioning",
          "name": "conditioning",
          "type": "CONDITIONING",
          "link": 29
        },
        {
          "label": "latent",
          "localized_name": "latent",
          "name": "latent",
          "shape": 7,
          "type": "LATENT",
          "link": 18
        }
      ],
      "outputs": [
        {
          "label": "CONDITIONING",
          "localized_name": "条件",
          "name": "CONDITIONING",
          "type": "CONDITIONING",
          "links": [
            30
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.47",
        "Node name for S&R": "ReferenceLatent",
        "widget_ue_connectable": {}
      },
      "widgets_values": []
    },
    {
      "id": 7,
      "type": "ConditioningZeroOut",
      "pos": [
        2630,
        2370
      ],
      "size": [
        310,
        30
      ],
      "flags": {},
      "order": 9,
      "mode": 0,
      "inputs": [
        {
          "label": "条件",
          "localized_name": "条件",
          "name": "conditioning",
          "type": "CONDITIONING",
          "link": 6
        }
      ],
      "outputs": [
        {
          "label": "条件",
          "localized_name": "条件",
          "name": "CONDITIONING",
          "type": "CONDITIONING",
          "links": [
            5
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.47",
        "Node name for S&R": "ConditioningZeroOut",
        "widget_ue_connectable": {}
      },
      "widgets_values": []
    },
    {
      "id": 12,
      "type": "VAEDecode",
      "pos": [
        2630,
        2540
      ],
      "size": [
        310,
        46
      ],
      "flags": {},
      "order": 15,
      "mode": 0,
      "inputs": [
        {
          "label": "Latent",
          "localized_name": "Latent",
          "name": "samples",
          "type": "LATENT",
          "link": 12
        },
        {
          "label": "VAE",
          "localized_name": "vae",
          "name": "vae",
          "type": "VAE",
          "link": 13
        }
      ],
      "outputs": [
        {
          "label": "图像",
          "localized_name": "图像",
          "name": "IMAGE",
          "type": "IMAGE",
          "links": [
            36
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.47",
        "Node name for S&R": "VAEDecode",
        "widget_ue_connectable": {}
      },
      "widgets_values": []
    },
    {
      "id": 8,
      "type": "KSampler",
      "pos": [
        2950,
        2190
      ],
      "size": [
        312.5430908203125,
        474
      ],
      "flags": {},
      "order": 14,
      "mode": 0,
      "inputs": [
        {
          "label": "模型",
          "localized_name": "模型",
          "name": "model",
          "type": "MODEL",
          "link": 37
        },
        {
          "label": "正面条件",
          "localized_name": "正面条件",
          "name": "positive",
          "type": "CONDITIONING",
          "link": 4
        },
        {
          "label": "负面条件",
          "localized_name": "负面条件",
          "name": "negative",
          "type": "CONDITIONING",
          "link": 5
        },
        {
          "label": "Latent",
          "localized_name": "Latent图像",
          "name": "latent_image",
          "type": "LATENT",
          "link": 9
        },
        {
          "localized_name": "随机种",
          "name": "seed",
          "type": "INT",
          "widget": {
            "name": "seed"
          },
          "link": null
        },
        {
          "localized_name": "步数",
          "name": "steps",
          "type": "INT",
          "widget": {
            "name": "steps"
          },
          "link": null
        },
        {
          "localized_name": "CFG",
          "name": "cfg",
          "type": "FLOAT",
          "widget": {
            "name": "cfg"
          },
          "link": null
        },
        {
          "localized_name": "采样器",
          "name": "sampler_name",
          "type": "COMBO",
          "widget": {
            "name": "sampler_name"
          },
          "link": null
        },
        {
          "localized_name": "调度器",
          "name": "scheduler",
          "type": "COMBO",
          "widget": {
            "name": "scheduler"
          },
          "link": null
        },
        {
          "localized_name": "降噪",
          "name": "denoise",
          "type": "FLOAT",
          "widget": {
            "name": "denoise"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "Latent",
          "localized_name": "Latent",
          "name": "LATENT",
          "type": "LATENT",
          "links": [
            12
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.47",
        "Node name for S&R": "KSampler",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        641902170004529,
        "randomize",
        20,
        1,
        "euler",
        "beta",
        1
      ]
    },
    {
      "id": 25,
      "type": "SaveImage",
      "pos": [
        3280,
        2200
      ],
      "size": [
        370,
        400
      ],
      "flags": {},
      "order": 16,
      "mode": 0,
      "inputs": [
        {
          "label": "图像",
          "localized_name": "图片",
          "name": "images",
          "type": "IMAGE",
          "link": 36
        },
        {
          "localized_name": "文件名前缀",
          "name": "filename_prefix",
          "type": "STRING",
          "widget": {
            "name": "filename_prefix"
          },
          "link": null
        }
      ],
      "outputs": [],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.47",
        "Node name for S&R": "SaveImage",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "ComfyUI"
      ]
    },
    {
      "id": 16,
      "type": "VAEEncode",
      "pos": [
        2580,
        1810
      ],
      "size": [
        190,
        46
      ],
      "flags": {},
      "order": 8,
      "mode": 4,
      "inputs": [
        {
          "label": "图像",
          "localized_name": "像素",
          "name": "pixels",
          "type": "IMAGE",
          "link": 34
        },
        {
          "label": "VAE",
          "localized_name": "vae",
          "name": "vae",
          "type": "VAE",
          "link": 19
        }
      ],
      "outputs": [
        {
          "label": "Latent",
          "localized_name": "Latent",
          "name": "LATENT",
          "type": "LATENT",
          "links": [
            18
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.47",
        "Node name for S&R": "VAEEncode",
        "widget_ue_connectable": {}
      },
      "widgets_values": []
    },
    {
      "id": 17,
      "type": "FluxKontextImageScale",
      "pos": [
        2220,
        2450
      ],
      "size": [
        400,
        26
      ],
      "flags": {},
      "order": 7,
      "mode": 0,
      "inputs": [
        {
          "label": "image",
          "localized_name": "image",
          "name": "image",
          "type": "IMAGE",
          "link": 31
        }
      ],
      "outputs": [
        {
          "label": "IMAGE",
          "localized_name": "图像",
          "name": "IMAGE",
          "type": "IMAGE",
          "links": [
            20
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.47",
        "Node name for S&R": "FluxKontextImageScale",
        "widget_ue_connectable": {}
      },
      "widgets_values": []
    },
    {
      "id": 10,
      "type": "VAEEncode",
      "pos": [
        2220,
        2520
      ],
      "size": [
        400,
        46
      ],
      "flags": {},
      "order": 10,
      "mode": 0,
      "inputs": [
        {
          "label": "图像",
          "localized_name": "像素",
          "name": "pixels",
          "type": "IMAGE",
          "link": 20
        },
        {
          "label": "VAE",
          "localized_name": "vae",
          "name": "vae",
          "type": "VAE",
          "link": 11
        }
      ],
      "outputs": [
        {
          "label": "Latent",
          "localized_name": "Latent",
          "name": "LATENT",
          "type": "LATENT",
          "links": [
            9,
            10
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.47",
        "Node name for S&R": "VAEEncode",
        "widget_ue_connectable": {}
      },
      "widgets_values": []
    },
    {
      "id": 23,
      "type": "FluxKontextImageScale",
      "pos": [
        2580,
        1750
      ],
      "size": [
        187.75448608398438,
        26
      ],
      "flags": {},
      "order": 5,
      "mode": 4,
      "inputs": [
        {
          "label": "image",
          "localized_name": "image",
          "name": "image",
          "type": "IMAGE",
          "link": 33
        }
      ],
      "outputs": [
        {
          "label": "IMAGE",
          "localized_name": "图像",
          "name": "IMAGE",
          "type": "IMAGE",
          "links": [
            34
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.47",
        "Node name for S&R": "FluxKontextImageScale",
        "widget_ue_connectable": {}
      },
      "widgets_values": []
    },
    {
      "id": 22,
      "type": "LoadImage",
      "pos": [
        2250,
        1750
      ],
      "size": [
        315,
        314
      ],
      "flags": {},
      "order": 0,
      "mode": 4,
      "inputs": [
        {
          "localized_name": "图像",
          "name": "image",
          "type": "COMBO",
          "widget": {
            "name": "image"
          },
          "link": null
        },
        {
          "localized_name": "选择文件上传",
          "name": "upload",
          "type": "IMAGEUPLOAD",
          "widget": {
            "name": "upload"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "图像",
          "localized_name": "图像",
          "name": "IMAGE",
          "type": "IMAGE",
          "links": [
            33
          ]
        },
        {
          "label": "遮罩",
          "localized_name": "遮罩",
          "name": "MASK",
          "type": "MASK"
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.47",
        "Node name for S&R": "LoadImage",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "图片 55.png",
        "image"
      ]
    },
    {
      "id": 4,
      "type": "CLIPTextEncode",
      "pos": [
        2220,
        2190
      ],
      "size": [
        400,
        210
      ],
      "flags": {},
      "order": 6,
      "mode": 0,
      "inputs": [
        {
          "label": "CLIP",
          "localized_name": "clip",
          "name": "clip",
          "type": "CLIP",
          "link": 1
        },
        {
          "localized_name": "文本",
          "name": "text",
          "type": "STRING",
          "widget": {
            "name": "text"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "条件",
          "localized_name": "条件",
          "name": "CONDITIONING",
          "type": "CONDITIONING",
          "links": [
            6,
            28
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.47",
        "Node name for S&R": "CLIPTextEncode",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "Replace the background of the girl in the picture with a supermarket scene, with supermarket shelves and a sign with kontext in the background, while keeping the subject unchanged"
      ]
    },
    {
      "id": 3,
      "type": "DualCLIPLoader",
      "pos": [
        1890,
        2320
      ],
      "size": [
        315,
        130
      ],
      "flags": {},
      "order": 1,
      "mode": 0,
      "inputs": [
        {
          "localized_name": "CLIP1",
          "name": "clip_name1",
          "type": "COMBO",
          "widget": {
            "name": "clip_name1"
          },
          "link": null
        },
        {
          "localized_name": "CLIP2",
          "name": "clip_name2",
          "type": "COMBO",
          "widget": {
            "name": "clip_name2"
          },
          "link": null
        },
        {
          "localized_name": "类型",
          "name": "type",
          "type": "COMBO",
          "widget": {
            "name": "type"
          },
          "link": null
        },
        {
          "localized_name": "设备",
          "name": "device",
          "shape": 7,
          "type": "COMBO",
          "widget": {
            "name": "device"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "CLIP",
          "localized_name": "CLIP",
          "name": "CLIP",
          "type": "CLIP",
          "links": [
            1
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.47",
        "Node name for S&R": "DualCLIPLoader",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "clip_l.safetensors",
        "t5xxl_fp8_e4m3fn.safetensors",
        "flux",
        "default"
      ]
    },
    {
      "id": 11,
      "type": "VAELoader",
      "pos": [
        1890,
        2490
      ],
      "size": [
        315,
        58
      ],
      "flags": {},
      "order": 2,
      "mode": 0,
      "inputs": [
        {
          "localized_name": "vae名称",
          "name": "vae_name",
          "type": "COMBO",
          "widget": {
            "name": "vae_name"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "VAE",
          "localized_name": "VAE",
          "name": "VAE",
          "type": "VAE",
          "links": [
            11,
            13,
            19
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.47",
        "Node name for S&R": "VAELoader",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "ae.sft"
      ]
    },
    {
      "id": 2,
      "type": "UNETLoader",
      "pos": [
        1890,
        2200
      ],
      "size": [
        315,
        82
      ],
      "flags": {},
      "order": 3,
      "mode": 0,
      "inputs": [
        {
          "localized_name": "UNET名称",
          "name": "unet_name",
          "type": "COMBO",
          "widget": {
            "name": "unet_name"
          },
          "link": null
        },
        {
          "localized_name": "剪枝类型",
          "name": "weight_dtype",
          "type": "COMBO",
          "widget": {
            "name": "weight_dtype"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "模型",
          "localized_name": "模型",
          "name": "MODEL",
          "type": "MODEL",
          "links": [
            37
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.47",
        "Node name for S&R": "UNETLoader",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "flux1-kontext-dev.safetensors",
        "fp8_e4m3fn"
      ]
    },
    {
      "id": 21,
      "type": "LoadImage",
      "pos": [
        1910,
        1750
      ],
      "size": [
        315,
        314
      ],
      "flags": {},
      "order": 4,
      "mode": 0,
      "inputs": [
        {
          "localized_name": "图像",
          "name": "image",
          "type": "COMBO",
          "widget": {
            "name": "image"
          },
          "link": null
        },
        {
          "localized_name": "选择文件上传",
          "name": "upload",
          "type": "IMAGEUPLOAD",
          "widget": {
            "name": "upload"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "图像",
          "localized_name": "图像",
          "name": "IMAGE",
          "type": "IMAGE",
          "links": [
            31
          ]
        },
        {
          "label": "遮罩",
          "localized_name": "遮罩",
          "name": "MASK",
          "type": "MASK"
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.47",
        "Node name for S&R": "LoadImage",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "屏幕截图 2025-07-28 053136.png",
        "image"
      ]
    }
  ],
  "links": [
    [
      1,
      3,
      0,
      4,
      0,
      "CLIP"
    ],
    [
      4,
      5,
      0,
      8,
      1,
      "CONDITIONING"
    ],
    [
      5,
      7,
      0,
      8,
      2,
      "CONDITIONING"
    ],
    [
      6,
      4,
      0,
      7,
      0,
      "CONDITIONING"
    ],
    [
      9,
      10,
      0,
      8,
      3,
      "LATENT"
    ],
    [
      10,
      10,
      0,
      6,
      1,
      "LATENT"
    ],
    [
      11,
      11,
      0,
      10,
      1,
      "VAE"
    ],
    [
      12,
      8,
      0,
      12,
      0,
      "LATENT"
    ],
    [
      13,
      11,
      0,
      12,
      1,
      "VAE"
    ],
    [
      18,
      16,
      0,
      15,
      1,
      "LATENT"
    ],
    [
      19,
      11,
      0,
      16,
      1,
      "VAE"
    ],
    [
      20,
      17,
      0,
      10,
      0,
      "IMAGE"
    ],
    [
      28,
      4,
      0,
      6,
      0,
      "CONDITIONING"
    ],
    [
      29,
      6,
      0,
      15,
      0,
      "CONDITIONING"
    ],
    [
      30,
      15,
      0,
      5,
      0,
      "CONDITIONING"
    ],
    [
      31,
      21,
      0,
      17,
      0,
      "IMAGE"
    ],
    [
      33,
      22,
      0,
      23,
      0,
      "IMAGE"
    ],
    [
      34,
      23,
      0,
      16,
      0,
      "IMAGE"
    ],
    [
      36,
      12,
      0,
      25,
      0,
      "IMAGE"
    ],
    [
      37,
      2,
      0,
      8,
      0,
      "MODEL"
    ]
  ],
  "groups": [
    {
      "id": 3,
      "title": "图像加载区",
      "bounding": [
        1890,
        1670,
        930,
        420
      ],
      "color": "#3f789e",
      "font_size": 24,
      "flags": {}
    },
    {
      "id": 4,
      "title": "KONTEXT生图区",
      "bounding": [
        1880,
        2120,
        1840,
        570
      ],
      "color": "#3f789e",
      "font_size": 24,
      "flags": {}
    }
  ],
  "config": {},
  "extra": {
    "ds": {
      "scale": 0.9646149645000037,
      "offset": [
        -1338.1929275155812,
        -1621.86428196335
      ]
    },
    "frontendVersion": "1.23.4",
    "VHS_KeepIntermediate": true,
    "links_added_by_ue": [],
    "VHS_MetadataImage": true,
    "ue_links": [],
    "0246.VERSION": [
      0,
      0,
      4
    ],
    "VHS_latentpreviewrate": 0,
    "VHS_latentpreview": false
  },
  "version": 0.4
}
```
