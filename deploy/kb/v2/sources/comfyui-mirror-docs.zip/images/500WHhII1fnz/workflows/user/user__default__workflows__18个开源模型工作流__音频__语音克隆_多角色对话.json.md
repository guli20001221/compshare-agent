# 语音克隆+多角色对话

- 来源类别：用户工作流
- 镜像内原始路径：`/ComfyUI/user/default/workflows/18个开源模型工作流/音频/语音克隆+多角色对话.json`
- 节点数量：11
- 连线数量：12

## 节点类型

- `LoadAudio` × 2
- `Qwen3TTSVoiceClone` × 2
- `Qwen3TTSVoiceClonePromptSave` × 2
- `LayerUtility: TextBox` × 1
- `Qwen3TTSDialogueSynthesis` × 1
- `Qwen3TTSModelLoader` × 1
- `Qwen3TTSRolePresetsInput` × 1
- `SaveAudio` × 1

## 工作流引用的模型或媒体文件

- `001-1.mp4`
- `004-1.mp4`

## 原始工作流 JSON

```json
{
  "id": "bf692eb0-368e-4bce-b746-41e3ec05c56d",
  "revision": 0,
  "last_node_id": 12,
  "last_link_id": 15,
  "nodes": [
    {
      "id": 2,
      "type": "Qwen3TTSModelLoader",
      "pos": [
        2084.69140625,
        1092.179443359375
      ],
      "size": [
        414.28265380859375,
        129.5310821533203
      ],
      "flags": {},
      "order": 0,
      "mode": 0,
      "inputs": [],
      "outputs": [
        {
          "label": "模型",
          "name": "模型",
          "type": "QWEN3_TTS_MODEL",
          "links": [
            1,
            4,
            7
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "Qwen3TTSModelLoader"
      },
      "widgets_values": [
        "Qwen/Qwen3-TTS-12Hz-1.7B-Base",
        "cuda",
        "fp16"
      ]
    },
    {
      "id": 5,
      "type": "LoadAudio",
      "pos": [
        2228.770751953125,
        1300.14501953125
      ],
      "size": [
        270,
        136
      ],
      "flags": {},
      "order": 1,
      "mode": 0,
      "inputs": [],
      "outputs": [
        {
          "label": "音频",
          "name": "AUDIO",
          "type": "AUDIO",
          "links": [
            5
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.5.1",
        "Node name for S&R": "LoadAudio"
      },
      "widgets_values": [
        "001-1.mp4",
        null,
        null
      ]
    },
    {
      "id": 4,
      "type": "Qwen3TTSVoiceClone",
      "pos": [
        2544.228759765625,
        1306.2525634765625
      ],
      "size": [
        400,
        450
      ],
      "flags": {},
      "order": 4,
      "mode": 0,
      "inputs": [
        {
          "label": "模型",
          "name": "模型",
          "type": "QWEN3_TTS_MODEL",
          "link": 4
        },
        {
          "label": "参考音频",
          "name": "参考音频",
          "type": "AUDIO",
          "link": 5
        }
      ],
      "outputs": [
        {
          "label": "音频",
          "name": "音频",
          "shape": 6,
          "type": "AUDIO",
          "links": null
        },
        {
          "label": "角色预设",
          "name": "角色预设",
          "type": "QWEN3_TTS_VOICE_PROMPT",
          "links": [
            11
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "Qwen3TTSVoiceClone"
      },
      "widgets_values": [
        "",
        "",
        "自动",
        false,
        2048,
        740161106432226,
        "fixed",
        1,
        false,
        0.8,
        50,
        0.8,
        1.1,
        false
      ]
    },
    {
      "id": 6,
      "type": "Qwen3TTSVoiceClone",
      "pos": [
        2550.996826171875,
        1813.492431640625
      ],
      "size": [
        400,
        450
      ],
      "flags": {},
      "order": 5,
      "mode": 0,
      "inputs": [
        {
          "label": "模型",
          "name": "模型",
          "type": "QWEN3_TTS_MODEL",
          "link": 7
        },
        {
          "label": "参考音频",
          "name": "参考音频",
          "type": "AUDIO",
          "link": 6
        }
      ],
      "outputs": [
        {
          "label": "音频",
          "name": "音频",
          "shape": 6,
          "type": "AUDIO",
          "links": null
        },
        {
          "label": "角色预设",
          "name": "角色预设",
          "type": "QWEN3_TTS_VOICE_PROMPT",
          "links": [
            13
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "Qwen3TTSVoiceClone"
      },
      "widgets_values": [
        "",
        "",
        "自动",
        false,
        2048,
        900735173986656,
        "fixed",
        1,
        false,
        0.8,
        50,
        0.8,
        1.1,
        false
      ]
    },
    {
      "id": 7,
      "type": "LoadAudio",
      "pos": [
        2255.485107421875,
        1820.3502197265625
      ],
      "size": [
        270,
        136
      ],
      "flags": {},
      "order": 2,
      "mode": 0,
      "inputs": [],
      "outputs": [
        {
          "label": "音频",
          "name": "AUDIO",
          "type": "AUDIO",
          "links": [
            6
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.5.1",
        "Node name for S&R": "LoadAudio"
      },
      "widgets_values": [
        "004-1.mp4",
        null,
        null
      ]
    },
    {
      "id": 10,
      "type": "Qwen3TTSVoiceClonePromptSave",
      "pos": [
        2983.901123046875,
        1317.0816650390625
      ],
      "size": [
        270,
        102
      ],
      "flags": {},
      "order": 6,
      "mode": 0,
      "inputs": [
        {
          "label": "角色预设",
          "name": "角色预设",
          "type": "QWEN3_TTS_VOICE_PROMPT",
          "link": 11
        }
      ],
      "outputs": [
        {
          "label": "文件路径",
          "name": "文件路径",
          "type": "STRING",
          "links": null
        },
        {
          "label": "角色预设",
          "name": "角色预设",
          "type": "QWEN3_TTS_VOICE_PROMPT",
          "links": [
            12
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "Qwen3TTSVoiceClonePromptSave"
      },
      "widgets_values": [
        "华强",
        ""
      ]
    },
    {
      "id": 11,
      "type": "Qwen3TTSVoiceClonePromptSave",
      "pos": [
        2987.550537109375,
        1818.181396484375
      ],
      "size": [
        270,
        102
      ],
      "flags": {},
      "order": 7,
      "mode": 0,
      "inputs": [
        {
          "label": "角色预设",
          "name": "角色预设",
          "type": "QWEN3_TTS_VOICE_PROMPT",
          "link": 13
        }
      ],
      "outputs": [
        {
          "label": "文件路径",
          "name": "文件路径",
          "type": "STRING",
          "links": null
        },
        {
          "label": "角色预设",
          "name": "角色预设",
          "type": "QWEN3_TTS_VOICE_PROMPT",
          "links": [
            14
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "Qwen3TTSVoiceClonePromptSave"
      },
      "widgets_values": [
        "老板",
        ""
      ]
    },
    {
      "id": 3,
      "type": "Qwen3TTSRolePresetsInput",
      "pos": [
        3580.308349609375,
        1312.4271240234375
      ],
      "size": [
        202.47909545898438,
        146
      ],
      "flags": {},
      "order": 8,
      "mode": 0,
      "inputs": [
        {
          "label": "已有角色预设",
          "name": "已有角色预设",
          "shape": 7,
          "type": "QWEN3_TTS_ROLE_PRESETS",
          "link": null
        },
        {
          "label": "角色预设1",
          "name": "角色预设1",
          "shape": 7,
          "type": "QWEN3_TTS_VOICE_PROMPT",
          "link": 12
        },
        {
          "label": "角色预设2",
          "name": "角色预设2",
          "shape": 7,
          "type": "QWEN3_TTS_VOICE_PROMPT",
          "link": 14
        },
        {
          "label": "角色预设3",
          "name": "角色预设3",
          "shape": 7,
          "type": "QWEN3_TTS_VOICE_PROMPT",
          "link": null
        },
        {
          "label": "角色预设4",
          "name": "角色预设4",
          "shape": 7,
          "type": "QWEN3_TTS_VOICE_PROMPT",
          "link": null
        },
        {
          "label": "角色预设5",
          "name": "角色预设5",
          "shape": 7,
          "type": "QWEN3_TTS_VOICE_PROMPT",
          "link": null
        },
        {
          "label": "角色预设6",
          "name": "角色预设6",
          "shape": 7,
          "type": "QWEN3_TTS_VOICE_PROMPT",
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "角色预设",
          "name": "角色预设",
          "type": "QWEN3_TTS_ROLE_PRESETS",
          "links": [
            2
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "Qwen3TTSRolePresetsInput"
      },
      "widgets_values": []
    },
    {
      "id": 1,
      "type": "Qwen3TTSDialogueSynthesis",
      "pos": [
        3815.074462890625,
        1298.284423828125
      ],
      "size": [
        400,
        450
      ],
      "flags": {},
      "order": 9,
      "mode": 0,
      "inputs": [
        {
          "label": "模型",
          "name": "模型",
          "type": "QWEN3_TTS_MODEL",
          "link": 1
        },
        {
          "label": "角色预设",
          "name": "角色预设",
          "shape": 7,
          "type": "QWEN3_TTS_ROLE_PRESETS",
          "link": 2
        },
        {
          "label": "对白文本",
          "name": "对白文本",
          "type": "STRING",
          "widget": {
            "name": "对白文本"
          },
          "link": 15
        }
      ],
      "outputs": [
        {
          "label": "音频",
          "name": "音频",
          "type": "AUDIO",
          "links": [
            9
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "Qwen3TTSDialogueSynthesis"
      },
      "widgets_values": [
        "",
        498460067834633,
        "randomize",
        1,
        "自动",
        "",
        true,
        false,
        2048,
        0.8,
        50,
        0.8,
        1.1,
        false
      ]
    },
    {
      "id": 12,
      "type": "LayerUtility: TextBox",
      "pos": [
        3389.380126953125,
        1525.806884765625
      ],
      "size": [
        400,
        200
      ],
      "flags": {},
      "order": 3,
      "mode": 0,
      "inputs": [],
      "outputs": [
        {
          "label": "text",
          "name": "text",
          "type": "STRING",
          "links": [
            15
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "LayerUtility: TextBox"
      },
      "widgets_values": [
        "老板:哥们你这瓜多少钱一斤哪\n华强:两块钱一斤\n老板:我操 你这瓜皮子是金子做的还是瓜粒子是金子做的\n华强:你瞧瞧现在这哪有瓜啊 你嫌贵 我还嫌贵呢\n\n"
      ],
      "color": "rgba(38, 73, 116, 0.7)"
    },
    {
      "id": 8,
      "type": "SaveAudio",
      "pos": [
        4256.04931640625,
        1282.72216796875
      ],
      "size": [
        270,
        112
      ],
      "flags": {},
      "order": 10,
      "mode": 0,
      "inputs": [
        {
          "label": "音频",
          "name": "audio",
          "type": "AUDIO",
          "link": 9
        }
      ],
      "outputs": [],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.5.1",
        "Node name for S&R": "SaveAudio"
      },
      "widgets_values": [
        "audio/ComfyUI"
      ]
    }
  ],
  "links": [
    [
      1,
      2,
      0,
      1,
      0,
      "QWEN3_TTS_MODEL"
    ],
    [
      2,
      3,
      0,
      1,
      1,
      "QWEN3_TTS_ROLE_PRESETS"
    ],
    [
      4,
      2,
      0,
      4,
      0,
      "QWEN3_TTS_MODEL"
    ],
    [
      5,
      5,
      0,
      4,
      1,
      "AUDIO"
    ],
    [
      6,
      7,
      0,
      6,
      1,
      "AUDIO"
    ],
    [
      7,
      2,
      0,
      6,
      0,
      "QWEN3_TTS_MODEL"
    ],
    [
      9,
      1,
      0,
      8,
      0,
      "AUDIO"
    ],
    [
      11,
      4,
      1,
      10,
      0,
      "QWEN3_TTS_VOICE_PROMPT"
    ],
    [
      12,
      10,
      1,
      3,
      1,
      "QWEN3_TTS_VOICE_PROMPT"
    ],
    [
      13,
      6,
      1,
      11,
      0,
      "QWEN3_TTS_VOICE_PROMPT"
    ],
    [
      14,
      11,
      1,
      3,
      2,
      "QWEN3_TTS_VOICE_PROMPT"
    ],
    [
      15,
      12,
      0,
      1,
      2,
      "STRING"
    ]
  ],
  "groups": [],
  "config": {},
  "extra": {
    "ds": {
      "scale": 0.8769226950000025,
      "offset": [
        -1956.693162180413,
        -885.2427274566815
      ]
    },
    "frontendVersion": "1.23.4",
    "VHS_latentpreview": false,
    "VHS_latentpreviewrate": 0,
    "VHS_MetadataImage": true,
    "VHS_KeepIntermediate": true
  },
  "version": 0.4
}
```
