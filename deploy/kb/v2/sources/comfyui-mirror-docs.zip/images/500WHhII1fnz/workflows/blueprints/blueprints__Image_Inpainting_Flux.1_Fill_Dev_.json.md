# Image Inpainting (Flux.1 Fill Dev)

- 来源类别：内置工作流蓝图
- 镜像内原始路径：`/ComfyUI/blueprints/Image Inpainting (Flux.1 Fill Dev).json`
- 节点数量：1
- 连线数量：0

## 节点类型

- `6e8d6e38-bdc3-436c-be85-ef9e67e70e07` × 1

## 原始工作流 JSON

```json
{
  "revision": 0,
  "last_node_id": 232,
  "last_link_id": 0,
  "nodes": [
    {
      "id": 232,
      "type": "6e8d6e38-bdc3-436c-be85-ef9e67e70e07",
      "pos": [
        1270,
        4640
      ],
      "size": [
        400,
        470
      ],
      "flags": {},
      "order": 0,
      "mode": 0,
      "inputs": [
        {
          "label": "image",
          "localized_name": "pixels",
          "name": "pixels",
          "type": "IMAGE",
          "link": null
        },
        {
          "localized_name": "mask",
          "name": "mask",
          "type": "MASK",
          "link": null
        },
        {
          "label": "prompt",
          "name": "text",
          "type": "STRING",
          "widget": {
            "name": "text"
          },
          "link": null
        },
        {
          "name": "seed",
          "type": "INT",
          "widget": {
            "name": "seed"
          },
          "link": null
        },
        {
          "name": "unet_name",
          "type": "COMBO",
          "widget": {
            "name": "unet_name"
          },
          "link": null
        },
        {
          "name": "clip_name1",
          "type": "COMBO",
          "widget": {
            "name": "clip_name1"
          },
          "link": null
        },
        {
          "name": "clip_name2",
          "type": "COMBO",
          "widget": {
            "name": "clip_name2"
          },
          "link": null
        },
        {
          "name": "vae_name",
          "type": "COMBO",
          "widget": {
            "name": "vae_name"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "localized_name": "IMAGE",
          "name": "IMAGE",
          "type": "IMAGE",
          "links": []
        }
      ],
      "properties": {
        "proxyWidgets": [
          [
            "23",
            "text"
          ],
          [
            "3",
            "seed"
          ],
          [
            "31",
            "unet_name"
          ],
          [
            "34",
            "clip_name1"
          ],
          [
            "34",
            "clip_name2"
          ],
          [
            "230",
            "vae_name"
          ]
        ],
        "ue_properties": {
          "widget_ue_connectable": {},
          "input_ue_unconnectable": {}
        },
        "cnr_id": "comfy-core",
        "ver": "0.18.1"
      },
      "widgets_values": [],
      "title": "Image Inpainting (Flux.1 Fill Dev)"
    }
  ],
  "links": [],
  "version": 0.4,
  "definitions": {
    "subgraphs": [
      {
        "id": "6e8d6e38-bdc3-436c-be85-ef9e67e70e07",
        "version": 1,
        "state": {
          "lastGroupId": 22,
          "lastNodeId": 232,
          "lastLinkId": 286,
          "lastRerouteId": 0
        },
        "revision": 0,
        "config": {},
        "name": "Image Inpainting (Flux.1 Fill Dev)",
        "inputNode": {
          "id": -10,
          "bounding": [
            -850,
            164,
            120,
            200
          ]
        },
        "outputNode": {
          "id": -20,
          "bounding": [
            1230,
            140,
            120,
            60
          ]
        },
        "inputs": [
          {
            "id": "65727ee9-09d0-40c9-bd86-11e0823eb676",
            "name": "pixels",
            "type": "IMAGE",
            "linkIds": [
              99
            ],
            "localized_name": "pixels",
            "label": "image",
            "pos": [
              -750,
              184
            ]
          },
          {
            "id": "28424f77-56c5-49c1-ba41-6bd78287c186",
            "name": "mask",
            "type": "MASK",
            "linkIds": [
              100
            ],
            "localized_name": "mask",
            "pos": [
              -750,
              204
            ]
          },
          {
            "id": "2339e5e0-8f8d-4600-b158-7d7dae5f0535",
            "name": "text",
            "type": "STRING",
            "linkIds": [
              277
            ],
            "label": "prompt",
            "pos": [
              -750,
              224
            ]
          },
          {
            "id": "5f433d9b-b97e-4bac-bb88-eb668de2d5a7",
            "name": "seed",
            "type": "INT",
            "linkIds": [
              282
            ],
            "pos": [
              -750,
              244
            ]
          },
          {
            "id": "35a8b6c1-c92c-4c1a-9b24-2e9bae7808f6",
            "name": "unet_name",
            "type": "COMBO",
            "linkIds": [
              283
            ],
            "pos": [
              -750,
              264
            ]
          },
          {
            "id": "3af8f8be-bce8-4ba0-aea0-ccf6b377d5f6",
            "name": "clip_name1",
            "type": "COMBO",
            "linkIds": [
              284
            ],
            "pos": [
              -750,
              284
            ]
          },
          {
            "id": "d9a4af80-4fa1-4792-b955-78bdaef4596e",
            "name": "clip_name2",
            "type": "COMBO",
            "linkIds": [
              285
            ],
            "pos": [
              -750,
              304
            ]
          },
          {
            "id": "d59398cf-7e9c-4dae-8c5a-08c4756f256a",
            "name": "vae_name",
            "type": "COMBO",
            "linkIds": [
              286
            ],
            "pos": [
              -750,
              324
            ]
          }
        ],
        "outputs": [
          {
            "id": "1dee24ec-54a8-41be-aa30-a8fb797d3d23",
            "name": "IMAGE",
            "type": "IMAGE",
            "linkIds": [
              95
            ],
            "localized_name": "IMAGE",
            "pos": [
              1250,
              160
            ]
          }
        ],
        "widgets": [],
        "nodes": [
          {
            "id": 34,
            "type": "DualCLIPLoader",
            "pos": [
              -590,
              150
            ],
            "size": [
              320,
              180
            ],
            "flags": {},
            "order": 3,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "clip_name1",
                "name": "clip_name1",
                "type": "COMBO",
                "widget": {
                  "name": "clip_name1"
                },
                "link": 284
              },
              {
                "localized_name": "clip_name2",
                "name": "clip_name2",
                "type": "COMBO",
                "widget": {
                  "name": "clip_name2"
                },
                "link": 285
              },
              {
                "localized_name": "type",
                "name": "type",
                "type": "COMBO",
                "widget": {
                  "name": "type"
                },
                "link": null
              },
              {
                "localized_name": "device",
                "name": "device",
                "shape": 7,
                "type": "COMBO",
                "widget": {
                  "name": "device"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "CLIP",
                "name": "CLIP",
                "type": "CLIP",
                "links": [
                  62
                ]
              }
            ],
            "properties": {
              "ue_properties": {
                "widget_ue_connectable": {},
                "input_ue_unconnectable": {}
              },
              "cnr_id": "comfy-core",
              "ver": "0.3.64",
              "Node name for S&R": "DualCLIPLoader",
              "models": [
                {
                  "name": "clip_l.safetensors",
                  "url": "https://huggingface.co/comfyanonymous/flux_text_encoders/resolve/main/clip_l.safetensors",
                  "directory": "text_encoders"
                },
                {
                  "name": "t5xxl_fp16.safetensors",
                  "url": "https://huggingface.co/comfyanonymous/flux_text_encoders/resolve/main/t5xxl_fp16.safetensors",
                  "directory": "text_encoders"
                }
              ]
            },
            "widgets_values": [
              "clip_l.safetensors",
              "t5xxl_fp16.safetensors",
              "flux",
              "default"
            ]
          },
          {
            "id": 229,
            "type": "FluxGuidance",
            "pos": [
              410,
              -40
            ],
            "size": [
              320,
              110
            ],
            "flags": {
              "collapsed": false
            },
            "order": 7,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "conditioning",
                "name": "conditioning",
                "type": "CONDITIONING",
                "link": 41
              },
              {
                "localized_name": "guidance",
                "name": "guidance",
                "type": "FLOAT",
                "widget": {
                  "name": "guidance"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "CONDITIONING",
                "name": "CONDITIONING",
                "type": "CONDITIONING",
                "slot_index": 0,
                "links": [
                  80
                ]
              }
            ],
            "properties": {
              "ue_properties": {
                "widget_ue_connectable": {},
                "input_ue_unconnectable": {}
              },
              "cnr_id": "comfy-core",
              "ver": "0.3.64",
              "Node name for S&R": "FluxGuidance"
            },
            "widgets_values": [
              30
            ]
          },
          {
            "id": 230,
            "type": "VAELoader",
            "pos": [
              -590,
              450
            ],
            "size": [
              320,
              110
            ],
            "flags": {},
            "order": 8,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "vae_name",
                "name": "vae_name",
                "type": "COMBO",
                "widget": {
                  "name": "vae_name"
                },
                "link": 286
              }
            ],
            "outputs": [
              {
                "localized_name": "VAE",
                "name": "VAE",
                "type": "VAE",
                "slot_index": 0,
                "links": [
                  60,
                  82
                ]
              }
            ],
            "properties": {
              "ue_properties": {
                "widget_ue_connectable": {},
                "input_ue_unconnectable": {}
              },
              "cnr_id": "comfy-core",
              "ver": "0.3.64",
              "Node name for S&R": "VAELoader",
              "models": [
                {
                  "name": "ae.safetensors",
                  "url": "https://huggingface.co/Comfy-Org/Lumina_Image_2.0_Repackaged/resolve/main/split_files/vae/ae.safetensors",
                  "directory": "vae"
                }
              ]
            },
            "widgets_values": [
              "ae.safetensors"
            ]
          },
          {
            "id": 31,
            "type": "UNETLoader",
            "pos": [
              -590,
              -90
            ],
            "size": [
              320,
              110
            ],
            "flags": {},
            "order": 2,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "unet_name",
                "name": "unet_name",
                "type": "COMBO",
                "widget": {
                  "name": "unet_name"
                },
                "link": 283
              },
              {
                "localized_name": "weight_dtype",
                "name": "weight_dtype",
                "type": "COMBO",
                "widget": {
                  "name": "weight_dtype"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "MODEL",
                "name": "MODEL",
                "type": "MODEL",
                "slot_index": 0,
                "links": [
                  85
                ]
              }
            ],
            "properties": {
              "ue_properties": {
                "widget_ue_connectable": {},
                "input_ue_unconnectable": {}
              },
              "cnr_id": "comfy-core",
              "ver": "0.3.64",
              "Node name for S&R": "UNETLoader",
              "models": [
                {
                  "name": "flux1-fill-dev.safetensors",
                  "url": "https://huggingface.co/Comfy-Org/flux1-dev/resolve/main/split_files/diffusion_models/flux1-fill-dev.safetensors",
                  "directory": "diffusion_models"
                }
              ]
            },
            "widgets_values": [
              "flux1-fill-dev.safetensors",
              "default"
            ]
          },
          {
            "id": 46,
            "type": "ConditioningZeroOut",
            "pos": [
              90,
              420
            ],
            "size": [
              230,
              80
            ],
            "flags": {},
            "order": 6,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "conditioning",
                "name": "conditioning",
                "type": "CONDITIONING",
                "link": 101
              }
            ],
            "outputs": [
              {
                "localized_name": "CONDITIONING",
                "name": "CONDITIONING",
                "type": "CONDITIONING",
                "links": [
                  102
                ]
              }
            ],
            "properties": {
              "ue_properties": {
                "widget_ue_connectable": {},
                "input_ue_unconnectable": {}
              },
              "cnr_id": "comfy-core",
              "ver": "0.3.64",
              "Node name for S&R": "ConditioningZeroOut"
            }
          },
          {
            "id": 23,
            "type": "CLIPTextEncode",
            "pos": [
              -160,
              -70
            ],
            "size": [
              480,
              410
            ],
            "flags": {},
            "order": 1,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "clip",
                "name": "clip",
                "type": "CLIP",
                "link": 62
              },
              {
                "localized_name": "text",
                "name": "text",
                "type": "STRING",
                "widget": {
                  "name": "text"
                },
                "link": 277
              }
            ],
            "outputs": [
              {
                "localized_name": "CONDITIONING",
                "name": "CONDITIONING",
                "type": "CONDITIONING",
                "slot_index": 0,
                "links": [
                  41,
                  101
                ]
              }
            ],
            "title": "CLIP Text Encode (Positive Prompt)",
            "properties": {
              "ue_properties": {
                "widget_ue_connectable": {},
                "input_ue_unconnectable": {}
              },
              "cnr_id": "comfy-core",
              "ver": "0.3.64",
              "Node name for S&R": "CLIPTextEncode"
            },
            "widgets_values": [
              ""
            ],
            "color": "#232",
            "bgcolor": "#353"
          },
          {
            "id": 39,
            "type": "DifferentialDiffusion",
            "pos": [
              780,
              -110
            ],
            "size": [
              280,
              110
            ],
            "flags": {},
            "order": 5,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "model",
                "name": "model",
                "type": "MODEL",
                "link": 85
              },
              {
                "localized_name": "strength",
                "name": "strength",
                "shape": 7,
                "type": "FLOAT",
                "widget": {
                  "name": "strength"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "MODEL",
                "name": "MODEL",
                "type": "MODEL",
                "slot_index": 0,
                "links": [
                  86
                ]
              }
            ],
            "properties": {
              "ue_properties": {
                "widget_ue_connectable": {},
                "input_ue_unconnectable": {}
              },
              "cnr_id": "comfy-core",
              "ver": "0.3.64",
              "Node name for S&R": "DifferentialDiffusion"
            },
            "widgets_values": [
              1
            ]
          },
          {
            "id": 231,
            "type": "VAEDecode",
            "pos": [
              780,
              590
            ],
            "size": [
              230,
              100
            ],
            "flags": {},
            "order": 9,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "samples",
                "name": "samples",
                "type": "LATENT",
                "link": 7
              },
              {
                "localized_name": "vae",
                "name": "vae",
                "type": "VAE",
                "link": 60
              }
            ],
            "outputs": [
              {
                "localized_name": "IMAGE",
                "name": "IMAGE",
                "type": "IMAGE",
                "slot_index": 0,
                "links": [
                  95
                ]
              }
            ],
            "properties": {
              "ue_properties": {
                "widget_ue_connectable": {},
                "input_ue_unconnectable": {}
              },
              "cnr_id": "comfy-core",
              "ver": "0.3.64",
              "Node name for S&R": "VAEDecode"
            }
          },
          {
            "id": 38,
            "type": "InpaintModelConditioning",
            "pos": [
              420,
              120
            ],
            "size": [
              310,
              200
            ],
            "flags": {},
            "order": 4,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "positive",
                "name": "positive",
                "type": "CONDITIONING",
                "link": 80
              },
              {
                "localized_name": "negative",
                "name": "negative",
                "type": "CONDITIONING",
                "link": 102
              },
              {
                "localized_name": "vae",
                "name": "vae",
                "type": "VAE",
                "link": 82
              },
              {
                "localized_name": "pixels",
                "name": "pixels",
                "type": "IMAGE",
                "link": 99
              },
              {
                "localized_name": "mask",
                "name": "mask",
                "type": "MASK",
                "link": 100
              },
              {
                "localized_name": "noise_mask",
                "name": "noise_mask",
                "type": "BOOLEAN",
                "widget": {
                  "name": "noise_mask"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "positive",
                "name": "positive",
                "type": "CONDITIONING",
                "slot_index": 0,
                "links": [
                  77
                ]
              },
              {
                "localized_name": "negative",
                "name": "negative",
                "type": "CONDITIONING",
                "slot_index": 1,
                "links": [
                  78
                ]
              },
              {
                "localized_name": "latent",
                "name": "latent",
                "type": "LATENT",
                "slot_index": 2,
                "links": [
                  88
                ]
              }
            ],
            "properties": {
              "ue_properties": {
                "widget_ue_connectable": {},
                "input_ue_unconnectable": {}
              },
              "cnr_id": "comfy-core",
              "ver": "0.3.64",
              "Node name for S&R": "InpaintModelConditioning"
            },
            "widgets_values": [
              true
            ]
          },
          {
            "id": 3,
            "type": "KSampler",
            "pos": [
              770,
              40
            ],
            "size": [
              290,
              470
            ],
            "flags": {},
            "order": 0,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "model",
                "name": "model",
                "type": "MODEL",
                "link": 86
              },
              {
                "localized_name": "positive",
                "name": "positive",
                "type": "CONDITIONING",
                "link": 77
              },
              {
                "localized_name": "negative",
                "name": "negative",
                "type": "CONDITIONING",
                "link": 78
              },
              {
                "localized_name": "latent_image",
                "name": "latent_image",
                "type": "LATENT",
                "link": 88
              },
              {
                "localized_name": "seed",
                "name": "seed",
                "type": "INT",
                "widget": {
                  "name": "seed"
                },
                "link": 282
              },
              {
                "localized_name": "steps",
                "name": "steps",
                "type": "INT",
                "widget": {
                  "name": "steps"
                },
                "link": null
              },
              {
                "localized_name": "cfg",
                "name": "cfg",
                "type": "FLOAT",
                "widget": {
                  "name": "cfg"
                },
                "link": null
              },
              {
                "localized_name": "sampler_name",
                "name": "sampler_name",
                "type": "COMBO",
                "widget": {
                  "name": "sampler_name"
                },
                "link": null
              },
              {
                "localized_name": "scheduler",
                "name": "scheduler",
                "type": "COMBO",
                "widget": {
                  "name": "scheduler"
                },
                "link": null
              },
              {
                "localized_name": "denoise",
                "name": "denoise",
                "type": "FLOAT",
                "widget": {
                  "name": "denoise"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "LATENT",
                "name": "LATENT",
                "type": "LATENT",
                "slot_index": 0,
                "links": [
                  7
                ]
              }
            ],
            "properties": {
              "ue_properties": {
                "widget_ue_connectable": {},
                "input_ue_unconnectable": {}
              },
              "cnr_id": "comfy-core",
              "ver": "0.3.64",
              "Node name for S&R": "KSampler"
            },
            "widgets_values": [
              0,
              "randomize",
              20,
              1,
              "euler",
              "normal",
              1
            ]
          }
        ],
        "groups": [
          {
            "id": 1,
            "title": "Load models",
            "bounding": [
              -620,
              -160,
              410,
              790
            ],
            "color": "#3f789e",
            "font_size": 24,
            "flags": {}
          },
          {
            "id": 3,
            "title": "Prompt",
            "bounding": [
              -180,
              -160,
              520,
              670
            ],
            "color": "#3f789e",
            "font_size": 24,
            "flags": {}
          }
        ],
        "links": [
          {
            "id": 41,
            "origin_id": 23,
            "origin_slot": 0,
            "target_id": 229,
            "target_slot": 0,
            "type": "CONDITIONING"
          },
          {
            "id": 101,
            "origin_id": 23,
            "origin_slot": 0,
            "target_id": 46,
            "target_slot": 0,
            "type": "CONDITIONING"
          },
          {
            "id": 62,
            "origin_id": 34,
            "origin_slot": 0,
            "target_id": 23,
            "target_slot": 0,
            "type": "CLIP"
          },
          {
            "id": 85,
            "origin_id": 31,
            "origin_slot": 0,
            "target_id": 39,
            "target_slot": 0,
            "type": "MODEL"
          },
          {
            "id": 86,
            "origin_id": 39,
            "origin_slot": 0,
            "target_id": 3,
            "target_slot": 0,
            "type": "MODEL"
          },
          {
            "id": 77,
            "origin_id": 38,
            "origin_slot": 0,
            "target_id": 3,
            "target_slot": 1,
            "type": "CONDITIONING"
          },
          {
            "id": 78,
            "origin_id": 38,
            "origin_slot": 1,
            "target_id": 3,
            "target_slot": 2,
            "type": "CONDITIONING"
          },
          {
            "id": 88,
            "origin_id": 38,
            "origin_slot": 2,
            "target_id": 3,
            "target_slot": 3,
            "type": "LATENT"
          },
          {
            "id": 7,
            "origin_id": 3,
            "origin_slot": 0,
            "target_id": 231,
            "target_slot": 0,
            "type": "LATENT"
          },
          {
            "id": 60,
            "origin_id": 230,
            "origin_slot": 0,
            "target_id": 231,
            "target_slot": 1,
            "type": "VAE"
          },
          {
            "id": 80,
            "origin_id": 229,
            "origin_slot": 0,
            "target_id": 38,
            "target_slot": 0,
            "type": "CONDITIONING"
          },
          {
            "id": 102,
            "origin_id": 46,
            "origin_slot": 0,
            "target_id": 38,
            "target_slot": 1,
            "type": "CONDITIONING"
          },
          {
            "id": 82,
            "origin_id": 230,
            "origin_slot": 0,
            "target_id": 38,
            "target_slot": 2,
            "type": "VAE"
          },
          {
            "id": 99,
            "origin_id": -10,
            "origin_slot": 0,
            "target_id": 38,
            "target_slot": 3,
            "type": "IMAGE"
          },
          {
            "id": 100,
            "origin_id": -10,
            "origin_slot": 1,
            "target_id": 38,
            "target_slot": 4,
            "type": "MASK"
          },
          {
            "id": 95,
            "origin_id": 231,
            "origin_slot": 0,
            "target_id": -20,
            "target_slot": 0,
            "type": "IMAGE"
          },
          {
            "id": 277,
            "origin_id": -10,
            "origin_slot": 2,
            "target_id": 23,
            "target_slot": 1,
            "type": "STRING"
          },
          {
            "id": 282,
            "origin_id": -10,
            "origin_slot": 3,
            "target_id": 3,
            "target_slot": 4,
            "type": "INT"
          },
          {
            "id": 283,
            "origin_id": -10,
            "origin_slot": 4,
            "target_id": 31,
            "target_slot": 0,
            "type": "COMBO"
          },
          {
            "id": 284,
            "origin_id": -10,
            "origin_slot": 5,
            "target_id": 34,
            "target_slot": 0,
            "type": "COMBO"
          },
          {
            "id": 285,
            "origin_id": -10,
            "origin_slot": 6,
            "target_id": 34,
            "target_slot": 1,
            "type": "COMBO"
          },
          {
            "id": 286,
            "origin_id": -10,
            "origin_slot": 7,
            "target_id": 230,
            "target_slot": 0,
            "type": "COMBO"
          }
        ],
        "extra": {
          "workflowRendererVersion": "LG"
        },
        "category": "Image generation and editing/Inpaint image",
        "description": "Inpaints masked image regions using Flux.1 fill [dev], Black Forest Labs' inpainting/outpainting model."
      }
    ]
  },
  "extra": {
    "ds": {
      "scale": 0.8480949417360862,
      "offset": [
        833.9510730024642,
        210.32152847588895
      ]
    },
    "ue_links": []
  }
}
```
