# Image Upscale(Z-image-Turbo)

- 来源类别：内置工作流蓝图
- 镜像内原始路径：`/ComfyUI/blueprints/Image Upscale(Z-image-Turbo).json`
- 节点数量：1
- 连线数量：0

## 节点类型

- `dd15cfd3-cd53-428c-b3e2-33ed4ff8fa78` × 1

## 工作流引用的模型或媒体文件

- `ae.safetensors`
- `qwen_3_4b.safetensors`
- `z_image_turbo_bf16.safetensors`

## 原始工作流 JSON

```json
{
  "id": "bf8108f3-d857-46c9-aef5-0e8ad2a64bf5",
  "revision": 0,
  "last_node_id": 95,
  "last_link_id": 115,
  "nodes": [
    {
      "id": 87,
      "type": "dd15cfd3-cd53-428c-b3e2-33ed4ff8fa78",
      "pos": [
        960.6668984200231,
        332.66676187423354
      ],
      "size": [
        400,
        469.9869791666667
      ],
      "flags": {},
      "order": 0,
      "mode": 0,
      "inputs": [
        {
          "localized_name": "image",
          "name": "image",
          "type": "IMAGE",
          "link": null
        },
        {
          "name": "unet_name",
          "type": "COMBO",
          "widget": {
            "name": "unet_name"
          },
          "link": null
        },
        {
          "name": "clip_name",
          "type": "COMBO",
          "widget": {
            "name": "clip_name"
          },
          "link": null
        },
        {
          "name": "vae_name",
          "type": "COMBO",
          "widget": {
            "name": "vae_name"
          },
          "link": null
        },
        {
          "label": "upscale_model",
          "name": "model_name",
          "type": "COMBO",
          "widget": {
            "name": "model_name"
          },
          "link": null
        },
        {
          "name": "denoise",
          "type": "FLOAT",
          "widget": {
            "name": "denoise"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "IMAGE",
          "localized_name": "IMAGE_1",
          "name": "IMAGE_1",
          "type": "IMAGE",
          "links": []
        }
      ],
      "properties": {
        "proxyWidgets": [
          [
            "67",
            "text"
          ],
          [
            "69",
            "seed"
          ],
          [
            "69",
            "control_after_generate"
          ],
          [
            "-1",
            "denoise"
          ],
          [
            "-1",
            "unet_name"
          ],
          [
            "-1",
            "clip_name"
          ],
          [
            "-1",
            "vae_name"
          ],
          [
            "-1",
            "model_name"
          ]
        ],
        "cnr_id": "comfy-core",
        "ver": "0.14.1"
      },
      "widgets_values": [
        null,
        null,
        null,
        0.33,
        "z_image_turbo_bf16.safetensors",
        "qwen_3_4b.safetensors",
        "ae.safetensors",
        "RealESRGAN_x4plus.safetensors"
      ]
    }
  ],
  "links": [],
  "groups": [],
  "definitions": {
    "subgraphs": [
      {
        "id": "dd15cfd3-cd53-428c-b3e2-33ed4ff8fa78",
        "version": 1,
        "state": {
          "lastGroupId": 5,
          "lastNodeId": 95,
          "lastLinkId": 115,
          "lastRerouteId": 0
        },
        "revision": 0,
        "config": {},
        "name": "Image Upscale (Z-image-Turbo)",
        "inputNode": {
          "id": -10,
          "bounding": [
            -150,
            390,
            125.224609375,
            160
          ]
        },
        "outputNode": {
          "id": -20,
          "bounding": [
            2070,
            490,
            120,
            60
          ]
        },
        "inputs": [
          {
            "id": "e9a14390-4f93-4065-8b02-323f999527c0",
            "name": "image",
            "type": "IMAGE",
            "linkIds": [
              86
            ],
            "localized_name": "image",
            "pos": [
              -44.775390625,
              410
            ]
          },
          {
            "id": "c5655e11-9531-4949-996c-958b5fe92085",
            "name": "unet_name",
            "type": "COMBO",
            "linkIds": [
              109
            ],
            "pos": [
              -44.775390625,
              430
            ]
          },
          {
            "id": "82576043-dd69-4604-b572-09fabb6e602d",
            "name": "clip_name",
            "type": "COMBO",
            "linkIds": [
              110
            ],
            "pos": [
              -44.775390625,
              450
            ]
          },
          {
            "id": "59e20fb5-cd61-4d4b-a1fd-15a90c7ba6c2",
            "name": "vae_name",
            "type": "COMBO",
            "linkIds": [
              111
            ],
            "pos": [
              -44.775390625,
              470
            ]
          },
          {
            "id": "adc35153-dc52-4bac-be7e-9da19471f441",
            "name": "model_name",
            "type": "COMBO",
            "linkIds": [
              112
            ],
            "label": "upscale_model",
            "pos": [
              -44.775390625,
              490
            ]
          },
          {
            "id": "c1b2f097-616e-4420-93c8-04eb79f4ba1e",
            "name": "denoise",
            "type": "FLOAT",
            "linkIds": [
              115
            ],
            "pos": [
              -44.775390625,
              510
            ]
          }
        ],
        "outputs": [
          {
            "id": "f138a0aa-489a-42e1-92f7-e3747688c94d",
            "name": "IMAGE_1",
            "type": "IMAGE",
            "linkIds": [
              97,
              103
            ],
            "localized_name": "IMAGE_1",
            "label": "IMAGE",
            "pos": [
              2090,
              510
            ]
          }
        ],
        "widgets": [],
        "nodes": [
          {
            "id": 71,
            "type": "CLIPTextEncode",
            "pos": [
              648.333324162179,
              398.3333435177784
            ],
            "size": [
              491.6666666666667,
              150
            ],
            "flags": {},
            "order": 7,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "clip",
                "name": "clip",
                "type": "CLIP",
                "link": 82
              },
              {
                "localized_name": "text",
                "name": "text",
                "type": "STRING",
                "widget": {
                  "name": "text"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "CONDITIONING",
                "name": "CONDITIONING",
                "type": "CONDITIONING",
                "links": [
                  83
                ]
              }
            ],
            "title": "CLIP Text Encode (Negative Prompt)",
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.3.73",
              "Node name for S&R": "CLIPTextEncode",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            },
            "widgets_values": [
              ""
            ],
            "color": "#323",
            "bgcolor": "#535"
          },
          {
            "id": 79,
            "type": "ImageUpscaleWithModel",
            "pos": [
              623.3333541162552,
              714.9999406294688
            ],
            "size": [
              233.5689453125,
              60
            ],
            "flags": {},
            "order": 10,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "upscale_model",
                "name": "upscale_model",
                "type": "UPSCALE_MODEL",
                "link": 87
              },
              {
                "localized_name": "image",
                "name": "image",
                "type": "IMAGE",
                "link": 88
              }
            ],
            "outputs": [
              {
                "localized_name": "IMAGE",
                "name": "IMAGE",
                "type": "IMAGE",
                "links": [
                  92
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.13.0",
              "Node name for S&R": "ImageUpscaleWithModel"
            },
            "widgets_values": []
          },
          {
            "id": 80,
            "type": "VAEEncode",
            "pos": [
              1173.3330331592938,
              631.6665944654844
            ],
            "size": [
              187.5,
              60
            ],
            "flags": {},
            "order": 11,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "pixels",
                "name": "pixels",
                "type": "IMAGE",
                "link": 93
              },
              {
                "localized_name": "vae",
                "name": "vae",
                "type": "VAE",
                "link": 90
              }
            ],
            "outputs": [
              {
                "localized_name": "LATENT",
                "name": "LATENT",
                "type": "LATENT",
                "links": [
                  91
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.13.0",
              "Node name for S&R": "VAEEncode"
            },
            "widgets_values": []
          },
          {
            "id": 81,
            "type": "ImageScaleBy",
            "pos": [
              865.0000410901742,
              714.9999828835583
            ],
            "size": [
              225,
              95.546875
            ],
            "flags": {},
            "order": 12,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "image",
                "name": "image",
                "type": "IMAGE",
                "link": 92
              },
              {
                "localized_name": "upscale_method",
                "name": "upscale_method",
                "type": "COMBO",
                "widget": {
                  "name": "upscale_method"
                },
                "link": null
              },
              {
                "localized_name": "scale_by",
                "name": "scale_by",
                "type": "FLOAT",
                "widget": {
                  "name": "scale_by"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "IMAGE",
                "name": "IMAGE",
                "type": "IMAGE",
                "links": [
                  93
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.13.0",
              "Node name for S&R": "ImageScaleBy"
            },
            "widgets_values": [
              "lanczos",
              0.5
            ]
          },
          {
            "id": 66,
            "type": "UNETLoader",
            "pos": [
              280,
              -20
            ],
            "size": [
              323.984375,
              118.64583333333334
            ],
            "flags": {},
            "order": 3,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "unet_name",
                "name": "unet_name",
                "type": "COMBO",
                "widget": {
                  "name": "unet_name"
                },
                "link": 109
              },
              {
                "localized_name": "weight_dtype",
                "name": "weight_dtype",
                "type": "COMBO",
                "widget": {
                  "name": "weight_dtype"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "MODEL",
                "name": "MODEL",
                "type": "MODEL",
                "links": [
                  104
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.3.73",
              "Node name for S&R": "UNETLoader",
              "models": [
                {
                  "name": "z_image_turbo_bf16.safetensors",
                  "url": "https://huggingface.co/Comfy-Org/z_image_turbo/resolve/main/split_files/diffusion_models/z_image_turbo_bf16.safetensors",
                  "directory": "diffusion_models"
                }
              ],
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            },
            "widgets_values": [
              "z_image_turbo_bf16.safetensors",
              "default"
            ]
          },
          {
            "id": 62,
            "type": "CLIPLoader",
            "pos": [
              280,
              140
            ],
            "size": [
              323.984375,
              150.65104166666669
            ],
            "flags": {},
            "order": 0,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "clip_name",
                "name": "clip_name",
                "type": "COMBO",
                "widget": {
                  "name": "clip_name"
                },
                "link": 110
              },
              {
                "localized_name": "type",
                "name": "type",
                "type": "COMBO",
                "widget": {
                  "name": "type"
                },
                "link": null
              },
              {
                "localized_name": "device",
                "name": "device",
                "shape": 7,
                "type": "COMBO",
                "widget": {
                  "name": "device"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "CLIP",
                "name": "CLIP",
                "type": "CLIP",
                "links": [
                  78,
                  82
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.3.73",
              "Node name for S&R": "CLIPLoader",
              "models": [
                {
                  "name": "qwen_3_4b.safetensors",
                  "url": "https://huggingface.co/Comfy-Org/z_image_turbo/resolve/main/split_files/text_encoders/qwen_3_4b.safetensors",
                  "directory": "text_encoders"
                }
              ],
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            },
            "widgets_values": [
              "qwen_3_4b.safetensors",
              "lumina2",
              "default"
            ]
          },
          {
            "id": 67,
            "type": "CLIPTextEncode",
            "pos": [
              650.621298596813,
              -33.81729273975067
            ],
            "size": [
              491.9791666666667,
              377.98177083333337
            ],
            "flags": {},
            "order": 4,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "clip",
                "name": "clip",
                "type": "CLIP",
                "link": 78
              },
              {
                "localized_name": "text",
                "name": "text",
                "type": "STRING",
                "widget": {
                  "name": "text"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "CONDITIONING",
                "name": "CONDITIONING",
                "type": "CONDITIONING",
                "links": [
                  75
                ]
              }
            ],
            "title": "CLIP Text Encode (Positive Prompt)",
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.3.73",
              "Node name for S&R": "CLIPTextEncode",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            },
            "widgets_values": [
              "masterpiece, 8k"
            ],
            "color": "#232",
            "bgcolor": "#353"
          },
          {
            "id": 63,
            "type": "VAELoader",
            "pos": [
              280,
              330
            ],
            "size": [
              323.984375,
              83.99739583333334
            ],
            "flags": {},
            "order": 1,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "vae_name",
                "name": "vae_name",
                "type": "COMBO",
                "widget": {
                  "name": "vae_name"
                },
                "link": 111
              }
            ],
            "outputs": [
              {
                "localized_name": "VAE",
                "name": "VAE",
                "type": "VAE",
                "links": [
                  73,
                  90
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.3.73",
              "Node name for S&R": "VAELoader",
              "models": [
                {
                  "name": "ae.safetensors",
                  "url": "https://huggingface.co/Comfy-Org/z_image_turbo/resolve/main/split_files/vae/ae.safetensors",
                  "directory": "vae"
                }
              ],
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            },
            "widgets_values": [
              "ae.safetensors"
            ]
          },
          {
            "id": 76,
            "type": "UpscaleModelLoader",
            "pos": [
              264.07395879037364,
              704.8118881098496
            ],
            "size": [
              323.984375,
              83.99739583333334
            ],
            "flags": {},
            "order": 8,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "model_name",
                "name": "model_name",
                "type": "COMBO",
                "widget": {
                  "name": "model_name"
                },
                "link": 112
              }
            ],
            "outputs": [
              {
                "localized_name": "UPSCALE_MODEL",
                "name": "UPSCALE_MODEL",
                "type": "UPSCALE_MODEL",
                "links": [
                  87
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.13.0",
              "Node name for S&R": "UpscaleModelLoader",
              "models": [
                {
                  "name": "RealESRGAN_x4plus.safetensors",
                  "url": "https://huggingface.co/Comfy-Org/Real-ESRGAN_repackaged/resolve/main/RealESRGAN_x4plus.safetensors",
                  "directory": "upscale_models"
                }
              ]
            },
            "widgets_values": [
              "RealESRGAN_x4plus.safetensors"
            ]
          },
          {
            "id": 70,
            "type": "ModelSamplingAuraFlow",
            "pos": [
              1200,
              -50
            ],
            "size": [
              371.9791666666667,
              80.1171875
            ],
            "flags": {},
            "order": 6,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "model",
                "name": "model",
                "type": "MODEL",
                "link": 104
              },
              {
                "localized_name": "shift",
                "name": "shift",
                "type": "FLOAT",
                "widget": {
                  "name": "shift"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "MODEL",
                "name": "MODEL",
                "type": "MODEL",
                "slot_index": 0,
                "links": [
                  74
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.3.64",
              "Node name for S&R": "ModelSamplingAuraFlow",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            },
            "widgets_values": [
              3
            ]
          },
          {
            "id": 65,
            "type": "VAEDecode",
            "pos": [
              1610,
              -50
            ],
            "size": [
              251.97916666666669,
              72.13541666666667
            ],
            "flags": {},
            "order": 2,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "samples",
                "name": "samples",
                "type": "LATENT",
                "link": 72
              },
              {
                "localized_name": "vae",
                "name": "vae",
                "type": "VAE",
                "link": 73
              }
            ],
            "outputs": [
              {
                "localized_name": "IMAGE",
                "name": "IMAGE",
                "type": "IMAGE",
                "slot_index": 0,
                "links": [
                  97,
                  103
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.3.64",
              "Node name for S&R": "VAEDecode",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            },
            "widgets_values": []
          },
          {
            "id": 78,
            "type": "ImageScaleToTotalPixels",
            "pos": [
              260,
              850
            ],
            "size": [
              325,
              122.21354166666667
            ],
            "flags": {},
            "order": 9,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "image",
                "name": "image",
                "type": "IMAGE",
                "link": 86
              },
              {
                "localized_name": "upscale_method",
                "name": "upscale_method",
                "type": "COMBO",
                "widget": {
                  "name": "upscale_method"
                },
                "link": null
              },
              {
                "localized_name": "megapixels",
                "name": "megapixels",
                "type": "FLOAT",
                "widget": {
                  "name": "megapixels"
                },
                "link": null
              },
              {
                "localized_name": "resolution_steps",
                "name": "resolution_steps",
                "type": "INT",
                "widget": {
                  "name": "resolution_steps"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "IMAGE",
                "name": "IMAGE",
                "type": "IMAGE",
                "links": [
                  88
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.13.0",
              "Node name for S&R": "ImageScaleToTotalPixels"
            },
            "widgets_values": [
              "lanczos",
              1,
              1
            ]
          },
          {
            "id": 69,
            "type": "KSampler",
            "pos": [
              1200,
              80
            ],
            "size": [
              366.6666666666667,
              474
            ],
            "flags": {},
            "order": 5,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "model",
                "name": "model",
                "type": "MODEL",
                "link": 74
              },
              {
                "localized_name": "positive",
                "name": "positive",
                "type": "CONDITIONING",
                "link": 75
              },
              {
                "localized_name": "negative",
                "name": "negative",
                "type": "CONDITIONING",
                "link": 83
              },
              {
                "localized_name": "latent_image",
                "name": "latent_image",
                "type": "LATENT",
                "link": 91
              },
              {
                "localized_name": "seed",
                "name": "seed",
                "type": "INT",
                "widget": {
                  "name": "seed"
                },
                "link": null
              },
              {
                "localized_name": "steps",
                "name": "steps",
                "type": "INT",
                "widget": {
                  "name": "steps"
                },
                "link": null
              },
              {
                "localized_name": "cfg",
                "name": "cfg",
                "type": "FLOAT",
                "widget": {
                  "name": "cfg"
                },
                "link": null
              },
              {
                "localized_name": "sampler_name",
                "name": "sampler_name",
                "type": "COMBO",
                "widget": {
                  "name": "sampler_name"
                },
                "link": null
              },
              {
                "localized_name": "scheduler",
                "name": "scheduler",
                "type": "COMBO",
                "widget": {
                  "name": "scheduler"
                },
                "link": null
              },
              {
                "localized_name": "denoise",
                "name": "denoise",
                "type": "FLOAT",
                "widget": {
                  "name": "denoise"
                },
                "link": 115
              }
            ],
            "outputs": [
              {
                "localized_name": "LATENT",
                "name": "LATENT",
                "type": "LATENT",
                "slot_index": 0,
                "links": [
                  72
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.3.64",
              "Node name for S&R": "KSampler",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            },
            "widgets_values": [
              1098688918602660,
              "randomize",
              5,
              1,
              "dpmpp_2m_sde",
              "beta",
              0.33
            ]
          }
        ],
        "groups": [
          {
            "id": 3,
            "title": "Prompt",
            "bounding": [
              640,
              -90,
              508.64583333333337,
              662.0666813520016
            ],
            "color": "#3f789e",
            "font_size": 24,
            "flags": {}
          },
          {
            "id": 5,
            "title": "Models",
            "bounding": [
              260,
              -90,
              344.6965254233087,
              516.414685926878
            ],
            "color": "#3f789e",
            "font_size": 24,
            "flags": {}
          }
        ],
        "links": [
          {
            "id": 104,
            "origin_id": 66,
            "origin_slot": 0,
            "target_id": 70,
            "target_slot": 0,
            "type": "MODEL"
          },
          {
            "id": 82,
            "origin_id": 62,
            "origin_slot": 0,
            "target_id": 71,
            "target_slot": 0,
            "type": "CLIP"
          },
          {
            "id": 87,
            "origin_id": 76,
            "origin_slot": 0,
            "target_id": 79,
            "target_slot": 0,
            "type": "UPSCALE_MODEL"
          },
          {
            "id": 88,
            "origin_id": 78,
            "origin_slot": 0,
            "target_id": 79,
            "target_slot": 1,
            "type": "IMAGE"
          },
          {
            "id": 93,
            "origin_id": 81,
            "origin_slot": 0,
            "target_id": 80,
            "target_slot": 0,
            "type": "IMAGE"
          },
          {
            "id": 90,
            "origin_id": 63,
            "origin_slot": 0,
            "target_id": 80,
            "target_slot": 1,
            "type": "VAE"
          },
          {
            "id": 92,
            "origin_id": 79,
            "origin_slot": 0,
            "target_id": 81,
            "target_slot": 0,
            "type": "IMAGE"
          },
          {
            "id": 74,
            "origin_id": 70,
            "origin_slot": 0,
            "target_id": 69,
            "target_slot": 0,
            "type": "MODEL"
          },
          {
            "id": 75,
            "origin_id": 67,
            "origin_slot": 0,
            "target_id": 69,
            "target_slot": 1,
            "type": "CONDITIONING"
          },
          {
            "id": 83,
            "origin_id": 71,
            "origin_slot": 0,
            "target_id": 69,
            "target_slot": 2,
            "type": "CONDITIONING"
          },
          {
            "id": 91,
            "origin_id": 80,
            "origin_slot": 0,
            "target_id": 69,
            "target_slot": 3,
            "type": "LATENT"
          },
          {
            "id": 72,
            "origin_id": 69,
            "origin_slot": 0,
            "target_id": 65,
            "target_slot": 0,
            "type": "LATENT"
          },
          {
            "id": 73,
            "origin_id": 63,
            "origin_slot": 0,
            "target_id": 65,
            "target_slot": 1,
            "type": "VAE"
          },
          {
            "id": 78,
            "origin_id": 62,
            "origin_slot": 0,
            "target_id": 67,
            "target_slot": 0,
            "type": "CLIP"
          },
          {
            "id": 86,
            "origin_id": -10,
            "origin_slot": 0,
            "target_id": 78,
            "target_slot": 0,
            "type": "IMAGE"
          },
          {
            "id": 97,
            "origin_id": 65,
            "origin_slot": 0,
            "target_id": -20,
            "target_slot": 0,
            "type": "IMAGE"
          },
          {
            "id": 103,
            "origin_id": 65,
            "origin_slot": 0,
            "target_id": -20,
            "target_slot": 0,
            "type": "IMAGE"
          },
          {
            "id": 109,
            "origin_id": -10,
            "origin_slot": 1,
            "target_id": 66,
            "target_slot": 0,
            "type": "COMBO"
          },
          {
            "id": 110,
            "origin_id": -10,
            "origin_slot": 2,
            "target_id": 62,
            "target_slot": 0,
            "type": "COMBO"
          },
          {
            "id": 111,
            "origin_id": -10,
            "origin_slot": 3,
            "target_id": 63,
            "target_slot": 0,
            "type": "COMBO"
          },
          {
            "id": 112,
            "origin_id": -10,
            "origin_slot": 4,
            "target_id": 76,
            "target_slot": 0,
            "type": "COMBO"
          },
          {
            "id": 115,
            "origin_id": -10,
            "origin_slot": 5,
            "target_id": 69,
            "target_slot": 9,
            "type": "FLOAT"
          }
        ],
        "extra": {
          "workflowRendererVersion": "LG"
        },
        "category": "Image generation and editing/Upscale",
        "description": "Upscales images to higher resolution using Z-Image-Turbo."
      }
    ]
  },
  "config": {},
  "extra": {
    "workflowRendererVersion": "LG"
  },
  "version": 0.4
}
```
