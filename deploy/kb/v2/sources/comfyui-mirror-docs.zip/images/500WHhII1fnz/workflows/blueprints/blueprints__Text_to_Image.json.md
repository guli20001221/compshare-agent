# Text to Image

- 来源类别：内置工作流蓝图
- 镜像内原始路径：`/ComfyUI/blueprints/Text to Image.json`
- 节点数量：1
- 连线数量：0

## 节点类型

- `2d5985c9-deef-41ae-9c34-6353d3d7d1ef` × 1

## 原始工作流 JSON

```json
{
  "revision": 0,
  "last_node_id": 71,
  "last_link_id": 0,
  "nodes": [
    {
      "id": 71,
      "type": "2d5985c9-deef-41ae-9c34-6353d3d7d1ef",
      "pos": [
        90,
        800
      ],
      "size": [
        400,
        80
      ],
      "flags": {},
      "order": 1,
      "mode": 0,
      "inputs": [
        {
          "label": "prompt",
          "name": "text",
          "type": "STRING",
          "widget": {
            "name": "text"
          },
          "link": null
        },
        {
          "name": "width",
          "type": "INT",
          "widget": {
            "name": "width"
          },
          "link": null
        },
        {
          "name": "height",
          "type": "INT",
          "widget": {
            "name": "height"
          },
          "link": null
        },
        {
          "name": "unet_name",
          "type": "COMBO",
          "widget": {
            "name": "unet_name"
          },
          "link": null
        },
        {
          "name": "clip_name",
          "type": "COMBO",
          "widget": {
            "name": "clip_name"
          },
          "link": null
        },
        {
          "name": "vae_name",
          "type": "COMBO",
          "widget": {
            "name": "vae_name"
          },
          "link": null
        },
        {
          "name": "steps",
          "type": "INT",
          "widget": {
            "name": "steps"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "localized_name": "IMAGE",
          "name": "IMAGE",
          "type": "IMAGE",
          "links": []
        }
      ],
      "title": "Text to Image",
      "properties": {
        "proxyWidgets": [
          [
            "67",
            "text"
          ],
          [
            "68",
            "width"
          ],
          [
            "68",
            "height"
          ],
          [
            "66",
            "unet_name"
          ],
          [
            "62",
            "clip_name"
          ],
          [
            "63",
            "vae_name"
          ],
          [
            "70",
            "steps"
          ],
          [
            "70",
            "control_after_generate"
          ]
        ],
        "cnr_id": "comfy-core",
        "ver": "0.3.73",
        "ue_properties": {
          "widget_ue_connectable": {
            "text": true
          },
          "version": "7.7",
          "input_ue_unconnectable": {}
        },
        "enableTabs": false,
        "tabWidth": 65,
        "tabXOffset": 10,
        "hasSecondTab": false,
        "secondTabText": "Send Back",
        "secondTabOffset": 80,
        "secondTabWidth": 65
      },
      "widgets_values": []
    }
  ],
  "links": [],
  "version": 0.4,
  "definitions": {
    "subgraphs": [
      {
        "id": "2d5985c9-deef-41ae-9c34-6353d3d7d1ef",
        "version": 1,
        "state": {
          "lastGroupId": 4,
          "lastNodeId": 71,
          "lastLinkId": 70,
          "lastRerouteId": 0
        },
        "revision": 0,
        "config": {},
        "name": "Text to Image",
        "inputNode": {
          "id": -10,
          "bounding": [
            -80,
            425,
            120,
            180
          ]
        },
        "outputNode": {
          "id": -20,
          "bounding": [
            1490,
            415,
            120,
            60
          ]
        },
        "inputs": [
          {
            "id": "fb178669-e742-4a53-8a69-7df59834dfd8",
            "name": "text",
            "type": "STRING",
            "linkIds": [
              34
            ],
            "label": "prompt",
            "pos": [
              20,
              445
            ]
          },
          {
            "id": "dd780b3c-23e9-46ff-8469-156008f42e5a",
            "name": "width",
            "type": "INT",
            "linkIds": [
              35
            ],
            "pos": [
              20,
              465
            ]
          },
          {
            "id": "7b08d546-6bb0-4ef9-82e9-ffae5e1ee6bc",
            "name": "height",
            "type": "INT",
            "linkIds": [
              36
            ],
            "pos": [
              20,
              485
            ]
          },
          {
            "id": "8ed4eb73-a2bf-4766-8bf4-c5890b560596",
            "name": "unet_name",
            "type": "COMBO",
            "linkIds": [
              38
            ],
            "pos": [
              20,
              505
            ]
          },
          {
            "id": "f362d639-d412-4b5d-8490-1e9995dc5f82",
            "name": "clip_name",
            "type": "COMBO",
            "linkIds": [
              39
            ],
            "pos": [
              20,
              525
            ]
          },
          {
            "id": "ee25ac16-de63-4b74-bbbb-5b29fdc1efcf",
            "name": "vae_name",
            "type": "COMBO",
            "linkIds": [
              40
            ],
            "pos": [
              20,
              545
            ]
          },
          {
            "id": "51cbcd61-9218-4bcb-89ac-ecdfb1ef8892",
            "name": "steps",
            "type": "INT",
            "linkIds": [
              70
            ],
            "pos": [
              20,
              565
            ]
          }
        ],
        "outputs": [
          {
            "id": "1fa72a21-ce00-4952-814e-1f2ffbe87d1d",
            "name": "IMAGE",
            "type": "IMAGE",
            "linkIds": [
              16
            ],
            "localized_name": "IMAGE",
            "pos": [
              1510,
              435
            ]
          }
        ],
        "widgets": [],
        "nodes": [
          {
            "id": 62,
            "type": "CLIPLoader",
            "pos": [
              110,
              330
            ],
            "size": [
              270,
              110
            ],
            "flags": {},
            "order": 0,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "clip_name",
                "name": "clip_name",
                "type": "COMBO",
                "widget": {
                  "name": "clip_name"
                },
                "link": 39
              },
              {
                "localized_name": "type",
                "name": "type",
                "type": "COMBO",
                "widget": {
                  "name": "type"
                },
                "link": null
              },
              {
                "localized_name": "device",
                "name": "device",
                "shape": 7,
                "type": "COMBO",
                "widget": {
                  "name": "device"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "CLIP",
                "name": "CLIP",
                "type": "CLIP",
                "links": [
                  28
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.3.73",
              "ue_properties": {
                "widget_ue_connectable": {},
                "version": "7.7",
                "input_ue_unconnectable": {}
              },
              "Node name for S&R": "CLIPLoader",
              "models": [
                {
                  "name": "qwen_3_4b.safetensors",
                  "url": "https://huggingface.co/Comfy-Org/z_image_turbo/resolve/main/split_files/text_encoders/qwen_3_4b.safetensors",
                  "directory": "text_encoders"
                }
              ],
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            },
            "widgets_values": [
              "qwen_3_4b.safetensors",
              "lumina2",
              "default"
            ]
          },
          {
            "id": 63,
            "type": "VAELoader",
            "pos": [
              110,
              480
            ],
            "size": [
              270,
              60
            ],
            "flags": {},
            "order": 1,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "vae_name",
                "name": "vae_name",
                "type": "COMBO",
                "widget": {
                  "name": "vae_name"
                },
                "link": 40
              }
            ],
            "outputs": [
              {
                "localized_name": "VAE",
                "name": "VAE",
                "type": "VAE",
                "links": [
                  27
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.3.73",
              "ue_properties": {
                "widget_ue_connectable": {},
                "version": "7.7",
                "input_ue_unconnectable": {}
              },
              "Node name for S&R": "VAELoader",
              "models": [
                {
                  "name": "ae.safetensors",
                  "url": "https://huggingface.co/Comfy-Org/z_image_turbo/resolve/main/split_files/vae/ae.safetensors",
                  "directory": "vae"
                }
              ],
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            },
            "widgets_values": [
              "ae.safetensors"
            ]
          },
          {
            "id": 64,
            "type": "ConditioningZeroOut",
            "pos": [
              640,
              620
            ],
            "size": [
              210,
              30
            ],
            "flags": {},
            "order": 2,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "conditioning",
                "name": "conditioning",
                "type": "CONDITIONING",
                "link": 32
              }
            ],
            "outputs": [
              {
                "localized_name": "CONDITIONING",
                "name": "CONDITIONING",
                "type": "CONDITIONING",
                "links": [
                  33
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.3.73",
              "ue_properties": {
                "widget_ue_connectable": {},
                "version": "7.7",
                "input_ue_unconnectable": {}
              },
              "Node name for S&R": "ConditioningZeroOut",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            }
          },
          {
            "id": 65,
            "type": "VAEDecode",
            "pos": [
              1220,
              160
            ],
            "size": [
              210,
              50
            ],
            "flags": {},
            "order": 3,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "samples",
                "name": "samples",
                "type": "LATENT",
                "link": 14
              },
              {
                "localized_name": "vae",
                "name": "vae",
                "type": "VAE",
                "link": 27
              }
            ],
            "outputs": [
              {
                "localized_name": "IMAGE",
                "name": "IMAGE",
                "type": "IMAGE",
                "slot_index": 0,
                "links": [
                  16
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.3.64",
              "ue_properties": {
                "widget_ue_connectable": {},
                "version": "7.7",
                "input_ue_unconnectable": {}
              },
              "Node name for S&R": "VAEDecode",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            }
          },
          {
            "id": 66,
            "type": "UNETLoader",
            "pos": [
              110,
              200
            ],
            "size": [
              270,
              90
            ],
            "flags": {},
            "order": 4,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "unet_name",
                "name": "unet_name",
                "type": "COMBO",
                "widget": {
                  "name": "unet_name"
                },
                "link": 38
              },
              {
                "localized_name": "weight_dtype",
                "name": "weight_dtype",
                "type": "COMBO",
                "widget": {
                  "name": "weight_dtype"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "MODEL",
                "name": "MODEL",
                "type": "MODEL",
                "links": [
                  26
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.3.73",
              "ue_properties": {
                "widget_ue_connectable": {},
                "version": "7.7",
                "input_ue_unconnectable": {}
              },
              "Node name for S&R": "UNETLoader",
              "models": [
                {
                  "name": "z_image_turbo_bf16.safetensors",
                  "url": "https://huggingface.co/Comfy-Org/z_image_turbo/resolve/main/split_files/diffusion_models/z_image_turbo_bf16.safetensors",
                  "directory": "diffusion_models"
                }
              ],
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            },
            "widgets_values": [
              "z_image_turbo_bf16.safetensors",
              "default"
            ]
          },
          {
            "id": 67,
            "type": "CLIPTextEncode",
            "pos": [
              430,
              200
            ],
            "size": [
              410,
              370
            ],
            "flags": {},
            "order": 5,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "clip",
                "name": "clip",
                "type": "CLIP",
                "link": 28
              },
              {
                "localized_name": "text",
                "name": "text",
                "type": "STRING",
                "widget": {
                  "name": "text"
                },
                "link": 34
              }
            ],
            "outputs": [
              {
                "localized_name": "CONDITIONING",
                "name": "CONDITIONING",
                "type": "CONDITIONING",
                "links": [
                  30,
                  32
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.3.73",
              "ue_properties": {
                "widget_ue_connectable": {},
                "version": "7.7",
                "input_ue_unconnectable": {}
              },
              "Node name for S&R": "CLIPTextEncode",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            },
            "widgets_values": [
              ""
            ]
          },
          {
            "id": 68,
            "type": "EmptySD3LatentImage",
            "pos": [
              110,
              630
            ],
            "size": [
              260,
              110
            ],
            "flags": {},
            "order": 6,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "width",
                "name": "width",
                "type": "INT",
                "widget": {
                  "name": "width"
                },
                "link": 35
              },
              {
                "localized_name": "height",
                "name": "height",
                "type": "INT",
                "widget": {
                  "name": "height"
                },
                "link": 36
              },
              {
                "localized_name": "batch_size",
                "name": "batch_size",
                "type": "INT",
                "widget": {
                  "name": "batch_size"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "LATENT",
                "name": "LATENT",
                "type": "LATENT",
                "slot_index": 0,
                "links": [
                  17
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.3.64",
              "ue_properties": {
                "widget_ue_connectable": {},
                "version": "7.7",
                "input_ue_unconnectable": {}
              },
              "Node name for S&R": "EmptySD3LatentImage",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            },
            "widgets_values": [
              1024,
              1024,
              1
            ]
          },
          {
            "id": 69,
            "type": "ModelSamplingAuraFlow",
            "pos": [
              880,
              160
            ],
            "size": [
              310,
              60
            ],
            "flags": {},
            "order": 7,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "model",
                "name": "model",
                "type": "MODEL",
                "link": 26
              },
              {
                "localized_name": "shift",
                "name": "shift",
                "type": "FLOAT",
                "widget": {
                  "name": "shift"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "MODEL",
                "name": "MODEL",
                "type": "MODEL",
                "slot_index": 0,
                "links": [
                  13
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.3.64",
              "ue_properties": {
                "widget_ue_connectable": {},
                "version": "7.7",
                "input_ue_unconnectable": {}
              },
              "Node name for S&R": "ModelSamplingAuraFlow",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            },
            "widgets_values": [
              3
            ]
          },
          {
            "id": 70,
            "type": "KSampler",
            "pos": [
              880,
              270
            ],
            "size": [
              320,
              270
            ],
            "flags": {},
            "order": 8,
            "mode": 0,
            "inputs": [
              {
                "localized_name": "model",
                "name": "model",
                "type": "MODEL",
                "link": 13
              },
              {
                "localized_name": "positive",
                "name": "positive",
                "type": "CONDITIONING",
                "link": 30
              },
              {
                "localized_name": "negative",
                "name": "negative",
                "type": "CONDITIONING",
                "link": 33
              },
              {
                "localized_name": "latent_image",
                "name": "latent_image",
                "type": "LATENT",
                "link": 17
              },
              {
                "localized_name": "seed",
                "name": "seed",
                "type": "INT",
                "widget": {
                  "name": "seed"
                },
                "link": null
              },
              {
                "localized_name": "steps",
                "name": "steps",
                "type": "INT",
                "widget": {
                  "name": "steps"
                },
                "link": 70
              },
              {
                "localized_name": "cfg",
                "name": "cfg",
                "type": "FLOAT",
                "widget": {
                  "name": "cfg"
                },
                "link": null
              },
              {
                "localized_name": "sampler_name",
                "name": "sampler_name",
                "type": "COMBO",
                "widget": {
                  "name": "sampler_name"
                },
                "link": null
              },
              {
                "localized_name": "scheduler",
                "name": "scheduler",
                "type": "COMBO",
                "widget": {
                  "name": "scheduler"
                },
                "link": null
              },
              {
                "localized_name": "denoise",
                "name": "denoise",
                "type": "FLOAT",
                "widget": {
                  "name": "denoise"
                },
                "link": null
              }
            ],
            "outputs": [
              {
                "localized_name": "LATENT",
                "name": "LATENT",
                "type": "LATENT",
                "slot_index": 0,
                "links": [
                  14
                ]
              }
            ],
            "properties": {
              "cnr_id": "comfy-core",
              "ver": "0.3.64",
              "ue_properties": {
                "widget_ue_connectable": {},
                "version": "7.7",
                "input_ue_unconnectable": {}
              },
              "Node name for S&R": "KSampler",
              "enableTabs": false,
              "tabWidth": 65,
              "tabXOffset": 10,
              "hasSecondTab": false,
              "secondTabText": "Send Back",
              "secondTabOffset": 80,
              "secondTabWidth": 65
            },
            "widgets_values": [
              0,
              "randomize",
              8,
              1,
              "res_multistep",
              "simple",
              1
            ]
          }
        ],
        "groups": [
          {
            "id": 2,
            "title": "Step2 - Image size",
            "bounding": [
              100,
              560,
              290,
              200
            ],
            "color": "#3f789e",
            "font_size": 24,
            "flags": {}
          },
          {
            "id": 3,
            "title": "Step3 - Prompt",
            "bounding": [
              410,
              130,
              450,
              540
            ],
            "color": "#3f789e",
            "font_size": 24,
            "flags": {}
          },
          {
            "id": 4,
            "title": "Step1 - Load models",
            "bounding": [
              100,
              130,
              290,
              413.6
            ],
            "color": "#3f789e",
            "font_size": 24,
            "flags": {}
          }
        ],
        "links": [
          {
            "id": 32,
            "origin_id": 67,
            "origin_slot": 0,
            "target_id": 64,
            "target_slot": 0,
            "type": "CONDITIONING"
          },
          {
            "id": 26,
            "origin_id": 66,
            "origin_slot": 0,
            "target_id": 69,
            "target_slot": 0,
            "type": "MODEL"
          },
          {
            "id": 14,
            "origin_id": 70,
            "origin_slot": 0,
            "target_id": 65,
            "target_slot": 0,
            "type": "LATENT"
          },
          {
            "id": 27,
            "origin_id": 63,
            "origin_slot": 0,
            "target_id": 65,
            "target_slot": 1,
            "type": "VAE"
          },
          {
            "id": 13,
            "origin_id": 69,
            "origin_slot": 0,
            "target_id": 70,
            "target_slot": 0,
            "type": "MODEL"
          },
          {
            "id": 30,
            "origin_id": 67,
            "origin_slot": 0,
            "target_id": 70,
            "target_slot": 1,
            "type": "CONDITIONING"
          },
          {
            "id": 33,
            "origin_id": 64,
            "origin_slot": 0,
            "target_id": 70,
            "target_slot": 2,
            "type": "CONDITIONING"
          },
          {
            "id": 17,
            "origin_id": 68,
            "origin_slot": 0,
            "target_id": 70,
            "target_slot": 3,
            "type": "LATENT"
          },
          {
            "id": 28,
            "origin_id": 62,
            "origin_slot": 0,
            "target_id": 67,
            "target_slot": 0,
            "type": "CLIP"
          },
          {
            "id": 16,
            "origin_id": 65,
            "origin_slot": 0,
            "target_id": -20,
            "target_slot": 0,
            "type": "IMAGE"
          },
          {
            "id": 34,
            "origin_id": -10,
            "origin_slot": 0,
            "target_id": 67,
            "target_slot": 1,
            "type": "STRING"
          },
          {
            "id": 35,
            "origin_id": -10,
            "origin_slot": 1,
            "target_id": 68,
            "target_slot": 0,
            "type": "INT"
          },
          {
            "id": 36,
            "origin_id": -10,
            "origin_slot": 2,
            "target_id": 68,
            "target_slot": 1,
            "type": "INT"
          },
          {
            "id": 38,
            "origin_id": -10,
            "origin_slot": 3,
            "target_id": 66,
            "target_slot": 0,
            "type": "COMBO"
          },
          {
            "id": 39,
            "origin_id": -10,
            "origin_slot": 4,
            "target_id": 62,
            "target_slot": 0,
            "type": "COMBO"
          },
          {
            "id": 40,
            "origin_id": -10,
            "origin_slot": 5,
            "target_id": 63,
            "target_slot": 0,
            "type": "COMBO"
          },
          {
            "id": 70,
            "origin_id": -10,
            "origin_slot": 6,
            "target_id": 70,
            "target_slot": 5,
            "type": "INT"
          }
        ],
        "extra": {
          "workflowRendererVersion": "LG"
        },
        "category": "Image generation and editing/Text to image",
        "description": "Generates images from text prompts using Z-Image-Turbo defaults with Qwen3 text encoder and VAE."
      }
    ]
  },
  "extra": {}
}
```
