# WanAnimate动作迁移-修复版

- 来源类别：用户工作流
- 镜像内原始路径：`/ComfyUI/user/default/workflows/Wan Animate系列/WanAnimate动作迁移-修复版.json`
- 节点数量：32
- 连线数量：48

## 节点类型

- `VHS_VideoCombine` × 4
- `INTConstant` × 2
- `ImageConcatMulti` × 2
- `PreviewImage` × 2
- `CLIPVisionLoader` × 1
- `DrawViTPose` × 1
- `GetImageSizeAndCount` × 1
- `ImageResizeKJv2` × 1
- `LoadImage` × 1
- `Note` × 1
- `OnnxDetectionModelLoader` × 1
- `PoseAndFaceDetection` × 1
- `VHS_LoadVideo` × 1
- `VHS_SelectImages` × 1
- `WanVideoAnimateEmbeds` × 1
- `WanVideoBlockSwap` × 1
- `WanVideoClipVisionEncode` × 1
- `WanVideoDecode` × 1
- `WanVideoLoraSelectMulti` × 1
- `WanVideoModelLoader` × 1
- `WanVideoSampler` × 1
- `WanVideoSetBlockSwap` × 1
- `WanVideoSetLoRAs` × 1
- `WanVideoTextEncodeCached` × 1
- `WanVideoTorchCompileSettings` × 1
- `WanVideoVAELoader` × 1

## 工作流引用的模型或媒体文件

- `/ComfyUI/output/Wanimate_00042-audio.mp4`
- `/ComfyUI/output/Wanimate_00043-audio.mp4`
- `/ComfyUI/temp/WanVideo2_1_T2V_00001.mp4`
- `/ComfyUI/temp/WanVideo2_1_T2V_00002.mp4`
- `2pq0.MP4`
- `Wan2_1_VAE_bf16.safetensors`
- `WanVideo2_1_T2V_00001.mp4`
- `WanVideo2_1_T2V_00002.mp4`
- `Wanimate_00042-audio.mp4`
- `Wanimate_00043-audio.mp4`
- `aV1_LoRA_14B_rank512_bf16.safetensors`
- `caled_KJ.safetensors`
- `e-l-wholebody.onnx`
- `ion_h.safetensors`
- `ized_dynamic_avg_rank_15_bf16.safetensors`
- `ized_dynamic_avg_rank_22_bf16.safetensors`
- `till_v2_lora_rank32_bf16.safetensors`
- `umt5-xxl-enc-fp8_e4m3fn.safetensors`
- `yolov10m.onnx`

## 原始工作流 JSON

```json
{
  "id": "511df2b2-0237-4a7f-8e5a-cce70155f994",
  "revision": 0,
  "last_node_id": 196,
  "last_link_id": 354,
  "nodes": [
    {
      "id": 62,
      "type": "WanVideoAnimateEmbeds",
      "pos": [
        1819.7667236328125,
        -1835.1961669921875
      ],
      "size": [
        274.2164001464844,
        370
      ],
      "flags": {},
      "order": 25,
      "mode": 0,
      "inputs": [
        {
          "label": "vae",
          "localized_name": "vae",
          "name": "vae",
          "type": "WANVAE",
          "link": 343
        },
        {
          "label": "clip_embeds",
          "localized_name": "clip_embeds",
          "name": "clip_embeds",
          "shape": 7,
          "type": "WANVIDIMAGE_CLIPEMBEDS",
          "link": 96
        },
        {
          "label": "ref_images",
          "localized_name": "ref_images",
          "name": "ref_images",
          "shape": 7,
          "type": "IMAGE",
          "link": 341
        },
        {
          "label": "pose_images",
          "localized_name": "pose_images",
          "name": "pose_images",
          "shape": 7,
          "type": "IMAGE",
          "link": 346
        },
        {
          "label": "face_images",
          "localized_name": "face_images",
          "name": "face_images",
          "shape": 7,
          "type": "IMAGE",
          "link": 348
        },
        {
          "label": "bg_images",
          "localized_name": "bg_images",
          "name": "bg_images",
          "shape": 7,
          "type": "IMAGE",
          "link": null
        },
        {
          "label": "mask",
          "localized_name": "mask",
          "name": "mask",
          "shape": 7,
          "type": "MASK",
          "link": null
        },
        {
          "label": "width",
          "localized_name": "width",
          "name": "width",
          "type": "INT",
          "widget": {
            "name": "width"
          },
          "link": 349
        },
        {
          "label": "height",
          "localized_name": "height",
          "name": "height",
          "type": "INT",
          "widget": {
            "name": "height"
          },
          "link": 350
        },
        {
          "label": "num_frames",
          "localized_name": "num_frames",
          "name": "num_frames",
          "type": "INT",
          "widget": {
            "name": "num_frames"
          },
          "link": 339
        },
        {
          "label": "force_offload",
          "localized_name": "force_offload",
          "name": "force_offload",
          "type": "BOOLEAN",
          "widget": {
            "name": "force_offload"
          },
          "link": null
        },
        {
          "label": "frame_window_size",
          "localized_name": "frame_window_size",
          "name": "frame_window_size",
          "type": "INT",
          "widget": {
            "name": "frame_window_size"
          },
          "link": null
        },
        {
          "label": "colormatch",
          "localized_name": "colormatch",
          "name": "colormatch",
          "type": "COMBO",
          "widget": {
            "name": "colormatch"
          },
          "link": null
        },
        {
          "label": "pose_strength",
          "localized_name": "pose_strength",
          "name": "pose_strength",
          "type": "FLOAT",
          "widget": {
            "name": "pose_strength"
          },
          "link": null
        },
        {
          "label": "face_strength",
          "localized_name": "face_strength",
          "name": "face_strength",
          "type": "FLOAT",
          "widget": {
            "name": "face_strength"
          },
          "link": null
        },
        {
          "label": "tiled_vae",
          "localized_name": "tiled_vae",
          "name": "tiled_vae",
          "shape": 7,
          "type": "BOOLEAN",
          "widget": {
            "name": "tiled_vae"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "image_embeds",
          "localized_name": "image_embeds",
          "name": "image_embeds",
          "type": "WANVIDIMAGE_EMBEDS",
          "links": [
            333
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "WanVideoAnimateEmbeds",
        "cnr_id": "ComfyUI-WanVideoWrapper",
        "ver": "761b1d191e50d589465e31dc0d40ff7c59b1b7b0",
        "widget_ue_connectable": {
          "width": true,
          "height": true,
          "num_frames": true
        }
      },
      "widgets_values": [
        832,
        480,
        501,
        false,
        77,
        "disabled",
        1,
        1,
        false
      ],
      "color": "#322",
      "bgcolor": "#533"
    },
    {
      "id": 35,
      "type": "WanVideoTorchCompileSettings",
      "pos": [
        -190,
        -1240
      ],
      "size": [
        591.5192260742188,
        250
      ],
      "flags": {},
      "order": 0,
      "mode": 0,
      "inputs": [
        {
          "label": "backend",
          "localized_name": "backend",
          "name": "backend",
          "type": "COMBO",
          "widget": {
            "name": "backend"
          },
          "link": null
        },
        {
          "label": "fullgraph",
          "localized_name": "fullgraph",
          "name": "fullgraph",
          "type": "BOOLEAN",
          "widget": {
            "name": "fullgraph"
          },
          "link": null
        },
        {
          "label": "mode",
          "localized_name": "mode",
          "name": "mode",
          "type": "COMBO",
          "widget": {
            "name": "mode"
          },
          "link": null
        },
        {
          "label": "dynamic",
          "localized_name": "dynamic",
          "name": "dynamic",
          "type": "BOOLEAN",
          "widget": {
            "name": "dynamic"
          },
          "link": null
        },
        {
          "label": "dynamo_cache_size_limit",
          "localized_name": "dynamo_cache_size_limit",
          "name": "dynamo_cache_size_limit",
          "type": "INT",
          "widget": {
            "name": "dynamo_cache_size_limit"
          },
          "link": null
        },
        {
          "label": "compile_transformer_blocks_only",
          "localized_name": "compile_transformer_blocks_only",
          "name": "compile_transformer_blocks_only",
          "type": "BOOLEAN",
          "widget": {
            "name": "compile_transformer_blocks_only"
          },
          "link": null
        },
        {
          "label": "dynamo_recompile_limit",
          "localized_name": "dynamo_recompile_limit",
          "name": "dynamo_recompile_limit",
          "shape": 7,
          "type": "INT",
          "widget": {
            "name": "dynamo_recompile_limit"
          },
          "link": null
        },
        {
          "label": "force_parameter_static_shapes",
          "localized_name": "force_parameter_static_shapes",
          "name": "force_parameter_static_shapes",
          "shape": 7,
          "type": "BOOLEAN",
          "widget": {
            "name": "force_parameter_static_shapes"
          },
          "link": null
        },
        {
          "label": "allow_unmerged_lora_compile",
          "localized_name": "allow_unmerged_lora_compile",
          "name": "allow_unmerged_lora_compile",
          "shape": 7,
          "type": "BOOLEAN",
          "widget": {
            "name": "allow_unmerged_lora_compile"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "torch_compile_args",
          "localized_name": "torch_compile_args",
          "name": "torch_compile_args",
          "type": "WANCOMPILEARGS",
          "slot_index": 0,
          "links": [
            100
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "WanVideoTorchCompileSettings",
        "cnr_id": "ComfyUI-WanVideoWrapper",
        "ver": "e5ef9752a7e846b232fc05fd993327a2e870a788",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "inductor",
        false,
        "default",
        false,
        64,
        true,
        128,
        false,
        false
      ],
      "color": "#223",
      "bgcolor": "#335"
    },
    {
      "id": 48,
      "type": "WanVideoSetLoRAs",
      "pos": [
        1020,
        -1800
      ],
      "size": [
        178.5533203125,
        46
      ],
      "flags": {},
      "order": 14,
      "mode": 0,
      "inputs": [
        {
          "label": "model",
          "localized_name": "model",
          "name": "model",
          "type": "WANVIDEOMODEL",
          "link": 59
        },
        {
          "label": "lora",
          "localized_name": "lora",
          "name": "lora",
          "shape": 7,
          "type": "WANVIDLORA",
          "link": 289
        }
      ],
      "outputs": [
        {
          "label": "model",
          "localized_name": "model",
          "name": "model",
          "type": "WANVIDEOMODEL",
          "links": [
            62
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "WanVideoSetLoRAs",
        "cnr_id": "ComfyUI-WanVideoWrapper",
        "ver": "e5ef9752a7e846b232fc05fd993327a2e870a788",
        "widget_ue_connectable": {}
      },
      "widgets_values": [],
      "color": "#223",
      "bgcolor": "#335"
    },
    {
      "id": 50,
      "type": "WanVideoSetBlockSwap",
      "pos": [
        1210,
        -1810
      ],
      "size": [
        209.6841796875,
        46
      ],
      "flags": {},
      "order": 19,
      "mode": 0,
      "inputs": [
        {
          "label": "model",
          "localized_name": "model",
          "name": "model",
          "type": "WANVIDEOMODEL",
          "link": 62
        },
        {
          "label": "block_swap_args",
          "localized_name": "block_swap_args",
          "name": "block_swap_args",
          "shape": 7,
          "type": "BLOCKSWAPARGS",
          "link": 64
        }
      ],
      "outputs": [
        {
          "label": "model",
          "localized_name": "model",
          "name": "model",
          "type": "WANVIDEOMODEL",
          "links": [
            63
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "WanVideoSetBlockSwap",
        "cnr_id": "ComfyUI-WanVideoWrapper",
        "ver": "e5ef9752a7e846b232fc05fd993327a2e870a788",
        "widget_ue_connectable": {}
      },
      "widgets_values": [],
      "color": "#223",
      "bgcolor": "#335"
    },
    {
      "id": 51,
      "type": "WanVideoBlockSwap",
      "pos": [
        1020,
        -1700
      ],
      "size": [
        281.404296875,
        202
      ],
      "flags": {},
      "order": 1,
      "mode": 0,
      "inputs": [
        {
          "label": "blocks_to_swap",
          "localized_name": "blocks_to_swap",
          "name": "blocks_to_swap",
          "type": "INT",
          "widget": {
            "name": "blocks_to_swap"
          },
          "link": null
        },
        {
          "label": "offload_img_emb",
          "localized_name": "offload_img_emb",
          "name": "offload_img_emb",
          "type": "BOOLEAN",
          "widget": {
            "name": "offload_img_emb"
          },
          "link": null
        },
        {
          "label": "offload_txt_emb",
          "localized_name": "offload_txt_emb",
          "name": "offload_txt_emb",
          "type": "BOOLEAN",
          "widget": {
            "name": "offload_txt_emb"
          },
          "link": null
        },
        {
          "label": "use_non_blocking",
          "localized_name": "use_non_blocking",
          "name": "use_non_blocking",
          "shape": 7,
          "type": "BOOLEAN",
          "widget": {
            "name": "use_non_blocking"
          },
          "link": null
        },
        {
          "label": "vace_blocks_to_swap",
          "localized_name": "vace_blocks_to_swap",
          "name": "vace_blocks_to_swap",
          "shape": 7,
          "type": "INT",
          "widget": {
            "name": "vace_blocks_to_swap"
          },
          "link": null
        },
        {
          "label": "prefetch_blocks",
          "localized_name": "prefetch_blocks",
          "name": "prefetch_blocks",
          "shape": 7,
          "type": "INT",
          "widget": {
            "name": "prefetch_blocks"
          },
          "link": null
        },
        {
          "label": "block_swap_debug",
          "localized_name": "block_swap_debug",
          "name": "block_swap_debug",
          "shape": 7,
          "type": "BOOLEAN",
          "widget": {
            "name": "block_swap_debug"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "block_swap_args",
          "localized_name": "block_swap_args",
          "name": "block_swap_args",
          "type": "BLOCKSWAPARGS",
          "links": [
            64
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "WanVideoBlockSwap",
        "cnr_id": "ComfyUI-WanVideoWrapper",
        "ver": "e5ef9752a7e846b232fc05fd993327a2e870a788",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        25,
        false,
        false,
        true,
        0,
        0,
        false
      ],
      "color": "#223",
      "bgcolor": "#335"
    },
    {
      "id": 64,
      "type": "ImageResizeKJv2",
      "pos": [
        -885.9152221679688,
        -1831.983642578125
      ],
      "size": [
        270,
        336
      ],
      "flags": {},
      "order": 12,
      "mode": 0,
      "inputs": [
        {
          "label": "image",
          "localized_name": "image",
          "name": "image",
          "type": "IMAGE",
          "link": 82
        },
        {
          "label": "mask",
          "localized_name": "mask",
          "name": "mask",
          "shape": 7,
          "type": "MASK",
          "link": null
        },
        {
          "label": "width",
          "localized_name": "width",
          "name": "width",
          "type": "INT",
          "widget": {
            "name": "width"
          },
          "link": 286
        },
        {
          "label": "height",
          "localized_name": "height",
          "name": "height",
          "type": "INT",
          "widget": {
            "name": "height"
          },
          "link": 287
        },
        {
          "label": "upscale_method",
          "localized_name": "upscale_method",
          "name": "upscale_method",
          "type": "COMBO",
          "widget": {
            "name": "upscale_method"
          },
          "link": null
        },
        {
          "label": "keep_proportion",
          "localized_name": "keep_proportion",
          "name": "keep_proportion",
          "type": "COMBO",
          "widget": {
            "name": "keep_proportion"
          },
          "link": null
        },
        {
          "label": "pad_color",
          "localized_name": "pad_color",
          "name": "pad_color",
          "type": "STRING",
          "widget": {
            "name": "pad_color"
          },
          "link": null
        },
        {
          "label": "crop_position",
          "localized_name": "crop_position",
          "name": "crop_position",
          "type": "COMBO",
          "widget": {
            "name": "crop_position"
          },
          "link": null
        },
        {
          "label": "divisible_by",
          "localized_name": "divisible_by",
          "name": "divisible_by",
          "type": "INT",
          "widget": {
            "name": "divisible_by"
          },
          "link": null
        },
        {
          "label": "device",
          "localized_name": "device",
          "name": "device",
          "shape": 7,
          "type": "COMBO",
          "widget": {
            "name": "device"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "IMAGE",
          "localized_name": "图像",
          "name": "IMAGE",
          "type": "IMAGE",
          "links": [
            291,
            340,
            341,
            342
          ]
        },
        {
          "label": "width",
          "localized_name": "width",
          "name": "width",
          "type": "INT",
          "links": []
        },
        {
          "label": "height",
          "localized_name": "height",
          "name": "height",
          "type": "INT",
          "links": []
        },
        {
          "label": "mask",
          "localized_name": "mask",
          "name": "mask",
          "type": "MASK",
          "links": null
        }
      ],
      "properties": {
        "Node name for S&R": "ImageResizeKJv2",
        "cnr_id": "comfyui-kjnodes",
        "ver": "468fcc86f0b29e79a8510e8239eb15714d6747a6",
        "widget_ue_connectable": {
          "width": true,
          "height": true
        }
      },
      "widgets_values": [
        832,
        480,
        "lanczos",
        "crop",
        "0, 0, 0",
        "top",
        16,
        "cpu"
      ]
    },
    {
      "id": 172,
      "type": "PreviewImage",
      "pos": [
        -587.8831787109375,
        -1828.6434326171875
      ],
      "size": [
        222.21678161621094,
        411.2475891113281
      ],
      "flags": {},
      "order": 15,
      "mode": 0,
      "inputs": [
        {
          "label": "图像",
          "localized_name": "图像",
          "name": "images",
          "type": "IMAGE",
          "link": 291
        }
      ],
      "outputs": [
        {
          "localized_name": "images",
          "name": "images",
          "type": "IMAGE",
          "links": null
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.59",
        "Node name for S&R": "PreviewImage",
        "widget_ue_connectable": {}
      },
      "widgets_values": []
    },
    {
      "id": 190,
      "type": "VHS_SelectImages",
      "pos": [
        -533.4309692382812,
        -2926.588623046875
      ],
      "size": [
        213.822265625,
        106
      ],
      "flags": {},
      "order": 18,
      "mode": 0,
      "inputs": [
        {
          "label": "图像",
          "localized_name": "image",
          "name": "image",
          "type": "IMAGE",
          "link": 330
        },
        {
          "localized_name": "索引",
          "name": "indexes",
          "type": "STRING",
          "widget": {
            "name": "indexes"
          },
          "link": null
        },
        {
          "localized_name": "如果为缺失则报错",
          "name": "err_if_missing",
          "type": "BOOLEAN",
          "widget": {
            "name": "err_if_missing"
          },
          "link": null
        },
        {
          "localized_name": "如果为空则报错",
          "name": "err_if_empty",
          "type": "BOOLEAN",
          "widget": {
            "name": "err_if_empty"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "图像",
          "localized_name": "图像",
          "name": "IMAGE",
          "type": "IMAGE",
          "links": [
            331
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "VHS_SelectImages",
        "cnr_id": "comfyui-videohelpersuite",
        "ver": "0edce8ef7ce173ac97a3ed3d6f4636029d1a4530",
        "widget_ue_connectable": {}
      },
      "widgets_values": {
        "indexes": "0",
        "err_if_missing": true,
        "err_if_empty": true
      }
    },
    {
      "id": 184,
      "type": "PoseAndFaceDetection",
      "pos": [
        -529.2863159179688,
        -2621.033447265625
      ],
      "size": [
        313.125,
        186
      ],
      "flags": {},
      "order": 17,
      "mode": 0,
      "inputs": [
        {
          "label": "model",
          "localized_name": "model",
          "name": "model",
          "type": "POSEMODEL",
          "link": 309
        },
        {
          "label": "images",
          "localized_name": "images",
          "name": "images",
          "type": "IMAGE",
          "link": 311
        },
        {
          "label": "retarget_image",
          "localized_name": "retarget_image",
          "name": "retarget_image",
          "shape": 7,
          "type": "IMAGE",
          "link": null
        },
        {
          "label": "width",
          "localized_name": "width",
          "name": "width",
          "type": "INT",
          "widget": {
            "name": "width"
          },
          "link": 312
        },
        {
          "label": "height",
          "localized_name": "height",
          "name": "height",
          "type": "INT",
          "widget": {
            "name": "height"
          },
          "link": 313
        },
        {
          "label": "face_padding",
          "localized_name": "face_padding",
          "name": "face_padding",
          "shape": 7,
          "type": "INT",
          "widget": {
            "name": "face_padding"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "pose_data",
          "localized_name": "pose_data",
          "name": "pose_data",
          "type": "POSEDATA",
          "links": [
            315
          ]
        },
        {
          "label": "face_images",
          "localized_name": "face_images",
          "name": "face_images",
          "type": "IMAGE",
          "links": [
            347,
            348,
            351
          ]
        },
        {
          "label": "key_frame_body_points",
          "localized_name": "key_frame_body_points",
          "name": "key_frame_body_points",
          "type": "STRING",
          "links": []
        },
        {
          "label": "bboxes",
          "localized_name": "bboxes",
          "name": "bboxes",
          "type": "BBOX",
          "links": []
        },
        {
          "label": "face_bboxes",
          "localized_name": "face_bboxes",
          "name": "face_bboxes",
          "type": "BBOX,",
          "links": null
        }
      ],
      "properties": {
        "aux_id": "kijai/ComfyUI-WanAnimatePreprocess",
        "Node name for S&R": "PoseAndFaceDetection",
        "ver": "e63d6e71ae4c271f3f81211a7ca7f87607b7e50d",
        "widget_ue_connectable": {
          "width": true,
          "height": true
        }
      },
      "widgets_values": [
        832,
        480,
        0
      ]
    },
    {
      "id": 191,
      "type": "PreviewImage",
      "pos": [
        -189.8636474609375,
        -2930.092041015625
      ],
      "size": [
        269.3385009765625,
        383.2370300292969
      ],
      "flags": {},
      "order": 22,
      "mode": 0,
      "inputs": [
        {
          "label": "图像",
          "localized_name": "图像",
          "name": "images",
          "type": "IMAGE",
          "link": 331
        }
      ],
      "outputs": [
        {
          "localized_name": "images",
          "name": "images",
          "type": "IMAGE",
          "links": null
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.60",
        "Node name for S&R": "PreviewImage",
        "widget_ue_connectable": {}
      },
      "widgets_values": []
    },
    {
      "id": 27,
      "type": "WanVideoSampler",
      "pos": [
        2129.76953125,
        -1825.1961669921875
      ],
      "size": [
        315,
        902
      ],
      "flags": {},
      "order": 26,
      "mode": 0,
      "inputs": [
        {
          "label": "model",
          "localized_name": "model",
          "name": "model",
          "type": "WANVIDEOMODEL",
          "link": 63
        },
        {
          "label": "image_embeds",
          "localized_name": "image_embeds",
          "name": "image_embeds",
          "type": "WANVIDIMAGE_EMBEDS",
          "link": 333
        },
        {
          "label": "text_embeds",
          "localized_name": "text_embeds",
          "name": "text_embeds",
          "shape": 7,
          "type": "WANVIDEOTEXTEMBEDS",
          "link": 281
        },
        {
          "label": "samples",
          "localized_name": "samples",
          "name": "samples",
          "shape": 7,
          "type": "LATENT",
          "link": null
        },
        {
          "label": "feta_args",
          "localized_name": "feta_args",
          "name": "feta_args",
          "shape": 7,
          "type": "FETAARGS",
          "link": null
        },
        {
          "label": "context_options",
          "localized_name": "context_options",
          "name": "context_options",
          "shape": 7,
          "type": "WANVIDCONTEXT",
          "link": null
        },
        {
          "label": "cache_args",
          "localized_name": "cache_args",
          "name": "cache_args",
          "shape": 7,
          "type": "CACHEARGS",
          "link": null
        },
        {
          "label": "flowedit_args",
          "localized_name": "flowedit_args",
          "name": "flowedit_args",
          "shape": 7,
          "type": "FLOWEDITARGS",
          "link": null
        },
        {
          "label": "slg_args",
          "localized_name": "slg_args",
          "name": "slg_args",
          "shape": 7,
          "type": "SLGARGS",
          "link": null
        },
        {
          "label": "loop_args",
          "localized_name": "loop_args",
          "name": "loop_args",
          "shape": 7,
          "type": "LOOPARGS",
          "link": null
        },
        {
          "label": "experimental_args",
          "localized_name": "experimental_args",
          "name": "experimental_args",
          "shape": 7,
          "type": "EXPERIMENTALARGS",
          "link": null
        },
        {
          "label": "sigmas",
          "localized_name": "sigmas",
          "name": "sigmas",
          "shape": 7,
          "type": "SIGMAS",
          "link": null
        },
        {
          "label": "unianimate_poses",
          "localized_name": "unianimate_poses",
          "name": "unianimate_poses",
          "shape": 7,
          "type": "UNIANIMATE_POSE",
          "link": null
        },
        {
          "label": "fantasytalking_embeds",
          "localized_name": "fantasytalking_embeds",
          "name": "fantasytalking_embeds",
          "shape": 7,
          "type": "FANTASYTALKING_EMBEDS",
          "link": null
        },
        {
          "label": "uni3c_embeds",
          "localized_name": "uni3c_embeds",
          "name": "uni3c_embeds",
          "shape": 7,
          "type": "UNI3C_EMBEDS",
          "link": null
        },
        {
          "label": "multitalk_embeds",
          "localized_name": "multitalk_embeds",
          "name": "multitalk_embeds",
          "shape": 7,
          "type": "MULTITALK_EMBEDS",
          "link": null
        },
        {
          "label": "freeinit_args",
          "localized_name": "freeinit_args",
          "name": "freeinit_args",
          "shape": 7,
          "type": "FREEINITARGS",
          "link": null
        },
        {
          "label": "steps",
          "localized_name": "steps",
          "name": "steps",
          "type": "INT",
          "widget": {
            "name": "steps"
          },
          "link": null
        },
        {
          "label": "cfg",
          "localized_name": "cfg",
          "name": "cfg",
          "type": "FLOAT",
          "widget": {
            "name": "cfg"
          },
          "link": null
        },
        {
          "label": "shift",
          "localized_name": "shift",
          "name": "shift",
          "type": "FLOAT",
          "widget": {
            "name": "shift"
          },
          "link": null
        },
        {
          "label": "seed",
          "localized_name": "seed",
          "name": "seed",
          "type": "INT",
          "widget": {
            "name": "seed"
          },
          "link": null
        },
        {
          "label": "force_offload",
          "localized_name": "force_offload",
          "name": "force_offload",
          "type": "BOOLEAN",
          "widget": {
            "name": "force_offload"
          },
          "link": null
        },
        {
          "label": "scheduler",
          "localized_name": "scheduler",
          "name": "scheduler",
          "type": "COMBO",
          "widget": {
            "name": "scheduler"
          },
          "link": null
        },
        {
          "label": "riflex_freq_index",
          "localized_name": "riflex_freq_index",
          "name": "riflex_freq_index",
          "type": "INT",
          "widget": {
            "name": "riflex_freq_index"
          },
          "link": null
        },
        {
          "label": "denoise_strength",
          "localized_name": "denoise_strength",
          "name": "denoise_strength",
          "shape": 7,
          "type": "FLOAT",
          "widget": {
            "name": "denoise_strength"
          },
          "link": null
        },
        {
          "label": "batched_cfg",
          "localized_name": "batched_cfg",
          "name": "batched_cfg",
          "shape": 7,
          "type": "BOOLEAN",
          "widget": {
            "name": "batched_cfg"
          },
          "link": null
        },
        {
          "label": "rope_function",
          "localized_name": "rope_function",
          "name": "rope_function",
          "shape": 7,
          "type": "COMBO",
          "widget": {
            "name": "rope_function"
          },
          "link": null
        },
        {
          "label": "start_step",
          "localized_name": "start_step",
          "name": "start_step",
          "shape": 7,
          "type": "INT",
          "widget": {
            "name": "start_step"
          },
          "link": null
        },
        {
          "label": "end_step",
          "localized_name": "end_step",
          "name": "end_step",
          "shape": 7,
          "type": "INT",
          "widget": {
            "name": "end_step"
          },
          "link": null
        },
        {
          "label": "add_noise_to_samples",
          "localized_name": "add_noise_to_samples",
          "name": "add_noise_to_samples",
          "shape": 7,
          "type": "BOOLEAN",
          "widget": {
            "name": "add_noise_to_samples"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "samples",
          "localized_name": "samples",
          "name": "samples",
          "type": "LATENT",
          "slot_index": 0,
          "links": [
            33
          ]
        },
        {
          "label": "denoised_samples",
          "localized_name": "denoised_samples",
          "name": "denoised_samples",
          "type": "LATENT",
          "links": null
        }
      ],
      "properties": {
        "Node name for S&R": "WanVideoSampler",
        "cnr_id": "ComfyUI-WanVideoWrapper",
        "ver": "e5ef9752a7e846b232fc05fd993327a2e870a788",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        6,
        1,
        5,
        42,
        "fixed",
        true,
        "dpm++_sde",
        0,
        1,
        "",
        "comfy",
        0,
        -1,
        false
      ]
    },
    {
      "id": 28,
      "type": "WanVideoDecode",
      "pos": [
        2469.76953125,
        -1675.1961669921875
      ],
      "size": [
        280.3896179199219,
        198
      ],
      "flags": {},
      "order": 27,
      "mode": 0,
      "inputs": [
        {
          "label": "vae",
          "localized_name": "vae",
          "name": "vae",
          "type": "WANVAE",
          "link": 344
        },
        {
          "label": "samples",
          "localized_name": "samples",
          "name": "samples",
          "type": "LATENT",
          "link": 33
        },
        {
          "label": "enable_vae_tiling",
          "localized_name": "enable_vae_tiling",
          "name": "enable_vae_tiling",
          "type": "BOOLEAN",
          "widget": {
            "name": "enable_vae_tiling"
          },
          "link": null
        },
        {
          "label": "tile_x",
          "localized_name": "tile_x",
          "name": "tile_x",
          "type": "INT",
          "widget": {
            "name": "tile_x"
          },
          "link": null
        },
        {
          "label": "tile_y",
          "localized_name": "tile_y",
          "name": "tile_y",
          "type": "INT",
          "widget": {
            "name": "tile_y"
          },
          "link": null
        },
        {
          "label": "tile_stride_x",
          "localized_name": "tile_stride_x",
          "name": "tile_stride_x",
          "type": "INT",
          "widget": {
            "name": "tile_stride_x"
          },
          "link": null
        },
        {
          "label": "tile_stride_y",
          "localized_name": "tile_stride_y",
          "name": "tile_stride_y",
          "type": "INT",
          "widget": {
            "name": "tile_stride_y"
          },
          "link": null
        },
        {
          "label": "normalization",
          "localized_name": "normalization",
          "name": "normalization",
          "shape": 7,
          "type": "COMBO",
          "widget": {
            "name": "normalization"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "images",
          "localized_name": "images",
          "name": "images",
          "type": "IMAGE",
          "slot_index": 0,
          "links": [
            48,
            334
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "WanVideoDecode",
        "cnr_id": "ComfyUI-WanVideoWrapper",
        "ver": "e5ef9752a7e846b232fc05fd993327a2e870a788",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        false,
        272,
        272,
        144,
        128,
        "default"
      ]
    },
    {
      "id": 42,
      "type": "GetImageSizeAndCount",
      "pos": [
        2469.76953125,
        -1815.1961669921875
      ],
      "size": [
        277.20001220703125,
        86
      ],
      "flags": {},
      "order": 28,
      "mode": 0,
      "inputs": [
        {
          "label": "图像",
          "localized_name": "image",
          "name": "image",
          "type": "IMAGE",
          "link": 48
        }
      ],
      "outputs": [
        {
          "label": "图像",
          "localized_name": "image",
          "name": "image",
          "type": "IMAGE",
          "slot_index": 0,
          "links": [
            87
          ]
        },
        {
          "label": "宽度",
          "localized_name": "width",
          "name": "width",
          "type": "INT",
          "links": null
        },
        {
          "label": "高度",
          "localized_name": "height",
          "name": "height",
          "type": "INT",
          "links": null
        },
        {
          "label": "数量",
          "localized_name": "count",
          "name": "count",
          "type": "INT",
          "links": null
        }
      ],
      "properties": {
        "Node name for S&R": "GetImageSizeAndCount",
        "cnr_id": "comfyui-kjnodes",
        "ver": "36f6fdd7d4c393675ac622bd300ef667ee65d8b8",
        "widget_ue_connectable": {}
      },
      "widgets_values": []
    },
    {
      "id": 77,
      "type": "ImageConcatMulti",
      "pos": [
        2469.76953125,
        -1435.1961669921875
      ],
      "size": [
        270,
        190
      ],
      "flags": {},
      "order": 24,
      "mode": 0,
      "inputs": [
        {
          "label": "图像_1",
          "localized_name": "image_1",
          "name": "image_1",
          "type": "IMAGE",
          "link": 342
        },
        {
          "label": "图像_2",
          "localized_name": "image_2",
          "name": "image_2",
          "shape": 7,
          "type": "IMAGE",
          "link": 347
        },
        {
          "localized_name": "输入数量",
          "name": "inputcount",
          "type": "INT",
          "widget": {
            "name": "inputcount"
          },
          "link": null
        },
        {
          "localized_name": "方向",
          "name": "direction",
          "type": "COMBO",
          "widget": {
            "name": "direction"
          },
          "link": null
        },
        {
          "localized_name": "匹配尺寸",
          "name": "match_image_size",
          "type": "BOOLEAN",
          "widget": {
            "name": "match_image_size"
          },
          "link": null
        },
        {
          "label": "image_3",
          "name": "image_3",
          "shape": 7,
          "type": "IMAGE",
          "link": 345
        },
        {
          "label": "image_4",
          "name": "image_4",
          "shape": 7,
          "type": "IMAGE",
          "link": 338
        }
      ],
      "outputs": [
        {
          "label": "图像",
          "localized_name": "images",
          "name": "images",
          "type": "IMAGE",
          "links": [
            107
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "ImageConcatMulti",
        "cnr_id": "comfyui-kjnodes",
        "ver": "468fcc86f0b29e79a8510e8239eb15714d6747a6",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        4,
        "down",
        true,
        null
      ]
    },
    {
      "id": 66,
      "type": "ImageConcatMulti",
      "pos": [
        2479.76953125,
        -1195.196044921875
      ],
      "size": [
        270,
        150
      ],
      "flags": {},
      "order": 30,
      "mode": 0,
      "inputs": [
        {
          "label": "图像_1",
          "localized_name": "image_1",
          "name": "image_1",
          "type": "IMAGE",
          "link": 87
        },
        {
          "label": "图像_2",
          "localized_name": "image_2",
          "name": "image_2",
          "shape": 7,
          "type": "IMAGE",
          "link": 107
        },
        {
          "localized_name": "输入数量",
          "name": "inputcount",
          "type": "INT",
          "widget": {
            "name": "inputcount"
          },
          "link": null
        },
        {
          "localized_name": "方向",
          "name": "direction",
          "type": "COMBO",
          "widget": {
            "name": "direction"
          },
          "link": null
        },
        {
          "localized_name": "匹配尺寸",
          "name": "match_image_size",
          "type": "BOOLEAN",
          "widget": {
            "name": "match_image_size"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "图像",
          "localized_name": "images",
          "name": "images",
          "type": "IMAGE",
          "links": [
            89
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "ImageConcatMulti",
        "cnr_id": "comfyui-kjnodes",
        "ver": "468fcc86f0b29e79a8510e8239eb15714d6747a6",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        2,
        "left",
        true,
        null
      ]
    },
    {
      "id": 70,
      "type": "WanVideoClipVisionEncode",
      "pos": [
        1519.765869140625,
        -1815.1961669921875
      ],
      "size": [
        280.9771423339844,
        262
      ],
      "flags": {},
      "order": 16,
      "mode": 0,
      "inputs": [
        {
          "label": "clip_vision",
          "localized_name": "clip_vision",
          "name": "clip_vision",
          "type": "CLIP_VISION",
          "link": 97
        },
        {
          "label": "image_1",
          "localized_name": "image_1",
          "name": "image_1",
          "type": "IMAGE",
          "link": 340
        },
        {
          "label": "image_2",
          "localized_name": "image_2",
          "name": "image_2",
          "shape": 7,
          "type": "IMAGE",
          "link": null
        },
        {
          "label": "negative_image",
          "localized_name": "negative_image",
          "name": "negative_image",
          "shape": 7,
          "type": "IMAGE",
          "link": null
        },
        {
          "label": "strength_1",
          "localized_name": "strength_1",
          "name": "strength_1",
          "type": "FLOAT",
          "widget": {
            "name": "strength_1"
          },
          "link": null
        },
        {
          "label": "strength_2",
          "localized_name": "strength_2",
          "name": "strength_2",
          "type": "FLOAT",
          "widget": {
            "name": "strength_2"
          },
          "link": null
        },
        {
          "label": "crop",
          "localized_name": "crop",
          "name": "crop",
          "type": "COMBO",
          "widget": {
            "name": "crop"
          },
          "link": null
        },
        {
          "label": "combine_embeds",
          "localized_name": "combine_embeds",
          "name": "combine_embeds",
          "type": "COMBO",
          "widget": {
            "name": "combine_embeds"
          },
          "link": null
        },
        {
          "label": "force_offload",
          "localized_name": "force_offload",
          "name": "force_offload",
          "type": "BOOLEAN",
          "widget": {
            "name": "force_offload"
          },
          "link": null
        },
        {
          "label": "tiles",
          "localized_name": "tiles",
          "name": "tiles",
          "shape": 7,
          "type": "INT",
          "widget": {
            "name": "tiles"
          },
          "link": null
        },
        {
          "label": "ratio",
          "localized_name": "ratio",
          "name": "ratio",
          "shape": 7,
          "type": "FLOAT",
          "widget": {
            "name": "ratio"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "image_embeds",
          "localized_name": "image_embeds",
          "name": "image_embeds",
          "type": "WANVIDIMAGE_CLIPEMBEDS",
          "links": [
            96
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "WanVideoClipVisionEncode",
        "cnr_id": "ComfyUI-WanVideoWrapper",
        "ver": "2bdd81a10b03c14443c79bdf3b783b1feb3d1fa3",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        1,
        1,
        "center",
        "average",
        true,
        0,
        0.5
      ],
      "color": "#233",
      "bgcolor": "#355"
    },
    {
      "id": 30,
      "type": "VHS_VideoCombine",
      "pos": [
        2821.869140625,
        -1872.3751220703125
      ],
      "size": [
        1069.339599609375,
        334
      ],
      "flags": {},
      "order": 31,
      "mode": 0,
      "inputs": [
        {
          "label": "图像",
          "localized_name": "images",
          "name": "images",
          "type": "IMAGE",
          "link": 89
        },
        {
          "label": "音频",
          "localized_name": "audio",
          "name": "audio",
          "shape": 7,
          "type": "AUDIO",
          "link": 337
        },
        {
          "label": "批次管理",
          "localized_name": "meta_batch",
          "name": "meta_batch",
          "shape": 7,
          "type": "VHS_BatchManager",
          "link": null
        },
        {
          "label": "vae",
          "localized_name": "vae",
          "name": "vae",
          "shape": 7,
          "type": "VAE",
          "link": null
        },
        {
          "localized_name": "帧率",
          "name": "frame_rate",
          "type": "FLOAT",
          "widget": {
            "name": "frame_rate"
          },
          "link": null
        },
        {
          "localized_name": "循环次数",
          "name": "loop_count",
          "type": "INT",
          "widget": {
            "name": "loop_count"
          },
          "link": null
        },
        {
          "localized_name": "文件名前缀",
          "name": "filename_prefix",
          "type": "STRING",
          "widget": {
            "name": "filename_prefix"
          },
          "link": null
        },
        {
          "localized_name": "格式",
          "name": "format",
          "type": "COMBO",
          "widget": {
            "name": "format"
          },
          "link": null
        },
        {
          "localized_name": "Ping-Pong",
          "name": "pingpong",
          "type": "BOOLEAN",
          "widget": {
            "name": "pingpong"
          },
          "link": null
        },
        {
          "localized_name": "保存到输出文件夹",
          "name": "save_output",
          "type": "BOOLEAN",
          "widget": {
            "name": "save_output"
          },
          "link": null
        },
        {
          "name": "pix_fmt",
          "type": [
            "yuv420p",
            "yuv420p10le"
          ],
          "widget": {
            "name": "pix_fmt"
          },
          "link": null
        },
        {
          "name": "crf",
          "type": "INT",
          "widget": {
            "name": "crf"
          },
          "link": null
        },
        {
          "label": "保存元数据",
          "localized_name": "保存元数据",
          "name": "save_metadata",
          "type": "BOOLEAN",
          "widget": {
            "name": "save_metadata"
          },
          "link": null
        },
        {
          "name": "trim_to_audio",
          "type": "BOOLEAN",
          "widget": {
            "name": "trim_to_audio"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "文件名",
          "localized_name": "Filenames",
          "name": "Filenames",
          "type": "VHS_FILENAMES",
          "links": null
        }
      ],
      "properties": {
        "Node name for S&R": "VHS_VideoCombine",
        "cnr_id": "comfyui-videohelpersuite",
        "ver": "8e4d79471bf1952154768e8435a9300077b534fa",
        "widget_ue_connectable": {}
      },
      "widgets_values": {
        "frame_rate": 30,
        "loop_count": 0,
        "filename_prefix": "Wanimate",
        "format": "video/h264-mp4",
        "pix_fmt": "yuv420p",
        "crf": 19,
        "save_metadata": true,
        "trim_to_audio": false,
        "pingpong": false,
        "save_output": true,
        "videopreview": {
          "hidden": false,
          "paused": false,
          "params": {
            "filename": "Wanimate_00043-audio.mp4",
            "subfolder": "",
            "type": "output",
            "format": "video/h264-mp4",
            "frame_rate": 30,
            "workflow": "Wanimate_00043.png",
            "fullpath": "/ComfyUI/output/Wanimate_00043-audio.mp4"
          }
        }
      }
    },
    {
      "id": 192,
      "type": "VHS_VideoCombine",
      "pos": [
        3939.92822265625,
        -1873.1243896484375
      ],
      "size": [
        551.8701782226562,
        334
      ],
      "flags": {},
      "order": 29,
      "mode": 0,
      "inputs": [
        {
          "label": "图像",
          "localized_name": "images",
          "name": "images",
          "type": "IMAGE",
          "link": 334
        },
        {
          "label": "音频",
          "localized_name": "audio",
          "name": "audio",
          "shape": 7,
          "type": "AUDIO",
          "link": 336
        },
        {
          "label": "批次管理",
          "localized_name": "meta_batch",
          "name": "meta_batch",
          "shape": 7,
          "type": "VHS_BatchManager",
          "link": null
        },
        {
          "label": "vae",
          "localized_name": "vae",
          "name": "vae",
          "shape": 7,
          "type": "VAE",
          "link": null
        },
        {
          "localized_name": "帧率",
          "name": "frame_rate",
          "type": "FLOAT",
          "widget": {
            "name": "frame_rate"
          },
          "link": null
        },
        {
          "localized_name": "循环次数",
          "name": "loop_count",
          "type": "INT",
          "widget": {
            "name": "loop_count"
          },
          "link": null
        },
        {
          "localized_name": "文件名前缀",
          "name": "filename_prefix",
          "type": "STRING",
          "widget": {
            "name": "filename_prefix"
          },
          "link": null
        },
        {
          "localized_name": "格式",
          "name": "format",
          "type": "COMBO",
          "widget": {
            "name": "format"
          },
          "link": null
        },
        {
          "localized_name": "Ping-Pong",
          "name": "pingpong",
          "type": "BOOLEAN",
          "widget": {
            "name": "pingpong"
          },
          "link": null
        },
        {
          "localized_name": "保存到输出文件夹",
          "name": "save_output",
          "type": "BOOLEAN",
          "widget": {
            "name": "save_output"
          },
          "link": null
        },
        {
          "name": "pix_fmt",
          "type": [
            "yuv420p",
            "yuv420p10le"
          ],
          "widget": {
            "name": "pix_fmt"
          },
          "link": null
        },
        {
          "name": "crf",
          "type": "INT",
          "widget": {
            "name": "crf"
          },
          "link": null
        },
        {
          "label": "保存元数据",
          "localized_name": "保存元数据",
          "name": "save_metadata",
          "type": "BOOLEAN",
          "widget": {
            "name": "save_metadata"
          },
          "link": null
        },
        {
          "name": "trim_to_audio",
          "type": "BOOLEAN",
          "widget": {
            "name": "trim_to_audio"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "文件名",
          "localized_name": "Filenames",
          "name": "Filenames",
          "type": "VHS_FILENAMES",
          "links": null
        }
      ],
      "properties": {
        "Node name for S&R": "VHS_VideoCombine",
        "cnr_id": "comfyui-videohelpersuite",
        "ver": "8e4d79471bf1952154768e8435a9300077b534fa",
        "widget_ue_connectable": {}
      },
      "widgets_values": {
        "frame_rate": 30,
        "loop_count": 0,
        "filename_prefix": "Wanimate",
        "format": "video/h264-mp4",
        "pix_fmt": "yuv420p",
        "crf": 19,
        "save_metadata": true,
        "trim_to_audio": false,
        "pingpong": false,
        "save_output": true,
        "videopreview": {
          "hidden": false,
          "paused": false,
          "params": {
            "filename": "Wanimate_00042-audio.mp4",
            "subfolder": "",
            "type": "output",
            "format": "video/h264-mp4",
            "frame_rate": 30,
            "workflow": "Wanimate_00042.png",
            "fullpath": "/ComfyUI/output/Wanimate_00042-audio.mp4"
          }
        }
      }
    },
    {
      "id": 57,
      "type": "LoadImage",
      "pos": [
        -1206.9171142578125,
        -1833.0458984375
      ],
      "size": [
        299.1521301269531,
        550.3935546875
      ],
      "flags": {},
      "order": 2,
      "mode": 0,
      "inputs": [
        {
          "localized_name": "图像",
          "name": "image",
          "type": "COMBO",
          "widget": {
            "name": "image"
          },
          "link": null
        },
        {
          "localized_name": "选择文件上传",
          "name": "upload",
          "type": "IMAGEUPLOAD",
          "widget": {
            "name": "upload"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "图像",
          "localized_name": "图像",
          "name": "IMAGE",
          "type": "IMAGE",
          "links": [
            82
          ]
        },
        {
          "label": "遮罩",
          "localized_name": "遮罩",
          "name": "MASK",
          "type": "MASK",
          "links": null
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.57",
        "Node name for S&R": "LoadImage",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "cefc1e178a82b9014a900fb482c4be773912b21b41ab.webp",
        "image"
      ]
    },
    {
      "id": 112,
      "type": "VHS_VideoCombine",
      "pos": [
        100.1931381225586,
        -2924.198974609375
      ],
      "size": [
        395.6411437988281,
        334
      ],
      "flags": {},
      "order": 21,
      "mode": 0,
      "inputs": [
        {
          "label": "图像",
          "localized_name": "images",
          "name": "images",
          "type": "IMAGE",
          "link": 351
        },
        {
          "label": "音频",
          "localized_name": "audio",
          "name": "audio",
          "shape": 7,
          "type": "AUDIO",
          "link": null
        },
        {
          "label": "批次管理",
          "localized_name": "meta_batch",
          "name": "meta_batch",
          "shape": 7,
          "type": "VHS_BatchManager",
          "link": null
        },
        {
          "label": "vae",
          "localized_name": "vae",
          "name": "vae",
          "shape": 7,
          "type": "VAE",
          "link": null
        },
        {
          "localized_name": "帧率",
          "name": "frame_rate",
          "type": "FLOAT",
          "widget": {
            "name": "frame_rate"
          },
          "link": null
        },
        {
          "localized_name": "循环次数",
          "name": "loop_count",
          "type": "INT",
          "widget": {
            "name": "loop_count"
          },
          "link": null
        },
        {
          "localized_name": "文件名前缀",
          "name": "filename_prefix",
          "type": "STRING",
          "widget": {
            "name": "filename_prefix"
          },
          "link": null
        },
        {
          "localized_name": "格式",
          "name": "format",
          "type": "COMBO",
          "widget": {
            "name": "format"
          },
          "link": null
        },
        {
          "localized_name": "Ping-Pong",
          "name": "pingpong",
          "type": "BOOLEAN",
          "widget": {
            "name": "pingpong"
          },
          "link": null
        },
        {
          "localized_name": "保存到输出文件夹",
          "name": "save_output",
          "type": "BOOLEAN",
          "widget": {
            "name": "save_output"
          },
          "link": null
        },
        {
          "name": "pix_fmt",
          "type": [
            "yuv420p",
            "yuv420p10le"
          ],
          "widget": {
            "name": "pix_fmt"
          },
          "link": null
        },
        {
          "name": "crf",
          "type": "INT",
          "widget": {
            "name": "crf"
          },
          "link": null
        },
        {
          "label": "保存元数据",
          "localized_name": "保存元数据",
          "name": "save_metadata",
          "type": "BOOLEAN",
          "widget": {
            "name": "save_metadata"
          },
          "link": null
        },
        {
          "name": "trim_to_audio",
          "type": "BOOLEAN",
          "widget": {
            "name": "trim_to_audio"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "文件名",
          "localized_name": "Filenames",
          "name": "Filenames",
          "type": "VHS_FILENAMES",
          "links": null
        }
      ],
      "properties": {
        "Node name for S&R": "VHS_VideoCombine",
        "cnr_id": "comfyui-videohelpersuite",
        "ver": "8e4d79471bf1952154768e8435a9300077b534fa",
        "widget_ue_connectable": {}
      },
      "widgets_values": {
        "frame_rate": 30,
        "loop_count": 0,
        "filename_prefix": "WanVideo2_1_T2V",
        "format": "video/h264-mp4",
        "pix_fmt": "yuv420p",
        "crf": 19,
        "save_metadata": true,
        "trim_to_audio": false,
        "pingpong": false,
        "save_output": false,
        "videopreview": {
          "hidden": false,
          "paused": false,
          "params": {
            "filename": "WanVideo2_1_T2V_00001.mp4",
            "subfolder": "",
            "type": "temp",
            "format": "video/h264-mp4",
            "frame_rate": 30,
            "workflow": "WanVideo2_1_T2V_00001.png",
            "fullpath": "/ComfyUI/temp/WanVideo2_1_T2V_00001.mp4"
          }
        }
      }
    },
    {
      "id": 65,
      "type": "WanVideoTextEncodeCached",
      "pos": [
        1609.765869140625,
        -1415.1961669921875
      ],
      "size": [
        488.4488220214844,
        362.56817626953125
      ],
      "flags": {},
      "order": 3,
      "mode": 0,
      "inputs": [
        {
          "label": "extender_args",
          "localized_name": "extender_args",
          "name": "extender_args",
          "shape": 7,
          "type": "WANVIDEOPROMPTEXTENDER_ARGS",
          "link": null
        },
        {
          "label": "model_name",
          "localized_name": "model_name",
          "name": "model_name",
          "type": "COMBO",
          "widget": {
            "name": "model_name"
          },
          "link": null
        },
        {
          "label": "precision",
          "localized_name": "precision",
          "name": "precision",
          "type": "COMBO",
          "widget": {
            "name": "precision"
          },
          "link": null
        },
        {
          "label": "positive_prompt",
          "localized_name": "positive_prompt",
          "name": "positive_prompt",
          "type": "STRING",
          "widget": {
            "name": "positive_prompt"
          },
          "link": null
        },
        {
          "label": "negative_prompt",
          "localized_name": "negative_prompt",
          "name": "negative_prompt",
          "type": "STRING",
          "widget": {
            "name": "negative_prompt"
          },
          "link": null
        },
        {
          "label": "quantization",
          "localized_name": "quantization",
          "name": "quantization",
          "type": "COMBO",
          "widget": {
            "name": "quantization"
          },
          "link": null
        },
        {
          "label": "use_disk_cache",
          "localized_name": "use_disk_cache",
          "name": "use_disk_cache",
          "type": "BOOLEAN",
          "widget": {
            "name": "use_disk_cache"
          },
          "link": null
        },
        {
          "label": "device",
          "localized_name": "device",
          "name": "device",
          "type": "COMBO",
          "widget": {
            "name": "device"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "text_embeds",
          "localized_name": "text_embeds",
          "name": "text_embeds",
          "type": "WANVIDEOTEXTEMBEDS",
          "links": [
            281
          ]
        },
        {
          "label": "negative_text_embeds",
          "localized_name": "negative_text_embeds",
          "name": "negative_text_embeds",
          "type": "WANVIDEOTEXTEMBEDS",
          "links": null
        },
        {
          "label": "positive_prompt",
          "localized_name": "positive_prompt",
          "name": "positive_prompt",
          "type": "STRING",
          "links": null
        }
      ],
      "properties": {
        "Node name for S&R": "WanVideoTextEncodeCached",
        "cnr_id": "ComfyUI-WanVideoWrapper",
        "ver": "761b1d191e50d589465e31dc0d40ff7c59b1b7b0",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "umt5-xxl-enc-fp8_e4m3fn.safetensors",
        "bf16",
        "",
        "色调艳丽，过曝，静态，细节模糊不清，字幕，风格，作品，画作，画面，静止，整体发灰，最差质量，低质量，JPEG压缩残留，丑陋的，残缺的，多余的手指，画得不好的手部，画得不好的脸部，畸形的，毁容的，形态畸形的肢体，手指融合，静止不动的画面，杂乱的背景，三条腿，背景人很多，倒着走",
        "disabled",
        false,
        "gpu"
      ],
      "color": "#432",
      "bgcolor": "#653"
    },
    {
      "id": 186,
      "type": "DrawViTPose",
      "pos": [
        -523.9083251953125,
        -2398.559326171875
      ],
      "size": [
        270,
        178
      ],
      "flags": {},
      "order": 20,
      "mode": 0,
      "inputs": [
        {
          "label": "pose_data",
          "localized_name": "pose_data",
          "name": "pose_data",
          "type": "POSEDATA",
          "link": 315
        },
        {
          "label": "width",
          "localized_name": "width",
          "name": "width",
          "type": "INT",
          "widget": {
            "name": "width"
          },
          "link": 316
        },
        {
          "label": "height",
          "localized_name": "height",
          "name": "height",
          "type": "INT",
          "widget": {
            "name": "height"
          },
          "link": 317
        },
        {
          "label": "retarget_padding",
          "localized_name": "retarget_padding",
          "name": "retarget_padding",
          "type": "INT",
          "widget": {
            "name": "retarget_padding"
          },
          "link": null
        },
        {
          "label": "body_stick_width",
          "localized_name": "body_stick_width",
          "name": "body_stick_width",
          "type": "INT",
          "widget": {
            "name": "body_stick_width"
          },
          "link": null
        },
        {
          "label": "hand_stick_width",
          "localized_name": "hand_stick_width",
          "name": "hand_stick_width",
          "type": "INT",
          "widget": {
            "name": "hand_stick_width"
          },
          "link": null
        },
        {
          "label": "draw_head",
          "localized_name": "draw_head",
          "name": "draw_head",
          "type": "BOOLEAN",
          "widget": {
            "name": "draw_head"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "pose_images",
          "localized_name": "pose_images",
          "name": "pose_images",
          "type": "IMAGE",
          "links": [
            318,
            345,
            346
          ]
        }
      ],
      "properties": {
        "aux_id": "kijai/ComfyUI-WanAnimatePreprocess",
        "Node name for S&R": "DrawViTPose",
        "ver": "e63d6e71ae4c271f3f81211a7ca7f87607b7e50d",
        "widget_ue_connectable": {
          "width": true,
          "height": true
        }
      },
      "widgets_values": [
        832,
        480,
        16,
        -1,
        -1,
        "True"
      ]
    },
    {
      "id": 187,
      "type": "VHS_VideoCombine",
      "pos": [
        1127.7979736328125,
        -3100.049560546875
      ],
      "size": [
        457.1752014160156,
        334
      ],
      "flags": {},
      "order": 23,
      "mode": 0,
      "inputs": [
        {
          "label": "图像",
          "localized_name": "images",
          "name": "images",
          "type": "IMAGE",
          "link": 318
        },
        {
          "label": "音频",
          "localized_name": "audio",
          "name": "audio",
          "shape": 7,
          "type": "AUDIO",
          "link": null
        },
        {
          "label": "批次管理",
          "localized_name": "meta_batch",
          "name": "meta_batch",
          "shape": 7,
          "type": "VHS_BatchManager",
          "link": null
        },
        {
          "label": "vae",
          "localized_name": "vae",
          "name": "vae",
          "shape": 7,
          "type": "VAE",
          "link": null
        },
        {
          "localized_name": "帧率",
          "name": "frame_rate",
          "type": "FLOAT",
          "widget": {
            "name": "frame_rate"
          },
          "link": null
        },
        {
          "localized_name": "循环次数",
          "name": "loop_count",
          "type": "INT",
          "widget": {
            "name": "loop_count"
          },
          "link": null
        },
        {
          "localized_name": "文件名前缀",
          "name": "filename_prefix",
          "type": "STRING",
          "widget": {
            "name": "filename_prefix"
          },
          "link": null
        },
        {
          "localized_name": "格式",
          "name": "format",
          "type": "COMBO",
          "widget": {
            "name": "format"
          },
          "link": null
        },
        {
          "localized_name": "Ping-Pong",
          "name": "pingpong",
          "type": "BOOLEAN",
          "widget": {
            "name": "pingpong"
          },
          "link": null
        },
        {
          "localized_name": "保存到输出文件夹",
          "name": "save_output",
          "type": "BOOLEAN",
          "widget": {
            "name": "save_output"
          },
          "link": null
        },
        {
          "name": "pix_fmt",
          "type": [
            "yuv420p",
            "yuv420p10le"
          ],
          "widget": {
            "name": "pix_fmt"
          },
          "link": null
        },
        {
          "name": "crf",
          "type": "INT",
          "widget": {
            "name": "crf"
          },
          "link": null
        },
        {
          "label": "保存元数据",
          "localized_name": "保存元数据",
          "name": "save_metadata",
          "type": "BOOLEAN",
          "widget": {
            "name": "save_metadata"
          },
          "link": null
        },
        {
          "name": "trim_to_audio",
          "type": "BOOLEAN",
          "widget": {
            "name": "trim_to_audio"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "文件名",
          "localized_name": "Filenames",
          "name": "Filenames",
          "type": "VHS_FILENAMES",
          "links": null
        }
      ],
      "properties": {
        "Node name for S&R": "VHS_VideoCombine",
        "cnr_id": "comfyui-videohelpersuite",
        "ver": "8e4d79471bf1952154768e8435a9300077b534fa",
        "widget_ue_connectable": {}
      },
      "widgets_values": {
        "frame_rate": 30,
        "loop_count": 0,
        "filename_prefix": "WanVideo2_1_T2V",
        "format": "video/h264-mp4",
        "pix_fmt": "yuv420p",
        "crf": 19,
        "save_metadata": true,
        "trim_to_audio": false,
        "pingpong": false,
        "save_output": false,
        "videopreview": {
          "hidden": false,
          "paused": false,
          "params": {
            "filename": "WanVideo2_1_T2V_00002.mp4",
            "subfolder": "",
            "type": "temp",
            "format": "video/h264-mp4",
            "frame_rate": 30,
            "workflow": "WanVideo2_1_T2V_00002.png",
            "fullpath": "/ComfyUI/temp/WanVideo2_1_T2V_00002.mp4"
          }
        }
      }
    },
    {
      "id": 71,
      "type": "CLIPVisionLoader",
      "pos": [
        -196.23793029785156,
        -1386.744140625
      ],
      "size": [
        595.8147583007812,
        61.25818634033203
      ],
      "flags": {},
      "order": 5,
      "mode": 0,
      "inputs": [
        {
          "localized_name": "CLIP名称",
          "name": "clip_name",
          "type": "COMBO",
          "widget": {
            "name": "clip_name"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "CLIP视觉",
          "localized_name": "CLIP视觉",
          "name": "CLIP_VISION",
          "type": "CLIP_VISION",
          "links": [
            97
          ]
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.3.59",
        "Node name for S&R": "CLIPVisionLoader",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "clip_vision_h.safetensors"
      ],
      "color": "#2a363b",
      "bgcolor": "#3f5159"
    },
    {
      "id": 63,
      "type": "VHS_LoadVideo",
      "pos": [
        -1185.73095703125,
        -2939.016845703125
      ],
      "size": [
        344.1662292480469,
        900.2955186631945
      ],
      "flags": {},
      "order": 13,
      "mode": 0,
      "inputs": [
        {
          "label": "批次管理",
          "localized_name": "meta_batch",
          "name": "meta_batch",
          "shape": 7,
          "type": "VHS_BatchManager",
          "link": null
        },
        {
          "label": "vae",
          "localized_name": "vae",
          "name": "vae",
          "shape": 7,
          "type": "VAE",
          "link": null
        },
        {
          "localized_name": "视频",
          "name": "video",
          "type": "COMBO",
          "widget": {
            "name": "video"
          },
          "link": null
        },
        {
          "localized_name": "强制帧率",
          "name": "force_rate",
          "type": "FLOAT",
          "widget": {
            "name": "force_rate"
          },
          "link": null
        },
        {
          "label": "custom_width",
          "localized_name": "custom_width",
          "name": "custom_width",
          "type": "INT",
          "widget": {
            "name": "custom_width"
          },
          "link": 352
        },
        {
          "label": "custom_height",
          "localized_name": "custom_height",
          "name": "custom_height",
          "type": "INT",
          "widget": {
            "name": "custom_height"
          },
          "link": 353
        },
        {
          "localized_name": "帧数读取上限",
          "name": "frame_load_cap",
          "type": "INT",
          "widget": {
            "name": "frame_load_cap"
          },
          "link": null
        },
        {
          "localized_name": "跳过前X帧",
          "name": "skip_first_frames",
          "type": "INT",
          "widget": {
            "name": "skip_first_frames"
          },
          "link": null
        },
        {
          "localized_name": "模选",
          "name": "select_every_nth",
          "type": "INT",
          "widget": {
            "name": "select_every_nth"
          },
          "link": null
        },
        {
          "localized_name": "format",
          "name": "format",
          "shape": 7,
          "type": "COMBO",
          "widget": {
            "name": "format"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "图像",
          "localized_name": "图像",
          "name": "IMAGE",
          "type": "IMAGE",
          "links": [
            311,
            330,
            338
          ]
        },
        {
          "label": "帧计数",
          "localized_name": "frame_count",
          "name": "frame_count",
          "type": "INT",
          "links": [
            339
          ]
        },
        {
          "label": "音频",
          "localized_name": "audio",
          "name": "audio",
          "type": "AUDIO",
          "links": [
            336,
            337
          ]
        },
        {
          "label": "视频信息",
          "localized_name": "video_info",
          "name": "video_info",
          "type": "VHS_VIDEOINFO",
          "links": null
        }
      ],
      "properties": {
        "Node name for S&R": "VHS_LoadVideo",
        "cnr_id": "comfyui-videohelpersuite",
        "ver": "8e4d79471bf1952154768e8435a9300077b534fa",
        "widget_ue_connectable": {}
      },
      "widgets_values": {
        "video": "v1e00fgi0000d2vbhgvog65nmtks2pq0.MP4",
        "force_rate": 30,
        "custom_width": 0,
        "custom_height": 0,
        "frame_load_cap": 300,
        "skip_first_frames": 0,
        "select_every_nth": 1,
        "format": "AnimateDiff",
        "videopreview": {
          "hidden": false,
          "paused": false,
          "params": {
            "filename": "v1e00fgi0000d2vbhgvog65nmtks2pq0.MP4",
            "type": "input",
            "format": "video/MP4",
            "force_rate": 30,
            "custom_width": 0,
            "custom_height": 520,
            "frame_load_cap": 300,
            "skip_first_frames": 0,
            "select_every_nth": 1
          }
        }
      }
    },
    {
      "id": 38,
      "type": "WanVideoVAELoader",
      "pos": [
        475.4573059082031,
        -1391.15283203125
      ],
      "size": [
        599.797119140625,
        106
      ],
      "flags": {},
      "order": 6,
      "mode": 0,
      "inputs": [
        {
          "label": "compile_args",
          "localized_name": "compile_args",
          "name": "compile_args",
          "shape": 7,
          "type": "WANCOMPILEARGS",
          "link": null
        },
        {
          "label": "model_name",
          "localized_name": "model_name",
          "name": "model_name",
          "type": "COMBO",
          "widget": {
            "name": "model_name"
          },
          "link": null
        },
        {
          "label": "precision",
          "localized_name": "precision",
          "name": "precision",
          "shape": 7,
          "type": "COMBO",
          "widget": {
            "name": "precision"
          },
          "link": null
        },
        {
          "label": "use_cpu_cache",
          "localized_name": "use_cpu_cache",
          "name": "use_cpu_cache",
          "shape": 7,
          "type": "BOOLEAN",
          "widget": {
            "name": "use_cpu_cache"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "vae",
          "localized_name": "vae",
          "name": "vae",
          "type": "WANVAE",
          "slot_index": 0,
          "links": [
            343,
            344
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "WanVideoVAELoader",
        "cnr_id": "ComfyUI-WanVideoWrapper",
        "ver": "e5ef9752a7e846b232fc05fd993327a2e870a788",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "Wan2_1_VAE_bf16.safetensors",
        "bf16",
        false
      ],
      "color": "#322",
      "bgcolor": "#533"
    },
    {
      "id": 22,
      "type": "WanVideoModelLoader",
      "pos": [
        -200,
        -1840
      ],
      "size": [
        601.9249267578125,
        338
      ],
      "flags": {},
      "order": 11,
      "mode": 0,
      "inputs": [
        {
          "label": "compile_args",
          "localized_name": "compile_args",
          "name": "compile_args",
          "shape": 7,
          "type": "WANCOMPILEARGS",
          "link": 100
        },
        {
          "label": "block_swap_args",
          "localized_name": "block_swap_args",
          "name": "block_swap_args",
          "shape": 7,
          "type": "BLOCKSWAPARGS",
          "link": null
        },
        {
          "label": "lora",
          "localized_name": "lora",
          "name": "lora",
          "shape": 7,
          "type": "WANVIDLORA",
          "link": null
        },
        {
          "label": "vram_management_args",
          "localized_name": "vram_management_args",
          "name": "vram_management_args",
          "shape": 7,
          "type": "VRAM_MANAGEMENTARGS",
          "link": null
        },
        {
          "label": "extra_model",
          "localized_name": "extra_model",
          "name": "extra_model",
          "shape": 7,
          "type": "VACEPATH",
          "link": null
        },
        {
          "label": "fantasytalking_model",
          "localized_name": "fantasytalking_model",
          "name": "fantasytalking_model",
          "shape": 7,
          "type": "FANTASYTALKINGMODEL",
          "link": null
        },
        {
          "label": "multitalk_model",
          "localized_name": "multitalk_model",
          "name": "multitalk_model",
          "shape": 7,
          "type": "MULTITALKMODEL",
          "link": null
        },
        {
          "label": "fantasyportrait_model",
          "localized_name": "fantasyportrait_model",
          "name": "fantasyportrait_model",
          "shape": 7,
          "type": "FANTASYPORTRAITMODEL",
          "link": null
        },
        {
          "label": "model",
          "localized_name": "model",
          "name": "model",
          "type": "COMBO",
          "widget": {
            "name": "model"
          },
          "link": null
        },
        {
          "label": "base_precision",
          "localized_name": "base_precision",
          "name": "base_precision",
          "type": "COMBO",
          "widget": {
            "name": "base_precision"
          },
          "link": null
        },
        {
          "label": "quantization",
          "localized_name": "quantization",
          "name": "quantization",
          "type": "COMBO",
          "widget": {
            "name": "quantization"
          },
          "link": null
        },
        {
          "label": "load_device",
          "localized_name": "load_device",
          "name": "load_device",
          "type": "COMBO",
          "widget": {
            "name": "load_device"
          },
          "link": null
        },
        {
          "label": "attention_mode",
          "localized_name": "attention_mode",
          "name": "attention_mode",
          "shape": 7,
          "type": "COMBO",
          "widget": {
            "name": "attention_mode"
          },
          "link": null
        },
        {
          "label": "rms_norm_function",
          "localized_name": "rms_norm_function",
          "name": "rms_norm_function",
          "shape": 7,
          "type": "COMBO",
          "widget": {
            "name": "rms_norm_function"
          },
          "link": null
        },
        {
          "label": "vace_model",
          "name": "vace_model",
          "shape": 7,
          "type": "VACEPATH",
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "model",
          "localized_name": "model",
          "name": "model",
          "type": "WANVIDEOMODEL",
          "slot_index": 0,
          "links": [
            59
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "WanVideoModelLoader",
        "cnr_id": "ComfyUI-WanVideoWrapper",
        "ver": "e5ef9752a7e846b232fc05fd993327a2e870a788",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "Wan2_2-Animate-14B_fp8_e4m3fn_scaled_KJ.safetensors",
        "fp16",
        "disabled",
        "offload_device",
        "sageattn",
        "default"
      ],
      "color": "#223",
      "bgcolor": "#335"
    },
    {
      "id": 151,
      "type": "INTConstant",
      "pos": [
        -1674.396728515625,
        -2743.20166015625
      ],
      "size": [
        210,
        58
      ],
      "flags": {
        "collapsed": false
      },
      "order": 7,
      "mode": 0,
      "inputs": [
        {
          "localized_name": "值",
          "name": "value",
          "type": "INT",
          "widget": {
            "name": "value"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "值",
          "localized_name": "value",
          "name": "value",
          "type": "INT",
          "links": [
            287,
            313,
            317,
            350,
            353
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "INTConstant",
        "cnr_id": "comfyui-kjnodes",
        "ver": "37659859825cea55940a58110525795ce5deb8be",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        1280
      ],
      "color": "#1b4669",
      "bgcolor": "#29699c"
    },
    {
      "id": 150,
      "type": "INTConstant",
      "pos": [
        -1670.246826171875,
        -2869.35595703125
      ],
      "size": [
        210,
        58
      ],
      "flags": {},
      "order": 8,
      "mode": 0,
      "inputs": [
        {
          "localized_name": "值",
          "name": "value",
          "type": "INT",
          "widget": {
            "name": "value"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "值",
          "localized_name": "value",
          "name": "value",
          "type": "INT",
          "links": [
            286,
            312,
            316,
            349,
            352
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "INTConstant",
        "cnr_id": "comfyui-kjnodes",
        "ver": "37659859825cea55940a58110525795ce5deb8be",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        720
      ],
      "color": "#1b4669",
      "bgcolor": "#29699c"
    },
    {
      "id": 196,
      "type": "Note",
      "pos": [
        -1674.896484375,
        -2627.40576171875
      ],
      "size": [
        410.9060974121094,
        434.4292297363281
      ],
      "flags": {},
      "order": 9,
      "mode": 0,
      "inputs": [],
      "outputs": [],
      "properties": {},
      "widgets_values": [
        "使用注意事项\n1在视频上传的节点中\nframe-load-cap / 帧数读取上限 这里最高帧数不要超过300\n\n2在这个说明框 的 上边 有两个 数字节点\n分别代表着视频的宽度和高度参数 你可以根据你的视频比例来修改\n但是建议视频的总清晰度不要超过720p 不然 会断连 或者 生成时间超长\n\n3视频的生成时间 9秒钟的视频一般要20分钟多 \n\n4在我的粉丝群或者镜像群里 都有个群公告里面会有一些注意事项一定先去看 后来用 \n\n5当前工作流我已经确认 720p清晰度的情况下 可以确认能跑通 30帧的十秒视频\n用时21分"
      ],
      "color": "#432",
      "bgcolor": "#653"
    },
    {
      "id": 171,
      "type": "WanVideoLoraSelectMulti",
      "pos": [
        410,
        -1830
      ],
      "size": [
        583.3719482421875,
        342
      ],
      "flags": {},
      "order": 10,
      "mode": 0,
      "inputs": [
        {
          "label": "prev_lora",
          "localized_name": "prev_lora",
          "name": "prev_lora",
          "shape": 7,
          "type": "WANVIDLORA",
          "link": null
        },
        {
          "label": "blocks",
          "localized_name": "blocks",
          "name": "blocks",
          "shape": 7,
          "type": "SELECTEDBLOCKS",
          "link": null
        },
        {
          "label": "lora_0",
          "localized_name": "lora_0",
          "name": "lora_0",
          "type": "COMBO",
          "widget": {
            "name": "lora_0"
          },
          "link": null
        },
        {
          "label": "strength_0",
          "localized_name": "strength_0",
          "name": "strength_0",
          "type": "FLOAT",
          "widget": {
            "name": "strength_0"
          },
          "link": null
        },
        {
          "label": "lora_1",
          "localized_name": "lora_1",
          "name": "lora_1",
          "type": "COMBO",
          "widget": {
            "name": "lora_1"
          },
          "link": null
        },
        {
          "label": "strength_1",
          "localized_name": "strength_1",
          "name": "strength_1",
          "type": "FLOAT",
          "widget": {
            "name": "strength_1"
          },
          "link": null
        },
        {
          "label": "lora_2",
          "localized_name": "lora_2",
          "name": "lora_2",
          "type": "COMBO",
          "widget": {
            "name": "lora_2"
          },
          "link": null
        },
        {
          "label": "strength_2",
          "localized_name": "strength_2",
          "name": "strength_2",
          "type": "FLOAT",
          "widget": {
            "name": "strength_2"
          },
          "link": null
        },
        {
          "label": "lora_3",
          "localized_name": "lora_3",
          "name": "lora_3",
          "type": "COMBO",
          "widget": {
            "name": "lora_3"
          },
          "link": null
        },
        {
          "label": "strength_3",
          "localized_name": "strength_3",
          "name": "strength_3",
          "type": "FLOAT",
          "widget": {
            "name": "strength_3"
          },
          "link": null
        },
        {
          "label": "lora_4",
          "localized_name": "lora_4",
          "name": "lora_4",
          "type": "COMBO",
          "widget": {
            "name": "lora_4"
          },
          "link": null
        },
        {
          "label": "strength_4",
          "localized_name": "strength_4",
          "name": "strength_4",
          "type": "FLOAT",
          "widget": {
            "name": "strength_4"
          },
          "link": null
        },
        {
          "label": "low_mem_load",
          "localized_name": "low_mem_load",
          "name": "low_mem_load",
          "shape": 7,
          "type": "BOOLEAN",
          "widget": {
            "name": "low_mem_load"
          },
          "link": null
        },
        {
          "label": "merge_loras",
          "localized_name": "merge_loras",
          "name": "merge_loras",
          "shape": 7,
          "type": "BOOLEAN",
          "widget": {
            "name": "merge_loras"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "lora",
          "localized_name": "lora",
          "name": "lora",
          "type": "WANVIDLORA",
          "links": [
            289
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "WanVideoLoraSelectMulti",
        "cnr_id": "ComfyUI-WanVideoWrapper",
        "ver": "b2c8cf969fcf60a38884ea2c29af177ae1f28b29",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "none",
        0,
        "lightx2v_T2V_14B_cfg_step_distill_v2_lora_rank32_bf16.safetensors",
        1.2,
        "Wan21_PusaV1_LoRA_14B_rank512_bf16.safetensors",
        1,
        "Wan2.2-Fun-A14B-InP-LOW-MPS_resized_dynamic_avg_rank_22_bf16.safetensors",
        0.5,
        "Wan2.2-Fun-A14B-InP-LOW-HPS2.1_resized_dynamic_avg_rank_15_bf16.safetensors",
        0.5,
        false,
        false
      ],
      "color": "#223",
      "bgcolor": "#335"
    },
    {
      "id": 185,
      "type": "OnnxDetectionModelLoader",
      "pos": [
        -534.2114868164062,
        -2768.85302734375
      ],
      "size": [
        292.8853454589844,
        106
      ],
      "flags": {},
      "order": 4,
      "mode": 0,
      "inputs": [
        {
          "label": "vitpose_model",
          "localized_name": "vitpose_model",
          "name": "vitpose_model",
          "type": "COMBO",
          "widget": {
            "name": "vitpose_model"
          },
          "link": null
        },
        {
          "label": "yolo_model",
          "localized_name": "yolo_model",
          "name": "yolo_model",
          "type": "COMBO",
          "widget": {
            "name": "yolo_model"
          },
          "link": null
        },
        {
          "label": "onnx_device",
          "localized_name": "onnx_device",
          "name": "onnx_device",
          "type": "COMBO",
          "widget": {
            "name": "onnx_device"
          },
          "link": null
        }
      ],
      "outputs": [
        {
          "label": "model",
          "localized_name": "model",
          "name": "model",
          "type": "POSEMODEL",
          "links": [
            309
          ]
        }
      ],
      "properties": {
        "aux_id": "kijai/ComfyUI-WanAnimatePreprocess",
        "Node name for S&R": "OnnxDetectionModelLoader",
        "ver": "e63d6e71ae4c271f3f81211a7ca7f87607b7e50d",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "vitpose-l-wholebody.onnx",
        "yolov10m.onnx",
        "CUDAExecutionProvider"
      ]
    }
  ],
  "links": [
    [
      33,
      27,
      0,
      28,
      1,
      "LATENT"
    ],
    [
      48,
      28,
      0,
      42,
      0,
      "IMAGE"
    ],
    [
      59,
      22,
      0,
      48,
      0,
      "WANVIDEOMODEL"
    ],
    [
      62,
      48,
      0,
      50,
      0,
      "WANVIDEOMODEL"
    ],
    [
      63,
      50,
      0,
      27,
      0,
      "WANVIDEOMODEL"
    ],
    [
      64,
      51,
      0,
      50,
      1,
      "BLOCKSWAPARGS"
    ],
    [
      82,
      57,
      0,
      64,
      0,
      "IMAGE"
    ],
    [
      87,
      42,
      0,
      66,
      0,
      "IMAGE"
    ],
    [
      89,
      66,
      0,
      30,
      0,
      "IMAGE"
    ],
    [
      96,
      70,
      0,
      62,
      1,
      "WANVIDIMAGE_CLIPEMBEDS"
    ],
    [
      97,
      71,
      0,
      70,
      0,
      "CLIP_VISION"
    ],
    [
      100,
      35,
      0,
      22,
      0,
      "WANCOMPILEARGS"
    ],
    [
      107,
      77,
      0,
      66,
      1,
      "IMAGE"
    ],
    [
      281,
      65,
      0,
      27,
      2,
      "WANVIDEOTEXTEMBEDS"
    ],
    [
      286,
      150,
      0,
      64,
      2,
      "INT"
    ],
    [
      287,
      151,
      0,
      64,
      3,
      "INT"
    ],
    [
      289,
      171,
      0,
      48,
      1,
      "WANVIDLORA"
    ],
    [
      291,
      64,
      0,
      172,
      0,
      "IMAGE"
    ],
    [
      309,
      185,
      0,
      184,
      0,
      "POSEMODEL"
    ],
    [
      311,
      63,
      0,
      184,
      1,
      "IMAGE"
    ],
    [
      312,
      150,
      0,
      184,
      3,
      "INT"
    ],
    [
      313,
      151,
      0,
      184,
      4,
      "INT"
    ],
    [
      315,
      184,
      0,
      186,
      0,
      "POSEDATA"
    ],
    [
      316,
      150,
      0,
      186,
      1,
      "INT"
    ],
    [
      317,
      151,
      0,
      186,
      2,
      "INT"
    ],
    [
      318,
      186,
      0,
      187,
      0,
      "IMAGE"
    ],
    [
      330,
      63,
      0,
      190,
      0,
      "IMAGE"
    ],
    [
      331,
      190,
      0,
      191,
      0,
      "IMAGE"
    ],
    [
      333,
      62,
      0,
      27,
      1,
      "WANVIDIMAGE_EMBEDS"
    ],
    [
      334,
      28,
      0,
      192,
      0,
      "IMAGE"
    ],
    [
      336,
      63,
      2,
      192,
      1,
      "AUDIO"
    ],
    [
      337,
      63,
      2,
      30,
      1,
      "AUDIO"
    ],
    [
      338,
      63,
      0,
      77,
      6,
      "IMAGE"
    ],
    [
      339,
      63,
      1,
      62,
      9,
      "INT"
    ],
    [
      340,
      64,
      0,
      70,
      1,
      "IMAGE"
    ],
    [
      341,
      64,
      0,
      62,
      2,
      "IMAGE"
    ],
    [
      342,
      64,
      0,
      77,
      0,
      "IMAGE"
    ],
    [
      343,
      38,
      0,
      62,
      0,
      "WANVAE"
    ],
    [
      344,
      38,
      0,
      28,
      0,
      "WANVAE"
    ],
    [
      345,
      186,
      0,
      77,
      5,
      "IMAGE"
    ],
    [
      346,
      186,
      0,
      62,
      3,
      "IMAGE"
    ],
    [
      347,
      184,
      1,
      77,
      1,
      "IMAGE"
    ],
    [
      348,
      184,
      1,
      62,
      4,
      "IMAGE"
    ],
    [
      349,
      150,
      0,
      62,
      7,
      "INT"
    ],
    [
      350,
      151,
      0,
      62,
      8,
      "INT"
    ],
    [
      351,
      184,
      1,
      112,
      0,
      "IMAGE"
    ],
    [
      352,
      150,
      0,
      63,
      4,
      "INT"
    ],
    [
      353,
      151,
      0,
      63,
      5,
      "INT"
    ]
  ],
  "groups": [
    {
      "id": 1,
      "title": "Reference Image",
      "bounding": [
        -1233.3623046875,
        -1920.180419921875,
        933.5728759765625,
        662.6868286132812
      ],
      "color": "#3f789e",
      "flags": {}
    },
    {
      "id": 3,
      "title": "Background Masking",
      "bounding": [
        -1228.970458984375,
        -3025.072265625,
        2293.58740234375,
        1008.6105346679688
      ],
      "color": "#3f789e",
      "flags": {}
    },
    {
      "id": 4,
      "title": "Models",
      "bounding": [
        -224.12948608398438,
        -1917.8428955078125,
        1668.8544921875,
        902.1675415039062
      ],
      "color": "#88A",
      "flags": {}
    },
    {
      "id": 5,
      "title": "Result collage",
      "bounding": [
        1480.81298828125,
        -1905.76708984375,
        1308.31005859375,
        1010.7964477539062
      ],
      "color": "#3f789e",
      "flags": {}
    }
  ],
  "config": {},
  "extra": {
    "ds": {
      "scale": 0.7972024500000114,
      "offset": [
        1705.6971590531177,
        3261.069924341931
      ]
    },
    "frontendVersion": "1.23.4",
    "node_versions": {
      "ComfyUI-WanVideoWrapper": "5a2383621a05825d0d0437781afcb8552d9590fd",
      "ComfyUI-KJNodes": "a5bd3c86c8ed6b83c55c2d0e7a59515b15a0137f",
      "ComfyUI-VideoHelperSuite": "0a75c7958fe320efcb052f1d9f8451fd20c730a8"
    },
    "VHS_latentpreview": false,
    "VHS_latentpreviewrate": 0,
    "VHS_MetadataImage": true,
    "VHS_KeepIntermediate": true,
    "0246.VERSION": [
      0,
      0,
      4
    ],
    "links_added_by_ue": [],
    "ue_links": []
  },
  "version": 0.4
}
```
