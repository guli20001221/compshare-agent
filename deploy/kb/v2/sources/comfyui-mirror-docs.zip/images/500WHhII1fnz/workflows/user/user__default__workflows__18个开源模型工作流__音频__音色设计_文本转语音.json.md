# 音色设计+文本转语音

- 来源类别：用户工作流
- 镜像内原始路径：`/ComfyUI/user/default/workflows/18个开源模型工作流/音频/音色设计+文本转语音.json`
- 节点数量：5
- 连线数量：4

## 节点类型

- `LayerUtility: TextBox` × 2
- `Qwen3TTSModelLoader` × 1
- `Qwen3TTSVoiceDesign` × 1
- `SaveAudio` × 1

## 原始工作流 JSON

```json
{
  "id": "ecaf95c3-5778-44dc-819a-b48c8c32d13b",
  "revision": 0,
  "last_node_id": 11,
  "last_link_id": 9,
  "nodes": [
    {
      "id": 4,
      "type": "Qwen3TTSVoiceDesign",
      "pos": [
        281.427490234375,
        129.9957733154297
      ],
      "size": [
        400,
        430
      ],
      "flags": {},
      "order": 3,
      "mode": 0,
      "inputs": [
        {
          "label": "模型",
          "name": "模型",
          "type": "QWEN3_TTS_MODEL",
          "link": 2
        },
        {
          "label": "文本",
          "name": "文本",
          "type": "STRING",
          "widget": {
            "name": "文本"
          },
          "link": 9
        },
        {
          "label": "提示词",
          "name": "提示词",
          "type": "STRING",
          "widget": {
            "name": "提示词"
          },
          "link": 8
        },
        {
          "label": "语言",
          "name": "语言",
          "type": "COMBO",
          "widget": {
            "name": "语言"
          }
        },
        {
          "label": "自动卸载模型",
          "name": "自动卸载模型",
          "type": "BOOLEAN",
          "widget": {
            "name": "自动卸载模型"
          }
        },
        {
          "label": "最大生成Token数",
          "name": "最大生成Token数",
          "type": "INT",
          "widget": {
            "name": "最大生成Token数"
          }
        },
        {
          "label": "seed",
          "name": "seed",
          "type": "INT",
          "widget": {
            "name": "seed"
          }
        },
        {
          "label": "语速",
          "name": "语速",
          "type": "FLOAT",
          "widget": {
            "name": "语速"
          }
        },
        {
          "label": "批量模式",
          "name": "批量模式",
          "shape": 7,
          "type": "BOOLEAN",
          "widget": {
            "name": "批量模式"
          }
        },
        {
          "label": "top_p",
          "name": "top_p",
          "shape": 7,
          "type": "FLOAT",
          "widget": {
            "name": "top_p"
          }
        },
        {
          "label": "top_k",
          "name": "top_k",
          "shape": 7,
          "type": "INT",
          "widget": {
            "name": "top_k"
          }
        },
        {
          "label": "temperature",
          "name": "temperature",
          "shape": 7,
          "type": "FLOAT",
          "widget": {
            "name": "temperature"
          }
        },
        {
          "label": "repetition_penalty",
          "name": "repetition_penalty",
          "shape": 7,
          "type": "FLOAT",
          "widget": {
            "name": "repetition_penalty"
          }
        },
        {
          "label": "启用高级采样配置",
          "name": "启用高级采样配置",
          "shape": 7,
          "type": "BOOLEAN",
          "widget": {
            "name": "启用高级采样配置"
          }
        }
      ],
      "outputs": [
        {
          "label": "音频",
          "name": "音频",
          "type": "AUDIO",
          "links": [
            1
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "Qwen3TTSVoiceDesign",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "",
        "",
        "自动",
        false,
        2048,
        735804443986754,
        "randomize",
        1,
        false,
        0.8,
        50,
        0.8,
        1.1,
        false
      ],
      "color": "#323",
      "bgcolor": "#535"
    },
    {
      "id": 11,
      "type": "LayerUtility: TextBox",
      "pos": [
        -153.40943908691406,
        293.42572021484375
      ],
      "size": [
        400,
        200
      ],
      "flags": {},
      "order": 0,
      "mode": 0,
      "inputs": [],
      "outputs": [
        {
          "label": "text",
          "name": "text",
          "type": "STRING",
          "links": [
            9
          ]
        }
      ],
      "title": "文本内容",
      "properties": {
        "Node name for S&R": "LayerUtility: TextBox"
      },
      "widgets_values": [
        "真正失败的人，就是那种特别害怕不能成功 怕死了，连试都不敢试的人"
      ],
      "color": "rgba(38, 73, 116, 0.7)"
    },
    {
      "id": 10,
      "type": "LayerUtility: TextBox",
      "pos": [
        -150.53724670410156,
        546.89697265625
      ],
      "size": [
        400,
        200
      ],
      "flags": {},
      "order": 1,
      "mode": 0,
      "inputs": [],
      "outputs": [
        {
          "label": "text",
          "name": "text",
          "type": "STRING",
          "links": [
            8
          ]
        }
      ],
      "title": "音色描述",
      "properties": {
        "Node name for S&R": "LayerUtility: TextBox"
      },
      "widgets_values": [
        "年轻女声，语气具有仙侠气质。"
      ],
      "color": "rgba(38, 73, 116, 0.7)"
    },
    {
      "id": 2,
      "type": "Qwen3TTSModelLoader",
      "pos": [
        -113.1377944946289,
        125.18313598632812
      ],
      "size": [
        362.8826599121094,
        119.88394927978516
      ],
      "flags": {},
      "order": 2,
      "mode": 0,
      "inputs": [
        {
          "label": "模型名称",
          "name": "模型名称",
          "type": "COMBO",
          "widget": {
            "name": "模型名称"
          }
        },
        {
          "label": "运行设备",
          "name": "运行设备",
          "type": "COMBO",
          "widget": {
            "name": "运行设备"
          }
        },
        {
          "label": "精度",
          "name": "精度",
          "type": "COMBO",
          "widget": {
            "name": "精度"
          }
        }
      ],
      "outputs": [
        {
          "label": "模型",
          "name": "模型",
          "type": "QWEN3_TTS_MODEL",
          "links": [
            2
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "Qwen3TTSModelLoader",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "Qwen/Qwen3-TTS-12Hz-1.7B-VoiceDesign",
        "cuda",
        "fp16"
      ],
      "color": "#323",
      "bgcolor": "#535"
    },
    {
      "id": 3,
      "type": "SaveAudio",
      "pos": [
        706.4375610351562,
        132.8223419189453
      ],
      "size": [
        270,
        112
      ],
      "flags": {},
      "order": 4,
      "mode": 0,
      "inputs": [
        {
          "label": "音频",
          "name": "audio",
          "type": "AUDIO",
          "link": 1
        },
        {
          "label": "filename_prefix",
          "name": "filename_prefix",
          "type": "STRING",
          "widget": {
            "name": "filename_prefix"
          }
        },
        {
          "label": "audioUI",
          "name": "audioUI",
          "type": "AUDIO_UI",
          "widget": {
            "name": "audioUI"
          }
        }
      ],
      "outputs": [
        {
          "label": "audio",
          "name": "audio",
          "type": "AUDIO",
          "links": null
        }
      ],
      "properties": {
        "cnr_id": "comfy-core",
        "ver": "0.9.2",
        "Node name for S&R": "SaveAudio",
        "widget_ue_connectable": {}
      },
      "widgets_values": [
        "audio/ComfyUI"
      ],
      "color": "#323",
      "bgcolor": "#535"
    }
  ],
  "links": [
    [
      1,
      4,
      0,
      3,
      0,
      "AUDIO"
    ],
    [
      2,
      2,
      0,
      4,
      0,
      "QWEN3_TTS_MODEL"
    ],
    [
      8,
      10,
      0,
      4,
      2,
      "STRING"
    ],
    [
      9,
      11,
      0,
      4,
      1,
      "STRING"
    ]
  ],
  "groups": [
    {
      "id": 1,
      "title": "文本转语音-音色自定义",
      "bounding": [
        -191.27366638183594,
        33.407997131347656,
        1355.2030029296875,
        764.1339721679688
      ],
      "color": "#3f789e",
      "font_size": 24,
      "flags": {}
    }
  ],
  "config": {},
  "extra": {
    "ds": {
      "scale": 0.8769226950000005,
      "offset": [
        485.742024947981,
        115.66629161118651
      ]
    },
    "frontendVersion": "1.23.4",
    "links_added_by_ue": [],
    "ue_links": [],
    "0246.VERSION": [
      0,
      0,
      4
    ],
    "VHS_latentpreview": false,
    "VHS_latentpreviewrate": 0,
    "VHS_MetadataImage": true,
    "VHS_KeepIntermediate": true
  },
  "version": 0.4
}
```
