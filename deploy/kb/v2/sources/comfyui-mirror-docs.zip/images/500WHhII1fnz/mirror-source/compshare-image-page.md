Title: Bob同学的comfyui云端镜像系列一键部署 | 优云智算

URL Source: https://www.compshare.cn/images/500WHhII1fnz

Markdown Content:
## 本次更新内容为

**一.更新概况**

1.更新了ComfyUI的版本内核

 2.新增并更新了大量的插件及节点

 3.新增了大量的最新开源模型

 4.清空了output文件夹

**二.新增工作流内容**

**音频 **

1语音克隆

 2文字转语音

 3多人对话

 4歌曲创作

**视频 **

5文生视频

 6图生视频

 7图生视频对口型

 8多人动作迁移

 9视频放大补帧

 10视频风格转绘

**图片**

11图片换装

 12文生图

 13提示词反推

 14洗图

 15图生图 16图片换脸 17图像放大 18分镜图

## 使用教程

### 1. 选择Bob同学的云端镜像创建实例

### 2. 然后在这里选择显卡并部署

![Image 1: 81e01fc9f6826797e8b697184356fbfc.png](https://ucompshare-picture.s3-cn-wlcb.s3stor.compshare.cn/VUYxn8VqznDP8aP4%2F1755759794118.png)

### 3. 点击开机并启动

![Image 2: 4967bd1a200d8bd897c93bc0ecee3b19.png](https://ucompshare-picture.s3-cn-wlcb.s3stor.compshare.cn/VUYxn8VqznDP8aP4%2F1755759801378.png)

### 4. 点击Comfyui直接跳转打开（开机后先等一分钟）

![Image 3: 045679e417494d4f9baed8ddb297b319.png](https://ucompshare-picture.s3-cn-wlcb.s3stor.compshare.cn/VUYxn8VqznDP8aP4%2F1755759827468.png)

### 5. 所有工作流都集成在这里点击即可使用

![Image 4: 4b10eb4802a4ccf9965b1ff44c043043.png](https://ucompshare-picture.s3-cn-wlcb.s3stor.compshare.cn/VUYxn8VqznDP8aP4%2F1755759846404.png)

## 有任何问题或者更新需求，可以Bob同学的交流群内反馈

![Image 5: 5b41e8fea1d84a9958f2f3431b4a08f3.png](https://ucompshare-picture.s3-cn-wlcb.s3stor.compshare.cn/VUYxn8VqznDP8aP4%2F1755759852464.png)
