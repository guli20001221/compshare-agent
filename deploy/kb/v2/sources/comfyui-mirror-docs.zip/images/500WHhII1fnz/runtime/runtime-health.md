# 当前镜像运行状态

这是一次只读探测结果；不包含服务器地址、密码、令牌或完整运行日志。

## ComfyUI 服务

- ComfyUI 首页：HTTP 200
- `/system_stats`：HTTP 200
- `/object_info`：HTTP 200
- 主服务：标准 ComfyUI，监听 8188

## 版本信息

- ComfyUI：`0.27.0`
- 前端：`1.45.20`
- Python：`3.10.15 (main, Oct  3 2024, 07:27:34) [GCC 11.2.0]`
- PyTorch：`2.6.0+cu124`
- 节点类型数：`2657`
- 模型文件数：`143`

## 已观察到的导入问题

- `.ipynb_checkpoints` 目录不是有效自定义节点目录，启动时被尝试导入。
- `SCAIL-Pose` 缺少 `__init__.py`，启动时导入失败。
- WanVideoWrapper 的部分可选 FantasyPortrait 功能缺少 `onnx`。
