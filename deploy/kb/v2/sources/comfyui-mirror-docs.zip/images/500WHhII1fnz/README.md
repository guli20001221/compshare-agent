# ComfyUI 镜像 500WHhII1fnz 专属资料

本目录来自镜像 `500WHhII1fnz` 的只读检查，服务端不做任何修改。

## 内容

- `custom-nodes/active/`：当前实例自定义节点目录中的 Markdown 文档。
- `custom-nodes/present-but-not-loaded/`：存在但启动时未加载的节点目录文档。
- `workflows/user/`：镜像内置的用户工作流，保留为可检索 Markdown，并附原始 JSON。
- `workflows/blueprints/`：ComfyUI 蓝图目录中的工作流，保留为可检索 Markdown，并附原始 JSON。
- `runtime/`：版本、节点类型、模型文件和运行状态清单。
- `mirror-source/`：镜像主页的 Markdown 内容。

模型、图片、视频、缓存、代码、日志和服务器凭据未打包。
