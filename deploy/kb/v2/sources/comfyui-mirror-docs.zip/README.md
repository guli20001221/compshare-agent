# ComfyUI 镜像 Markdown 文档总包

这是一个可以持续追加多个 ComfyUI 镜像的 Markdown 原文包。公共官方文档只保存一份，每个镜像的实际版本、节点、工作流、蓝图和模型清单放在 `images/<镜像 ID>/` 下。

## 当前内容

- 公共官方教程：86 个中文页面
- 公共官方界面文档：16 个页面
- 镜像 `500WHhII1fnz`：ComfyUI `0.27.0`，2657 个节点，35 个用户工作流，89 个蓝图

## 目录

- `official/`：公共 ComfyUI 教程和界面文档，已排除 APP、账号、积分、合作推广等内容。
- `installed-custom-nodes/`：上一镜像的插件文档，保留作公共/历史基线。
- `images/500WHhII1fnz/`：当前镜像的专属资料。
  - `custom-nodes/`：当前节点目录中的 Markdown 文档。
  - `workflows/`：实际用户工作流和 ComfyUI 蓝图，Markdown 中保留原始 JSON。
  - `runtime/`：版本、节点清单、模型文件名清单和运行健康摘要。
  - `mirror-source/`：镜像主页 Markdown。
- `community/comfyorg-cn/`：精选的中文社区实操教程，分为核心补充和兼容性参考。
- `manifest.json`：来源、原始路径、抓取时间、类别、兼容性和哈希索引。

模型、图片、视频、缓存、代码、完整日志、配置文件、数据库、令牌和密码未打包。
