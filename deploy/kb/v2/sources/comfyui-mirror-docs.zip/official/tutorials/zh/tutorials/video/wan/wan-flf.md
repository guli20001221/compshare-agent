> ## Documentation Index
> Fetch the complete documentation index at: https://docs.comfy.org/llms.txt
> Use this file to discover all available pages before exploring further.

# ComfyUI Wan2.1 FLF2V 原生示例

> 本文介绍了如何在 ComfyUI 中完成 Wan2.1 FLF2V 视频生成示例

Wan FLF2V（首尾帧视频生成）是由阿里通义万相团队推出的开源视频生成模型。其开源协议为 [Apache 2.0](https://github.com/Wan-Video/Wan2.1?tab=Apache-2.0-1-ov-file)。
用户只需提供起始帧和结束帧两张图像，模型即可自动生成中间过渡帧，输出一段逻辑连贯、自然流畅的720p高清视频。

**核心技术亮点**

1. **首尾帧精准控制**：首尾帧匹配度达98%，通过起始和结束画面定义视频边界，模型智能填充中间动态变化，实现场景转换和物体形态演变等效果。
2. **稳定流畅视频生成**：采用CLIP语义特征和交叉注意力机制，视频抖动率比同类模型降低37%，确保转场自然流畅。
3. **多功能创作能力**：支持中英文字幕动态嵌入、二次元/写实/奇幻等多风格生成，适应不同创作需求。
4. **720p高清输出**：直接生成1280×720分辨率视频，无需后处理，适用于社交媒体和商业应用。
5. **开源生态支持**：模型权重、代码及训练框架全面开源，支持主流AI平台部署。

**技术原理与架构**

1. **DiT架构**：基于扩散模型和Diffusion Transformer架构，结合Full Attention机制优化时空依赖建模，确保视频连贯性。
2. **三维因果变分编码器**：Wan-VAE技术将高清画面压缩至1/128尺寸，同时保留细微动态细节，显著降低显存需求。
3. **三阶段训练策略**：从480P分辨率开始预训练，逐步提升至720P，通过分阶段优化平衡生成质量与计算效率。

**相关链接**

* **GitHub代码仓库**：[GitHub](https://github.com/Wan-Video/Wan2.1)
* **Hugging Face模型页**：[Hugging Face](https://huggingface.co/Wan-AI/Wan2.1-FLF2V-14B-720P)
* **ModelScope（魔搭社区）**：[ModelScope](https://www.modelscope.cn/models/Wan-AI/Wan2.1-FLF2V-14B-720P)

<Tip>
  <Tabs>
    <Tab title="便携版或手动安装用户">
      请确保你的 ComfyUI 已经更新。

      * [ComfyUI 下载](https://www.comfy.org/download)
      * [ComfyUI 更新教程](/zh/installation/update_comfyui)

      本指南里的工作流可以在 ComfyUI 的[工作流模板](/zh/interface/features/template)中找到。如果找不到，可能是 ComfyUI 没有更新。

      如果加载工作流时有节点缺失，可能原因有：

      1. 你用的不是最新开发版（nightly）。
      2. 你用的是稳定版或桌面版（没有包含最新的更新）。
      3. 启动时有些节点导入失败。
    </Tab>

    <Tab title="桌面版或云端用户">
      * 桌面版是基于 ComfyUI 稳定版本构建的，它会在有新的桌面稳定版本发布时自动更新。
      * [Cloud](https://cloud.comfy.org) 会在 ComfyUI 稳定版本发布后更新，我们会同步更新 Cloud。

      所以，如果你发现本教程中有任何核心节点缺失，那是因为对应的节点支持还在开发中没有发布正式的稳定版，请等待下一个稳定版本发布。
    </Tab>
  </Tabs>
</Tip>

## Wan2.1 FLF2V 720P ComfyUI 原生工作流示例

### 1. 下载工作流文件及相关输入文件

<Tip>
  由于这是一个在高分辨率图片上训练的模型，所以使用较小的尺寸可能无法获得较好的结果，我们在示例中使用了 720 \* 1280 的尺寸，这可能导致较低显存的用户无法很顺利运行,对应的图片生成也会非常差耗时。如果需要，在一开始的时候请修改视频生成的尺寸，但仅供测试，如需生成最终结果，请使用 720 \* 1280 左右的尺寸。
</Tip>

请下载下面的 WebP 保存下面的 WebP 文件，并拖入 ComfyUI 中来加载对应的工作流,对应工作流已嵌入对应的模型下载文件信息。

![Wan2.1 FLF2V 720P f16 工作流](https://raw.githubusercontent.com/Comfy-Org/example_workflows/refs/heads/main/wan2.1_flf2v/wan2.1_flf2v_720_f16.webp)

请下载下面的两张图片，我们将会作为作为视频的起始帧和结束帧

![start\_image](https://raw.githubusercontent.com/Comfy-Org/example_workflows/refs/heads/main/wan2.1_flf2v/input/start_image.png)
![end\_image](https://raw.githubusercontent.com/Comfy-Org/example_workflows/refs/heads/main/wan2.1_flf2v/input/end_image.png)

### 2.手动模型安装

本篇指南涉及的所有模型你都可以在[这里](https://huggingface.co/Comfy-Org/Wan_2.1_ComfyUI_repackaged/tree/main/split_files)找到。

**diffusion\_models** 根据你的硬件情况选择一个版本进行下载，FP8 版本对显存要求低一些

* FP16:[wan2.1\_flf2v\_720p\_14B\_fp16.safetensors](https://huggingface.co/Comfy-Org/Wan_2.1_ComfyUI_repackaged/resolve/main/split_files/diffusion_models/wan2.1_flf2v_720p_14B_fp16.safetensors?download=true)
* FP8:[wan2.1\_flf2v\_720p\_14B\_fp8\_e4m3fn.safetensors](https://huggingface.co/Comfy-Org/Wan_2.1_ComfyUI_repackaged/blob/main/split_files/diffusion_models/wan2.1_flf2v_720p_14B_fp8_e4m3fn.safetensors)

<Tip>
  如果你之前运行过 Wan Video 相关的工作流，你可能已经有了下面的这些文件。
</Tip>

从**Text encoders** 选择一个版本进行下载，

* [umt5\_xxl\_fp16.safetensors](https://huggingface.co/Comfy-Org/Wan_2.1_ComfyUI_repackaged/resolve/main/split_files/text_encoders/umt5_xxl_fp16.safetensors?download=true)
* [umt5\_xxl\_fp8\_e4m3fn\_scaled.safetensors](https://huggingface.co/Comfy-Org/Wan_2.1_ComfyUI_repackaged/resolve/main/split_files/text_encoders/umt5_xxl_fp8_e4m3fn_scaled.safetensors?download=true)

**VAE**

* [wan\_2.1\_vae.safetensors](https://huggingface.co/Comfy-Org/Wan_2.1_ComfyUI_repackaged/resolve/main/split_files/vae/wan_2.1_vae.safetensors?download=true)

**CLIP Vision**

* [clip\_vision\_h.safetensors](https://huggingface.co/Comfy-Org/Wan_2.1_ComfyUI_repackaged/resolve/main/split_files/clip_vision/clip_vision_h.safetensors?download=true)

文件保存位置

```
ComfyUI/
├── models/
│   ├── diffusion_models/
│   │   └─── wan2.1_flf2v_720p_14B_fp16.safetensors          # 或者 FP8 版本
│   ├── text_encoders/
│   │   └─── umt5_xxl_fp8_e4m3fn_scaled.safetensors           # 或者你选择的版本
│   ├── vae/
│   │   └──  wan_2.1_vae.safetensors
│   └── clip_vision/
│       └──  clip_vision_h.safetensors   
```

### 3. 按步骤完成工作流运行

<img src="https://mintcdn.com/dripart/SIDaLac8vBogzwm7/images/tutorial/video/wan/wan2.1_flf2v_14B_720P_step_guide.jpg?fit=max&auto=format&n=SIDaLac8vBogzwm7&q=85&s=f52356ef98601526215d4c21802f261f" alt="Wan2.1 FLF2V 720P 原生工作流步骤" width="2361" height="1623" data-path="images/tutorial/video/wan/wan2.1_flf2v_14B_720P_step_guide.jpg" />

1. 确保 `Load Diffusion Model` 节点加载了 `wan2.1_flf2v_720p_14B_fp16.safetensors` 或者 `wan2.1_flf2v_720p_14B_fp8_e4m3fn.safetensors`
2. 确保 `Load CLIP` 节点加载了 `umt5_xxl_fp8_e4m3fn_scaled.safetensors`
3. 确保 `Load VAE` 节点加载了 `wan_2.1_vae.safetensors`
4. 确保 `Load CLIP Vision` 节点加载了 `clip_vision_h.safetensors `
5. 在 `Start_image` 节点上传起始帧
6. 在 `End_image` 节点上传结束帧
7. （可选）修改 正向和负向的提示词（Prompt）使用中英文都可以
8. （**重要**）在 `WanFirstLastFrameToVideo` 修改对应视频的尺寸我们默认使用了 720 \* 1280 的尺寸来，因为这是一个 720P 的尺寸来，因为这是一个720P的模型，所以使用较小的尺寸会无法获得较好的结果。
9. 点击 `Run` 按钮，或者使用快捷键 `Ctrl(cmd) + Enter(回车)` 来执行视频生成
