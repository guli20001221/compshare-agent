> ## Documentation Index
> Fetch the complete documentation index at: https://docs.comfy.org/llms.txt
> Use this file to discover all available pages before exploring further.

# ComfyUI SCAIL-2 角色替换工作流教程

> 使用 SCAIL-2 模型，让参考角色图像跟随驱动视频运动，实现角色动画或视频内角色替换。

**SCAIL-2** 是构建在 Wan2.1 之上的端到端角色动画模型。它通过驱动视频驱动参考角色图像，支持角色动画（让角色执行动作）和视频内角色替换（将视频中跟踪的人物替换为参考角色）。

**主要特性**：

* **端到端角色动画**：用驱动视频的运动驱动静态角色图像
* **两种模式**：动画模式（角色执行动作）和替换模式（将跟踪人物替换为参考角色）
* **长视频支持**：基于分段的重叠帧扩展生成
* **内置 ComfyUI 节点**：使用原生 `WanSCAILToVideo`、`SCAIL2ColoredMask` 和 `SAM3` 跟踪，无需额外自定义节点，仅需下载标准模型即可

**相关链接**：

* [Hugging Face: SCAIL-2](https://huggingface.co/zai-org/SCAIL-2)
* [SCAIL-2 扩散模型](https://huggingface.co/Comfy-Org/SCAIL-2)

## SCAIL-2 角色替换工作流

<CardGroup cols={2}>
  <Card title="在 Comfy Cloud 中运行" icon="cloud" href="https://cloud.comfy.org/?template=video_wan21_scail2_character_replacement&utm_source=docs&utm_medium=referral&utm_campaign=scail2">
    在 Comfy Cloud 中打开
  </Card>

  <Card title="下载工作流" icon="download" href="https://github.com/Comfy-Org/workflow_templates/blob/main/templates/video_wan21_scail2_character_replacement.json">
    下载 JSON 或在模板库中搜索 "SCAIL-2"
  </Card>
</CardGroup>

<Tip>
  <Tabs>
    <Tab title="便携版或手动安装用户">
      请确保你的 ComfyUI 已经更新。

      * [ComfyUI 下载](https://www.comfy.org/download)
      * [ComfyUI 更新教程](/zh/installation/update_comfyui)

      本指南里的工作流可以在 ComfyUI 的[工作流模板](/zh/interface/features/template)中找到。如果找不到，可能是 ComfyUI 没有更新。

      如果加载工作流时有节点缺失，可能原因有：

      1. 你用的不是最新开发版（nightly）。
      2. 你用的是稳定版或桌面版（没有包含最新的更新）。
      3. 启动时有些节点导入失败。
    </Tab>

    <Tab title="桌面版或云端用户">
      * 桌面版是基于 ComfyUI 稳定版本构建的，它会在有新的桌面稳定版本发布时自动更新。
      * [Cloud](https://cloud.comfy.org) 会在 ComfyUI 稳定版本发布后更新，我们会同步更新 Cloud。

      所以，如果你发现本教程中有任何核心节点缺失，那是因为对应的节点支持还在开发中没有发布正式的稳定版，请等待下一个稳定版本发布。
    </Tab>
  </Tabs>
</Tip>

## 工作流原理

本工作流使用两个子图节点——**Base** 子图（第一段）和 **Extend** 子图（后续段落）——来支持短视频和长视频的角色动画。

1. **加载**驱动视频（`pose_video`）和参考角色图像
2. **Base 子图**处理第一段（默认 81 帧）
3. **Extend 子图**处理第 2 段及后续，将上一段的 `previous_frames` 链接起来
4. 预览结果并保存

<Card title="了解 Subgraph 子图" icon="book-open" href="/zh/interface/features/subgraph">
  本工作流使用 Subgraph 节点进行模块化处理。查看子图文档了解如何自定义和扩展工作流。
</Card>

### 长视频

对于较长的视频，计算段落数量：`ceil(total_frames / 76)`。除第一段外均使用 Extend 子图。复制 Extend 节点以增加更多段落，链接 `previous_frames` 输出，并递增 `segment_index`。

> **注意：** `WanSCAILToVideo` 无法自动排队所有段落——需要手动运行每个段落。

## 两种模式

| 模式       | `replace_mode` | 驱动视频蒙版背景 | 说明                 |
| -------- | :------------: | :------: | ------------------ |
| **替换模式** |   `true`（默认）   |    白色    | 将驱动视频中跟踪的人物替换为参考角色 |
| **动画模式** |     `false`    |    黑色    | 参考角色执行驱动视频的动作      |

在两个子图节点上均设置 `replace_mode` 参数。

## 输入和参数

### 共用参数（Base 和 Extend）

| 参数                                          | 说明                                       |
| ------------------------------------------- | ---------------------------------------- |
| `pose_video`                                | 要传递动作的驱动视频                               |
| `reference_image`                           | 要动画化或插入的角色图像                             |
| `prompt`                                    | 输出视频描述                                   |
| `replace_mode`                              | `true` = 替换模式，`false` = 动画模式             |
| `segment_index`                             | `1` 为第一段，`2+` 为延续。姿态偏移 = `76 × (索引 − 1)` |
| `width` / `height`                          | 输出分辨率，例如 `896×512`。必须能被 16 整除            |
| `frame_count`                               | 每段帧数（默认：81）                              |
| `previous_frame_count`                      | 段落间的重叠帧数（默认：5）                           |
| `pose_strength` / `pose_start` / `pose_end` | 姿态条件的强度和时间范围                             |

### SAM3 跟踪（两个输入）

`sam3_video_object` 和 `sam3_image_object` 输入控制 SAM3 蒙版跟踪——**不是** SCAIL-2 的输出提示词。它们确定彩色蒙版跟踪哪些对象：

| 输入                  | 目标   | 输出                     |
| ------------------- | ---- | ---------------------- |
| `sam3_video_object` | 驱动视频 | `pose_video_mask`      |
| `sam3_image_object` | 参考图像 | `reference_image_mask` |

* 使用开放式文本描述（默认：`human`）
* 当视频和参考中的目标相同时使用相同的描述
* 如果视频和参考需要不同的关注点（例如拥挤场景），使用不同的描述

## 模型安装

首先将 ComfyUI 更新到最新版本，以获取内置的 WanSCAILToVideo 和 SCAIL2ColoredMask 节点。

### 所需模型

**diffusion\_models**

* [wan2.1\_14B\_SCAIL\_2\_fp16.safetensors](https://huggingface.co/Comfy-Org/SCAIL-2/resolve/main/diffusion_models/wan2.1_14B_SCAIL_2_fp16.safetensors)

**text\_encoders**（选择其一）

* [umt5\_xxl\_fp8\_e4m3fn\_scaled.safetensors](https://huggingface.co/Comfy-Org/Wan_2.1_ComfyUI_repackaged/resolve/main/split_files/text_encoders/umt5_xxl_fp8_e4m3fn_scaled.safetensors)

**clip\_vision**

* [clip\_vision\_h.safetensors](https://huggingface.co/Comfy-Org/Wan_2.1_ComfyUI_repackaged/resolve/main/split_files/clip_vision/clip_vision_h.safetensors)

**vae**

* [Wan2\_1\_VAE\_bf16.safetensors](https://huggingface.co/Kijai/WanVideo_comfy/resolve/main/Wan2_1_VAE_bf16.safetensors)

**loras**

* [lightx2v\_I2V\_14B\_480p\_cfg\_step\_distill\_rank64\_bf16.safetensors](https://huggingface.co/Kijai/WanVideo_comfy/resolve/main/Lightx2v/lightx2v_I2V_14B_480p_cfg_step_distill_rank64_bf16.safetensors)
* [wan2.1\_SCAIL\_2\_DPO\_lora\_bf16.safetensors](https://huggingface.co/Comfy-Org/SCAIL-2/resolve/main/loras/wan2.1_SCAIL_2_DPO_lora_bf16.safetensors)

**checkpoints**

* [sam3.1\_multiplex\_fp16.safetensors](https://huggingface.co/Comfy-Org/sam3.1/resolve/main/checkpoints/sam3.1_multiplex_fp16.safetensors)

### 文件存放位置

```
ComfyUI/
├── models/
│   ├── diffusion_models/
│   │   └── wan2.1_14B_SCAIL_2_fp16.safetensors
│   ├── text_encoders/
│   │   └── umt5_xxl_fp8_e4m3fn_scaled.safetensors
│   ├── clip_vision/
│   │   └── clip_vision_h.safetensors
│   ├── vae/
│   │   └── Wan2_1_VAE_bf16.safetensors
│   ├── loras/
│   │   ├── lightx2v_I2V_14B_480p_cfg_step_distill_rank64_bf16.safetensors
│   │   └── wan2.1_SCAIL_2_DPO_lora_bf16.safetensors
│   └── checkpoints/
│       └── sam3.1_multiplex_fp16.safetensors
```
