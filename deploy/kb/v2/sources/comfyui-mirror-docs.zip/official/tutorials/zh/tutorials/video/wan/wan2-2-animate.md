> ## Documentation Index
> Fetch the complete documentation index at: https://docs.comfy.org/llms.txt
> Use this file to discover all available pages before exploring further.

# Wan2.2 Animate ComfyUI 原生工作流

> 统一的人物动画和替换框架，具有精确的运动和表情复制。

Wan-Animate 是由 WAN 团队开发的一个统一的人物动画和替换框架。

该模型可以根据表演者的视频对任何人物进行动画处理，精确复制表演者的面部表情和动作，生成高度真实的人物视频。

它还可以将视频中的角色替换为动画角色，在保留其表情和动作的同时，复制原始的光线和色调，以实现与环境的无缝集成。

## 模型亮点

* 双模式功能：单一架构支持动画和角色替换功能，可轻松切换操作模式。
* 高级身体运动控制：使用空间对齐的骨架信号来精确复制身体动作。
* 精确的运动和表情：准确重现参考视频中的动作和面部表情。
* 自然的环境集成：将替换的角色与原始视频环境无缝融合。
* 流畅的长视频生成：迭代生成确保在扩展视频中保持一致的运动和视觉流畅性。

## ComfyOrg Wan2.2 Animate 直播回放

<iframe className="w-full aspect-video rounded-xl" src="https://www.youtube.com/embed/5kb-rP0m5BA?si=lbIYkCP5akkG2N6D" title="Wan 2.2 Animate in ComfyUI with Flipping Sigmas / September 19th, 2025" frameborder="0" allow="accelerometer; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen />

<Tip>
  <Tabs>
    <Tab title="便携版或手动安装用户">
      请确保你的 ComfyUI 已经更新。

      * [ComfyUI 下载](https://www.comfy.org/download)
      * [ComfyUI 更新教程](/zh/installation/update_comfyui)

      本指南里的工作流可以在 ComfyUI 的[工作流模板](/zh/interface/features/template)中找到。如果找不到，可能是 ComfyUI 没有更新。

      如果加载工作流时有节点缺失，可能原因有：

      1. 你用的不是最新开发版（nightly）。
      2. 你用的是稳定版或桌面版（没有包含最新的更新）。
      3. 启动时有些节点导入失败。
    </Tab>

    <Tab title="桌面版或云端用户">
      * 桌面版是基于 ComfyUI 稳定版本构建的，它会在有新的桌面稳定版本发布时自动更新。
      * [Cloud](https://cloud.comfy.org) 会在 ComfyUI 稳定版本发布后更新，我们会同步更新 Cloud。

      所以，如果你发现本教程中有任何核心节点缺失，那是因为对应的节点支持还在开发中没有发布正式的稳定版，请等待下一个稳定版本发布。
    </Tab>
  </Tabs>
</Tip>

## 关于 Wan2.2 Animate 工作流

在本文中，我们将提供两个工作流：

1. 仅使用核心节点的工作流（不完整；你需要自行预处理图像）
2. 包含一些自定义节点的工作流（完整；可直接使用，但新用户可能不知道如何安装自定义节点）

## Wan2.2 Animate ComfyUI 原生工作流（不含自定义节点）

### 1. 下载工作流文件

下载以下工作流文件并将其拖入 ComfyUI 以加载工作流。

<a className="prose" target="_blank" href="https://raw.githubusercontent.com/Comfy-Org/workflow_templates/refs/heads/main/templates/video_wan2_2_14B_animate.json" style={{ display: 'inline-block', backgroundColor: '#0078D6', color: '#ffffff', padding: '10px 20px', borderRadius: '8px', borderColor: "transparent", textDecoration: 'none', fontWeight: 'bold'}}>
  <p className="prose" style={{ margin: 0, fontSize: "0.8rem" }}>下载工作流</p>
</a>

<a className="prose" target="_blank" href="https://cloud.comfy.org/?template=video_wan2_2_14B_animate&utm_source=docs" style={{ display: 'inline-block', backgroundColor: '#28A745', color: '#FFFFFF', padding: '10px 20px', borderRadius: '8px', borderColor: "transparent", textDecoration: 'none', fontWeight: 'bold'}}>
  <p className="prose" style={{ margin: 0, fontSize: "0.8rem" }}>在 Comfy 云上运行</p>
</a>

下载以下素材作为输入：

**参考图像：**
![Reference\_Image](https://raw.githubusercontent.com/Comfy-Org/example_workflows/refs/heads/main/video/wan/wan2.2_animate/ref_image.png)

**输入视频**

<video controls className="w-full aspect-video" src="https://raw.githubusercontent.com/Comfy-Org/example_workflows/refs/heads/main/video/wan/wan2.2_animate/original_video.mp4" />

### 2. 模型链接

**diffusion\_models**

* [Wan2\_2-Animate-14B\_fp8\_e4m3fn\_scaled\_KJ.safetensors](https://huggingface.co/Kijai/WanVideo_comfy_fp8_scaled/resolve/main/Wan22Animate/Wan2_2-Animate-14B_fp8_e4m3fn_scaled_KJ.safetensors) 这是来自 Kijai 仓库的模型
* [wan2.2\_animate\_14B\_bf16.safetensors](https://huggingface.co/Comfy-Org/Wan_2.2_ComfyUI_Repackaged/resolve/main/split_files/diffusion_models/wan2.2_animate_14B_bf16.safetensors) 原始模型权重

**clip\_visions**

* [clip\_vision\_h.safetensors](https://huggingface.co/Comfy-Org/Wan_2.1_ComfyUI_repackaged/resolve/main/split_files/clip_vision/clip_vision_h.safetensors)

**loras**

* [lightx2v\_I2V\_14B\_480p\_cfg\_step\_distill\_rank64\_bf16.safetensors](https://huggingface.co/Kijai/WanVideo_comfy/resolve/main/Lightx2v/lightx2v_I2V_14B_480p_cfg_step_distill_rank64_bf16.safetensors) 这是一个 4 步的加速 lora
  **vae**
* [wan\_2.1\_vae.safetensors](https://huggingface.co/Comfy-Org/Wan_2.2_ComfyUI_Repackaged/resolve/main/split_files/vae/wan_2.1_vae.safetensors)

**text\_encoders**

* [umt5\_xxl\_fp8\_e4m3fn\_scaled.safetensors](https://huggingface.co/Comfy-Org/Wan_2.1_ComfyUI_repackaged/resolve/main/split_files/text_encoders/umt5_xxl_fp8_e4m3fn_scaled.safetensors)

```
ComfyUI/
├───📂 models/
│   ├───📂 diffusion_models/
│   │   ├─── Wan2_2-Animate-14B_fp8_e4m3fn_scaled_KJ.safetensors
│   │   └─── wan2.2_animate_14B_bf16.safetensors
│   ├───📂 loras/
│   │   └─── lightx2v_I2V_14B_480p_cfg_step_distill_rank64_bf16.safetensors
│   ├───📂 text_encoders/
│   │   └─── umt5_xxl_fp8_e4m3fn_scaled.safetensors 
│   ├───📂 clip_visions/ 
│   │   └─── clip_vision_h.safetensors
│   └───📂 vae/
│       └── wan_2.1_vae.safetensors
```

### 3. 安装自定义节点

下载以下工作流文件并将其拖入 ComfyUI 以加载工作流，如果你已安装 [ComfyUI-Manager](https://github.com/Comfy-Org/ComfyUI-Manager)，你可以直接点击 `Install missing nodes` 按钮来安装缺失的节点。

我们需要安装以下自定义节点：

* [ComfyUI-KJNodes](https://github.com/kijai/ComfyUI-KJNodes)
* [ComfyUI-comfyui\_controlnet\_aux](https://github.com/Fannovel16/comfyui_controlnet_aux)

如果你不知道如何安装自定义节点，请参阅 [如何安装自定义节点](/zh/installation/install_custom_node)

### 4. 工作流说明

Wan2.2 animate 有两种模式：Mix 和 Move

* Mix：使用参考图像中的角色替换视频中的角色
* Move：使用输入视频中的角色动作和表情控制使参考图像进行类似的动作或表情（类似于 Wan2.2 Fun Control）

#### 4.1 Mix 模式

<img src="https://mintcdn.com/dripart/UGcNWAMSJO6Toi_8/images/tutorial/video/wan/wan2_2/wan_2.2_14b_animate.jpg?fit=max&auto=format&n=UGcNWAMSJO6Toi_8&q=85&s=d451c51be227ab808ff8aa2723a054ad" alt="Workflow" width="4088" height="4096" data-path="images/tutorial/video/wan/wan2_2/wan_2.2_14b_animate.jpg" />

0. 如果你是第一次运行此工作流，请使用较小的尺寸进行视频生成，以防你没有足够的显存运行工作流，由于 `WanAnimateToVideo` 的限制，视频的宽度或高度应为 16 的倍数。
1. 确保所有模型都已正确加载
2. 如需要，更新提示词
3. 上传参考图像，此图像中的角色将是目标角色
4. 你可以使用我们提供的视频作为首次输入视频，[comfyui\_controlnet\_aux](https://github.com/Fannovel16/comfyui_controlnet_aux) 中的 **DWPose Estimator** 节点将预处理输入视频以生成姿态和面部控制视频
5. `Points Editor` 来自 [KJNodes](https://github.com/kijai/ComfyUI-KJNodes/)，默认情况下此节点不会加载输入视频的第一帧，你需要运行一次工作流或手动上传第一帧
   * 在 `Points Editor` 节点下方，我们添加了关于此节点如何工作以及如何编辑的说明，请参阅它
6. 对于 "Video Extend" 组，它是为了扩展输出视频长度
   * 每个 `Video Extend` 将扩展另外 77 帧（约 4.8125 秒）
   * 如果你的输入视频少于 5 秒，你可能不需要它
   * 如果你想扩展更长的时间，你需要多次复制和粘贴，你需要将上一个 Video Extend 的 `batch_images` 链接到下一个，同时将上一个 Video Extend 的 `video_frame_offset` 链接到下一个
7. 点击 `Run` 按钮或使用快捷键 `Ctrl(cmd) + Enter` 来执行视频生成

#### 4.2 Move 模式

我们在 Wan2.2 animate 工作流中使用了 [子图](/zh/interface/features/subgraph)，以下是切换到 Move 模式的方法：

<img src="https://mintcdn.com/dripart/UGcNWAMSJO6Toi_8/images/tutorial/video/wan/wan2_2/wan2.2_animate_subgraph.jpg?fit=max&auto=format&n=UGcNWAMSJO6Toi_8&q=85&s=193caf05c2494550d6b92318523c54a4" alt="Subgraph" width="1228" height="1206" data-path="images/tutorial/video/wan/wan2_2/wan2.2_animate_subgraph.jpg" />

如果你想切换到 Move 模式，可以从 `Video Sampling and output(Subgraph)` 节点断开 `background_video` 和 `character_mask` 输入。
