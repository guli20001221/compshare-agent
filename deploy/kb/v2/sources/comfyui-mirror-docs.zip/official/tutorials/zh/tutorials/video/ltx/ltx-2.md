> ## Documentation Index
> Fetch the complete documentation index at: https://docs.comfy.org/llms.txt
> Use this file to discover all available pages before exploring further.

# LTX-2.0 ComfyUI 工作流示例

> 学习如何在 ComfyUI 中使用 LTX-2 实现同步音视频生成

<iframe width="560" height="315" src="https://www.youtube.com/embed/7uaU4Rm7fEo?si=tune56PDf9QfD-JY" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen />

[LTX-2](https://huggingface.co/Lightricks/LTX-2) 是 Lightricks 推出的 190 亿参数 DiT 音视频基础模型。它可以在单次生成中同步产出视频和音频，将动作、对话、背景音效和音乐融为一体。

<Tip>
  <Tabs>
    <Tab title="便携版或手动安装用户">
      请确保你的 ComfyUI 已经更新。

      * [ComfyUI 下载](https://www.comfy.org/download)
      * [ComfyUI 更新教程](/zh/installation/update_comfyui)

      本指南里的工作流可以在 ComfyUI 的[工作流模板](/zh/interface/features/template)中找到。如果找不到，可能是 ComfyUI 没有更新。

      如果加载工作流时有节点缺失，可能原因有：

      1. 你用的不是最新开发版（nightly）。
      2. 你用的是稳定版或桌面版（没有包含最新的更新）。
      3. 启动时有些节点导入失败。
    </Tab>

    <Tab title="桌面版或云端用户">
      * 桌面版是基于 ComfyUI 稳定版本构建的，它会在有新的桌面稳定版本发布时自动更新。
      * [Cloud](https://cloud.comfy.org) 会在 ComfyUI 稳定版本发布后更新，我们会同步更新 Cloud。

      所以，如果你发现本教程中有任何核心节点缺失，那是因为对应的节点支持还在开发中没有发布正式的稳定版，请等待下一个稳定版本发布。
    </Tab>
  </Tabs>
</Tip>

## 主要特性

* **音视频同步生成**：一次生成动作、对话、音效和音乐
* **多种生成模式**：支持文生视频、图生视频和视频转视频
* **控制选项**：通过 IC-LoRAs 支持 Canny、Depth 和 Pose 视频控制
* **关键帧驱动生成**：在关键帧图像之间进行插值
* **原生放大**：空间 (2x) 和时间 (2x) 放大器，提升分辨率和帧率
* **提示词增强**：支持自动提示词增强

## 模型检查点

| 名称                             | 描述              |
| ------------------------------ | --------------- |
| ltx-2-19b-dev                  | bf16 完整模型，灵活可训练 |
| ltx-2-19b-dev-fp8              | fp8 量化完整模型      |
| ltx-2-19b-distilled            | 蒸馏版本，8 步，CFG=1  |
| ltx-2-spatial-upscaler-x2-1.0  | 2x 空间放大器，提升分辨率  |
| ltx-2-temporal-upscaler-x2-1.0 | 2x 时间放大器，提升帧率   |

## 快速入门

LTX-2 已原生支持 ComfyUI。开始使用：

1. 将 ComfyUI 更新到最新版本
2. 进入 **模板库** > **视频** > 选择任意 LTX-2 工作流
3. 按照弹窗提示下载模型并运行工作流

## 工作流

### 文生视频

从文本提示词生成视频。

<Card title="文生视频" icon="download" href="https://raw.githubusercontent.com/Comfy-Org/workflow_templates/refs/heads/main/templates/video_ltx2_t2v.json">
  下载工作流
</Card>

<Card title="在 Comfy Cloud 运行" icon="cloud" href="https://cloud.comfy.org/?template=video_ltx2_t2v&utm_source=docs&utm_campaign=ltx_2">
  在云端打开
</Card>

**蒸馏版本**（更快，8 步）：

<Card title="文生视频蒸馏版" icon="download" href="https://raw.githubusercontent.com/Comfy-Org/workflow_templates/refs/heads/main/templates/video_ltx2_t2v_distilled.json">
  下载工作流
</Card>

### 图生视频

从输入图像生成视频。

<Card title="图生视频" icon="download" href="https://raw.githubusercontent.com/Comfy-Org/workflow_templates/refs/heads/main/templates/video_ltx2_i2v.json">
  下载工作流
</Card>

<Card title="在 Comfy Cloud 运行" icon="cloud" href="https://cloud.comfy.org/?template=video_ltx2_i2v&utm_source=docs&utm_campaign=ltx_2">
  在云端打开
</Card>

**蒸馏版本**（更快，8 步）：

<Card title="图生视频蒸馏版" icon="download" href="https://raw.githubusercontent.com/Comfy-Org/workflow_templates/refs/heads/main/templates/video_ltx2_i2v_distilled.json">
  下载工作流
</Card>

### 控制生成视频

使用 IC-LoRAs 进行结构控制生成视频。

**深度控制：**

<Card title="深度转视频" icon="download" href="https://github.com/Comfy-Org/workflow_templates/raw/refs/heads/main/templates/video_ltx2_depth_to_video.json">
  下载工作流
</Card>

<Card title="在 Comfy Cloud 运行" icon="cloud" href="https://cloud.comfy.org/?template=video_ltx2_depth_to_video&utm_source=docs&utm_campaign=ltx_2">
  在云端打开
</Card>

**Canny 边缘控制：**

<Card title="Canny 转视频" icon="download" href="https://raw.githubusercontent.com/Comfy-Org/workflow_templates/refs/heads/main/templates/video_ltx2_canny_to_video.json">
  下载工作流
</Card>

<Card title="在 Comfy Cloud 运行" icon="cloud" href="https://cloud.comfy.org/?template=video_ltx2_canny_to_video&utm_source=docs&utm_campaign=ltx_2">
  在云端打开
</Card>

**姿态控制：**

<Card title="姿态转视频" icon="download" href="https://raw.githubusercontent.com/Comfy-Org/workflow_templates/refs/heads/main/templates/video_ltx2_pose_to_video.json">
  下载工作流
</Card>

<Card title="在 Comfy Cloud 运行" icon="cloud" href="https://cloud.comfy.org/?template=video_ltx2_pose_to_video&utm_source=docs&utm_campaign=ltx_2">
  在云端打开
</Card>

## 提示词技巧

编写 LTX-2 提示词时，请专注于详细、按时间顺序描述动作和场景。在一个连贯的段落中包含具体的动作、外观、镜头角度和环境细节。直接从动作开始，保持描述的字面性和精确性。

提示词结构建议：

* 用一句话描述主要动作
* 动作和手势的具体细节
* 角色/物体外观
* 背景和环境细节
* 镜头角度和运动
* 光线和色彩
* 任何变化或突发事件

提示词最好控制在 200 词以内。

## 资源

* [GitHub 仓库](https://github.com/Lightricks/LTX-2)
* [Hugging Face 模型](https://huggingface.co/Lightricks/LTX-2)
* [LTX-2 提示词指南](https://ltx.video/blog/how-to-prompt-for-ltx-2)
* [ComfyUI-LTXVideo](https://github.com/Lightricks/ComfyUI-LTXVideo/)
