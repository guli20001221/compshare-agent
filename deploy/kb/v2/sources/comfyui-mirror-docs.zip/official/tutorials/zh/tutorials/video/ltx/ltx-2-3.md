> ## Documentation Index
> Fetch the complete documentation index at: https://docs.comfy.org/llms.txt
> Use this file to discover all available pages before exploring further.

# LTX-2.3 ComfyUI 工作流示例

> 学习如何在 ComfyUI 中使用 LTX-2.3 实现增强音视频生成，支持更精细的细节和竖屏视频

[LTX-2.3](https://huggingface.co/Lightricks/LTX-2.3) 是 Lightricks 开源音视频生成模型的最新版本，现已原生支持 ComfyUI。在 LTX-2 的基础上，该版本在细节、竖屏视频、音频、图生视频、提示词理解和文字渲染方面都有重大改进。

<Tip>
  <Tabs>
    <Tab title="便携版或手动安装用户">
      请确保你的 ComfyUI 已经更新。

      * [ComfyUI 下载](https://www.comfy.org/download)
      * [ComfyUI 更新教程](/zh/installation/update_comfyui)

      本指南里的工作流可以在 ComfyUI 的[工作流模板](/zh/interface/features/template)中找到。如果找不到，可能是 ComfyUI 没有更新。

      如果加载工作流时有节点缺失，可能原因有：

      1. 你用的不是最新开发版（nightly）。
      2. 你用的是稳定版或桌面版（没有包含最新的更新）。
      3. 启动时有些节点导入失败。
    </Tab>

    <Tab title="桌面版或云端用户">
      * 桌面版是基于 ComfyUI 稳定版本构建的，它会在有新的桌面稳定版本发布时自动更新。
      * [Cloud](https://cloud.comfy.org) 会在 ComfyUI 稳定版本发布后更新，我们会同步更新 Cloud。

      所以，如果你发现本教程中有任何核心节点缺失，那是因为对应的节点支持还在开发中没有发布正式的稳定版，请等待下一个稳定版本发布。
    </Tab>
  </Tabs>
</Tip>

## 主要特性

* **更精细的细节**：新的潜空间和更新的 VAE，带来更锐利的纹理、更干净的边缘和更精确的视觉效果
* **9:16 竖屏支持**：竖屏视频质量大幅提升，非常适合社交媒体和移动端
* **更好的音频**：更干净的声音，减少噪音，增强对话、音乐和环境音效
* **改进的图生视频**：更一致的运动效果，减少卡顿等问题，动画更流畅自然
* **更智能的提示词理解**：改进的文本编码器，更准确地理解复杂提示词
* **更清晰的文字渲染**：视频中的文字和字母渲染更准确

## 快速入门

LTX-2.3 已原生支持 ComfyUI。开始使用：

1. 将 ComfyUI 更新到最新版本
2. 进入 **模板库** > **视频** > 选择任意 LTX-2.3 工作流
3. 按照弹窗提示下载模型并运行工作流

## 工作流

### 图生视频

从输入图像生成视频，运动更一致，动画更流畅。

<Card title="图生视频" icon="download" href="https://raw.githubusercontent.com/Comfy-Org/workflow_templates/refs/heads/main/templates/video_ltx2_3_i2v.json">
  下载工作流
</Card>

<Card title="在 Comfy Cloud 运行" icon="cloud" href="https://links.comfy.org/4skdlDQ">
  在云端打开
</Card>

### 文生视频

从文本提示词生成视频，提示词理解和文字渲染更出色。

<Card title="文生视频" icon="download" href="https://raw.githubusercontent.com/Comfy-Org/workflow_templates/refs/heads/main/templates/video_ltx2_3_t2v.json">
  下载工作流
</Card>

<Card title="在 Comfy Cloud 运行" icon="cloud" href="https://links.comfy.org/4rZ1DyY">
  在云端打开
</Card>

## 模型下载

### 检查点

| 名称                  | 描述        | 下载                                                                                               |
| ------------------- | --------- | ------------------------------------------------------------------------------------------------ |
| ltx-2.3-22b-dev     | BF16 完整模型 | [下载](https://huggingface.co/Lightricks/LTX-2.3/resolve/main/ltx-2.3-22b-dev.safetensors)         |
| ltx-2.3-22b-dev-fp8 | FP8 量化模型  | [下载](https://huggingface.co/Lightricks/LTX-2.3-fp8/resolve/main/ltx-2.3-22b-dev-fp8.safetensors) |

### LoRAs

| 名称                             | 下载                                                                                                      |
| ------------------------------ | ------------------------------------------------------------------------------------------------------- |
| ltx-2.3-22b-distilled-lora-384 | [下载](https://huggingface.co/Lightricks/LTX-2.3/resolve/main/ltx-2.3-22b-distilled-lora-384.safetensors) |

### 潜空间放大模型

| 名称                              | 下载                                                                                                       |
| ------------------------------- | -------------------------------------------------------------------------------------------------------- |
| ltx-2.3-spatial-upscaler-x2-1.0 | [下载](https://huggingface.co/Lightricks/LTX-2.3/resolve/main/ltx-2.3-spatial-upscaler-x2-1.0.safetensors) |

### 文本编码器

| 名称                            | 下载                                                                                                                       |
| ----------------------------- | ------------------------------------------------------------------------------------------------------------------------ |
| gemma\_3\_12B\_it\_fp4\_mixed | [下载](https://huggingface.co/Comfy-Org/ltx-2/resolve/main/split_files/text_encoders/gemma_3_12B_it_fp4_mixed.safetensors) |

## 模型存储位置

```
ComfyUI/
├── models/
│   ├── latent_upscale_models/
│   │   └── ltx-2.3-spatial-upscaler-x2-1.0.safetensors
│   ├── checkpoints/
│   │   ├── ltx-2.3-22b-dev-fp8.safetensors
│   │   └── ltx-2.3-22b-dev.safetensors
│   ├── loras/
│   │   └── ltx-2.3-22b-distilled-lora-384.safetensors
│   └── text_encoders/
│       └── gemma_3_12B_it_fp4_mixed.safetensors
```

## 资源

* [Hugging Face 模型](https://huggingface.co/Lightricks/LTX-2.3)
* [GitHub 仓库](https://github.com/Lightricks/LTX-2)
* [ComfyUI-LTXVideo](https://github.com/Lightricks/ComfyUI-LTXVideo/)
