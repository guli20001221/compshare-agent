> ## Documentation Index
> Fetch the complete documentation index at: https://docs.comfy.org/llms.txt
> Use this file to discover all available pages before exploring further.

# Qwen3.5 ComfyUI 工作流示例

> Qwen3.5 是阿里巴巴云推出的开源多模态大语言模型，具备图像理解和文本生成能力，提供 4B 参数版本，适用于图像描述和反向提示词工程。

<Tip>
  <Tabs>
    <Tab title="便携版或手动安装用户">
      请确保你的 ComfyUI 已经更新。

      * [ComfyUI 下载](https://www.comfy.org/download)
      * [ComfyUI 更新教程](/zh/installation/update_comfyui)

      本指南里的工作流可以在 ComfyUI 的[工作流模板](/zh/interface/features/template)中找到。如果找不到，可能是 ComfyUI 没有更新。

      如果加载工作流时有节点缺失，可能原因有：

      1. 你用的不是最新开发版（nightly）。
      2. 你用的是稳定版或桌面版（没有包含最新的更新）。
      3. 启动时有些节点导入失败。
    </Tab>

    <Tab title="桌面版或云端用户">
      * 桌面版是基于 ComfyUI 稳定版本构建的，它会在有新的桌面稳定版本发布时自动更新。
      * [Cloud](https://cloud.comfy.org) 会在 ComfyUI 稳定版本发布后更新，我们会同步更新 Cloud。

      所以，如果你发现本教程中有任何核心节点缺失，那是因为对应的节点支持还在开发中没有发布正式的稳定版，请等待下一个稳定版本发布。
    </Tab>
  </Tabs>
</Tip>

**Qwen3.5** 是一个开源多模态大语言模型，来自阿里巴巴云，在 Qwen 3.0 系列的基础上增加了图像理解能力。它同时支持文本生成和基于图像的任务，如图像描述和反向提示词工程。

**模型亮点**：

* **多模态** — 接受文本和图像输入，用于视觉理解任务
* **图像描述** — 能够描述图像并生成详细说明
* **反向提示词工程** — 从参考图像中提取提示词和生成参数
* **ComfyUI 原生支持** — 使用内置 `TextGenerate` 节点，无需自定义节点
* **轻量级** — 4B 参数模型，适合消费级 GPU

## 使用场景

Qwen3.5 在需要将视觉理解与文本生成结合的 ComfyUI 场景中表现出色：

* **图像反推提示词** — 将参考图像输入 Qwen3.5，让模型生成一份能够复现该图像的详细提示词。当你看到一张效果很好的图片但不知道它的 prompt 是怎样写的时，这个功能尤其有用。
* **提示词优化** — 加载现有提示词和图像构思，让 Qwen3.5 生成、细化或扩展更丰富的描述以获得更好的生成效果。
* **图像描述** — 自动为生成的图片生成标题、描述或元数据标签，适用于作品归档或训练数据准备。
* **视觉问答** — 询问关于图像内容的问题（"这张图里有什么物体？"、"背景是什么颜色？"），获得结构化的文本答案。
* **文字读取** — 使用合适的 prompt，模型可能会尝试读取图片中的可见文字或标签，但可靠性取决于文字渲染的质量和清晰度。

## 可用工作流

### Qwen3.5: 文本生成

<Card title="下载工作流" icon="download" href="https://github.com/Comfy-Org/workflow_templates/blob/main/templates/llm_qwen3_5_text_gen.json">
  下载 JSON 或在模板库中搜索 "Qwen3.5 Text Generation"
</Card>

<Card title="在 Comfy Cloud 运行" icon="cloud" href="https://cloud.comfy.org/?template=llm_qwen3_5_text_gen&utm_source=docs&utm_medium=referral&utm_campaign=qwen3_5">
  在 Comfy Cloud 中打开
</Card>

![Qwen3.5 文本生成工作流](https://raw.githubusercontent.com/Comfy-Org/workflow_templates/main/templates/llm_qwen3_5_text_gen-1.webp)

此工作流展示了 Qwen3.5 的**文本生成和图像理解**能力。接受文本提示词和可选图像输入，根据输入生成描述性文本或结构化分析。

**输入**：

* **文本提示词** — 你的问题、指令或任务描述
* **图像**（可选） — 用于视觉理解任务（图像描述、反向提示词工程、提示词优化等）

**关键控制参数**：

* **最大长度** — 生成的最大 token 数（默认 256）
* **采样模式** — 开关采样，调节温度、top-k、top-p、重复惩罚和随机种子
* **使用默认模板** — 应用模型内置系统提示词

**输出**：

* **生成的文本** — 模型回复的纯文本字符串

<Card title="了解子图" icon="book-open" href="/zh/interface/features/subgraph">
  本工作流使用子图节点进行模块化处理。查看子图文档了解如何自定义和扩展工作流。
</Card>

## 模型下载

Qwen3.5 模型以文本编码器的形式加载到 ComfyUI 中。根据你的硬件选择合适的版本：

<Card title="Qwen3.5 2B (bf16)" icon="download" href="https://huggingface.co/Comfy-Org/Qwen3.5/resolve/main/text_encoders/qwen3.5_2b_bf16.safetensors">
  轻量版，约 4.5 GB。适合低显存环境和快速下载。
</Card>

<Card title="Qwen3.5 4B (bf16)" icon="download" href="https://huggingface.co/Comfy-Org/Qwen3.5/resolve/main/text_encoders/qwen3.5_4b_bf16.safetensors">
  大小和质量均衡。推荐大多数消费级 GPU。
</Card>

<Card title="Qwen3.5 9B (bf16)" icon="download" href="https://huggingface.co/Comfy-Org/Qwen3.5/resolve/main/text_encoders/qwen3.5_9b_bf16.safetensors">
  最大版本，约 19 GB。输出质量更高，需要更多显存。
</Card>

将下载的 `.safetensors` 文件放入：

```
📂 ComfyUI/
├── 📂 models/
│   └── 📂 text_encoders/
│       └── qwen3.5_4b_bf16.safetensors   # 或 2b / 9b 版本
```
