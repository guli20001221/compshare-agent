> ## Documentation Index
> Fetch the complete documentation index at: https://docs.comfy.org/llms.txt
> Use this file to discover all available pages before exploring further.

# Krea-2 ComfyUI 工作流示例

> Krea 2 是一款专为高美学质量和风格多样性设计的文生图模型，提供 RAW（基础版）和 Turbo（蒸馏版）两个版本。

<iframe width="560" height="315" src="https://www.youtube.com/embed/17GiSs-YOZw?si=sUXPPOargSSttMpe" title="krea.ai 2 is back and this time the weights are OPEN." frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen />

**Krea 2** 是由 [Krea AI](https://www.krea.ai) 从零训练的文生图模型，专注于创意和风格探索。

Krea 2 以两个模型的形式发布，它们被设计为协同工作——**在 RAW 上训练 LoRA，在 Turbo 上运行推理**：

* **Krea 2 RAW**：基础模型，使用完整采样步数（52步），未经过蒸馏，多样性强且塑性强，非常适合微调和 LoRA 训练。
* **Krea 2 Turbo**：8 步蒸馏模型，专为快速高质量生成而设计。在 RAW 上训练的 LoRA 可直接应用于 Turbo。

**许可证**：[Krea AI 社区许可证](https://www.krea.ai/krea-2-licensing)

## 观看发布活动

<iframe width="560" height="315" src="https://www.youtube.com/embed/31jiUhCEjJ4?si=5RNQbHURu5lijlGC" title="Krea 2 Live Launch Event" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen />

如果想了解更多关于 Krea 2 的开发故事、模型能力以及其对开源生态的意义，请看上面的发布活动回放（特邀 Victor Perez、Miguel Lara 和 ComfyAnonymous 对谈）。

## 可用模型权重

Krea 2 提供两个版本：

* **Krea 2 RAW**：基础模型，使用完整采样步数（52步），多样性和塑性强，非常适合微调和 LoRA 训练。
* **Krea 2 Turbo**：8 步蒸馏模型，专为快速高质量生成而设计。在 RAW 上训练的 LoRA 可以直接应用于 Turbo。

**相关链接**：

* [Krea 2 在 Hugging Face (RAW)](https://huggingface.co/krea/Krea-2-Raw)
* [Krea 2 在 Hugging Face (Turbo)](https://huggingface.co/krea/Krea-2-Turbo)
* [Comfy-Org/Krea-2 (ComfyUI 模型)](https://huggingface.co/Comfy-Org/Krea-2)
* [GitHub 官方仓库](https://github.com/krea-ai/krea-2)
* [技术报告](https://www.krea.ai/blog/krea-2-technical-report)

## Krea-2 Turbo 文生图工作流

<img src="https://raw.githubusercontent.com/Comfy-Org/workflow_templates/main/templates/image_krea2_turbo_t2i-1.webp" alt="Krea-2 Turbo 文生图工作流" />

<CardGroup cols={2}>
  <Card title="在 Comfy Cloud 运行" icon="cloud" href="https://cloud.comfy.org/?template=image_krea2_turbo_t2i&utm_source=docs&utm_medium=referral&utm_campaign=krea-2">
    在 Comfy Cloud 中打开
  </Card>

  <Card title="下载工作流" icon="download" href="https://github.com/Comfy-Org/workflow_templates/blob/main/templates/image_krea2_turbo_t2i.json">
    下载 JSON 或在模板库中搜索"Krea-2"
  </Card>
</CardGroup>

<Tip>
  <Tabs>
    <Tab title="便携版或手动安装用户">
      请确保你的 ComfyUI 已经更新。

      * [ComfyUI 下载](https://www.comfy.org/download)
      * [ComfyUI 更新教程](/zh/installation/update_comfyui)

      本指南里的工作流可以在 ComfyUI 的[工作流模板](/zh/interface/features/template)中找到。如果找不到，可能是 ComfyUI 没有更新。

      如果加载工作流时有节点缺失，可能原因有：

      1. 你用的不是最新开发版（nightly）。
      2. 你用的是稳定版或桌面版（没有包含最新的更新）。
      3. 启动时有些节点导入失败。
    </Tab>

    <Tab title="桌面版或云端用户">
      * 桌面版是基于 ComfyUI 稳定版本构建的，它会在有新的桌面稳定版本发布时自动更新。
      * [Cloud](https://cloud.comfy.org) 会在 ComfyUI 稳定版本发布后更新，我们会同步更新 Cloud。

      所以，如果你发现本教程中有任何核心节点缺失，那是因为对应的节点支持还在开发中没有发布正式的稳定版，请等待下一个稳定版本发布。
    </Tab>
  </Tabs>
</Tip>

工作流分为以下几个部分：

1. **Text to Image (Krea-2 Turbo) 子图**：核心生成管线，包含模型加载、提示词处理、采样和 VAE 解码
2. **ResolutionSelector**：选择输出分辨率。Krea 2 支持 1K 到 2K 的输出，将 megapixels 值设为 2.0 即可获得 2K 分辨率。
3. **CustomCombo (LoRA 选择器)**：预置的触发词选择器，对应可用的风格 LoRA。如果你下载了额外的 LoRA，可以自定义该选择器并与对应的 LoRA 文件配对使用。
4. **SaveImage**：保存生成的图像

<Card title="了解子图" icon="book-open" href="/zh/interface/features/subgraph">
  本工作流使用子图节点进行模块化处理。查看子图文档了解如何定制和扩展工作流。
</Card>

### 一键生成

最简单的操作是：直接在子图中输入提示词，选择分辨率，点击 **Queue Prompt**。默认设置（8步、提示词增强开启、不使用 LoRA）即可生成高质量图像。

### 工作流控制参数

**Text to Image (Krea-2 Turbo)** 子图暴露了以下控制参数：

| 控制                            | 说明                             |
| ----------------------------- | ------------------------------ |
| **Text String (User Prompt)** | 描述要生成图像的文本提示词                  |
| **prompt\_enhance**           | 开启/关闭 LLM 提示词扩展功能              |
| **LLM\_max\_token**           | 提示词扩展的最大 token 数               |
| **Width / Height**            | 输出分辨率（由 ResolutionSelector 控制） |
| **Seed**                      | 随机种子，用于复现结果                    |
| **enable\_lora?**             | 启用或禁用风格 LoRA                   |
| **LoRA Strength**             | 风格 LoRA 的应用强度                  |
| **LoRA Trigger Word**         | 自动填充所选 LoRA 的触发词               |

### 风格 LoRA

Krea 还发布了一组 Krea 2 的风格 LoRA。在 **CustomCombo** 节点中选择一个，并在子图中启用 `enable_lora?` 即可应用：

| LoRA              | 触发词                                | 推荐强度 | 下载                                                                                         |
| ----------------- | ---------------------------------- | :--: | ------------------------------------------------------------------------------------------ |
| krea2\_coolblue   | teal watercolor illustration style |  0.8 | [下载](https://huggingface.co/Comfy-Org/Krea-2/blob/main/loras/krea2_coolblue.safetensors)   |
| krea2\_darkbrush  | monochrome ink wash style          |  1.0 | [下载](https://huggingface.co/Comfy-Org/Krea-2/blob/main/loras/krea2_darkbrush.safetensors)  |
| krea2\_plasmoid   | ethereal shimmering light style    |  0.8 | [下载](https://huggingface.co/Comfy-Org/Krea-2/blob/main/loras/krea2_plasmoid.safetensors)   |
| krea2\_warmpastel | muted minimalist sketch style      |  0.8 | [下载](https://huggingface.co/Comfy-Org/Krea-2/blob/main/loras/krea2_warmpastel.safetensors) |

将 `.safetensors` 文件放入 `ComfyUI/models/loras/` 目录。

## 模型下载

如需本地使用，请从 [Comfy-Org/Krea-2](https://huggingface.co/Comfy-Org/Krea-2) 下载 ComfyUI 优化版模型文件。

<CardGroup cols={3}>
  <Card title="扩散模型 (FP8)" icon="download" href="https://huggingface.co/Comfy-Org/Krea-2/resolve/main/diffusion_models/krea2_turbo_fp8_scaled.safetensors">
    krea2\_turbo\_fp8\_scaled.safetensors：Turbo FP8（推荐大多数用户使用）
  </Card>

  <Card title="文本编码器 (FP8)" icon="download" href="https://huggingface.co/Comfy-Org/Krea-2/resolve/main/text_encoders/qwen3vl_4b_fp8_scaled.safetensors">
    qwen3vl\_4b\_fp8\_scaled.safetensors：Qwen3VL-4B 文本编码器
  </Card>

  <Card title="VAE" icon="download" href="https://huggingface.co/Comfy-Org/Krea-2/resolve/main/vae/qwen_image_vae.safetensors">
    qwen\_image\_vae.safetensors
  </Card>

  <Card title="风格 LoRA" icon="download" href="https://huggingface.co/collections/krea/krea-2-loras">
    查看 Hugging Face 上的所有风格 LoRA
  </Card>
</CardGroup>

其他模型变体（BF16、NVFP4、MXFP8）也可供高端硬件的用户使用。

### 模型存储位置

```
📂 ComfyUI/
├── 📂 models/
│   ├── 📂 diffusion_models/
│   │   └── krea2_turbo_fp8_scaled.safetensors
│   ├── 📂 text_encoders/
│   │   └── qwen3vl_4b_fp8_scaled.safetensors
│   ├── 📂 vae/
│   │   └── qwen_image_vae.safetensors
│   └── 📂 loras/
│       └── krea2_warmpastel.safetensors (及其它风格 LoRA)
```
