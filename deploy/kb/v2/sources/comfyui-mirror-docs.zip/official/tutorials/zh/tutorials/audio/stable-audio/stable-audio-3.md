> ## Documentation Index
> Fetch the complete documentation index at: https://docs.comfy.org/llms.txt
> Use this file to discover all available pages before exploring further.

# Stable Audio 3 ComfyUI 工作流示例

> 本文介绍如何在 ComfyUI 中使用 Stability AI 开源模型 Stable Audio 3 进行文本转音频生成，支持 Qwen 提示词扩展和分类感知的重新提示功能。

<Tip>
  <Tabs>
    <Tab title="便携版或手动安装用户">
      请确保你的 ComfyUI 已经更新。

      * [ComfyUI 下载](https://www.comfy.org/download)
      * [ComfyUI 更新教程](/zh/installation/update_comfyui)

      本指南里的工作流可以在 ComfyUI 的[工作流模板](/zh/interface/features/template)中找到。如果找不到，可能是 ComfyUI 没有更新。

      如果加载工作流时有节点缺失，可能原因有：

      1. 你用的不是最新开发版（nightly）。
      2. 你用的是稳定版或桌面版（没有包含最新的更新）。
      3. 启动时有些节点导入失败。
    </Tab>

    <Tab title="桌面版或云端用户">
      * 桌面版是基于 ComfyUI 稳定版本构建的，它会在有新的桌面稳定版本发布时自动更新。
      * [Cloud](https://cloud.comfy.org) 会在 ComfyUI 稳定版本发布后更新，我们会同步更新 Cloud。

      所以，如果你发现本教程中有任何核心节点缺失，那是因为对应的节点支持还在开发中没有发布正式的稳定版，请等待下一个稳定版本发布。
    </Tab>
  </Tabs>
</Tip>

**Stable Audio 3** ([GitHub](https://github.com/Stability-AI/stable-audio-3)) 是 Stability AI 最新开源的音频生成模型，使用全授权音乐数据训练，可用于商业用途。它使用专用子图节点从文本描述生成高质量立体声音频——包括音乐、音效和乐器声音——并支持可选的 Qwen 分类感知重新提示功能。

Stable Audio 3 提供三个变体：

* **Small-SFX** — 音效和短氛围音，最长 2 分钟。模型小巧，CPU 可运行。
* **Small-Music** — 短音乐片段，适合设备端使用，最长 2 分钟。
* **Medium** — 更长曲目，结构和音乐性更完整，最长约 6 分 20 秒。需要 GPU。

**相关链接**：

* [GitHub: Stability-AI/stable-audio-3](https://github.com/Stability-AI/stable-audio-3)
* [Hugging Face (Comfy-Org/stable-audio-3)](https://huggingface.co/Comfy-Org/stable-audio-3)
* [博客：发布公告](https://blog.comfy.org/p/stable-audio-3-day-0-support)

## 可用工作流

### Stable Audio 3 Medium

<Card title="下载工作流" icon="download" href="https://github.com/Comfy-Org/workflow_templates/blob/main/templates/audio_stable_audio_3_medium.json">
  下载 JSON 或在模板库中搜索"Stable Audio 3 Medium"
</Card>

<Card title="在 Comfy Cloud 中运行" icon="cloud" href="https://cloud.comfy.org/?template=audio_stable_audio_3_medium&utm_source=docs&utm_medium=referral&utm_campaign=stable-audio-3">
  在 Comfy Cloud 中打开
</Card>

![Stable Audio 3 Medium 工作流](https://raw.githubusercontent.com/Comfy-Org/workflow_templates/main/templates/audio_stable_audio_3_medium-1.webp)

**Stable Audio 3 Medium** 工作流是一个完整的文本转音频流水线。你提供一个简短的文本创意、可选时长、种子和类别——工作流会使用 Qwen 配合分类感知的重新提示模板扩展你的提示词，然后通过 Stable Audio 3 检查点生成立体声音频。

**使用方法**：

1. **文本创意** — 输入你想生成的声音、音乐或效果的文字描述（例如"强劲节拍的电子舞曲"）
2. **时长** — 设置音频片段长度（秒）
3. **种子** — 调整种子值控制可重现性
4. **类别** — 选择重新提示预设：**音乐（Music）**、**乐器（Instrument）**、**音效（SFX）** 或 **单次音效（One-shot）**
5. **启用重新提示** — 打开 `use_reprompt` 开关，让 Qwen 将你的短创意扩展为详细提示词后再生成
6. 点击**运行**（`Ctrl/Cmd + Enter`）生成音频。文件将保存在 `ComfyUI/output/audio/` 目录

### Stable Audio 3 Medium Base

<Card title="下载工作流" icon="download" href="https://github.com/Comfy-Org/workflow_templates/blob/main/templates/audio_stable_audio_3_medium_base.json">
  下载 JSON 或在模板库中搜索"Stable Audio 3 Medium Base"
</Card>

<Card title="在 Comfy Cloud 中运行" icon="cloud" href="https://cloud.comfy.org/?template=audio_stable_audio_3_medium_base&utm_source=docs&utm_medium=referral&utm_campaign=stable-audio-3">
  在 Comfy Cloud 中打开
</Card>

![Stable Audio 3 Medium Base 工作流](https://raw.githubusercontent.com/Comfy-Org/workflow_templates/main/templates/audio_stable_audio_3_medium_base-1.webp)

简化版本，不包含 Qwen 提示词扩展。接收完整的文本提示词直接传递给模型。当你已经有详细的提示词、希望加快生成速度时使用。

**使用方法**：

1. **文本提示词** — 输入详细的音频描述
2. **时长** — 设置音频片段长度（秒）
3. **种子** — 控制可重现性
4. 点击**运行**（`Ctrl/Cmd + Enter`）生成音频

## 模型下载

加载工作流时，如果模型缺失，ComfyUI 会提示并提供对应下载链接。如需手动设置，请下载以下文件并放在正确目录。

### 检查点

<Card title="stable_audio_3_medium.safetensors" icon="download" href="https://huggingface.co/Comfy-Org/stable-audio-3/resolve/main/checkpoints/stable_audio_3_medium.safetensors">
  用于 Medium 工作流。放入 models/checkpoints/
</Card>

<Card title="stable_audio_3_medium_base.safetensors" icon="download" href="https://huggingface.co/Comfy-Org/stable-audio-3/resolve/main/checkpoints/stable_audio_3_medium_base.safetensors">
  用于 Medium Base 工作流。放入 models/checkpoints/
</Card>

放在以下目录：

```
📂 ComfyUI/
├── 📂 models/
│   └── 📂 checkpoints/
│       ├── stable_audio_3_medium.safetensors
│       └── stable_audio_3_medium_base.safetensors
```

### 文本编码器

<Card title="t5gemma_b_b_ul2.safetensors" icon="download" href="https://huggingface.co/Comfy-Org/stable-audio-3/resolve/main/text_encoders/t5gemma_b_b_ul2.safetensors">
  所有 Stable Audio 3 工作流都需要。放入 models/text\_encoders/
</Card>

<Card title="qwen3.5_2b_bf16.safetensors" icon="download" href="https://huggingface.co/Comfy-Org/Qwen3.5/resolve/main/text_encoders/qwen3.5_2b_bf16.safetensors">
  Medium 工作流需要（Qwen 重新提示）。放入 models/text\_encoders/
</Card>

放在以下目录：

```
📂 ComfyUI/
├── 📂 models/
│   └── 📂 text_encoders/
│       ├── t5gemma_b_b_ul2.safetensors
│       └── qwen3.5_2b_bf16.safetensors
```

放置完成后，在 ComfyUI 中按快捷键 **R** 刷新节点定义，即可使用最新加载的模型。
