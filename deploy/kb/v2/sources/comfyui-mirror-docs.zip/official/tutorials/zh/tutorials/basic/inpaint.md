> ## Documentation Index
> Fetch the complete documentation index at: https://docs.comfy.org/llms.txt
> Use this file to discover all available pages before exploring further.

# ComfyUI 局部重绘工作流

> 本篇指南将带你了解 ComfyUI 中的局部重绘工作流，并带你完成一个局部重绘的示例，以及遮罩编辑器的使用等

本篇将引导了解 AI 绘图中，局部重绘的概念，并在 ComfyUI 中完成局部重绘工作流生成，我们将接触以下内容：

* 使用局部重绘工作流完成画面的修改
* 了解并使用 ComfyUI 中遮罩编辑器
* 了解相关节点 VAE Encoder (for Inpainting)

## 关于局部重绘

在 AI 图像生成过程中，我们常会遇到生成的画面整体较为满意，但是画面中存在一些不希望出现或者错误的元素，但是重新生成可能会生成另外一张完全不同的图片，所以这时候利用局部重绘来修复这部分的元素就非常有必要了。

这就像让 **画家(AI 绘图模型)** 画了一幅画，但是总是会有稍微有 **局部区域需要调整**，我们需要向画家说明**需要调整的区域(遮罩)**，然后让画家会根据我们的要求进行 **重新绘制(重绘)**。

局部重绘的场景包括：

* **瑕疵修复：** 消除照片中多余物体、错误的AI生成的画面的肢体等
* **细节优化：** 精准调整局部元素（如修改服装纹理、调整面部表情）
* 等其它场景

## ComfyUI 局部重绘工作流示例讲解

### 模型及相关素材准备

#### 1. 模型安装

下载下面的模型文件，并保存到`ComfyUI/models/checkpoints`目录下

* [512-inpainting-ema.safetensors](https://huggingface.co/Comfy-Org/stable_diffusion_2.1_repackaged/resolve/main/512-inpainting-ema.safetensors)

#### 2. 局部重绘素材

请下载下面的图片，我们将在这个示例中使用这个图片作为输入使用

<img src="https://mintcdn.com/dripart/OltlUSVBSNcJsDMs/images/tutorial/basic/inpaint/input.png?fit=max&auto=format&n=OltlUSVBSNcJsDMs&q=85&s=a6557da482429ba4feff636d36f1bb54" alt="ComfyUI局部重绘输入图片" width="1024" height="1024" data-path="images/tutorial/basic/inpaint/input.png" />

<Note>这张照片已经包含了 alpha 透明通道，所以并不需要你手动绘制蒙版，在本篇教程也会涉及如何使用遮罩编辑器来绘制蒙版的部分，我们会引导你一步步来完成整个局部重绘的过程</Note>

#### 3. 局部重绘工作流

下面这张图的 metadata 包含的对应的json工作流，请将其下载后 **拖入** ComfyUI 界面或者使用菜单 **工作流(Workflow)** --> **打开工作流(Open,快捷键 `Ctrl + O`)** 来加载这个局部重绘工作流

![ComfyUI局部重绘工作流](https://raw.githubusercontent.com/Comfy-Org/example_workflows/refs/heads/main/image/basic/sd1.5_inpaint.png)

### ComfyUI 局部重绘工作流示例讲解

<img src="https://mintcdn.com/dripart/OltlUSVBSNcJsDMs/images/tutorial/basic/inpaint/inpaint_workflow.png?fit=max&auto=format&n=OltlUSVBSNcJsDMs&q=85&s=eec79976ea5771763a00668de7c15bc3" alt="ComfyUI 局部重绘工作流" width="2000" height="1108" data-path="images/tutorial/basic/inpaint/inpaint_workflow.png" />

请参照图片序号对照下面的提示完成以下操作：

1. 请确保已经加载了你所下载使用的模型
2. 请在 `Load Image` 节点中加载局部重绘的素材
3. 点击 `Queue` 按钮，或者使用快捷键 `Ctrl + Enter(回车)` 来执行图片生成

此外我们在这里可以对比一下，下图是使用[v1-5-pruned-emaonly-fp16.safetensors](https://huggingface.co/Comfy-Org/stable-diffusion-v1-5-archive/blob/main/v1-5-pruned-emaonly-fp16.safetensors) 模型来进行 inpainting 的结果。

<img src="https://mintcdn.com/dripart/OltlUSVBSNcJsDMs/images/tutorial/basic/inpaint/inpaint_sd1.5_pruned_emaonly.png?fit=max&auto=format&n=OltlUSVBSNcJsDMs&q=85&s=36916904f9884b5bc3c62f6b60ec17e8" alt="ComfyUI 局部重绘工作流 - SD1.5" width="1024" height="1024" data-path="images/tutorial/basic/inpaint/inpaint_sd1.5_pruned_emaonly.png" />

你会发现 [512-inpainting-ema.safetensors](https://huggingface.co/Comfy-Org/stable_diffusion_2.1_repackaged/resolve/main/512-inpainting-ema.safetensors) 模型生成的结果局部重绘的效果更好过渡更自然。
这因为这个模型是专为 inpainting 设计的模型，它可以帮助我们更好地控制生成区域，从而获得更好的局部重绘效果。

记得我们一直用的比喻吗？不同的模型就像能力不同的画家一样，但每个画家都有自己能力的上限，选择合适的模型可以让你的生成效果更好。

你可以进行下面的尝试来让画面达到你想要的效果:

1. 修改正向 、负向提示词，使用更具体的描述
2. 尝试多次运行，让 `KSampler` 使用不同的种子，从而带来不同的生成效果
3. 在了解本篇遮罩编辑器使用的部分后，对于生成的结果再次进行重绘以获得满意的结果。

接下来我们将简单了解如何使用 **遮罩编辑器(Mask Editor)** ，因为之前提供的输入图片中是已经包含了`alpha`透明通道（也就是我们希望在绘图过程中进行编辑的区域），所以并不需要你手动绘制，但在日常使用中我们会更经常使用 **遮罩编辑器(Mask Editor)** 来绘制 蒙版(Mask)

### 使用遮罩编辑器(Mask Editor) 绘制蒙版

首先在上一步工作流中的`Save Image` 节点上右键，你可以在右键菜单中看到`复制(Clipspace)` 选项，点击后会复制当前图片到剪贴板

<img src="https://mintcdn.com/dripart/OltlUSVBSNcJsDMs/images/tutorial/basic/inpaint/inpaint_copy_clipspace.png?fit=max&auto=format&n=OltlUSVBSNcJsDMs&q=85&s=7d1bfea21723437c4ca09bba34edd1ed" alt="ComfyUI 局部重绘 - 复制图片" width="751" height="1112" data-path="images/tutorial/basic/inpaint/inpaint_copy_clipspace.png" />

然后在 **加载图像(Load Image)** 节点上右键，你可以在右键菜单中看到`Paste(Clipspace)` 选项，点击后会从剪贴板中粘贴图片

<img src="https://mintcdn.com/dripart/OltlUSVBSNcJsDMs/images/tutorial/basic/inpaint/inpaint_paste_clipspace.png?fit=max&auto=format&n=OltlUSVBSNcJsDMs&q=85&s=42c942d88b97c696f6f2ed59f7ff9bc8" alt="ComfyUI 局部重绘 - 粘贴图片" width="750" height="947" data-path="images/tutorial/basic/inpaint/inpaint_paste_clipspace.png" />

然后在 **加载图像(Load Image)** 节点上右键，你可以在右键菜单中看到`在遮罩编辑器中打开(Open in MaskEditor)` 选项，点击后会打开遮罩编辑器

<img src="https://mintcdn.com/dripart/OltlUSVBSNcJsDMs/images/tutorial/basic/inpaint/inpaint_open_in_maskeditor.jpg?fit=max&auto=format&n=OltlUSVBSNcJsDMs&q=85&s=682a66f54e0f61366c42e553d50f4e76" alt="打开遮罩编辑器" width="894" height="1000" data-path="images/tutorial/basic/inpaint/inpaint_open_in_maskeditor.jpg" />

<img src="https://mintcdn.com/dripart/OltlUSVBSNcJsDMs/images/tutorial/basic/inpaint/inpaint-maskeditor.gif?s=217f481d8cd4e22183c0dd1551f3e831" alt="遮罩编辑器" width="960" height="720" data-path="images/tutorial/basic/inpaint/inpaint-maskeditor.gif" />

1. 你可以右侧编辑相关参数，比如调整画笔大小、透明度等等
2. 绘制错误区域可以使用橡皮檫来擦除
3. 绘制完成后点击 `Save` 按钮保存蒙版

这样绘制完成的内容就会作为 遮罩(Mask) 输入到 VAE Encoder (for Inpainting) 节点中一起进行编码

然后试着调整提示词，再次进行生成，直到你可以完成满意的生成结果。

## 局部重绘制相关节点

通过[文生图](/zh/tutorials/basic/text-to-image)、[图生图](/zh/tutorials/basic/image-to-image) 和本篇的工作流对比，我想你应该可以看到这几个工作流主要的差异都在于 VAE 部分这部分的条件输入,
在这个工作流中我们使用到的是 **VAE 内部编码器** 节点，这个节点是专门用于局部重绘的节点，它可以帮助我们更好地控制生成区域，从而获得更好的生成效果。

<img src="https://mintcdn.com/dripart/Rig0_LOInmwVbVSB/images/comfy_core/latent/inpaint/vae_encode_for_inpainting.jpg?fit=max&auto=format&n=Rig0_LOInmwVbVSB&q=85&s=2eeecee7cf23a0e1ab7b1a996256278f" alt="VAE Encoder (for Inpainting) 节点" width="854" height="440" data-path="images/comfy_core/latent/inpaint/vae_encode_for_inpainting.jpg" />

**输入类型**

| 参数名称           | 作用                                                     |
| -------------- | ------------------------------------------------------ |
| `pixels`       | 需要编码到潜空间的输入图像。                                         |
| `vae`          | 用于将图片从像素空间编码到潜在空间的 VAE 模型。                             |
| `mask`         | 图片遮罩，用来具体指明哪个区域需要进行修改。                                 |
| `grow_mask_by` | 在原有的遮罩基础上，向外扩展的像素值，保证在遮罩区域外围有一定的过度区域，避免重绘区域与原图存在生硬的过渡。 |

**输出类型**

| 参数名称     | 作用                |
| -------- | ----------------- |
| `latent` | 经过 VAE 编码后的潜空间图像。 |
