> ## Documentation Index
> Fetch the complete documentation index at: https://docs.comfy.org/llms.txt
> Use this file to discover all available pages before exploring further.

# ComfyUI 帧插值工作流

> 学习如何在 ComfyUI 视频工作流中使用帧插值来平滑运动和提高帧率

## 什么是帧插值？

<Note>
  此工作流包含自定义节点。在运行工作流之前，你需要使用 [ComfyUI 管理器](/zh/manager/overview) 安装这些自定义节点。
</Note>

帧插值在现有帧之间生成中间帧，从而实现更平滑的运动和改进的时间一致性。这种技术对于视频后处理至关重要，可以显著提高生成视频的质量。

## 使用场景

帧插值支持：

* **提高短片的帧率** - 将低帧率视频转换为更高帧率
* **平滑生成或编辑视频中的运动** - 减少卡顿和阶梯状伪影
* **为下游视频模型准备序列** - 标准化帧率以实现一致处理
* **修复低帧率生成** - 许多视频生成工作流默认为 16fps，这可能会引入明显的卡顿

## 为什么帧插值很重要

许多图像和视频生成工作流仍然默认为 16fps，这可能会引入明显的卡顿、阶梯效应和不均匀的运动——尤其是在相机移动和角色动画中。

帧插值是一种有效的方法，可以在不重新生成源帧的情况下平滑这些伪影，使运动感觉更自然，同时保留原始构图和时序。

帧插值不仅可以作为最终后处理步骤，还可以用作预处理步骤——允许你尽早标准化帧率，并将更干净的时间数据输入到更大的动画和视频管道中。

<Card title="在 Comfy Cloud 中试用" icon="cloud" href="https://cloud.comfy.org/?template=utility-frame_interpolation-film.json&utm_source=docs&utm_medium=inhouse_social&utm_campaign=inhouse_feature_launches&utm_content=post&utm_niche=workflow_engineering&utm_creator=purz">
  在 Comfy Cloud 上运行
</Card>

<Card title="下载 JSON" icon="download" href="https://github.com/Comfy-Org/workflow_templates/blob/main/templates/utility-frame_interpolation-film.json">
  下载工作流文件
</Card>
