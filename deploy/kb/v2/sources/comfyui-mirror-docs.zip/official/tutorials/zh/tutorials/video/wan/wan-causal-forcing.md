> ## Documentation Index
> Fetch the complete documentation index at: https://docs.comfy.org/llms.txt
> Use this file to discover all available pages before exploring further.

# Causal Forcing 图生视频 ComfyUI 工作流示例

> 使用 Wan2.1 的 Causal Forcing 或 Causal Forcing++ 从图片生成视频——只需 1 步推理即可获得流畅、时序一致的视频。

**Causal Forcing（因果强制）** 是一种视频生成技术，在推理过程中应用 **循环条件控制**：每一帧生成后都会作为输入反馈给模型，用于预测下一帧。通过这种方式，仅需 **1 到 4 步推理**，就能从单张起始图片生成流畅、时序一致的视频。

此工作流基于 **Wan2.1**，支持 **Causal Forcing**（标准）和 **Causal Forcing++**（增强）两种模式。

<img src="https://raw.githubusercontent.com/Comfy-Org/workflow_templates/main/templates/video_causal_forcing_i2v-1.webp" alt="Causal Forcing 图生视频工作流" />

<Tip>
  <Tabs>
    <Tab title="便携版或手动安装用户">
      请确保你的 ComfyUI 已经更新。

      * [ComfyUI 下载](https://www.comfy.org/download)
      * [ComfyUI 更新教程](/zh/installation/update_comfyui)

      本指南里的工作流可以在 ComfyUI 的[工作流模板](/zh/interface/features/template)中找到。如果找不到，可能是 ComfyUI 没有更新。

      如果加载工作流时有节点缺失，可能原因有：

      1. 你用的不是最新开发版（nightly）。
      2. 你用的是稳定版或桌面版（没有包含最新的更新）。
      3. 启动时有些节点导入失败。
    </Tab>

    <Tab title="桌面版或云端用户">
      * 桌面版是基于 ComfyUI 稳定版本构建的，它会在有新的桌面稳定版本发布时自动更新。
      * [Cloud](https://cloud.comfy.org) 会在 ComfyUI 稳定版本发布后更新，我们会同步更新 Cloud。

      所以，如果你发现本教程中有任何核心节点缺失，那是因为对应的节点支持还在开发中没有发布正式的稳定版，请等待下一个稳定版本发布。
    </Tab>
  </Tabs>
</Tip>

<CardGroup cols={1}>
  <Card title="下载工作流" icon="download" href="https://github.com/Comfy-Org/workflow_templates/blob/main/templates/video_causal_forcing_i2v.json">
    下载 JSON 或在模板库中搜索 "Causal Forcing"
  </Card>
</CardGroup>

## 工作原理

与标准视频生成（并行处理所有帧）不同，Causal Forcing 将视频生成视为一个 **顺序过程**：

1. 模型将输入图像作为 **首帧**
2. 基于前一帧生成下一帧
3. 每生成一帧都作为下一帧的输入
4. 重复此过程直到生成目标帧数

这种循环方法带来了 **很强的时序一致性**——每帧自然地承接前一帧——并且仅需很少的推理步数（1 到 4 步）即可生成高质量结果。

<Card title="了解子图" icon="book-open" href="/zh/interface/features/subgraph">
  本工作流使用子图节点进行模块化处理。查看子图文档了解如何自定义和扩展工作流。
</Card>

### Causal Forcing 与 Causal Forcing++

| 模式                   | 说明                                     |
| -------------------- | -------------------------------------- |
| **Causal Forcing**   | 标准循环条件控制。2–4 步即可获得良好质量。                |
| **Causal Forcing++** | 增强模式，应用额外条件控制以获得更好的时序连贯性。仅需 1–2 步即可工作。 |

## 使用工作流

### 输入

工作流接受一张输入图片（首帧）和一个描述视频内容的文本提示（可选）。

| 设置                       | 说明                                     |
| ------------------------ | -------------------------------------- |
| **first\_frame**（必填）     | 视频的起始图像。通过 **LoadImage** 节点加载 PNG/JPG。 |
| **positive\_prompt**（可选） | 对期望视频内容的文字描述。留空则无文本条件控制。               |
| **duration**（可选）         | 生成帧数。默认为模型期望输出的帧数。                     |

### WAN I2V 子图参数

这些参数直接暴露在蓝图子图节点上：

| 参数           | 默认值 | 说明                    |
| ------------ | --- | --------------------- |
| `unet_name`  | —   | 使用的 Wan2.1 I2V 模型检查点  |
| `clip_name`  | —   | 用于提示词的 CLIP / 文本编码器模型 |
| `vae_name`   | —   | 用于编码/解码的 VAE 模型       |
| `width`      | —   | 输出视频宽度                |
| `height`     | —   | 输出视频高度                |
| `noise_seed` | —   | 可复现结果的随机种子            |

## 运行步骤

1. **加载图片** — 使用 **LoadImage** 节点加载起始帧
2. **编写提示词**（可选）— 描述期望的视频内容
3. **设置帧数** — 生成多少帧
4. **选择模型** — 选择 Wan2.1 I2V 检查点、CLIP 和 VAE
5. **选择模式** — Causal Forcing 或 Causal Forcing++
6. **运行** — 帧将按顺序生成并保存到 `ComfyUI/output/`

## 模型下载

下载 Wan2.1 I2V 模型及所需文件。放入对应的 `models/` 子目录。

### Wan2.1 I2V

<CardGroup cols={2}>
  <Card title="Wan2.1 I2V 14B" icon="download" href="https://huggingface.co/Comfy-Org/Wan_2.1_ComfyUI_repackaged/resolve/main/split_files/diffusion_models/wan2.1_i2v_480p_14B_fp16.safetensors?download=true">
    wan2.1\_i2v\_480p\_14B\_fp16.safetensors — Wan2.1 I2V 14B 检查点
  </Card>

  <Card title="Wan2.1 I2V 1.3B" icon="download" href="https://huggingface.co/Comfy-Org/Wan_2.1_ComfyUI_repackaged/resolve/main/split_files/diffusion_models/wan2.1_t2v_1.3B_fp16.safetensors?download=true">
    wan2.1\_t2v\_1.3B\_fp16.safetensors — Wan2.1 1.3B 检查点（最低 8GB 显存）
  </Card>
</CardGroup>

### CLIP 和 VAE

<CardGroup cols={2}>
  <Card title="CLIP (google-bert)" icon="download" href="https://huggingface.co/google-bert/bert-base-uncased/resolve/main/model.safetensors">
    google-bert/bert-base-uncased — CLIP 文本编码器
  </Card>

  <Card title="VAE (Wan2.1)" icon="download" href="https://huggingface.co/Comfy-Org/Wan_2.1_ComfyUI_repackaged/resolve/main/split_files/vae/Wan2.1_VAE_bf16.safetensors?download=true">
    Wan2.1\_VAE\_bf16.safetensors — Wan2.1 VAE
  </Card>
</CardGroup>

### 模型存放位置

```
📂 ComfyUI/
├── 📂 models/
│   ├── 📂 diffusion_models/
│   │      └── wan2.1_i2v_480p_14B_fp16.safetensors（或 1.3B 版本）
│   ├── 📂 text_encoders/
│   │      └── bert-base-uncased（文件夹，内含 model.safetensors）
│   └── 📂 vae/
│          └── Wan2.1_VAE_bf16.safetensors
```
