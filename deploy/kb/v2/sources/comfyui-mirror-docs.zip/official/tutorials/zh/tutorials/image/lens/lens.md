> ## Documentation Index
> Fetch the complete documentation index at: https://docs.comfy.org/llms.txt
> Use this file to discover all available pages before exploring further.

# Lens ComfyUI 工作流示例

> Lens 是微软开源的一个 3.8B 参数文生图模型，采用双流 MMDiT 架构，结合 GPT-OSS-20B 文本特征和 FLUX.2 VAE，实现高效高分辨率图像生成。

**Lens** 是 **微软** 开源的文生图模型，采用 MIT 许可证。拥有 **38亿** 参数，采用 **双流 MMDiT** 架构，配合 **GPT-OSS-20B** 文本编码器特征和 **FLUX.2 语义 VAE**，以远少于大模型的训练算力实现了具有竞争力的图像质量。

**模型亮点**：

* **双流 MMDiT 架构** — 图像和文本联合处理，生成更连贯
* **GPT-OSS-20B 多层文本特征** — 强大的文本理解能力，精准遵循提示
* **FLUX.2 语义 VAE** — 高保真潜在空间表示
* **混合分辨率训练** — 支持多种宽高比，无需裁切
* **38亿参数紧凑模型** — 在 24 GB 显存的消费级 GPU 上即可运行

**相关链接**：

* [论文 (arXiv)](https://arxiv.org/abs/2605.21573)
* [GitHub](https://github.com/microsoft/Lens)
* [Hugging Face (微软)](https://huggingface.co/microsoft/Lens)
* [Hugging Face (Comfy-Org)](https://huggingface.co/Comfy-Org/Lens)

## Lens 文生图工作流

标准版和 Turbo 版均使用 **Subgraph** 节点管理文生图流程。你可以打开子图查看或自定义内部节点。

<Card title="了解 Subgraph" icon="book-open" href="/zh/interface/features/subgraph">
  本工作流使用 Subgraph 节点实现模块化处理。查看 Subgraph 文档了解如何自定义和扩展工作流。
</Card>

### Lens

<CardGroup cols={2}>
  <Card title="下载工作流" icon="download" href="https://github.com/Comfy-Org/workflow_templates/blob/main/templates/image_lens_t2i.json">
    下载 JSON 或在模板库中搜索 "Lens"
  </Card>

  {/*<Card title="在 Comfy Cloud 运行" icon="cloud" href="https://cloud.comfy.org/?template=image_lens_t2i&utm_source=docs&utm_medium=referral&utm_campaign=lens">*/}

  {/*</Card>*/}
</CardGroup>

<Tip>
  <Tabs>
    <Tab title="便携版或手动安装用户">
      请确保你的 ComfyUI 已经更新。

      * [ComfyUI 下载](https://www.comfy.org/download)
      * [ComfyUI 更新教程](/zh/installation/update_comfyui)

      本指南里的工作流可以在 ComfyUI 的[工作流模板](/zh/interface/features/template)中找到。如果找不到，可能是 ComfyUI 没有更新。

      如果加载工作流时有节点缺失，可能原因有：

      1. 你用的不是最新开发版（nightly）。
      2. 你用的是稳定版或桌面版（没有包含最新的更新）。
      3. 启动时有些节点导入失败。
    </Tab>

    <Tab title="桌面版或云端用户">
      * 桌面版是基于 ComfyUI 稳定版本构建的，它会在有新的桌面稳定版本发布时自动更新。
      * [Cloud](https://cloud.comfy.org) 会在 ComfyUI 稳定版本发布后更新，我们会同步更新 Cloud。

      所以，如果你发现本教程中有任何核心节点缺失，那是因为对应的节点支持还在开发中没有发布正式的稳定版，请等待下一个稳定版本发布。
    </Tab>
  </Tabs>
</Tip>

#### 开始使用

1. 更新 ComfyUI 到最新版本
2. 进入 **模板** 搜索 **Lens**
3. 选择 **Lens** 工作流
4. 下载缺失的模型（见 [模型下载](#模型下载)），输入提示词，点击 **队列运行**

#### 示例输出

<img src="https://raw.githubusercontent.com/Comfy-Org/workflow_templates/main/output/image_lens_t2i.png" alt="Lens 文生图示例输出" />

### Lens Turbo

Lens Turbo 是蒸馏版，只需较少的采样步数即可生成图像，推理速度更快。

<CardGroup cols={2}>
  <Card title="下载工作流" icon="download" href="https://github.com/Comfy-Org/workflow_templates/blob/main/templates/image_lens_turbo_t2i.json">
    下载 JSON 或在模板库中搜索 "Lens Turbo"
  </Card>

  {/*<Card title="在 Comfy Cloud 运行" icon="cloud" href="https://cloud.comfy.org/?template=image_lens_turbo_t2i&utm_source=docs&utm_medium=referral&utm_campaign=lens">*/}

  {/*</Card>*/}
</CardGroup>

#### 开始使用

1. 更新 ComfyUI 到最新版本
2. 进入 **模板** 搜索 **Lens Turbo**
3. 选择 **Lens Turbo** 工作流
4. 下载缺失的模型（见 [模型下载](#模型下载)），输入提示词，点击 **队列运行**

#### 示例输出

<img src="https://raw.githubusercontent.com/Comfy-Org/workflow_templates/main/output/image_lens_turbo_t2i.png" alt="Lens Turbo 文生图示例输出" />

## 模型下载

所有模型文件可在 Hugging Face 上的 [Comfy-Org/Lens](https://huggingface.co/Comfy-Org/Lens) 找到。

<CardGroup cols={2}>
  <Card title="lens_bf16.safetensors" icon="download" href="https://huggingface.co/Comfy-Org/Lens/resolve/main/diffusion_models/lens_bf16.safetensors">
    Lens 扩散模型 (BF16)
  </Card>

  <Card title="lens_turbo_bf16.safetensors" icon="download" href="https://huggingface.co/Comfy-Org/Lens/resolve/main/diffusion_models/lens_turbo_bf16.safetensors">
    Lens Turbo 扩散模型 (BF16)
  </Card>
</CardGroup>

<CardGroup cols={2}>
  <Card title="gpt_oss_20b_nvfp4.safetensors" icon="download" href="https://huggingface.co/Comfy-Org/Lens/resolve/main/text_encoders/gpt_oss_20b_nvfp4.safetensors">
    Lens 和 Lens Turbo 共用的文本编码器 (GPT-OSS-20B)
  </Card>

  <Card title="flux2-vae.safetensors" icon="download" href="https://huggingface.co/Comfy-Org/Lens/resolve/main/vae/flux2-vae.safetensors">
    Lens 和 Lens Turbo 共用的 VAE (FLUX.2)
  </Card>
</CardGroup>

**模型存放路径**

```
📂 ComfyUI/
├── 📂 models/
│   ├── 📂 diffusion_models/
│   │   ├── lens_bf16.safetensors（或 lens_mxfp8.safetensors）
│   │   └── lens_turbo_bf16.safetensors（或 lens_turbo_mxfp8.safetensors）
│   ├── 📂 text_encoders/
│   │   └── gpt_oss_20b_nvfp4.safetensors
│   └── 📂 vae/
│       └── flux2-vae.safetensors
```

## 可用模型

| 模型         | 描述                     | 推理步数 | 链接                                                    |
| ---------- | ---------------------- | ---- | ----------------------------------------------------- |
| Lens       | 标准 3.8B 模型 — 更高质量，更多步数 | \~50 | [Hugging Face](https://huggingface.co/microsoft/Lens) |
| Lens Turbo | 蒸馏版 — 更少步数，更快生成        | \~8  | [Hugging Face](https://huggingface.co/microsoft/Lens) |
