> ## Documentation Index
> Fetch the complete documentation index at: https://docs.comfy.org/llms.txt
> Use this file to discover all available pages before exploring further.

# ComfyUI 图像放大

> 学习如何在 ComfyUI 中使用本地模型和合作伙伴节点进行图像放大

本指南介绍 ComfyUI 中的图像放大工作流，包括本地模型和合作伙伴节点选项，适用于各种使用场景。

<Card title="AI 放大完全手册" icon="book-open" href="https://blog.comfy.org/p/upscaling-in-comfyui">
  如需更全面的深入分析、基准测试和视觉对比，请阅读 ComfyUI 博客上的完整文章。
</Card>

## 为什么需要图像放大

* **行业对分辨率的要求**：4K/8K 最终成品在影视特效、营销、电商、游戏和设计行业中被广泛要求，且标准还在不断提高。
* **重新构图**：当素材需要适配不同的宽高比和位置时，额外的分辨率余量可以防止裁剪或重新构图后的质量损失。
* **AI 内容的问题**：生成式 AI 大幅提升了视觉创作的速度，但目前大多数 AI 素材仍然以 480-720p 生成，在像素级别上还未达到生产标准：边缘、微纹理、面部/手部、压缩伪影等。这催生了新的工作流程：生成 → 修复/优化 → 放大 → 交付。
* **成本/时间优化**：先生成或渲染较小尺寸 → 最后再放大。这是预算/时间紧张的工作流程中的标准效率策略。

## 核心概念

### 放大 vs. 增强

* **放大（Upscaling）**：在重建细节的同时提高分辨率。
* **增强（Enhancement）**：改善感知质量（降噪、锐化、修复、色彩、面部等）。

AI 工作流的最佳实践通常是将两个步骤结合使用。

### 创意放大 vs. 保守放大

扩散模型和生成式 AI 改变了"放大"的含义。传统上，超分辨率旨在**保留原始信号**。如今，一些模型可以**重新想象从未存在过的细节**。不同的模型在两者之间取得不同的平衡。

|        | 保守放大                                                | 创意放大                                                  |
| ------ | --------------------------------------------------- | ----------------------------------------------------- |
| **方式** | 保留原始内容                                              | 重新想象并增强                                               |
| **优势** | 高精度、一致性、适合生产环境                                      | 细节丰富、更锐利、视觉效果更突出                                      |
| **局限** | 可能显得平淡，对低质量输入改善有限                                   | 可能产生幻觉或结构偏移                                           |
| **模型** | Magnific Precise、SeedVR2、FlashVSR、Topaz Fast、HitPaw | Wan 2.2、Magnific Creative、Topaz Astra、HitPaw Creative |

## 使用场景

<Note>
  **总结**

  * **人像**：Magnific Skin Enhancer
  * **产品摄影**：Magnific Precise、WaveSpeed SeedVR2 或 Nano Banana Pro
  * **风景和插画**：模型选择取决于你的具体需求
  * **AI 伪影**：不要依赖放大来修复常见的 AI 伪影
  * **SeedVR2 技巧**：放大前先使用 `ImageScaleToTotalPixels` 节点将图像缩小到 0.35 百万像素，效果更好
</Note>

### 人像和皮肤增强

在放大真实人物的肖像时，实现逼真的皮肤细节同时保持角色一致性是关键。最好的放大模型需要能够添加纹理、毛孔和自然的皮肤瑕疵来修复塑料感的皮肤。在这个领域，Magnific Image Skin Enhancer 远超其他模型。

**推荐**：Magnific Image Skin Enhancer

<Card title="Magnific 皮肤增强" icon="cloud" href="https://links.comfy.org/4cbvbE7">
  在 Comfy Cloud 上试用或下载工作流
</Card>

### 产品摄影

在放大产品图像时，必须保持材质、产品标签边缘和小文字的忠实呈现。因此需要使用保守型放大模型。

**推荐**：HitPaw、Magnific Precise、WaveSpeed SeedVR2、Nano Banana Pro

<Card title="HitPaw" icon="cloud" href="https://links.comfy.org/4kkoula">
  在 Comfy Cloud 上试用或下载工作流
</Card>

<Card title="Nano Banana Pro 产品" icon="cloud" href="https://links.comfy.org/4qUntD0">
  在 Comfy Cloud 上试用或下载工作流
</Card>

<Card title="SeedVR2（开源）" icon="cloud" href="https://links.comfy.org/4ko2sOG">
  在 Comfy Cloud 上试用或下载工作流
</Card>

### 风景和环境

对于这个使用场景，选择哪个放大模型取决于你的需求。想让环境照片细节丰富并营造氛围？使用创意型放大模型。有一个需要保持建筑一致性的场景？使用保守型放大模型。

值得注意的是，如果你的输入图像有伪影，创意型放大模型可能能够重新想象这些伪影，而保守型放大模型则不会。

<Card title="Topaz 风景" icon="cloud" href="https://links.comfy.org/4r1utxS">
  在 Comfy Cloud 上试用或下载工作流
</Card>

<Card title="Recraft 创意" icon="cloud" href="https://links.comfy.org/4afKfOJ">
  在 Comfy Cloud 上试用或下载工作流
</Card>

<Card title="Recraft 清晰" icon="cloud" href="https://links.comfy.org/3O0M4Yf">
  在 Comfy Cloud 上试用或下载工作流
</Card>

### 风格化艺术/插画

这是另一个正确的放大模型取决于你需求的使用场景。经验法则是，如果你的输入有非常独特的风格，最好的模型是保守型的。创意型模型可能会添加过多细节，偏离所需的插画风格。然而，如果你的输入图像有细节提升的空间，创意型模型效果很好，甚至可以改善风格。

我们建议尝试调整 Magnific Creative 和 Topaz Image Enhance 的"创意度"参数来找到满足你需求的值！Nano Banana Pro 对于更常见的风格和添加细节也很有效（但可能依赖"种子运气"）。

**推荐**：Magnific Creative、Topaz Image Enhance、Nano Banana Pro

<Card title="Topaz 插画" icon="cloud" href="https://links.comfy.org/46zi8c1">
  在 Comfy Cloud 上试用或下载工作流
</Card>

<Card title="Topaz 创意" icon="cloud" href="https://links.comfy.org/4kjT12P">
  在 Comfy Cloud 上试用或下载工作流
</Card>

<Card title="Nano Banana Pro 风格化艺术" icon="cloud" href="https://links.comfy.org/3O0Maiz">
  在 Comfy Cloud 上试用或下载工作流
</Card>

<Card title="Nano Banana Pro 人像" icon="cloud" href="https://links.comfy.org/3O9XtF7">
  在 Comfy Cloud 上试用或下载工作流
</Card>

### AI 生成图像

当放大具有典型 AI 问题（如多余的手指、伪影、不正确的解剖结构和变形）的图像时，人们通常假设创意放大可以修复这些问题。有时确实如此，但很多时候并非如此。最佳做法是在放大之前使用图像编辑模型或传统工具解决这些问题（或重新生成图像）。

## 可用模型

### 本地模型（ESRGAN）

有关使用 ESRGAN 模型进行基础本地放大，请参阅[基础放大教程](/zh/tutorials/basic/upscale)。

| 模型         | 最适合     |
| ---------- | ------- |
| RealESRGAN | 通用放大    |
| BSRGAN     | 文字和锐利边缘 |
| SwinIR     | 自然纹理、风景 |

<Card title="传统非 AI 放大" icon="cloud" href="https://links.comfy.org/45Nu9um">
  在 Comfy Cloud 上试用或下载工作流
</Card>

### 通用创意放大

适用于各种使用场景的通用创意放大：

<Card title="HitPaw 创意" icon="cloud" href="https://links.comfy.org/4kkoula">
  在 Comfy Cloud 上试用或下载工作流
</Card>

<Card title="Recraft 创意" icon="cloud" href="https://links.comfy.org/4afKfOJ">
  在 Comfy Cloud 上试用或下载工作流
</Card>

<Card title="Recraft 清晰" icon="cloud" href="https://links.comfy.org/3O0M4Yf">
  在 Comfy Cloud 上试用或下载工作流
</Card>

### 合作伙伴节点

合作伙伴节点通过 API 提供高级放大模型访问。

| 模型                          | 类型 | 特性                   |
| --------------------------- | -- | -------------------- |
| Topaz Image Enhance (Bloom) | 创意 | 主体检测、面部增强、色彩保留，最高 8K |
| Magnific Precise            | 保守 | 高精度、适合生产环境           |
| Magnific Creative           | 创意 | 细节重新想象               |
| Magnific Skin Enhancer      | 创意 | 人像专用，添加逼真皮肤纹理        |
| Nano Banana Pro             | 保守 | 快速，适合产品摄影            |
| WaveSpeed SeedVR2           | 保守 | 高保真度                 |
| HitPaw                      | 两者 | 保守和创意模式              |
| Recraft                     | 两者 | 创意和清晰模式              |

## 基准测试：1K 到 4K 放大时间

| 模型                     | 时间     |
| ---------------------- | ------ |
| Magnific Precise       | \~40秒  |
| WaveSpeed SeedVR2      | \~40秒  |
| Magnific Creative      | \~50秒  |
| Magnific Skin Enhancer | \~60秒  |
| HitPaw                 | \~60秒  |
| Nano Banana Pro        | \~80秒  |
| Topaz Image Enhance    | \~100秒 |

## 技巧

* 对于 SeedVR2，在放大之前使用 `ImageScaleToTotalPixels` 节点将图像缩小到 0.35 百万像素可获得更好的效果。
* 链接多个放大节点（例如 2x → 4x）以实现超高倍率放大。
* 在生成后连接放大节点，实现"生成 + 增强"工作流。
* 在特定图像类型上测试多个模型以找到最佳匹配。
