> ## Documentation Index
> Fetch the complete documentation index at: https://docs.comfy.org/llms.txt
> Use this file to discover all available pages before exploring further.

# Anima Base v1 ComfyUI 工作流示例

> Anima 是 CircleStone Labs / Comfy Org 推出的 2B 参数文生图模型，针对动漫和非照片级插画生成进行了优化。

**Anima** 是由 [CircleStone Labs](https://huggingface.co/circlestone-labs/Anima) 与 Comfy Org 合作推出的开源文生图模型。该模型拥有 **20 亿** 参数，专注于生成高质量的 **动漫和非照片级** 图像——非常适合角色设计、场景绘制和概念艺术。

**模型亮点**：

* **专注于动漫和艺术插画** — 针对非照片级艺术风格进行了调优
* **ComfyUI 原生支持** — 使用标准的 UNETLoader、CLIPLoader 和 VAELoader 节点加载
* **Qwen-3 0.6B 文本编码器**（text encoder）— 提供强大的语言理解和提示词遵循能力
* **无需输入图像** — 纯文生图生成
* **紧凑轻量** — 2B 扩散模型（diffusion model），在消费级 GPU 上即可流畅运行

**相关链接**：

* [Hugging Face（Anima）](https://huggingface.co/circlestone-labs/Anima)

## 可用工作流

Anima 提供两个工作流——基础版适用于标准使用，预览版适用于早期体验。

两个工作流均使用 **子图**（Subgraph）节点来管理文生图生成管线。您可以打开子图查看或自定义内部节点。

<Card title="了解 Subgraph" icon="book-open" href="/zh/interface/features/subgraph">
  此工作流使用 Subgraph 节点实现模块化处理。查阅 Subgraph 文档了解如何自定义和扩展工作流。
</Card>

### Anima Base v1：文生图

<Card title="下载工作流" icon="download" href="https://github.com/Comfy-Org/workflow_templates/blob/main/templates/image_anima_base_v1.json">
  下载 JSON 或在模板库中搜索 "Anima Base v1"
</Card>

<Card title="在 Comfy Cloud 上运行" icon="cloud" href="https://cloud.comfy.org/?template=image_anima_base_v1&utm_source=docs&utm_medium=referral&utm_campaign=anima">
  在 Comfy Cloud 中打开
</Card>

#### 快速开始

1. 将 ComfyUI 更新至最新版本，或使用 [Comfy Cloud](https://cloud.comfy.org/?template=image_anima_base_v1\&utm_source=docs\&utm_medium=referral\&utm_campaign=anima)
2. 前往 **模板**，搜索 **Anima Base v1**
3. 选择 **Anima Base v1: Text to Image** 工作流
4. 下载缺失的模型（参见[模型下载](#anima-模型下载)），输入提示词后点击 **运行**

#### 示例输出

<img src="https://raw.githubusercontent.com/Comfy-Org/workflow_templates/main/output/image_anima_base_v1.png" alt="Anima Base v1 示例输出" />

### Anima Preview：动漫文生图

<Card title="下载工作流" icon="download" href="https://github.com/Comfy-Org/workflow_templates/blob/main/templates/image_anima_preview.json">
  下载 JSON 或在模板库中搜索 "Anima Preview"
</Card>

<Card title="在 Comfy Cloud 上运行" icon="cloud" href="https://cloud.comfy.org/?template=image_anima_preview&utm_source=docs&utm_medium=referral&utm_campaign=anima">
  在 Comfy Cloud 中打开
</Card>

#### 快速开始

1. 将 ComfyUI 更新至最新版本，或使用 [Comfy Cloud](https://cloud.comfy.org/?template=image_anima_preview\&utm_source=docs\&utm_medium=referral\&utm_campaign=anima)
2. 前往 **模板**，搜索 **Anima Preview**
3. 选择 **Anima Anime Text-to-Image Generation** 工作流
4. 下载缺失的模型（参见[模型下载](#anima-模型下载)），输入提示词后点击 **运行**

#### 示例输出

<img src="https://raw.githubusercontent.com/Comfy-Org/workflow_templates/main/output/image_anima_preview.png" alt="Anima Preview 示例输出" />

## Anima 模型下载

所有模型文件均可从 Hugging Face 的 [circlestone-labs/Anima](https://huggingface.co/circlestone-labs/Anima) 获取。

<Card title="anima-base-v1.0.safetensors" icon="download" href="https://huggingface.co/circlestone-labs/Anima/resolve/main/split_files/diffusion_models/anima-base-v1.0.safetensors">
  Anima Base v1 扩散模型（2B）。
</Card>

<Card title="qwen_3_06b_base.safetensors" icon="download" href="https://huggingface.co/circlestone-labs/Anima/resolve/main/split_files/text_encoders/qwen_3_06b_base.safetensors">
  两个工作流共用的文本编码器（Qwen-3 0.6B）。
</Card>

<Card title="qwen_image_vae.safetensors" icon="download" href="https://huggingface.co/circlestone-labs/Anima/resolve/main/split_files/vae/qwen_image_vae.safetensors">
  两个工作流共用的 VAE。
</Card>

**模型存储位置**

```
📂 ComfyUI/
├── 📂 models/
│   ├── 📂 diffusion_models/
│   │   └── anima-base-v1.0.safetensors
│   ├── 📂 text_encoders/
│   │   └── qwen_3_06b_base.safetensors
│   └── 📂 vae/
│       └── qwen_image_vae.safetensors
```

### 预览版模型

如果您使用 Preview 工作流，请下载以下预览版扩散模型：

<Card title="anima-preview3-base.safetensors" icon="download" href="https://huggingface.co/circlestone-labs/Anima/resolve/main/split_files/diffusion_models/anima-preview3-base.safetensors">
  Anima Preview 扩散模型（2B）。
</Card>

**预览版模型存储位置**

```
📂 ComfyUI/
├── 📂 models/
│   └── 📂 diffusion_models/
│       └── anima-preview3-base.safetensors
```

## 局限性

* **不适合写实风格** — 该模型专门为动漫和插画风格设计，写实渲染超出其设计范围
* **文字渲染较弱** — 高分辨率文字和复杂排版的渲染效果可能不理想
* **构图偏简洁** — 基础版模型生成的构图较简单，高级艺术风格可能需要微调或进一步优化
