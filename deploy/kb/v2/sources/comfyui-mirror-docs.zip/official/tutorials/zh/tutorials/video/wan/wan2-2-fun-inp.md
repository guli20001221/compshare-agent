> ## Documentation Index
> Fetch the complete documentation index at: https://docs.comfy.org/llms.txt
> Use this file to discover all available pages before exploring further.

# ComfyUI Wan2.2 Fun Inp 首尾帧视频生成示例

> 本文介绍了如何在 ComfyUI 中完成 Wan2.2 Fun Inp 首尾帧视频生成示例

**Wan2.2-Fun-Inp** 是 Alibaba pai团队推出的首尾帧控制视频生成模型，支持输入**首帧和尾帧图像**，生成中间过渡视频，为创作者带来更强的创意控制力。该模型采用 **Apache 2.0 许可协议**发布，支持商业使用。

**核心功能**：

* **首尾帧控制**：支持输入首帧和尾帧图像，生成中间过渡视频，提升视频连贯性与创意自由度
* **高质量视频生成**：基于 Wan2.2 架构，输出影视级质量视频
* **多分辨率支持**：支持生成512×512、768×768、1024×1024等分辨率的视频，适配不同场景需求

**模型版本**：

* **14B 高性能版**：模型体积达 32GB+，效果更优但需高显存支持

下面是相关模型权重和代码仓库：

* [🤗Wan2.2-Fun-Inp-14B](https://huggingface.co/alibaba-pai/Wan2.2-Fun-A14B-InP)
* 代码仓库：[VideoX-Fun](https://github.com/aigc-apps/VideoX-Fun)

## ComfyOrg Wan2.2 Fun InP & Control Youtube 直播回放

<iframe className="w-full aspect-video rounded-xl" src="https://www.youtube.com/embed/YcAerNYIvho?si=Zh8tzRwI_OTAFx3m" title="ComfyUI Selection Toolbox New Features" allow="accelerometer; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowFullScreen />

## Wan2.2 Fun Inp 首尾帧视频生成工作流示例

<Tip>
  <Tabs>
    <Tab title="便携版或手动安装用户">
      请确保你的 ComfyUI 已经更新。

      * [ComfyUI 下载](https://www.comfy.org/download)
      * [ComfyUI 更新教程](/zh/installation/update_comfyui)

      本指南里的工作流可以在 ComfyUI 的[工作流模板](/zh/interface/features/template)中找到。如果找不到，可能是 ComfyUI 没有更新。

      如果加载工作流时有节点缺失，可能原因有：

      1. 你用的不是最新开发版（nightly）。
      2. 你用的是稳定版或桌面版（没有包含最新的更新）。
      3. 启动时有些节点导入失败。
    </Tab>

    <Tab title="桌面版或云端用户">
      * 桌面版是基于 ComfyUI 稳定版本构建的，它会在有新的桌面稳定版本发布时自动更新。
      * [Cloud](https://cloud.comfy.org) 会在 ComfyUI 稳定版本发布后更新，我们会同步更新 Cloud。

      所以，如果你发现本教程中有任何核心节点缺失，那是因为对应的节点支持还在开发中没有发布正式的稳定版，请等待下一个稳定版本发布。
    </Tab>
  </Tabs>
</Tip>

这里提供的工作流包含了两个版本：

1. 使用了 lightx2v 的 [Wan2.2-Lightning](https://huggingface.co/lightx2v/Wan2.2-Lightning) 4 步 LoRA : 但可能导致生成的视频动态会有损失，但速度会更快
2. 没有使用加速 LoRA 的 fp8\_scaled 版本

下面是使用 RTX4090D 24GB 显存 GPU 测试的结果 640\*640 分辨率， 81 帧长度的用时对比

| 模型类型                   | 显存占用 | 首次生成时长 | 第二次生成时长 |
| ---------------------- | ---- | ------ | ------- |
| fp8\_scaled            | 83%  | ≈ 524秒 | ≈ 520秒  |
| fp8\_scaled + 4步LoRA加速 | 89%  | ≈ 138秒 | ≈ 79秒   |

由于使用了加速 LoRA 后提速较为明显，虽然动态有所损失，但对低显存用户较为友好，所以在提供的两组工作流中，我们默认启用了使用了加速 LoRA 版本，如果你需要启用另一组的工作流，框选后使用 **Ctrl+B** 即可启用

### 1. 工作流文件下载

请更新你的 ComfyUI 至最新版本，通过菜单 `工作流` -> `浏览模板` -> `视频` 找到 "**Wan2.2 Fun Inp**" 来加载工作流。

或者，在更新 ComfyUI 至最新版本后，下载下面的工作流并拖入 ComfyUI 中加载。

<a className="prose" target="_blank" href="https://raw.githubusercontent.com/Comfy-Org/workflow_templates/refs/heads/main/templates/video_wan2_2_14B_fun_inpaint.json" style={{ display: 'inline-block', backgroundColor: '#0078D6', color: '#ffffff', padding: '10px 20px', borderRadius: '8px', borderColor: "transparent", textDecoration: 'none', fontWeight: 'bold'}}>
  <p className="prose" style={{ margin: 0, fontSize: "0.8rem" }}>下载 JSON 格式工作流</p>
</a>

<a className="prose" target="_blank" href="https://cloud.comfy.org/?template=video_wan2_2_14B_fun_inpaint&utm_source=docs" style={{ display: 'inline-block', backgroundColor: '#28A745', color: '#FFFFFF', padding: '10px 20px', borderRadius: '8px', borderColor: "transparent", textDecoration: 'none', fontWeight: 'bold'}}>
  <p className="prose" style={{ margin: 0, fontSize: "0.8rem" }}>在 Comfy 云上运行</p>
</a>

使用下面的素材作为首尾帧

![Wan2.2 Fun Control ComfyUI 工作流起始帧素材](https://raw.githubusercontent.com/Comfy-Org/example_workflows/refs/heads/main/video/wan/wan2.2_fun_inp/start_image.png)
![Wan2.2 Fun Control ComfyUI 工作流结束帧素材](https://raw.githubusercontent.com/Comfy-Org/example_workflows/refs/heads/main/video/wan/wan2.2_fun_inp/end_image.png)

### 2. 手动下载模型

**Diffusion Model**

* [wan2.2\_fun\_inpaint\_high\_noise\_14B\_fp8\_scaled.safetensors](https://huggingface.co/Comfy-Org/Wan_2.2_ComfyUI_Repackaged/resolve/main/split_files/diffusion_models/wan2.2_fun_inpaint_high_noise_14B_fp8_scaled.safetensors)
* [wan2.2\_fun\_inpaint\_low\_noise\_14B\_fp8\_scaled.safetensors](https://huggingface.co/Comfy-Org/Wan_2.2_ComfyUI_Repackaged/resolve/main/split_files/diffusion_models/wan2.2_fun_inpaint_low_noise_14B_fp8_scaled.safetensors)

**Lightning LoRA (可选，用于加速)**

* [wan2.2\_i2v\_lightx2v\_4steps\_lora\_v1\_high\_noise.safetensors](https://huggingface.co/Comfy-Org/Wan_2.2_ComfyUI_Repackaged/resolve/main/split_files/loras/wan2.2_i2v_lightx2v_4steps_lora_v1_high_noise.safetensors)
* [wan2.2\_i2v\_lightx2v\_4steps\_lora\_v1\_low\_noise.safetensors](https://huggingface.co/Comfy-Org/Wan_2.2_ComfyUI_Repackaged/resolve/main/split_files/loras/wan2.2_i2v_lightx2v_4steps_lora_v1_low_noise.safetensors)

**VAE**

* [wan\_2.1\_vae.safetensors](https://huggingface.co/Comfy-Org/Wan_2.2_ComfyUI_Repackaged/resolve/main/split_files/vae/wan_2.1_vae.safetensors)

**Text Encoder**

* [umt5\_xxl\_fp8\_e4m3fn\_scaled.safetensors](https://huggingface.co/Comfy-Org/Wan_2.1_ComfyUI_repackaged/resolve/main/split_files/text_encoders/umt5_xxl_fp8_e4m3fn_scaled.safetensors)

```
ComfyUI/
├───📂 models/
│   ├───📂 diffusion_models/
│   │   ├─── wan2.2_fun_inpaint_high_noise_14B_fp8_scaled.safetensors
│   │   └─── wan2.2_fun_inpaint_low_noise_14B_fp8_scaled.safetensors
│   ├───📂 loras/
│   │   ├─── wan2.2_i2v_lightx2v_4steps_lora_v1_high_noise.safetensors
│   │   └─── wan2.2_i2v_lightx2v_4steps_lora_v1_low_noise.safetensors
│   ├───📂 text_encoders/
│   │   └─── umt5_xxl_fp8_e4m3fn_scaled.safetensors 
│   └───📂 vae/
│       └── wan_2.1_vae.safetensors
```

### 3. 按步骤完成工作流

<img src="https://mintcdn.com/dripart/SIDaLac8vBogzwm7/images/tutorial/video/wan/wan2_2/wan_2.2_14b_fun_inp.jpg?fit=max&auto=format&n=SIDaLac8vBogzwm7&q=85&s=3d87de35d3eaa2f9599c35e9963c6c18" alt="步骤图" width="4182" height="2048" data-path="images/tutorial/video/wan/wan2_2/wan_2.2_14b_fun_inp.jpg" />

<Note>
  这个工作流是使用了 LoRA 的工作流，请确保对应的 Diffusion model 和 LoRA 是一致的
</Note>

1. **High noise** 模型及 **LoRA** 加载

* 确保 `Load Diffusion Model` 节点加载了 `wan2.2_fun_inpaint_high_noise_14B_fp8_scaled.safetensors` 模型
* 确保 `LoraLoaderModelOnly` 节点加载了 `wan2.2_i2v_lightx2v_4steps_lora_v1_high_noise.safetensors`

2. **Low noise** 模型及 **LoRA** 加载

* 确保 `Load Diffusion Model` 节点加载了 `wan2.2_fun_inpaint_low_noise_14B_fp8_scaled.safetensors` 模型
* 确保 `LoraLoaderModelOnly` 节点加载了 `wan2.2_i2v_lightx2v_4steps_lora_v1_low_noise.safetensors`

3. 确保 `Load CLIP` 节点加载了 `umt5_xxl_fp8_e4m3fn_scaled.safetensors` 模型
4. 确保 `Load VAE` 节点加载了 `wan_2.1_vae.safetensors` 模型
5. 首尾帧图片上传，分别上传首尾帧图片素材
6. 在 Prompt 组中输入提示词
7. `WanFunInpaintToVideo` 节点尺寸和视频长度调整
   * 调整 `width` 和 `height` 的尺寸，默认为 `640`, 我们设置了较小的尺寸你可以按需进行修改
   * 调整 `length`, 这里为视频总帧数，当前工作流 fps 为 16, 假设你需要生成一个 5 秒的视频，那么你应该设置 5\*16 = 80
8. 点击 `Run` 按钮，或者使用快捷键 `Ctrl(cmd) + Enter(回车)` 来执行视频生成
