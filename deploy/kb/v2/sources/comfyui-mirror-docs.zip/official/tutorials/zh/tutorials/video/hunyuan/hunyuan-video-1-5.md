> ## Documentation Index
> Fetch the complete documentation index at: https://docs.comfy.org/llms.txt
> Use this file to discover all available pages before exploring further.

# 混元视频 1.5 ComfyUI 教程

> 了解如何使用混元视频 1.5，一个轻量级的 8.3B 参数模型，可在消费级 GPU 上生成高质量视频

混元视频 1.5是由腾讯混元团队开发的轻量级 8.3B 参数模型。它可在消费级 GPU（24GB 显存）上提供旗舰级质量的视频生成，大幅降低了使用门槛，同时不影响质量。

## 模型亮点

* **小巧强大**：在消费级硬件上运行的同时，提供与大型模型相当的 SOTA 性能。
* **多功能生成**：支持高质量的文本生成视频和图像生成视频（5-10秒），具有出色的一致性。
* **精确控制**：对镜头运动、物理效果和情感表达有强大的指令遵循能力。
* **电影级质量**：原生 720p 输出（可升级至 1080p），具有专业美学效果。
* **丰富功能**：支持多种风格（写实、动漫、3D）和视频内文字渲染（中文/英文）。

<Tip>
  <Tabs>
    <Tab title="便携版或手动安装用户">
      请确保你的 ComfyUI 已经更新。

      * [ComfyUI 下载](https://www.comfy.org/download)
      * [ComfyUI 更新教程](/zh/installation/update_comfyui)

      本指南里的工作流可以在 ComfyUI 的[工作流模板](/zh/interface/features/template)中找到。如果找不到，可能是 ComfyUI 没有更新。

      如果加载工作流时有节点缺失，可能原因有：

      1. 你用的不是最新开发版（nightly）。
      2. 你用的是稳定版或桌面版（没有包含最新的更新）。
      3. 启动时有些节点导入失败。
    </Tab>

    <Tab title="桌面版或云端用户">
      * 桌面版是基于 ComfyUI 稳定版本构建的，它会在有新的桌面稳定版本发布时自动更新。
      * [Cloud](https://cloud.comfy.org) 会在 ComfyUI 稳定版本发布后更新，我们会同步更新 Cloud。

      所以，如果你发现本教程中有任何核心节点缺失，那是因为对应的节点支持还在开发中没有发布正式的稳定版，请等待下一个稳定版本发布。
    </Tab>
  </Tabs>
</Tip>

## 模型链接

**text\_encoders**

* [qwen\_2.5\_vl\_7b\_fp8\_scaled.safetensors](https://huggingface.co/Comfy-Org/HunyuanVideo_1.5_repackaged/resolve/main/split_files/text_encoders/qwen_2.5_vl_7b_fp8_scaled.safetensors)
* [byt5\_small\_glyphxl\_fp16.safetensors](https://huggingface.co/Comfy-Org/HunyuanVideo_1.5_repackaged/resolve/main/split_files/text_encoders/byt5_small_glyphxl_fp16.safetensors)

**diffusion\_models**

* [hunyuanvideo1.5\_1080p\_sr\_distilled\_fp16.safetensors](https://huggingface.co/Comfy-Org/HunyuanVideo_1.5_repackaged/resolve/main/split_files/diffusion_models/hunyuanvideo1.5_1080p_sr_distilled_fp16.safetensors)
* [hunyuanvideo1.5\_720p\_t2v\_fp16.safetensors](https://huggingface.co/Comfy-Org/HunyuanVideo_1.5_repackaged/resolve/main/split_files/diffusion_models/hunyuanvideo1.5_720p_t2v_fp16.safetensors)

**vae**

* [hunyuanvideo15\_vae\_fp16.safetensors](https://huggingface.co/Comfy-Org/HunyuanVideo_1.5_repackaged/resolve/main/split_files/vae/hunyuanvideo15_vae_fp16.safetensors)

Model Storage Location

```
:open_file_folder: ComfyUI/
├── :open_file_folder: models/
│   ├── :open_file_folder: text_encoders/
│   │      ├── qwen_2.5_vl_7b_fp8_scaled.safetensors
│   │      └── byt5_small_glyphxl_fp16.safetensors
│   ├── :open_file_folder: diffusion_models/
│   │      ├── hunyuanvideo1.5_1080p_sr_distilled_fp16.safetensors
│   │      └── hunyuanvideo1.5_720p_t2v_fp16.safetensors
│   └── :open_file_folder: vae/
│          └── hunyuanvideo15_vae_fp16.safetensors
```

## 工作流

[video\_hunyuan\_video\_1.5\_720p\_i2v.json](https://raw.githubusercontent.com/Comfy-Org/workflow_templates/refs/heads/main/templates/video_hunyuan_video_1.5_720p_i2v.json)

[video\_hunyuan\_video\_1.5\_720p\_t2v.json](https://raw.githubusercontent.com/Comfy-Org/workflow_templates/refs/heads/main/templates/video_hunyuan_video_1.5_720p_t2v.json)
