> ## Documentation Index
> Fetch the complete documentation index at: https://docs.comfy.org/llms.txt
> Use this file to discover all available pages before exploring further.

# ComfyUI 视频放大

> 学习如何在 ComfyUI 中使用本地模型和合作伙伴节点进行视频放大

本指南介绍 ComfyUI 中的视频放大工作流，包括本地模型和合作伙伴节点选项，适用于各种使用场景。

<Card title="The Complete AI Upscaling Handbook" icon="book" href="https://blog.comfy.org/p/upscaling-in-comfyui">
  如需更全面的深入分析、基准测试和视觉对比，请参阅 ComfyUI 博客上的完整文章。
</Card>

## TL;DR

* **质量模式**：SeedVR2 和 HitPaw 提供最准确和一致的真实感效果。
* **速度模式**：FlashVSR 和 HitPaw 是最快的选择。
* **AI 视频修复**：Topaz Astra Creative 在电影级润色和修复 AI 生成视频方面表现最强。
* **档案修复**：SeedVR2 在增强清晰度的同时保留原始结构。
* **CGI/3D 渲染**：Topaz、SeedVR2 和 HitPaw 都能产生干净、锐利的结果。

## 核心概念

### 放大 vs. 增强

* **放大（Upscaling）**：在重建细节的同时提高分辨率。
* **增强（Enhancement）**：改善感知质量（降噪、锐化、修复、时间一致性等）。

视频放大增加了时间维度的考量——在提高分辨率的同时保持帧间一致性。

### 创意放大 vs. 保守放大

|        | 保守放大                                         | 创意放大                                            |
| ------ | -------------------------------------------- | ----------------------------------------------- |
| **方式** | 保留原始内容                                       | 重新想象并增强                                         |
| **优势** | 高精度、时间一致性、适合生产环境                             | 细节丰富、更锐利、视觉效果更突出                                |
| **局限** | 可能显得平淡，对低质量输入改善有限                            | 可能产生幻觉、时间闪烁                                     |
| **模型** | Topaz Starlight Fast、FlashVSR、SeedVR2、HitPaw | Topaz Starlight Creative (Astra)、Wan 2.2、HitPaw |

## 使用场景

### 质量模式

**SeedVR2** 和 **HitPaw** 提供最准确的结果，具有出色的图像质量和优秀的角色一致性。

**Topaz** 也能有效放大，但有时可能比预期更具创意性。这使其特别适合可以接受风格化外观的电影素材。

<Card title="SeedVR2 - 保守放大（WaveSpeed API）" icon="cloud" href="https://links.comfy.org/4khbzjY">
  在 Comfy Cloud 上试用或下载工作流
</Card>

<Card title="SeedVR2 - 保守放大（开源）" icon="cloud" href="https://links.comfy.org/4tm2RoI">
  在 Comfy Cloud 上试用或下载工作流
</Card>

<Card title="HitPaw - 一体化方案" icon="cloud" href="https://links.comfy.org/4kthLWs">
  在 Comfy Cloud 上试用或下载工作流
</Card>

<Card title="Topaz Astra - 创意放大" icon="cloud" href="https://links.comfy.org/4tlbyQj">
  在 Comfy Cloud 上试用或下载工作流
</Card>

### 速度模式

**FlashVSR** 在速度优先时表现极佳。将 720p 放大到 1080p 大约需要 **41 秒处理 10 秒视频**，是目前最快的选项之一。

**HitPaw** 也相对较快。在 **Topaz** 中，Fast 和 Creative 模式的渲染速度相似，因此通常建议使用 **Creative** 模式以获得更好的视觉效果而不牺牲时间。

<Card title="FlashVSR - 保守放大（WaveSpeed API）" icon="cloud" href="https://links.comfy.org/4khbzjY">
  在 Comfy Cloud 上试用或下载工作流
</Card>

<Card title="HitPaw - 一体化方案" icon="cloud" href="https://links.comfy.org/4kthLWs">
  在 Comfy Cloud 上试用或下载工作流
</Card>

<Card title="Topaz Astra - 创意放大" icon="cloud" href="https://links.comfy.org/4tlbyQj">
  在 Comfy Cloud 上试用或下载工作流
</Card>

### AI 视频修复

**Topaz Astra Creative** 产生非常平滑和视觉一致的输出，是修复 AI 生成视频的强力选择。

一个有用的工作流技巧是先运行 **修复或清理步骤**，然后放大到 **1080p**，最后逐步放大到 **4K**。这种分步方法通常能带来更好的稳定性和细节。

<Card title="Topaz Astra - 创意放大" icon="cloud" href="https://links.comfy.org/4tlbyQj">
  在 Comfy Cloud 上试用或下载工作流
</Card>

<Card title="Wan 2.2 Upscale - 创意放大" icon="cloud" href="https://links.comfy.org/3NVEu1b">
  在 Comfy Cloud 上试用或下载工作流
</Card>

### 档案修复

**SeedVR2** 在档案修复方面表现尤为出色。它在增强清晰度的同时保留源素材的原始结构和细节，避免引入人工或夸张的特征。

<Card title="SeedVR2 - 保守放大（开源）" icon="cloud" href="https://links.comfy.org/4tm2RoI">
  在 Comfy Cloud 上试用或下载工作流
</Card>

<Card title="SeedVR2 - 保守放大（WaveSpeed API）" icon="cloud" href="https://links.comfy.org/4khbzjY">
  在 Comfy Cloud 上试用或下载工作流
</Card>

<Card title="Fast GAN - 传统放大" icon="cloud" href="https://links.comfy.org/46wNZtS">
  在 Comfy Cloud 上试用或下载工作流
</Card>

### CGI / 3D 渲染

**Topaz、SeedVR2 和 HitPaw** 在 CGI 和 3D 渲染素材上都表现出色。它们产生干净、锐利的结果，并保持对合成图像至关重要的清晰边缘。

<Card title="Topaz Astra - 创意放大" icon="cloud" href="https://links.comfy.org/4tlbyQj">
  在 Comfy Cloud 上试用或下载工作流
</Card>

<Card title="SeedVR2 - 保守放大（WaveSpeed API）" icon="cloud" href="https://links.comfy.org/4khbzjY">
  在 Comfy Cloud 上试用或下载工作流
</Card>

<Card title="HitPaw - 一体化方案" icon="cloud" href="https://links.comfy.org/4kthLWs">
  在 Comfy Cloud 上试用或下载工作流
</Card>

### 动画和动态图形

清晰的线条和一致的颜色至关重要。保守放大可以保留预期的风格。

**推荐**：Topaz Starlight Fast、Fast GAN

<Card title="Fast GAN - 传统放大" icon="cloud" href="https://links.comfy.org/46wNZtS">
  在 Comfy Cloud 上试用或下载工作流
</Card>

## 放大速度对比（10 秒 720p 视频）

| 模型               | 分辨率   | 时间     |
| ---------------- | ----- | ------ |
| FlashVSR（本地）     | 1080p | \~41s  |
| FlashVSR（本地）     | 4K    | \~52s  |
| HitPaw           | 2K    | \~80s  |
| HitPaw           | 4K    | \~175s |
| SeedVR2（本地，5090） | 1080p | \~312s |
| Topaz Astra      | 1080p | \~374s |
| Topaz Astra      | 4K    | \~560s |

## 可用模型

### 合作伙伴节点

合作伙伴节点通过 API 提供高级视频放大模型访问。

| 模型                               | 类型 | 最大分辨率 | 特性        |
| -------------------------------- | -- | ----- | --------- |
| Topaz Starlight Fast             | 保守 | 4K    | 快速、精确放大   |
| Topaz Starlight Creative (Astra) | 创意 | 4K    | 基于扩散的创意放大 |
| Topaz Apollo                     | -  | -     | 帧插值       |
| WaveSpeed SeedVR2                | 保守 | -     | 高保真度      |
| WaveSpeed FlashVSR               | 保守 | -     | 快速视频超分辨率  |
| HitPaw                           | 两者 | -     | 一体化视频增强   |

### Topaz Video Enhance 功能

* **放大**：Starlight (Astra) 支持快速视频放大至 FullHD (1080p) 或 4K，同时保持清晰度。
* **插值**：Apollo 模型用于帧插值，支持慢动作设置和自定义帧率（如 60fps）。
* **动态压缩**：智能识别和处理视频中的压缩伪影，提高画面纯净度。

## 开始使用 Topaz Video Enhance

1. 将 ComfyUI 更新到最新版本。
2. 在节点列表中搜索 `Topaz Video Enhance` 节点。
3. 连接视频输入并配置设置。
4. 运行工作流。

## 技巧

* 将放大与[帧插值](/zh/tutorials/utility/frame-interpolation)结合使用，获得更流畅、更高分辨率的输出。
* 对于 AI 生成的视频，考虑在放大之前修复伪影，而不是依赖创意放大来修复它们。
* 在处理完整视频之前，先在示例片段上测试不同的模型。
* 对于需要严格保持原始保真度的内容，使用保守放大。
