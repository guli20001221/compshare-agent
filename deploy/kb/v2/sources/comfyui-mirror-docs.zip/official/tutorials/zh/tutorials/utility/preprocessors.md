> ## Documentation Index
> Fetch the complete documentation index at: https://docs.comfy.org/llms.txt
> Use this file to discover all available pages before exploring further.

# ComfyUI 预处理器工作流

> 学习如何在 ComfyUI 中使用深度估计、线稿转换、姿态检测和法线提取预处理器

## 什么是预处理器？

<Note>
  这些工作流包含自定义节点。在运行工作流之前，你需要使用 [ComfyUI 管理器](/zh/manager/overview) 安装这些自定义节点。
</Note>

预处理器是从图像中提取结构信息的基础工具。它们将图像转换为条件信号，如深度图、线稿、姿态骨架和表面法线。这些输出可以在 ControlNet、图生图和视频工作流中提供更好的控制和一致性。

将预处理器作为独立工作流使用可以实现：

* 无需重新运行完整图表即可快速迭代
* 预处理和生成的清晰分离
* 更容易调试和调优
* 更可预测的图像和视频结果

## 深度估计

深度估计将平面图像转换为表示场景中相对距离的深度图。这种结构信号是受控生成、空间感知编辑和重新打光工作流的基础。

此工作流强调：

* 干净、稳定的深度提取
* 一致的归一化以供下游使用
* 与 ControlNet 和图像编辑管道的轻松集成

深度输出可以在多个处理过程中重复使用，使迭代更容易，无需重新运行昂贵的上游步骤。

<Card title="深度估计工作流" icon="cloud" href="https://cloud.comfy.org/?template=utility-depthAnything-v2-relative-video&utm_source=docs&utm_medium=inhouse_social&utm_campaign=inhouse_feature_launches&utm_content=post&utm_niche=workflow_engineering&utm_creator=purz">
  在 Comfy Cloud 上运行
</Card>

<Card title="下载工作流" icon="download" href="https://github.com/Comfy-Org/workflow_templates/blob/main/templates/utility-depthAnything-v2-relative-video.json">
  下载 JSON
</Card>

## 线稿转换

线稿预处理器将图像提炼为其基本边缘和轮廓，去除纹理和颜色，同时保留结构。

此工作流旨在：

* 生成干净、高对比度的线稿
* 最小化断裂或噪声边缘
* 为风格化和重绘工作流提供可靠的结构指导

线稿与深度和姿态配合特别好，提供强大的结构约束而不会过度约束风格。

<Card title="线稿转换工作流" icon="cloud" href="https://cloud.comfy.org/?template=utility-lineart-video&utm_source=docs&utm_medium=inhouse_social&utm_campaign=inhouse_feature_launches&utm_content=post&utm_niche=workflow_engineering&utm_creator=purz">
  在 Comfy Cloud 上运行
</Card>

<Card title="下载工作流" icon="download" href="https://github.com/Comfy-Org/workflow_templates/blob/main/templates/utility-lineart-video.json">
  下载 JSON
</Card>

## 姿态检测

姿态检测从图像中提取身体关键点和骨骼结构，实现对人体姿势和动作的精确控制。

此工作流专注于：

* 清晰、可读的姿态输出
* 适合跨帧重用的稳定关键点检测
* 与基于姿态的 ControlNet 和动画管道的兼容性

通过将姿态提取隔离到专用工作流中，姿态数据变得更容易检查、优化和重用。

<Card title="姿态检测工作流" icon="cloud" href="https://cloud.comfy.org/?template=utility-openpose-video&utm_source=docs&utm_medium=inhouse_social&utm_campaign=inhouse_feature_launches&utm_content=post&utm_niche=workflow_engineering&utm_creator=purz">
  在 Comfy Cloud 上运行
</Card>

<Card title="下载工作流" icon="download" href="https://github.com/Comfy-Org/workflow_templates/blob/main/templates/utility-openpose-video.json">
  下载 JSON
</Card>

## 法线提取

法线估计将平面图像转换为表面法线图——一个描述表面每个部分朝向的逐像素方向场（通常编码为 RGB）。这种信号对于重新打光、材质感知风格化和高度结构化的编辑非常有用。

此工作流强调：

* 干净、稳定的法线提取，最小化斑点
* 一致的方向和归一化以供可靠的下游使用
* ControlNet 就绪的输出，用于重新打光、优化和保持结构的编辑
* 跨处理过程重用，无需重新运行早期步骤即可迭代

法线输出可用于：

* 在保持几何形状的同时驱动重新打光/着色变化
* 为风格化和重绘管道添加更强的 3D 结构
* 与姿态/深度配合用于动画工作时提高跨帧一致性

<Card title="法线提取工作流" icon="cloud" href="https://cloud.comfy.org/?template=utility-normal_crafter-video&utm_source=docs&utm_medium=inhouse_social&utm_campaign=inhouse_feature_launches&utm_content=post&utm_niche=workflow_engineering&utm_creator=purz">
  在 Comfy Cloud 上运行
</Card>

<Card title="下载工作流" icon="download" href="https://github.com/Comfy-Org/workflow_templates/blob/main/templates/utility-normal_crafter-video.json">
  下载 JSON
</Card>
