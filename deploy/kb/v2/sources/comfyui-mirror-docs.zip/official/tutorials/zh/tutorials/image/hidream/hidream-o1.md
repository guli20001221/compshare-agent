> ## Documentation Index
> Fetch the complete documentation index at: https://docs.comfy.org/llms.txt
> Use this file to discover all available pages before exploring further.

# ComfyUI 原生 HiDream-O1-Image 工作流示例

> 本文档将引导你完成 ComfyUI 原生 HiDream-O1-Image 文生图和图像编辑工作流

<Tip>
  <Tabs>
    <Tab title="便携版或手动安装用户">
      请确保你的 ComfyUI 已经更新。

      * [ComfyUI 下载](https://www.comfy.org/download)
      * [ComfyUI 更新教程](/zh/installation/update_comfyui)

      本指南里的工作流可以在 ComfyUI 的[工作流模板](/zh/interface/features/template)中找到。如果找不到，可能是 ComfyUI 没有更新。

      如果加载工作流时有节点缺失，可能原因有：

      1. 你用的不是最新开发版（nightly）。
      2. 你用的是稳定版或桌面版（没有包含最新的更新）。
      3. 启动时有些节点导入失败。
    </Tab>

    <Tab title="桌面版或云端用户">
      * 桌面版是基于 ComfyUI 稳定版本构建的，它会在有新的桌面稳定版本发布时自动更新。
      * [Cloud](https://cloud.comfy.org) 会在 ComfyUI 稳定版本发布后更新，我们会同步更新 Cloud。

      所以，如果你发现本教程中有任何核心节点缺失，那是因为对应的节点支持还在开发中没有发布正式的稳定版，请等待下一个稳定版本发布。
    </Tab>
  </Tabs>
</Tip>

![HiDream-O1-Image Demo](https://raw.githubusercontent.com/HiDream-ai/HiDream-O1-Image/main/assets/general.webp)

HiDream-O1-Image 是 HiDream-ai 于 2026年5月8日 开源的原生统一图像生成基础模型。采用像素级统一变换器（UiT）架构，无需 VAE 或分离的文本编码器，支持 **文生图（Text-to-Image）**、**指令式图像编辑**、**主体驱动个性化生成** 和 **故事板生成**，最高可生成 2048×2048 分辨率。

HiDream-O1-Image 基于 [MIT 协议](https://github.com/HiDream-ai/HiDream-O1-Image?tab=MIT-1-ov-file)开源，ComfyUI 已原生支持（PR [#13817](https://github.com/Comfy-Org/ComfyUI/pull/13817)）。

[HiDream-O1-Image - GitHub](https://github.com/HiDream-ai/HiDream-O1-Image)

### 模型版本

| 模型                     | 推理步数 | 模型仓库                                                                              |
| ---------------------- | ---- | --------------------------------------------------------------------------------- |
| HiDream-O1-Image（Full） | 50   | [🤗 HiDream-O1-Image](https://huggingface.co/HiDream-ai/HiDream-O1-Image)         |
| HiDream-O1-Image-Dev   | 28   | [🤗 HiDream-O1-Image-Dev](https://huggingface.co/HiDream-ai/HiDream-O1-Image-Dev) |

## HiDream-O1-Image Full 工作流

### 1. 工作流文件下载

请更新你的 ComfyUI 到最新版本，并通过菜单 `工作流` -> `浏览模板` -> `Image` 找到 "HiDream O1 Full: Image generation" 以加载工作流。

![HiDream-O1-Image Full 工作流](https://raw.githubusercontent.com/Comfy-Org/workflow_templates/main/output/image_hidream_o1.png)

<Card title="下载 JSON 格式工作流" icon="download" href="https://raw.githubusercontent.com/Comfy-Org/workflow_templates/refs/heads/main/templates/image_hidream_o1.json">
  Download workflow
</Card>

<Card title="Run on Comfy Cloud" icon="cloud" href="https://cloud.comfy.org/?template=image_hidream_o1&utm_source=docs">
  Open in cloud
</Card>

### 2. 手动下载模型

**Checkpoint** — 经过重新打包和量化。所有版本均将最严重的离群值保留在 bf16，并移除了未使用的 deepstack 层：

* [hidream\_o1\_image\_fp8\_scaled.safetensors](https://huggingface.co/Comfy-Org/HiDream-O1-Image/resolve/main/checkpoints/hidream_o1_image_fp8_scaled.safetensors) — FP8 量化版，在支持的硬件上使用 fp8/mxfp8 矩阵乘法加速安全 MLP 层
* [hidream\_o1\_image\_mxfp8.safetensors](https://huggingface.co/Comfy-Org/HiDream-O1-Image/resolve/main/checkpoints/hidream_o1_image_mxfp8.safetensors) — MXFP8 量化变体
* [hidream\_o1\_image\_bf16.safetensors](https://huggingface.co/Comfy-Org/HiDream-O1-Image/resolve/main/checkpoints/hidream_o1_image_bf16.safetensors) — bf16 全精度版（文件最大）

**文本编码器（提示词优化）** — 所有版本通用：

* [gemma4\_e4b\_it\_fp8\_scaled.safetensors](https://huggingface.co/Comfy-Org/gemma-4/resolve/main/text_encoders/gemma4_e4b_it_fp8_scaled.safetensors)

**LoRA（可选）** — Dev 蒸馏也可以作为 LoRA 应用到 Full 模型中，让你可以调节蒸馏强度（由 [Kijai](https://huggingface.co/Kijai/hidream-O1-image_comfy) 提供）：

* [hidream\_o1\_dev\_lora\_rank\_64\_bf16.safetensors](https://huggingface.co/Kijai/hidream-O1-image_comfy/resolve/main/loras/hidream_o1_dev_lora_rank_64_bf16.safetensors) — 全秩版
* [hidream\_o1\_dev\_lora\_rank\_64\_bf16\_pruned\_v1.safetensors](https://huggingface.co/Kijai/hidream-O1-image_comfy/resolve/main/loras/hidream_o1_dev_lora_rank_64_bf16_pruned_v1.safetensors) — 剪枝版
* [hidream\_o1\_image\_dev\_2604\_lora\_avg\_rankg\_224\_bf16.safetensors](https://huggingface.co/Kijai/hidream-O1-image_comfy/resolve/main/loras/hidream_o1_image_dev_2604_lora_avg_rankg_224_bf16.safetensors) — 基于 checkpoint 的替代蒸馏

```
📂 ComfyUI/
├── 📂 models/
│   ├── 📂 checkpoints/
│   │   ├── hidream_o1_image_fp8_scaled.safetensors
│   │   ├── hidream_o1_image_mxfp8.safetensors
│   │   └── hidream_o1_image_bf16.safetensors
│   ├── 📂 loras/
│   │   └── hidream_o1_dev_lora_rank_64_bf16.safetensors
│   └── 📂 text_encoders/
│       └── gemma4_e4b_it_fp8_scaled.safetensors
```

### 3. 使用工作流

* 确保 `CheckpointLoaderSimple` 节点加载了对应的 checkpoint 模型
* 在 `CLIPTextEncode` 节点中输入你的提示词
* **文生图模式**：将 **"Switch to Image Edit"** 开关设为 **关闭**（默认）。采样器直接使用你的文本提示词。
* **图像编辑模式**：将 **"Switch to Image Edit"** 设为 **开启**，然后在 `Load Image` 节点中上传参考图片，连接到 `HiDreamO1ReferenceImages` 节点。

> **注意：** O1 采样器输出的是 latent 样本，需要通过 `VAEDecode` 节点（使用 `CheckpointLoaderSimple` 加载的 VAE）解码后才能看到图像。

## HiDream-O1-Image Dev 工作流

### 1. 工作流文件下载

请更新你的 ComfyUI 到最新版本，并通过菜单 `工作流` -> `浏览模板` -> `Image` 找到 "HiDream O1 Dev" 以加载工作流。

![HiDream-O1-Image Dev 工作流](https://raw.githubusercontent.com/Comfy-Org/workflow_templates/main/output/image_hidream_o1_dev.png)

<Card title="下载 JSON 格式工作流" icon="download" href="https://raw.githubusercontent.com/Comfy-Org/workflow_templates/refs/heads/main/templates/image_hidream_o1_dev.json">
  Download workflow
</Card>

<Card title="Run on Comfy Cloud" icon="cloud" href="https://cloud.comfy.org/?template=image_hidream_o1_dev&utm_source=docs">
  Open in cloud
</Card>

### 2. 手动下载模型

**Checkpoint（Dev 版）** — 经过重新打包和量化。所有版本均将最严重的离群值保留在 bf16，并移除了未使用的 deepstack 层：

* [hidream\_o1\_image\_dev\_fp8\_scaled.safetensors](https://huggingface.co/Comfy-Org/HiDream-O1-Image/resolve/main/checkpoints/hidream_o1_image_dev_fp8_scaled.safetensors) — FP8 量化版，在支持的硬件上使用 fp8/mxfp8 矩阵乘法加速安全 MLP 层
* [hidream\_o1\_image\_dev\_mxfp8.safetensors](https://huggingface.co/Comfy-Org/HiDream-O1-Image/resolve/main/checkpoints/hidream_o1_image_dev_mxfp8.safetensors) — MXFP8 量化变体
* [hidream\_o1\_image\_dev\_bf16.safetensors](https://huggingface.co/Comfy-Org/HiDream-O1-Image/resolve/main/checkpoints/hidream_o1_image_dev_bf16.safetensors) — bf16 全精度版（文件最大）

**文本编码器（提示词优化）** — 所有版本通用：

* [gemma4\_e4b\_it\_fp8\_scaled.safetensors](https://huggingface.co/Comfy-Org/gemma-4/resolve/main/text_encoders/gemma4_e4b_it_fp8_scaled.safetensors)

```
📂 ComfyUI/
├── 📂 models/
│   ├── 📂 checkpoints/
│   │   ├── hidream_o1_image_dev_fp8_scaled.safetensors
│   │   ├── hidream_o1_image_dev_mxfp8.safetensors
│   │   └── hidream_o1_image_dev_bf16.safetensors
│   └── 📂 text_encoders/
│       └── gemma4_e4b_it_fp8_scaled.safetensors
```

### 3. 使用工作流

* 确保 `CheckpointLoaderSimple` 节点加载了 `hidream_o1_image_dev_fp8_scaled.safetensors`
* Dev 版本使用 28 步推理，CFG 自动设为 1.0，无需负向提示词
* **文生图模式**：将 **"Switch to Image Edit"** 开关设为 **关闭**（默认）
* **图像编辑模式**：将 **"Switch to Image Edit"** 设为 **开启**，在 `Load Image` 中上传参考图片，连接到 `HiDreamO1ReferenceImages` 节点

## 补充说明

* **长文本渲染：** HiDream-O1-Image 在图像中的文字渲染表现出色，在提示词中明确指定文字内容、字体风格和位置可获得更佳效果。

  ![长文本渲染与排版控制](https://raw.githubusercontent.com/HiDream-ai/HiDream-O1-Image/main/assets/text-layout.webp)

* **图像缩放：** 如果输入参考图像过大，可以启用 `ImageScaleToTotalPixels` 节点（Ctrl+B）缩放至 4MP。

* **拼缝平滑（实验性）：** `HiDreamO1PatchSeamSmoothing` 节点可减少采样过程中的拼缝伪影。Full 工作流中默认启用。
