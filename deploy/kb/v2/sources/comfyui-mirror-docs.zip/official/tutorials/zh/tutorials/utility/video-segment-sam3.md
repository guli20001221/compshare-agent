> ## Documentation Index
> Fetch the complete documentation index at: https://docs.comfy.org/llms.txt
> Use this file to discover all available pages before exploring further.

# SAM 3.1：ComfyUI 通用分割工作流

> 学习使用 Meta 的 SAM 3.1 模型在 ComfyUI 中通过文本提示对图像和视频进行分割

<Tip>
  <Tabs>
    <Tab title="便携版或手动安装用户">
      请确保你的 ComfyUI 已经更新。

      * [ComfyUI 下载](https://www.comfy.org/download)
      * [ComfyUI 更新教程](/zh/installation/update_comfyui)

      本指南里的工作流可以在 ComfyUI 的[工作流模板](/zh/interface/features/template)中找到。如果找不到，可能是 ComfyUI 没有更新。

      如果加载工作流时有节点缺失，可能原因有：

      1. 你用的不是最新开发版（nightly）。
      2. 你用的是稳定版或桌面版（没有包含最新的更新）。
      3. 启动时有些节点导入失败。
    </Tab>

    <Tab title="桌面版或云端用户">
      * 桌面版是基于 ComfyUI 稳定版本构建的，它会在有新的桌面稳定版本发布时自动更新。
      * [Cloud](https://cloud.comfy.org) 会在 ComfyUI 稳定版本发布后更新，我们会同步更新 Cloud。

      所以，如果你发现本教程中有任何核心节点缺失，那是因为对应的节点支持还在开发中没有发布正式的稳定版，请等待下一个稳定版本发布。
    </Tab>
  </Tabs>
</Tip>

[SAM 3](https://ai.meta.com/sam3)（Segment Anything Model 3）是 Meta 推出的统一基础模型，支持图像和视频的可提示分割。它能通过文本或视觉提示（点、框、遮罩）检测、分割和追踪物体。相比前代 [SAM 2](https://github.com/facebookresearch/sam2)，SAM 3 引入了通过短文本短语对开放词汇概念进行全量分割的能力。

[SAM 3.1 Multiplex](https://github.com/facebookresearch/sam3) 是最新发布的检查点版本，引入了共享内存方法的联合多物体追踪——在不牺牲精度的情况下显著提升了速度。

SAM 3.1 在 ComfyUI 中获得原生支持（PR [#13408](https://github.com/Comfy-Org/ComfyUI/pull/13408)），模型权重基于 [SAM License](https://github.com/facebookresearch/sam3/blob/main/LICENSE) 发布。

[SAM 3 GitHub](https://github.com/facebookresearch/sam3) | [论文 (arXiv)](https://arxiv.org/abs/2604.02296) | [🤗 Model Hub](https://huggingface.co/Comfy-Org/sam3.1)

<video controls width="100%">
  <source src="https://raw.githubusercontent.com/Comfy-Org/workflow_templates/refs/heads/main/output/utility_video_segment_sam3.mp4" type="video/mp4" />
</video>

SAM 3.1 能根据文本提示在视频帧中分割并追踪物体。以上示例展示了目标物体在视频中通过遮罩进行分割的输出结果。

### 核心优势

* **文本驱动分割** — 用自然语言描述要分割的内容，无需手动标注点或框
* **图像和视频双支持** — 支持单张图像分割和视频序列跨帧追踪
* **多物体支持** — 使用逗号分隔的提示可同时分割和追踪多个物体
* **开放词汇** — 处理远超以往工作的开放词汇概念

> **限制：** 模型文本提示的 token 上限为 32 个。为获得最佳结果，请保持提示简短并聚焦于目标物体。

## SAM 3.1 分割工作流

### 1. 工作流文件下载

请更新你的 ComfyUI 到最新版本，并通过菜单 `工作流` -> `浏览模板` 找到 Utility 类别下的 SAM 3.1 工作流。

**视频分割：**

<Card title="下载 JSON 格式工作流" icon="download" href="https://raw.githubusercontent.com/Comfy-Org/workflow_templates/refs/heads/main/templates/utility_video_segment_sam3.json">
  下载视频工作流
</Card>

<Card title="在 Comfy Cloud 中运行" icon="cloud" href="https://cloud.comfy.org/?template=utility_video_segment_sam3&utm_source=docs">
  Open in cloud
</Card>

**图像分割：**

<Card title="下载 JSON 格式工作流" icon="download" href="https://raw.githubusercontent.com/Comfy-Org/workflow_templates/refs/heads/main/templates/utility_image_segment_sam3.json">
  下载图像工作流
</Card>

<Card title="在 Comfy Cloud 中运行" icon="cloud" href="https://cloud.comfy.org/?template=utility_image_segment_sam3&utm_source=docs">
  Open in cloud
</Card>

### 2. 手动下载模型

SAM 3.1 模型托管在 [Comfy-Org SAM 3.1 模型仓库](https://huggingface.co/Comfy-Org/sam3.1)。

* [sam3.1\_multiplex\_fp16.safetensors](https://huggingface.co/Comfy-Org/sam3.1/resolve/main/checkpoints/sam3.1_multiplex_fp16.safetensors)

放置到以下目录结构：

```
📂 ComfyUI/
└── 📂 models/
    └── 📂 checkpoints/
        └── sam3.1_multiplex_fp16.safetensors
```

### 3. 使用工作流

**图像分割：**

* **图像** — 通过 `Load Image` 节点加载图像（放入 ComfyUI 的 `input/` 文件夹）
* **物体提示** — 要分割物体的简短文本描述，例如 `person`、`car`、`cat`
* 输出为图像的遮罩，RGBA 预览显示分割结果

**视频分割：**

* **视频** — 通过 `Load Video` 节点加载视频
* **物体提示** — 同上，描述要在各帧之间追踪和分割的物体的简短文本
* 输出包含每帧的遮罩和边界框

**提示格式：**

| 提示        | 作用                          |
| --------- | --------------------------- |
| SAM3 物体提示 | 描述要分割的**物体**。最多 32 个 token。 |

如需分别提示多个主体，用逗号分隔，并使用 `:N` 指定每个提示检测的最大物体数量：
`eye:2, window panels:4`

<Card title="了解 Subgraph" icon="book-open" href="/zh/interface/features/subgraph">
  本工作流使用了 Subgraph 节点实现模块化处理。查阅 Subgraph 文档了解如何自定义和扩展工作流。
</Card>

## 补充说明

* **保持提示简短而具体** — 模型每个提示有 32 个 token 的限制
* **多物体检测** — 使用逗号分隔不同物体类型，用 `:N` 限制每种类型的检测数量
* **分割遮罩** — 输出遮罩可作为其他工作流的输入（例如修复、背景移除）
* **更新需求** — 确保 ComfyUI 已更新到最新版本以支持 SAM 3.1
