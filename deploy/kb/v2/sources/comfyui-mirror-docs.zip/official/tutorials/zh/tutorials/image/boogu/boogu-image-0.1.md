> ## Documentation Index
> Fetch the complete documentation index at: https://docs.comfy.org/llms.txt
> Use this file to discover all available pages before exploring further.

# Boogu-Image-0.1 ComfyUI 工作流示例

> Boogu-Image-0.1 是采用 Apache-2.0 许可证的 10B 参数统一图像生成与编辑模型系列，包含文生图变体和指令驱动编辑变体。

**Boogu-Image-0.1** 是一个采用 Apache-2.0 许可证的开源统一图像生成与编辑模型系列。它通过整合理解与生成能力的系统，在摄影、文字渲染、风格化和图像编辑任务中均能提供具有竞争力的表现。

**模型变体**：

* **Boogu-Image-0.1-Turbo**：四步蒸馏文生图变体，专注于高质量生成与真实感，配备 LoRA rank-128 模块。仅需 3-4 采样步骤即可生成。推荐作为大多数文生图用例的默认选项。
* **Boogu-Image-0.1-Base**：具有强大多样性与可控性的基础模型，非常适合微调以及在 2K 分辨率下进行超密集文字渲染。
* **Boogu-Image-0.1-Edit**：专为指令驱动控制的图像编辑与变换任务微调的变体。

**模型亮点**：

* **10B 参数**，可在消费级 GPU 上高效推理
* **Apache-2.0 许可证**，支持开放使用和下游开发
* **双语文字渲染**（中英文），排版清晰可靠
* **多功能能力**：逼真摄影、风格化、海报设计以及精确的文字渲染

**相关链接**：

* [项目页面](https://boogu.org/)
* [GitHub](https://github.com/boogu-project/Boogu-Image)
* [Hugging Face (ComfyUI)](https://huggingface.co/Comfy-Org/Boogu-Image)
* [Hugging Face (Turbo)](https://huggingface.co/Boogu/Boogu-Image-0.1-Turbo-fp8)
* [Hugging Face (Edit)](https://huggingface.co/Boogu/Boogu-Image-0.1-Edit-fp8)

## Boogu-Image-0.1-Turbo 文生图工作流

<CardGroup cols={2}>
  <Card title="在 Comfy Cloud 中运行" icon="cloud" href="https://cloud.comfy.org/?template=image_boogu_image_0_1_turbo_t2i&utm_source=docs&utm_medium=referral&utm_campaign=boogu_image_launch">
    在 Comfy Cloud 中打开
  </Card>

  <Card title="下载工作流" icon="download" href="https://github.com/Comfy-Org/workflow_templates/blob/main/templates/image_boogu_image_0_1_turbo_t2i.json">
    下载 JSON 或在模板库中搜索 "Boogu image 0.1"
  </Card>
</CardGroup>

<Tip>
  <Tabs>
    <Tab title="便携版或手动安装用户">
      请确保你的 ComfyUI 已经更新。

      * [ComfyUI 下载](https://www.comfy.org/download)
      * [ComfyUI 更新教程](/zh/installation/update_comfyui)

      本指南里的工作流可以在 ComfyUI 的[工作流模板](/zh/interface/features/template)中找到。如果找不到，可能是 ComfyUI 没有更新。

      如果加载工作流时有节点缺失，可能原因有：

      1. 你用的不是最新开发版（nightly）。
      2. 你用的是稳定版或桌面版（没有包含最新的更新）。
      3. 启动时有些节点导入失败。
    </Tab>

    <Tab title="桌面版或云端用户">
      * 桌面版是基于 ComfyUI 稳定版本构建的，它会在有新的桌面稳定版本发布时自动更新。
      * [Cloud](https://cloud.comfy.org) 会在 ComfyUI 稳定版本发布后更新，我们会同步更新 Cloud。

      所以，如果你发现本教程中有任何核心节点缺失，那是因为对应的节点支持还在开发中没有发布正式的稳定版，请等待下一个稳定版本发布。
    </Tab>
  </Tabs>
</Tip>

Boogu-Image-0.1-Turbo 工作流使用一个子图封装了扩散、文本编码和 VAE 解码管线。您只需提供文本提示词和分辨率设置，子图会处理其余部分。

### Boogu-Image-0.1-Turbo 模型下载

<Card title="boogu_image_turbo_fp8_scaled.safetensors" icon="download" href="https://huggingface.co/Comfy-Org/Boogu-Image/resolve/main/diffusion_models/boogu_image_turbo_fp8_scaled.safetensors">
  Boogu-Image-0.1-Turbo 的扩散模型。
</Card>

<Card title="qwen3vl_8b_fp8_scaled.safetensors" icon="download" href="https://huggingface.co/Comfy-Org/Boogu-Image/resolve/main/text_encoders/qwen3vl_8b_fp8_scaled.safetensors">
  Boogu-Image-0.1-Turbo 的文本编码器。
</Card>

<Card title="ae.safetensors" icon="download" href="https://huggingface.co/Comfy-Org/HiDream-I1_ComfyUI/resolve/main/split_files/vae/ae.safetensors?download=true">
  Boogu-Image-0.1-Turbo 的 VAE。
</Card>

<Card title="boogu_image_turbo_lora_rank_128_bf16.safetensors" icon="download" href="https://huggingface.co/Comfy-Org/Boogu-Image/resolve/main/loras/boogu_image_turbo_lora_rank_128_bf16.safetensors">
  Boogu-Image-0.1-Turbo 的 LoRA 模块 (rank-128)。
</Card>

**模型存储位置**

```
📂 ComfyUI/
├── 📂 models/
│   ├── 📂 diffusion_models/
│   │   └── boogu_image_turbo_fp8_scaled.safetensors
│   ├── 📂 text_encoders/
│   │   └── qwen3vl_8b_fp8_scaled.safetensors
│   ├── 📂 vae/
│   │   └── ae.safetensors
│   └── 📂 loras/
│       └── boogu_image_turbo_lora_rank_128_bf16.safetensors
```

## Boogu-Image-0.1-Edit 图像编辑工作流

<CardGroup cols={2}>
  <Card title="在 Comfy Cloud 中运行" icon="cloud" href="https://cloud.comfy.org/?template=image_boogu_image_0_1_edit&utm_source=docs&utm_medium=referral&utm_campaign=boogu_image_launch">
    在 Comfy Cloud 中打开
  </Card>

  <Card title="下载工作流" icon="download" href="https://github.com/Comfy-Org/workflow_templates/blob/main/templates/image_boogu_image_0_1_edit.json">
    下载 JSON 或在模板库中搜索 "Boogu image 0.1 Edit"
  </Card>
</CardGroup>

<CardGroup cols={1}>
  <Card title="下载示例图像" icon="image" href="https://raw.githubusercontent.com/Comfy-Org/workflow_templates/main/input/tech_cowboy.png">
    获取此工作流的示例输入图像
  </Card>
</CardGroup>

### Boogu-Image-0.1-Edit 模型下载

<Card title="boogu_image_edit_fp8_scaled.safetensors" icon="download" href="https://huggingface.co/Comfy-Org/Boogu-Image/resolve/main/diffusion_models/boogu_image_edit_fp8_scaled.safetensors">
  Boogu-Image-0.1-Edit 的扩散模型。
</Card>

<Card title="qwen3vl_8b_fp8_scaled.safetensors" icon="download" href="https://huggingface.co/Comfy-Org/Boogu-Image/resolve/main/text_encoders/qwen3vl_8b_fp8_scaled.safetensors">
  Boogu-Image-0.1-Edit 的文本编码器。
</Card>

<Card title="ae.safetensors" icon="download" href="https://huggingface.co/Comfy-Org/HiDream-I1_ComfyUI/resolve/main/split_files/vae/ae.safetensors?download=true">
  Boogu-Image-0.1-Edit 的 VAE。
</Card>

**模型存储位置**

```
📂 ComfyUI/
├── 📂 models/
│   ├── 📂 diffusion_models/
│   │   └── boogu_image_edit_fp8_scaled.safetensors
│   ├── 📂 text_encoders/
│   │   └── qwen3vl_8b_fp8_scaled.safetensors
│   └── 📂 vae/
│       └── ae.safetensors
```
