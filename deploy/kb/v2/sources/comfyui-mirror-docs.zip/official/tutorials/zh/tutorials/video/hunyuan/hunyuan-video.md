> ## Documentation Index
> Fetch the complete documentation index at: https://docs.comfy.org/llms.txt
> Use this file to discover all available pages before exploring further.

# ComfyUI 混元视频示例

> 本文介绍了如何在 ComfyUI 中完成混元文生视频及图生视频的工作流

<video controls className="w-full aspect-video" src="https://github.com/user-attachments/assets/442afb73-3092-454f-bc46-02361c285930" />

混元视频（Hunyuan Video）系列是[腾讯](https://huggingface.co/tencent)研发并开源的，该模型以混合架构为核心，支持[文本生成视频](https://github.com/Tencent/HunyuanVideo)
和[图生成视频](https://github.com/Tencent/HunyuanVideo-I2V)，参数规模达 13B。

技术特点：

* **核心架构：** 采用类似Sora的DiT（Diffusion Transformer）架构，有效融合了文本、图像和动作信息，提高了生成视频帧之间的一致性、质量和对齐度，通过统一的全注意力机制实现多视角镜头切换，确保主体一致性。
* **3D VAE：** 定义的 3D VAE 将视频压缩到紧凑的潜空间，同时压缩视频，使得图生视频的生成更加高效。
* **卓越的图像-视频-文本对齐：** 使用 MLLM 文本编码器，在图像和视频生成中表现出色，能够更好地遵循文本指令，捕捉细节，并进行复杂推理。

你可以在[混元视频](https://github.com/Tencent/HunyuanVideo) 和[混元视频-I2V](https://github.com/Tencent/HunyuanVideo-I2V) 了解到更多开源信息。

本篇指南将引导你完成在 ComfyUI 中 **文生视频** 和 **图生视频** 的视频生成。

<Tip>
  本篇教程中的工作流图片的 Metadata 中已包含对应模型下载信息，直接拖入 ComfyUI 或使用菜单 `Workflows` -> `Open（ctrl+o）` 来加载对应的工作流，会提示完成对应的模型下载。

  另外在本篇指南中也提供了对应的模型地址 ，如果自动下载无法完成或者你使用的不是 Desktop 版本，请尝试手动完成模型的下载。

  所有模型保存在[这里](https://huggingface.co/Comfy-Org/HunyuanVideo_repackaged/tree/main/split_files)可以下载
</Tip>

<Tip>
  <Tabs>
    <Tab title="便携版或手动安装用户">
      请确保你的 ComfyUI 已经更新。

      * [ComfyUI 下载](https://www.comfy.org/download)
      * [ComfyUI 更新教程](/zh/installation/update_comfyui)

      本指南里的工作流可以在 ComfyUI 的[工作流模板](/zh/interface/features/template)中找到。如果找不到，可能是 ComfyUI 没有更新。

      如果加载工作流时有节点缺失，可能原因有：

      1. 你用的不是最新开发版（nightly）。
      2. 你用的是稳定版或桌面版（没有包含最新的更新）。
      3. 启动时有些节点导入失败。
    </Tab>

    <Tab title="桌面版或云端用户">
      * 桌面版是基于 ComfyUI 稳定版本构建的，它会在有新的桌面稳定版本发布时自动更新。
      * [Cloud](https://cloud.comfy.org) 会在 ComfyUI 稳定版本发布后更新，我们会同步更新 Cloud。

      所以，如果你发现本教程中有任何核心节点缺失，那是因为对应的节点支持还在开发中没有发布正式的稳定版，请等待下一个稳定版本发布。
    </Tab>
  </Tabs>
</Tip>

## 工作流共用模型

在文生视频和图生视频的工作流中下面的这些模型是共有的，请完成下载并保存到指定目录中

* [clip\_l.safetensors](https://huggingface.co/Comfy-Org/HunyuanVideo_repackaged/resolve/main/split_files/text_encoders/clip_l.safetensors?download=true)
* [llava\_llama3\_fp8\_scaled.safetensors](https://huggingface.co/Comfy-Org/HunyuanVideo_repackaged/resolve/main/split_files/text_encoders/llava_llama3_fp8_scaled.safetensors?download=true)
* [hunyuan\_video\_vae\_bf16.safetensors](https://huggingface.co/Comfy-Org/HunyuanVideo_repackaged/resolve/main/split_files/vae/hunyuan_video_vae_bf16.safetensors?download=true)

保存位置：

```
ComfyUI/
├── models/
│   ├── text_encoders/
│   │   ├── clip_l.safetensors
│   │   └── llava_llama3_fp8_scaled.safetensors
│   ├── vae/
│   │   └── hunyuan_video_vae_bf16.safetensors
```

## 混元文生视频工作流

混元文生视频开源于 2024 年 12 月，支持通过自然语言描述生成 5 秒的短视频，支持中英文输入。

### 1. 文生视频相关工作流

请保存下面的图片，并拖入 ComfyUI 以加载工作流
![ComfyUI 工作流 - 混元文生视频](https://raw.githubusercontent.com/Comfy-Org/example_workflows/main/hunyuan-video/t2v/kitchen.webp)

### 2. 混元文生图模型

请下载 [hunyuan\_video\_t2v\_720p\_bf16.safetensors](https://huggingface.co/Comfy-Org/HunyuanVideo_repackaged/resolve/main/split_files/diffusion_models/hunyuan_video_t2v_720p_bf16.safetensors?download=true) 并保存至 `ComfyUI/models/diffusion_models` 文件夹中

确保包括共用模型文件夹有以下完整的模型文件：

```
ComfyUI/
├── models/
│   ├── text_encoders/
│   │   ├── clip_l.safetensors                       // 共用模型
│   │   └── llava_llama3_fp8_scaled.safetensors      // 共用模型
│   ├── vae/
│   │   └── hunyuan_video_vae_bf16.safetensors       // 共用模型
│   └── diffusion_models/
│       └── hunyuan_video_t2v_720p_bf16.safetensors  // T2V 模型
```

### 3. 按步骤完成工作流的运行

<img src="https://mintcdn.com/dripart/OVkvfOwYrH10fL3Y/images/tutorial/advanced/hunyuanvideo/flow_diagram_t2v.jpg?fit=max&auto=format&n=OVkvfOwYrH10fL3Y&q=85&s=8cf9db23e82c1c31702966878d7d6326" alt="ComfyUI 混元视频 T2V 工作流" width="4004" height="1810" data-path="images/tutorial/advanced/hunyuanvideo/flow_diagram_t2v.jpg" />

1. 确保在`DualCLIPLoader`中下面的模型已加载：
   * clip\_name1: clip\_l.safetensors
   * clip\_name2: llava\_llama3\_fp8\_scaled.safetensors
2. 确保在`Load Diffusion Model`加载了`hunyuan_video_t2v_720p_bf16.safetensors`
3. 确保在`Load VAE`中加载了`hunyuan_video_vae_bf16.safetensors`
4. 点击 `Queue` 按钮，或者使用快捷键 `Ctrl(cmd) + Enter(回车)` 来运行工作流

<Tip>
  `EmptyHunyuanLatentVideo` 节点的 `length` 设置为 1 时，该模型可以生成静态图像。
</Tip>

## 混元图生视频工作流

混元图生视频模型开源于2025年3月6日，基于 HunyuanVideo 框架，支持将静态图像转化为流畅的高质量视频，同时开放了 LoRA 训练代码，支持定制特殊视频效果如：头发生长、物体变形等等。

目前混元图生视频模型分为两个版本：

* v1 “concat” : 视频的运动流畅性较好，但比较少遵循图像引导
* v2 “replace”: 在v1 更新后的次日更新的版本，图像的引导性较好，但相对于 V1 版本似乎不那么有活力

<div class="flex justify-between">
  <div class="text-center">
    <p>v1 “concat”</p>

    <img src="https://comfyanonymous.github.io/ComfyUI_examples/hunyuan_video/hunyuan_video_image_to_video.webp" alt="HunyuanVideo v1" />
  </div>

  <div class="text-center">
    <p>v2 “replace”</p>

    <img src="https://comfyanonymous.github.io/ComfyUI_examples/hunyuan_video/hunyuan_video_image_to_video_v2.webp" alt="HunyuanVideo v2" />
  </div>
</div>

### v1 及 v2 版本共用的模型

请下载下面的文件，并保存到 `ComfyUI/models/clip_vision` 目录中

* [llava\_llama3\_vision.safetensors](https://huggingface.co/Comfy-Org/HunyuanVideo_repackaged/resolve/main/split_files/clip_vision/llava_llama3_vision.safetensors?download=true)

### v1 “concat” 图生视频工作流

#### 1. 工作流及相关素材

请下载下面的工作流图片,并拖入 ComfyUI 以加载工作流
![ComfyUI 工作流 - 混元图生视频v1](https://raw.githubusercontent.com/Comfy-Org/example_workflows/main/hunyuan-video/i2v/v1_robot.webp)

请下载下面的图片，我们将使用它作为图生视频的起始帧
![起始帧](https://raw.githubusercontent.com/Comfy-Org/example_workflows/refs/heads/main/hunyuan-video/i2v/robot-ballet.png)

#### 2. v1 版本模型

* [hunyuan\_video\_image\_to\_video\_720p\_bf16.safetensors](https://huggingface.co/Comfy-Org/HunyuanVideo_repackaged/resolve/main/split_files/diffusion_models/hunyuan_video_image_to_video_720p_bf16.safetensors?download=true)

确保包括共用模型文件夹有以下完整的模型文件：

```
ComfyUI/
├── models/
│   ├── clip_vision/
│   │   └── llava_llama3_vision.safetensors                     // I2V 共用模型
│   ├── text_encoders/
│   │   ├── clip_l.safetensors                                  //  共用模型
│   │   └── llava_llama3_fp8_scaled.safetensors                 //  共用模型
│   ├── vae/
│   │   └── hunyuan_video_vae_bf16.safetensors                  // 共用模型
│   └── diffusion_models/
│       └── hunyuan_video_image_to_video_720p_bf16.safetensors  // I2V v1 "concat" 版本模型
```

#### 3. 按步骤完成工作流

<img src="https://mintcdn.com/dripart/OVkvfOwYrH10fL3Y/images/tutorial/advanced/hunyuanvideo/flow_diagram_i2v_v1.jpg?fit=max&auto=format&n=OVkvfOwYrH10fL3Y&q=85&s=66d1fd271cc2a45a4fbcd92850074912" alt="ComfyUI 混元视频I2V v1 工作流" width="4604" height="1780" data-path="images/tutorial/advanced/hunyuanvideo/flow_diagram_i2v_v1.jpg" />

1. 确保 `DualCLIPLoader` 中下面的模型已加载：
   * clip\_name1: clip\_l.safetensors
   * clip\_name2: llava\_llama3\_fp8\_scaled.safetensors
2. 确保  `Load CLIP Vision` 加载了 `llava_llama3_vision.safetensors`
3. 请在 `Load Image Model` 加载了 `hunyuan_video_image_to_video_720p_bf16.safetensors`
4. 确保 `Load VAE` 中加载了 `hunyuan_video_vae_bf16.safetensors`
5. 确保 `Load Diffusion Model` 中加载了 `hunyuan_video_image_to_video_720p_bf16.safetensors`
6. 点击 `Queue` 按钮，或者使用快捷键 `Ctrl(cmd) + Enter(回车)` 来运行工作流

### v2 “replace” 图生视频工作流

v2 版本的工作流与 v1 版本的工作流基本相同，你只需要下载一个 **replace** 的模型，然后在 `Load Diffusion Model` 中使用即可。

#### 1. 工作流及相关素材

请下载下面的工作流图片,并拖入 ComfyUI 以加载工作流

![ComfyUI 工作流 - 混元图生视频v1](https://raw.githubusercontent.com/Comfy-Org/example_workflows/main/hunyuan-video/i2v/v2_fennec_gril.webp)

请下载下面的图片，我们将使用它作为图生视频的起始帧
![起始帧](https://comfyanonymous.github.io/ComfyUI_examples/flux/flux_dev_example.png)

#### 2. v2 版本模型

* [hunyuan\_video\_v2\_replace\_image\_to\_video\_720p\_bf16.safetensors](https://huggingface.co/Comfy-Org/HunyuanVideo_repackaged/resolve/main/split_files/diffusion_models/hunyuan_video_v2_replace_image_to_video_720p_bf16.safetensors?download=true)

确保包括共用模型文件夹有以下完整的模型文件：

```
ComfyUI/
├── models/
│   ├── clip_vision/
│   │   └── llava_llama3_vision.safetensors                                // I2V 共用模型
│   ├── text_encoders/
│   │   ├── clip_l.safetensors                                             //  共用模型
│   │   └── llava_llama3_fp8_scaled.safetensors                            //  共用模型
│   ├── vae/
│   │   └── hunyuan_video_vae_bf16.safetensors                             //  共用模型
│   └── diffusion_models/
│       └── hunyuan_video_v2_replace_image_to_video_720p_bf16.safetensors  // V2 "replace" 版本模型
```

#### 3. 按步骤完成工作流

<img src="https://mintcdn.com/dripart/OVkvfOwYrH10fL3Y/images/tutorial/advanced/hunyuanvideo/flow_diagram_i2v_v2.jpg?fit=max&auto=format&n=OVkvfOwYrH10fL3Y&q=85&s=f26ddd8edc837fbf9d2bb4f6459a82ee" alt="ComfyUI 混元视频I2V v2 工作流" width="4604" height="1780" data-path="images/tutorial/advanced/hunyuanvideo/flow_diagram_i2v_v2.jpg" />

1. 确保 `DualCLIPLoader` 中下面的模型已加载：
   * clip\_name1: clip\_l.safetensors
   * clip\_name2: llava\_llama3\_fp8\_scaled.safetensors
2. 确保 `Load CLIP Vision` 加载了 `llava_llama3_vision.safetensors`
3. 请在 `Load Image Model` 加载了 `hunyuan_video_image_to_video_720p_bf16.safetensors`
4. 确保 `Load VAE` 中加载了 `hunyuan_video_vae_bf16.safetensors`
5. 确保 `Load Diffusion Model` 中加载了 `hunyuan_video_v2_replace_image_to_video_720p_bf16.safetensors`
6. 点击 `Queue` 按钮，或者使用快捷键 `Ctrl(cmd) + Enter(回车)` 来运行工作流

## 开始你的尝试

下面是我们提供了一些示例图片和对应的提示词，你可以基于这些内容，进行修改，创作出属于你自己的视频。

<img src="https://mintcdn.com/dripart/OVkvfOwYrH10fL3Y/images/tutorial/advanced/hunyuanvideo/humanoid_android_dressed_in_a_flowing.png?fit=max&auto=format&n=OVkvfOwYrH10fL3Y&q=85&s=16d6b0ea15e14c74e8d2e5bfacfe4bf8" alt="example" width="1024" height="1024" data-path="images/tutorial/advanced/hunyuanvideo/humanoid_android_dressed_in_a_flowing.png" />

```
Futuristic robot dancing ballet, dynamic motion, fast motion, fast shot, moving scene
```

***

<img src="https://mintcdn.com/dripart/OVkvfOwYrH10fL3Y/images/tutorial/advanced/hunyuanvideo/samurai.png?fit=max&auto=format&n=OVkvfOwYrH10fL3Y&q=85&s=f8a76a691a7a9ebda088941350538375" alt="example" width="1024" height="1024" data-path="images/tutorial/advanced/hunyuanvideo/samurai.png" />

```
Samurai waving sword and hitting the camera. camera angle movement, zoom in, fast scene, super fast, dynamic
```

***

<img src="https://mintcdn.com/dripart/NmGUk_QSXQXRVtZP/images/tutorial/advanced/hunyuanvideo/a_flying_car.png?fit=max&auto=format&n=NmGUk_QSXQXRVtZP&q=85&s=aa2ce4f30c4d367170a8a696e62a7c7e" alt="example" width="1024" height="1024" data-path="images/tutorial/advanced/hunyuanvideo/a_flying_car.png" />

```
flying car fastly moving and flying through the city
```

***

<img src="https://mintcdn.com/dripart/NmGUk_QSXQXRVtZP/images/tutorial/advanced/hunyuanvideo/cyber_car_race.png?fit=max&auto=format&n=NmGUk_QSXQXRVtZP&q=85&s=875b086bd33ac131bda4fe6c718b9bc7" alt="example" width="1024" height="1024" data-path="images/tutorial/advanced/hunyuanvideo/cyber_car_race.png" />

```
cyberpunk car race in night city, dynamic, super fast, fast shot
```
