> ## Documentation Index
> Fetch the complete documentation index at: https://docs.comfy.org/llms.txt
> Use this file to discover all available pages before exploring further.

# Wan-Alpha 教程

> 学习如何在 ComfyUI 中使用 Wan-Alpha 生成带有 Alpha 通道透明度的视频

Wan-Alpha 是一个专门的文本生成视频模型,可以生成带有 Alpha 通道透明度的高质量视频。它基于 Wan2.1-14B-T2V 基础模型构建,能够创建具有透明背景和半透明物体的视频,非常适合合成工作流程。

该模型擅长生成透明背景、半透明物体(气泡、玻璃、水)、发光效果以及具有适当 Alpha 通道的精细细节(头发、烟雾、粒子)。

# 视频教程

<iframe width="560" height="315" src="https://www.youtube.com/embed/OyDjj7OPUzA" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen />

[下载工作流](https://github.com/Comfy-Org/workflows/blob/main/tutorial_workflows/Get_Comfy_With_Comfy_Wan_Alpha.json)

## 资源

* [Wan-Alpha GitHub](https://github.com/WeChatCV/Wan-Alpha)
* [Hugging Face 模型](https://huggingface.co/htdong/Wan-Alpha)
* [ComfyUI 版本](https://huggingface.co/htdong/Wan-Alpha_ComfyUI)
* [研究论文](https://arxiv.org/pdf/2509.24979)
