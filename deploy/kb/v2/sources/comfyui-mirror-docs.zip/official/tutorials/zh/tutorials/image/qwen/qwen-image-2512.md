> ## Documentation Index
> Fetch the complete documentation index at: https://docs.comfy.org/llms.txt
> Use this file to discover all available pages before exploring further.

# Qwen-Image-2512 ComfyUI 原生工作流示例

> Qwen-Image-2512 是 Qwen-Image 文生图基础模型的 12 月更新版本，具有增强的人物真实感、更精细的自然细节和改进的文字渲染能力。

**Qwen-Image-2512** 是 Qwen-Image 文生图基础模型的 12 月更新版本。与 8 月发布的基础 Qwen-Image 模型相比，Qwen-Image-2512 在图像质量和真实感方面有显著提升。

**Qwen-Image-2512 的主要增强**：

* **增强的人物真实感**：显著减少"AI生成"的感觉，大幅提升整体图像真实性，尤其是人物主体
* **更精细的自然细节**：风景、动物毛发和其他自然元素的渲染更加细腻
* **改进的文字渲染**：提高文字元素的准确性和质量，实现更好的排版和更忠实的多模态（文字+图像）组合

**官方链接**：

* [GitHub 仓库](https://github.com/QwenLM/Qwen-Image)
* [Hugging Face](https://huggingface.co/Qwen/Qwen-Image-2512)
* [ModelScope](https://modelscope.cn/models/Qwen/Qwen-Image-2512)
* [技术报告](https://qianwen-res.oss-cn-beijing.aliyuncs.com/Qwen-Image/Qwen_Image.pdf)
* [博客](https://qwen.ai/blog?id=qwen-image-2512)

## 支持的宽高比

| 宽高比  | 分辨率       |
| ---- | --------- |
| 1:1  | 1328x1328 |
| 16:9 | 1664x928  |
| 9:16 | 928x1664  |
| 4:3  | 1472x1104 |
| 3:4  | 1104x1472 |
| 3:2  | 1584x1056 |
| 2:3  | 1056x1584 |

## Qwen-Image-2512 ComfyUI 原生工作流示例

<Tip>
  <Tabs>
    <Tab title="便携版或手动安装用户">
      请确保你的 ComfyUI 已经更新。

      * [ComfyUI 下载](https://www.comfy.org/download)
      * [ComfyUI 更新教程](/zh/installation/update_comfyui)

      本指南里的工作流可以在 ComfyUI 的[工作流模板](/zh/interface/features/template)中找到。如果找不到，可能是 ComfyUI 没有更新。

      如果加载工作流时有节点缺失，可能原因有：

      1. 你用的不是最新开发版（nightly）。
      2. 你用的是稳定版或桌面版（没有包含最新的更新）。
      3. 启动时有些节点导入失败。
    </Tab>

    <Tab title="桌面版或云端用户">
      * 桌面版是基于 ComfyUI 稳定版本构建的，它会在有新的桌面稳定版本发布时自动更新。
      * [Cloud](https://cloud.comfy.org) 会在 ComfyUI 稳定版本发布后更新，我们会同步更新 Cloud。

      所以，如果你发现本教程中有任何核心节点缺失，那是因为对应的节点支持还在开发中没有发布正式的稳定版，请等待下一个稳定版本发布。
    </Tab>
  </Tabs>
</Tip>

<a href="https://cloud.comfy.org/?template=image_qwen_Image_2512&utm_source=docs" style={{ display: 'inline-block', backgroundColor: '#7c3aed', color: '#ffffff', padding: '10px 20px', borderRadius: '8px', borderColor: "transparent", textDecoration: 'none', fontWeight: 'bold', marginBottom: '1rem'}}>
  在 Comfy Cloud 上运行
</a>

### 1. 工作流文件

更新 ComfyUI 后，您可以在模板中找到工作流文件，或将下面的工作流拖入 ComfyUI 加载。

工作流包含两个子图：

* **Text to Image (Qwen-Image 2512)**：标准 50 步生成
* **Text to Image (Qwen-Image 2512 4steps)**：使用 Lightning LoRA 的 4 步加速生成

<a className="prose" target="_blank" href="https://raw.githubusercontent.com/Comfy-Org/workflow_templates/refs/heads/main/templates/image_qwen_Image_2512.json" style={{ display: 'inline-block', backgroundColor: '#0078D6', color: '#ffffff', padding: '10px 20px', borderRadius: '8px', borderColor: "transparent", textDecoration: 'none', fontWeight: 'bold'}}>
  <p className="prose" style={{ margin: 0, fontSize: "0.8rem" }}>下载 JSON 工作流</p>
</a>

### 2. 模型下载

**文本编码器**

* [qwen\_2.5\_vl\_7b\_fp8\_scaled.safetensors](https://huggingface.co/Comfy-Org/Qwen-Image_ComfyUI/resolve/main/split_files/text_encoders/qwen_2.5_vl_7b_fp8_scaled.safetensors)

**LoRA（可选 - 用于 4 步 Lightning 加速）**

* [Qwen-Image-Lightning-4steps-V1.0.safetensors](https://huggingface.co/lightx2v/Qwen-Image-Lightning/resolve/main/Qwen-Image-Lightning-4steps-V1.0.safetensors)

**扩散模型**

* [qwen\_image\_2512\_fp8\_e4m3fn.safetensors](https://huggingface.co/Comfy-Org/Qwen-Image_ComfyUI/resolve/main/split_files/diffusion_models/qwen_image_2512_fp8_e4m3fn.safetensors)（推荐大多数用户使用）
* [qwen\_image\_2512\_bf16.safetensors](https://huggingface.co/Comfy-Org/Qwen-Image_ComfyUI/resolve/main/split_files/diffusion_models/qwen_image_2512_bf16.safetensors)（如果您有足够的显存并想要更好的质量）

**VAE**

* [qwen\_image\_vae.safetensors](https://huggingface.co/Comfy-Org/Qwen-Image_ComfyUI/resolve/main/split_files/vae/qwen_image_vae.safetensors)

**模型存储位置**

```
📂 ComfyUI/
├── 📂 models/
│   ├── 📂 text_encoders/
│   │      └── qwen_2.5_vl_7b_fp8_scaled.safetensors
│   ├── 📂 loras/
│   │      └── Qwen-Image-Lightning-4steps-V1.0.safetensors
│   ├── 📂 diffusion_models/
│   │      ├── qwen_image_2512_bf16.safetensors
│   │      └── qwen_image_2512_fp8_e4m3fn.safetensors
│   └── 📂 vae/
│          └── qwen_image_vae.safetensors
```
