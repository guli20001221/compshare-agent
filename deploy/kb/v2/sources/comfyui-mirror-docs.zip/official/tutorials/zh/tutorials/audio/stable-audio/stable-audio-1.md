> ## Documentation Index
> Fetch the complete documentation index at: https://docs.comfy.org/llms.txt
> Use this file to discover all available pages before exploring further.

# Stable Audio 1.0 ComfyUI 工作流示例

> 本文介绍如何在 ComfyUI 中使用 Stability AI 的开源模型 Stable Audio 1.0 进行文本转音频生成。

<Tip>
  <Tabs>
    <Tab title="便携版或手动安装用户">
      请确保你的 ComfyUI 已经更新。

      * [ComfyUI 下载](https://www.comfy.org/download)
      * [ComfyUI 更新教程](/zh/installation/update_comfyui)

      本指南里的工作流可以在 ComfyUI 的[工作流模板](/zh/interface/features/template)中找到。如果找不到，可能是 ComfyUI 没有更新。

      如果加载工作流时有节点缺失，可能原因有：

      1. 你用的不是最新开发版（nightly）。
      2. 你用的是稳定版或桌面版（没有包含最新的更新）。
      3. 启动时有些节点导入失败。
    </Tab>

    <Tab title="桌面版或云端用户">
      * 桌面版是基于 ComfyUI 稳定版本构建的，它会在有新的桌面稳定版本发布时自动更新。
      * [Cloud](https://cloud.comfy.org) 会在 ComfyUI 稳定版本发布后更新，我们会同步更新 Cloud。

      所以，如果你发现本教程中有任何核心节点缺失，那是因为对应的节点支持还在开发中没有发布正式的稳定版，请等待下一个稳定版本发布。
    </Tab>
  </Tabs>
</Tip>

**Stable Audio 1.0** 是 Stability AI 首个开源的音频生成模型。它接收文本提示词，生成一段音频片段。在 ComfyUI 中，它使用标准流水线：CLIP 编码提示词、KSampler 去噪潜空间、VAE 解码为音频。

**相关链接**：

* [GitHub: Stability-AI/stable-audio-open-1.0](https://github.com/Stability-AI/stable-audio-open-1.0)

## 工作流

<Card title="下载工作流" icon="download" href="https://github.com/Comfy-Org/workflow_templates/blob/main/templates/audio_stable_audio_example.json">
  下载 JSON 或在模板库中搜索"Stable Audio 1.0"
</Card>

<Card title="在 Comfy Cloud 中运行" icon="cloud" href="https://cloud.comfy.org/?template=audio_stable_audio_example&utm_source=docs&utm_medium=referral&utm_campaign=stable-audio-1">
  在 Comfy Cloud 中打开
</Card>

![Stable Audio 1.0 工作流](https://raw.githubusercontent.com/Comfy-Org/workflow_templates/main/templates/audio_stable_audio_example-1.webp)

使用**标准 ComfyUI 节点**，无需自定义节点。加载 Stable Audio 1.0 检查点，CLIP 文本编码器编码提示词，KSampler 在潜空间中降噪，最后 VAE 解码为音频。

**使用方法**：

1. **加载模型** — `CheckpointLoaderSimple` 使用 `stable-audio-open-1.0.safetensors`
2. **写提示词** — 在 `CLIPTextEncode` 节点输入描述（例如"heaven church electronic dance music"）
3. **设置时长** — 调整 `EmptyLatentAudio` 节点的长度值（默认 47.6 秒）
4. 点击**运行**（`Ctrl/Cmd + Enter`）生成音频。文件将保存在 `ComfyUI/output/audio/`

## 模型下载

加载工作流时，如果模型缺失，ComfyUI 会提示并提供对应下载链接。如需手动设置，请下载以下文件并放在正确目录。

### 检查点

<Card title="stable-audio-open-1.0.safetensors" icon="download" href="https://huggingface.co/StabilityAI/stable-audio-open-1.0/resolve/main/stable-audio-open-1.0.safetensors">
  2.3GB。放入 models/checkpoints/
</Card>

放在以下目录：

```
📂 ComfyUI/
├── 📂 models/
│   └── 📂 checkpoints/
│       └── stable-audio-open-1.0.safetensors
```

### 文本编码器

<Card title="t5-base.safetensors" icon="download" href="https://huggingface.co/Comfy-Org/t5-base/resolve/main/t5-base.safetensors">
  提示词处理的文本编码器。放入 models/text\_encoders/
</Card>

放在以下目录：

```
📂 ComfyUI/
├── 📂 models/
│   └── 📂 text_encoders/
│       └── t5-base.safetensors
```

放置完成后，在 ComfyUI 中按快捷键 **R** 刷新节点定义，即可使用最新加载的模型。
