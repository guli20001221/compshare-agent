> ## Documentation Index
> Fetch the complete documentation index at: https://docs.comfy.org/llms.txt
> Use this file to discover all available pages before exploring further.

# BiRefNet：ComfyUI 图像背景移除工作流

> 学习使用 BiRefNet 模型在 ComfyUI 中移除图像背景

<Tip>
  <Tabs>
    <Tab title="便携版或手动安装用户">
      请确保你的 ComfyUI 已经更新。

      * [ComfyUI 下载](https://www.comfy.org/download)
      * [ComfyUI 更新教程](/zh/installation/update_comfyui)

      本指南里的工作流可以在 ComfyUI 的[工作流模板](/zh/interface/features/template)中找到。如果找不到，可能是 ComfyUI 没有更新。

      如果加载工作流时有节点缺失，可能原因有：

      1. 你用的不是最新开发版（nightly）。
      2. 你用的是稳定版或桌面版（没有包含最新的更新）。
      3. 启动时有些节点导入失败。
    </Tab>

    <Tab title="桌面版或云端用户">
      * 桌面版是基于 ComfyUI 稳定版本构建的，它会在有新的桌面稳定版本发布时自动更新。
      * [Cloud](https://cloud.comfy.org) 会在 ComfyUI 稳定版本发布后更新，我们会同步更新 Cloud。

      所以，如果你发现本教程中有任何核心节点缺失，那是因为对应的节点支持还在开发中没有发布正式的稳定版，请等待下一个稳定版本发布。
    </Tab>
  </Tabs>
</Tip>

BiRefNet（Bilateral Reference Network）是一款高质量的图像背景移除模型。它能为人、产品、动物以及头发或皮毛等细节复杂的物体生成清晰精细的遮罩。

BiRefNet 在 ComfyUI 中获得原生支持（PR [#12747](https://github.com/Comfy-Org/ComfyUI/pull/12747)），模型权重基于 [MIT 协议](https://github.com/ZhengPeng7/BiRefNet/blob/main/LICENSE) 发布。

[Hugging Face 上的 BiRefNet](https://huggingface.co/ZhengPeng7/BiRefNet) | [Comfy-Org 模型仓库](https://huggingface.co/Comfy-Org/BiRefNet) | [论文 (arXiv)](https://arxiv.org/abs/2401.00807)

### 核心优势

* **高质量遮罩** — 头发、皮毛等精细边缘的精确检测
* **通用主体检测** — 对人、产品、动物和复杂场景均有良好效果
* **一键式操作** — 只需加载图像，模型自动完成处理
* **RGBA 输出** — 生成背景透明的图像，可直接用于合成

> **限制：** 背景极其杂乱或主体与背景融合的情况下，遮罩精度可能下降。模型每次处理一张图像。

## BiRefNet 背景移除工作流

### 1. 工作流文件下载

请更新你的 ComfyUI 到最新版本，并通过菜单 `工作流` -> `浏览模板` 找到 Utility 类别下的 "BiRefNet: Remove Background"。

<Card title="下载 JSON 格式工作流" icon="download" href="https://raw.githubusercontent.com/Comfy-Org/workflow_templates/refs/heads/main/templates/utility_birefnet_remove_background.json">
  下载工作流
</Card>

<Card title="在 Comfy Cloud 中运行" icon="cloud" href="https://cloud.comfy.org/?template=utility_birefnet_remove_background&utm_source=docs">
  Open in cloud
</Card>

### 2. 手动下载模型

BiRefNet 模型托管在 [Comfy-Org BiRefNet 模型仓库](https://huggingface.co/Comfy-Org/BiRefNet)。

* [birefnet.safetensors](https://huggingface.co/Comfy-Org/BiRefNet/resolve/main/background_removal/birefnet.safetensors)

放置到以下目录结构：

```
📂 ComfyUI/
└── 📂 models/
    └── 📂 background_removal/
        └── birefnet.safetensors
```

### 3. 使用工作流

* **图像** — 通过 `Load Image` 节点加载图像（放入 ComfyUI 的 `input/` 文件夹）
* `Remove Background (BiRefNet)` 子图会处理图像并输出：
  * **IMAGE** — 背景透明的 RGBA 结果
  * **mask** — 提取的前景遮罩

输出可预览，也可作为其他节点的输入进行合成、进一步编辑或保存。

<Card title="了解 Subgraph" icon="book-open" href="/zh/interface/features/subgraph">
  本工作流使用了 Subgraph 节点实现模块化处理。查阅 Subgraph 文档了解如何自定义和扩展工作流。
</Card>

## 补充说明

* **模型目录** — 模型必须放置在 `ComfyUI/models/background_removal/` 目录，而非 `checkpoints` 文件夹
* **更新需求** — BiRefNet 支持需要较新版本的 ComfyUI，请确保已更新到最新版本
* **RGBA 输出** — 透明背景结果可直接合成到新背景上，或用于下游工作流
