> ## Documentation Index
> Fetch the complete documentation index at: https://docs.comfy.org/llms.txt
> Use this file to discover all available pages before exploring further.

# Qwen 3.0 ComfyUI 工作流示例

> Qwen 3.0 是阿里巴巴云推出的强大开源大语言模型，具备强推理能力，提供 4B 参数版本，适用于文本生成和结构化推理任务。

<Tip>
  <Tabs>
    <Tab title="便携版或手动安装用户">
      请确保你的 ComfyUI 已经更新。

      * [ComfyUI 下载](https://www.comfy.org/download)
      * [ComfyUI 更新教程](/zh/installation/update_comfyui)

      本指南里的工作流可以在 ComfyUI 的[工作流模板](/zh/interface/features/template)中找到。如果找不到，可能是 ComfyUI 没有更新。

      如果加载工作流时有节点缺失，可能原因有：

      1. 你用的不是最新开发版（nightly）。
      2. 你用的是稳定版或桌面版（没有包含最新的更新）。
      3. 启动时有些节点导入失败。
    </Tab>

    <Tab title="桌面版或云端用户">
      * 桌面版是基于 ComfyUI 稳定版本构建的，它会在有新的桌面稳定版本发布时自动更新。
      * [Cloud](https://cloud.comfy.org) 会在 ComfyUI 稳定版本发布后更新，我们会同步更新 Cloud。

      所以，如果你发现本教程中有任何核心节点缺失，那是因为对应的节点支持还在开发中没有发布正式的稳定版，请等待下一个稳定版本发布。
    </Tab>
  </Tabs>
</Tip>

**Qwen 3.0**（又称 Qwen3）是阿里巴巴云推出的强大开源大语言模型，专为文本生成、推理和结构化分析而设计。它通过内置的 `TextGenerate` 节点原生支持 ComfyUI。

**模型亮点**：

* **强推理能力** — Qwen3-4B-Thinking 支持逐步链式推理
* **专注文本生成** — 针对结构化文本输出、分析和编程任务进行了优化
* **ComfyUI 原生支持** — 使用内置 `TextGenerate` 节点，无需自定义节点
* **轻量级** — 与 Qwen3.5 共用相同的文本编码器格式，提供 2B/4B/9B 三种版本适应不同硬件

## 使用场景

Qwen 3.0 非常适合在 ComfyUI 工作流中需要结构化文本生成和智能推理的任务：

* **提示词优化** — 将现有提示词输入 Qwen 3.0，让模型重写、扩展或润色以获得更好的图生效果。例如，将简短的关键词提示词转换为包含风格、光照和构图的详细描述。
* **工作流逻辑推理** — 利用模型分析工作流参数、建议处理步骤或生成结构化指令传递给其他节点。
* **文本分析** — 从文本输入中提取信息、分类内容或生成结构化报告。
* **链式推理** — 启用思考模式处理复杂多步任务，在生成最终输出前进行中间推理。

## 可用工作流

### Qwen 3.0：文本生成

<Card title="下载工作流" icon="download" href="https://github.com/Comfy-Org/workflow_templates/blob/main/templates/llm_qwen3_text_gen.json">
  下载 JSON 或在模板库中搜索 "Qwen 3.0 Text Generation"
</Card>

<Card title="在 Comfy Cloud 中运行" icon="cloud" href="https://cloud.comfy.org/?template=llm_qwen3_text_gen&utm_source=docs&utm_medium=referral&utm_campaign=qwen3">
  在 Comfy Cloud 中打开
</Card>

![Qwen 3.0 文本生成工作流](https://raw.githubusercontent.com/Comfy-Org/workflow_templates/main/templates/llm_qwen3_text_gen-1.webp)

本工作流展示了 Qwen 3.0 的核心**文本生成**能力。它接收文本提示词，并利用模型内置的推理能力生成详细的结构化回复。

**输入**：

* **文本提示词** — 你的问题、指令或任务描述

**关键控制**：

* **Max length** — 生成的最大 token 数量（默认 256）
* **Sampling mode** — 开关采样，并调整 temperature、top-k、top-p、重复惩罚和随机种子
* **Thinking mode** — 在最终答案前启用逐步推理
* **Use default template** — 使用模型内置系统提示词模板

**输出**：

* **Generated text** — 模型的纯文本回复

<Card title="了解 Subgraph" icon="book-open" href="/zh/interface/features/subgraph">
  本工作流使用了 Subgraph 节点进行模块化处理。查看 Subgraph 文档了解如何自定义和扩展工作流。
</Card>

## 模型下载

Qwen 3.0 模型以文本编码器的形式加载到 ComfyUI 中，模型文件与 Qwen3.5 共用。根据你的硬件选择合适的版本：

<Card title="Qwen3.5 2B (bf16)" icon="download" href="https://huggingface.co/Comfy-Org/Qwen3.5/resolve/main/text_encoders/qwen3.5_2b_bf16.safetensors">
  轻量版，约 4.5 GB。适合低显存环境和快速下载。
</Card>

<Card title="Qwen3.5 4B (bf16)" icon="download" href="https://huggingface.co/Comfy-Org/Qwen3.5/resolve/main/text_encoders/qwen3.5_4b_bf16.safetensors">
  大小和质量均衡。推荐大多数消费级 GPU。
</Card>

<Card title="Qwen3.5 9B (bf16)" icon="download" href="https://huggingface.co/Comfy-Org/Qwen3.5/resolve/main/text_encoders/qwen3.5_9b_bf16.safetensors">
  最大版本，约 19 GB。输出质量更高，需要更多显存。
</Card>

将下载的 `.safetensors` 文件放入：

```
📂 ComfyUI/
├── 📂 models/
│   └── 📂 text_encoders/
│       └── qwen3.5_4b_bf16.safetensors   # 或 2b / 9b 版本
```
