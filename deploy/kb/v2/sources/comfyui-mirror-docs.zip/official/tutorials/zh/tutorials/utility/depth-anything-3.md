> ## Documentation Index
> Fetch the complete documentation index at: https://docs.comfy.org/llms.txt
> Use this file to discover all available pages before exploring further.

# ComfyUI Depth Anything 3 官方示例

> 了解如何在 ComfyUI 中使用 Depth Anything 3 进行单目和多视角深度估计，支持图像和视频输入。

# ComfyUI Depth Anything 3 简介

[Depth Anything 3 (DA3)](https://github.com/ByteDance-Seed/Depth-Anything-3) 来自字节跳动豆包团队，是一个视觉 Transformer，能够从任意视觉输入中恢复空间一致的几何信息，无论是否具有已知的相机位姿。单个 DINO 编码器和统一的深度-射线表示使得同一模型家族能够覆盖单目深度、多视角深度、相机位姿估计和 3D 重建。

主要能力：

* **统一单目与多视角深度**：从单张图像或多张图像估计深度
* **相机位姿估计**：从无序图像集合中恢复相机位置
* **3D 重建**：支持多视角输入
* **视频深度估计**：为视频输入生成逐帧深度序列
* **多种模型变体**：Small、Base、Mono/Metric Large

<Tip>
  <Tabs>
    <Tab title="便携版或手动安装用户">
      请确保你的 ComfyUI 已经更新。

      * [ComfyUI 下载](https://www.comfy.org/download)
      * [ComfyUI 更新教程](/zh/installation/update_comfyui)

      本指南里的工作流可以在 ComfyUI 的[工作流模板](/zh/interface/features/template)中找到。如果找不到，可能是 ComfyUI 没有更新。

      如果加载工作流时有节点缺失，可能原因有：

      1. 你用的不是最新开发版（nightly）。
      2. 你用的是稳定版或桌面版（没有包含最新的更新）。
      3. 启动时有些节点导入失败。
    </Tab>

    <Tab title="桌面版或云端用户">
      * 桌面版是基于 ComfyUI 稳定版本构建的，它会在有新的桌面稳定版本发布时自动更新。
      * [Cloud](https://cloud.comfy.org) 会在 ComfyUI 稳定版本发布后更新，我们会同步更新 Cloud。

      所以，如果你发现本教程中有任何核心节点缺失，那是因为对应的节点支持还在开发中没有发布正式的稳定版，请等待下一个稳定版本发布。
    </Tab>
  </Tabs>
</Tip>

<Tip>
  ComfyUI 现已原生支持 Depth Anything 3 节点。开始前请确保已更新到最新版本的 [ComfyUI](https://github.com/Comfy-Org/ComfyUI)。
</Tip>

## 模型下载

下载 Depth Anything 3 的模型文件并将其保存到对应的 ComfyUI 文件夹：

* **Small** ([depth\_anything\_3\_small.safetensors](https://huggingface.co/Comfy-Org/Depth-Anything-3/resolve/main/geometry_estimation/depth_anything_3_small.safetensors)) — 轻量快速推理
* **Base** ([depth\_anything\_3\_base.safetensors](https://huggingface.co/Comfy-Org/Depth-Anything-3/resolve/main/geometry_estimation/depth_anything_3_base.safetensors)) — 平衡性能
* **Mono-Large** ([depth\_anything\_3\_mono\_large.safetensors](https://huggingface.co/Comfy-Org/Depth-Anything-3/resolve/main/geometry_estimation/depth_anything_3_mono_large.safetensors)) — 最佳单目深度，含天空检测
* **Metric-Large** ([depth\_anything\_3\_metric\_large.safetensors](https://huggingface.co/Comfy-Org/Depth-Anything-3/resolve/main/geometry_estimation/depth_anything_3_metric_large.safetensors)) — 物理度量深度（米级）

```
ComfyUI/
├── models/
│   ├── geometry_estimation/
│   │   ├── depth_anything_3_small.safetensors
│   │   ├── depth_anything_3_base.safetensors
│   │   ├── depth_anything_3_mono_large.safetensors
│   │   └── depth_anything_3_metric_large.safetensors
```

## 示例工作流

***

## 1. 图像深度估计

**功能说明：** 上传一张图像，使用 **Image Depth Estimation (Depth Anything 3)** 生成深度图。结果在 **Depth Preview** 中显示，提供原始图像与深度输出的并排对比视图。

<CardGroup cols={2}>
  <Card title="下载工作流" icon="download" href="https://github.com/Comfy-Org/workflow_templates/blob/main/templates/utility_depth_anything3_image_depth_estimation.json">
    下载 JSON 或在模板库中搜索 "Depth Anything 3"
  </Card>

  <Card title="下载示例图片" icon="image" href="https://raw.githubusercontent.com/Comfy-Org/workflow_templates/main/input/retro_futuristic_home.png">
    获取此工作流的示例输入图片
  </Card>
</CardGroup>

<div style={{display: 'flex', gap: '1rem', flexWrap: 'wrap'}}>
  <img src="https://raw.githubusercontent.com/Comfy-Org/workflow_templates/main/templates/utility_depth_anything3_image_depth_estimation-1.webp" alt="图像深度估计输出" style={{maxWidth: '48%', height: 'auto'}} />

  <img src="https://raw.githubusercontent.com/Comfy-Org/workflow_templates/main/templates/utility_depth_anything3_image_depth_estimation-2.webp" alt="图像深度估计对比" style={{maxWidth: '48%', height: 'auto'}} />
</div>

### 运行步骤

1. **LoadImage** — 加载输入图像
2. **LoadDA3Model** — 选择 Depth Anything 3 变体
3. **运行** — 点击 Queue 或使用 `Cmd+Enter`
4. 工作流输出深度图和并排比较结果

<Card title="了解子图" icon="book-open" href="/zh/interface/features/subgraph">
  此工作流使用子图节点进行模块化处理。查看子图文档了解如何自定义和扩展工作流。
</Card>

***

## 2. 视频深度估计

**功能说明：** 上传一个视频，运行 **Video Depth Estimation (Depth Anything 3)** 生成逐帧深度序列。在子图内部，**GetVideoComponents** 将输入视频拆分为帧，**LoadDA3Model** 加载模型，**SetVideoComponents** 将深度帧重新组合为视频输出。

<CardGroup cols={2}>
  <Card title="下载工作流" icon="download" href="https://github.com/Comfy-Org/workflow_templates/blob/main/templates/utility_depth_anything3_video_depth_estimation.json">
    下载 JSON 或在模板库中搜索 "Depth Anything 3"
  </Card>

  <Card title="在 Comfy Cloud 运行" icon="cloud" href="https://cloud.comfy.org/?template=utility_depth_anything3_video_depth_estimation&utm_source=docs&utm_medium=referral&utm_campaign=depth-anything-3">
    在 Comfy Cloud 中打开
  </Card>
</CardGroup>

![视频深度估计预览](https://raw.githubusercontent.com/Comfy-Org/workflow_templates/main/templates/utility_depth_anything3_video_depth_estimation-1.webp)

### 运行步骤

1. **LoadVideo** — 加载输入视频
2. **选择模型** — 在 **Small**、**Base**、**Mono-Large** 或 **Metric-Large** 中选择
3. **运行** — 点击 Queue 或使用 `Cmd+Enter`
4. 工作流输出逐帧深度图视频

<Card title="了解子图" icon="book-open" href="/zh/interface/features/subgraph">
  此工作流使用子图节点进行模块化处理。查看子图文档了解如何自定义和扩展工作流。
</Card>

## 模型变体

| 变体               | head\_type | 天空检测 | 置信度 | 相机解码 | 最佳用途         |
| ---------------- | ---------- | :--: | :-: | :--: | ------------ |
| **Small**        | dualdpt    |   ❌  |  ✅  |   ✅  | 快速推理、移动/边缘设备 |
| **Base**         | dualdpt    |   ❌  |  ✅  |   ✅  | 均衡性能         |
| **Mono-Large**   | dpt        |   ✅  |  ❌  |   ❌  | 带天空检测的单目深度   |
| **Metric-Large** | dpt        |   ✅  |  ❌  |   ❌  | 物理度量深度（米级输出） |

* **Small** 和 **Base** 使用 `dualdpt` 头类型，支持置信度估计和相机解码器，适用于多视角应用。
* **Mono-Large** 和 **Metric-Large** 使用 `dpt` 头类型，支持天空检测。Metric-Large 输出原始米级深度。

## 社区资源

* [Depth Anything 3 GitHub (ByteDance-Seed)](https://github.com/ByteDance-Seed/Depth-Anything-3) — 研究论文和代码
* [Comfy-Org/Depth-Anything-3](https://huggingface.co/Comfy-Org/Depth-Anything-3) — 官方 ComfyUI 模型权重
