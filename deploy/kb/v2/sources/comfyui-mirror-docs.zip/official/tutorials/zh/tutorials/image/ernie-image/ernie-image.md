> ## Documentation Index
> Fetch the complete documentation index at: https://docs.comfy.org/llms.txt
> Use this file to discover all available pages before exploring further.

# ERNIE-Image ComfyUI 工作流示例

> ERNIE-Image 是百度开源的 8B 扩散变换器文生图模型，具备精准文字渲染、强大的指令跟随能力，并内置提示词增强器。

**ERNIE-Image** 是百度开源的文生图模型，基于 Apache-2.0 协议发布。该模型基于 **8B** 参数的扩散变换器（DiT）构建，支持精准文字渲染、强大的指令跟随以及结构化视觉生成，可产出高质量图像。

模型内置 **提示词增强器**（3B），可将简短输入扩展为更丰富的提示词，从而获得更好的生成效果。

**模型亮点**：

* **精准文字渲染** — 支持英文、中文等语言的密集及布局敏感型文字
* **强大的指令跟随** — 能处理复杂提示词、多对象关系及知识密集型描述
* **结构化视觉生成** — 海报、漫画/动漫分镜、多面板构图
* **广泛的风格范围** — 从写实摄影到电影级美学
* **轻量易部署** — 8B 参数，24 GB 显存即可运行
* **内置提示词增强器** — 3B 模型，可将简短输入扩展为更丰富的提示词

**相关链接**：

* [Hugging Face（ERNIE-Image）](https://huggingface.co/Baidu/ERNIE-Image)
* [Hugging Face（ComfyUI 支持）](https://huggingface.co/Comfy-Org/ERNIE-Image)

## ERNIE-Image 文生图工作流

<Card title="下载工作流" icon="download" href="https://raw.githubusercontent.com/Comfy-Org/workflow_templates/refs/heads/main/templates/image_ernie_image.json">
  下载 ERNIE-Image 文生图工作流 JSON 文件。
</Card>

<Card title="在 Comfy Cloud 上运行" icon="cloud" href="https://cloud.comfy.org/?template=image_ernie_image&utm_source=docs">
  在 Comfy Cloud 上直接运行此工作流。
</Card>

<Tip>
  <Tabs>
    <Tab title="便携版或手动安装用户">
      请确保你的 ComfyUI 已经更新。

      * [ComfyUI 下载](https://www.comfy.org/download)
      * [ComfyUI 更新教程](/zh/installation/update_comfyui)

      本指南里的工作流可以在 ComfyUI 的[工作流模板](/zh/interface/features/template)中找到。如果找不到，可能是 ComfyUI 没有更新。

      如果加载工作流时有节点缺失，可能原因有：

      1. 你用的不是最新开发版（nightly）。
      2. 你用的是稳定版或桌面版（没有包含最新的更新）。
      3. 启动时有些节点导入失败。
    </Tab>

    <Tab title="桌面版或云端用户">
      * 桌面版是基于 ComfyUI 稳定版本构建的，它会在有新的桌面稳定版本发布时自动更新。
      * [Cloud](https://cloud.comfy.org) 会在 ComfyUI 稳定版本发布后更新，我们会同步更新 Cloud。

      所以，如果你发现本教程中有任何核心节点缺失，那是因为对应的节点支持还在开发中没有发布正式的稳定版，请等待下一个稳定版本发布。
    </Tab>
  </Tabs>
</Tip>

### 快速开始

1. 将 ComfyUI 更新至最新版本，或使用 [Comfy Cloud](https://cloud.comfy.org/?template=image_ernie_image\&utm_source=docs)
2. 前往 **模板**，搜索 **ERNIE-Image**
3. 选择 **ERNIE-Image** 工作流
4. 下载缺失的模型，更新提示词，然后点击 **运行**

### ERNIE-Image 模型下载

所有重新打包的模型文件均可在 Hugging Face 的 [Comfy-Org/ERNIE-Image](https://huggingface.co/Comfy-Org/ERNIE-Image) 获取。

<Card title="ernie-image.safetensors" icon="download" href="https://huggingface.co/Comfy-Org/ERNIE-Image/resolve/main/diffusion_models/ernie-image.safetensors">
  ERNIE-Image 扩散模型。
</Card>

<Card title="ministral-3-3b.safetensors" icon="download" href="https://huggingface.co/Comfy-Org/ERNIE-Image/resolve/main/text_encoders/ministral-3-3b.safetensors">
  ERNIE-Image 文本编码器。
</Card>

<Card title="ernie-image-prompt-enhancer.safetensors" icon="download" href="https://huggingface.co/Comfy-Org/ERNIE-Image/resolve/main/text_encoders/ernie-image-prompt-enhancer.safetensors">
  ERNIE-Image 提示词增强器文本编码器。
</Card>

<Card title="flux2-vae.safetensors" icon="download" href="https://huggingface.co/Comfy-Org/ERNIE-Image/resolve/main/vae/flux2-vae.safetensors">
  ERNIE-Image VAE。
</Card>

**模型存储位置**

```
📂 ComfyUI/
├── 📂 models/
│   ├── 📂 diffusion_models/
│   │   └── ernie-image.safetensors
│   ├── 📂 text_encoders/
│   │   ├── ministral-3-3b.safetensors
│   │   └── ernie-image-prompt-enhancer.safetensors
│   └── 📂 vae/
│       └── flux2-vae.safetensors
```

## ERNIE-Image-Turbo

[ERNIE-Image-Turbo](https://huggingface.co/Baidu/ERNIE-Image-Turbo) 是经 DMD 和 RL 优化的快速变体，仅需 **8 步** 即可生成图像，而标准模型需要约 50 步。

<Card title="下载工作流" icon="download" href="https://raw.githubusercontent.com/Comfy-Org/workflow_templates/refs/heads/main/templates/image_ernie_image_turbo.json">
  下载 ERNIE-Image-Turbo 文生图工作流 JSON 文件。
</Card>

<Card title="在 Comfy Cloud 上运行" icon="cloud" href="https://cloud.comfy.org/?template=image_ernie_image_turbo&utm_source=docs">
  在 Comfy Cloud 上直接运行此工作流。
</Card>

### ERNIE-Image-Turbo 模型下载

<Card title="ernie-image-turbo.safetensors" icon="download" href="https://huggingface.co/Comfy-Org/ERNIE-Image/resolve/main/diffusion_models/ernie-image-turbo.safetensors">
  ERNIE-Image-Turbo 扩散模型。
</Card>

<Card title="ministral-3-3b.safetensors" icon="download" href="https://huggingface.co/Comfy-Org/ERNIE-Image/resolve/main/text_encoders/ministral-3-3b.safetensors">
  ERNIE-Image-Turbo 文本编码器。
</Card>

<Card title="ernie-image-prompt-enhancer.safetensors" icon="download" href="https://huggingface.co/Comfy-Org/ERNIE-Image/resolve/main/text_encoders/ernie-image-prompt-enhancer.safetensors">
  ERNIE-Image-Turbo 提示词增强器文本编码器。
</Card>

<Card title="flux2-vae.safetensors" icon="download" href="https://huggingface.co/Comfy-Org/ERNIE-Image/resolve/main/vae/flux2-vae.safetensors">
  ERNIE-Image-Turbo VAE。
</Card>

**模型存储位置**

```
📂 ComfyUI/
├── 📂 models/
│   ├── 📂 diffusion_models/
│   │   └── ernie-image-turbo.safetensors
│   ├── 📂 text_encoders/
│   │   ├── ministral-3-3b.safetensors
│   │   └── ernie-image-prompt-enhancer.safetensors
│   └── 📂 vae/
│       └── flux2-vae.safetensors
```

## 可用模型

| 模型                | 描述                               | 推理步数 | 链接                                                             |
| ----------------- | -------------------------------- | ---- | -------------------------------------------------------------- |
| ERNIE-Image       | 主 SFT 模型 — 更强的质量与指令跟随能力          | 约 50 | [Hugging Face](https://huggingface.co/Baidu/ERNIE-Image)       |
| ERNIE-Image-Turbo | 经 DMD 和 RL 优化的 Turbo 模型 — 更快生成速度 | 8    | [Hugging Face](https://huggingface.co/Baidu/ERNIE-Image-Turbo) |

## 示例

### 文字渲染与设计排版

![咖啡制作流程信息图](https://substack-post-media.s3.amazonaws.com/public/images/1cc1c3e6-e556-45b4-b6a9-205e5610d022_1360x768.png)

<Accordion title="提示词">
  ```text theme={null}
  Educational comic book style infographic showing the coffee making process. The background has a light beige vintage paper texture. At the top center of the image is a bold brown title that reads 'The Coffee Making Process', with a smaller English subtitle 'How Coffee is Made' below. The main part consists of six step blocks connected by brown dotted arrows, arranged in two rows up and down, forming a Z-shaped visual guide.

  The first step in the upper left corner illustrates a coffee tree full of ripe red coffee cherries, with a cut coffee cherry next to it showing the beans inside, labeled 'Step 1: Harvesting Cherries' below the block.
  The second step in the upper middle shows wooden fermentation boxes filled with coffee beans, labeled 'Step 2: Pulping and Fermentation'.
  The third step in the upper right depicts coffee beans being dried under the sun on bamboo mats, labeled 'Step 3: Sun Drying'.
  The fourth step in the lower left shows a vintage metal roasting machine with coffee beans rolling inside and steam rising, labeled 'Step 4: Roasting'.
  The fifth step in the lower middle features a stone grinder pouring out smooth coffee grounds, labeled 'Step 5: Grinding'.
  The sixth step in the lower right shows a production line where coffee liquid is being poured into molds, with finished packaged coffee beside it, labeled 'Step 6: Brewing and Forming'.

  The four corners of the image are decorated with hand-drawn coffee leaves and coffee beans. The overall color palette consists of warm brown, caramel, cream, deep red and olive green, with delicate lines and clear layout.
  ```
</Accordion>

![日本浮世绘风格语言学习卡片](https://substack-post-media.s3.amazonaws.com/public/images/913c7f5e-f1fe-4f19-b811-ad777ed430b7_768x1360.png)

<Accordion title="提示词">
  ```text theme={null}
  Vertical rectangular language learning flashcard in traditional Japanese Ukiyo-e woodblock style. Whole card framed by dark blue traditional Seigaiha wave borders, with aged beige rough washi paper texture background.

  Upper two-thirds: Ukiyo-e illustration. A graceful spotted sika deer stands calmly in the center, with delicate black outlines and traditional flat coloring. Background: classic Japanese scenery — snow-capped Mount Fuji in distance, stylized layered clouds, falling pink cherry blossom petals. A red square antique seal with the Chinese character '鹿' in seal script at the lower right. Color scheme: indigo, vermilion, moss green, beige, with woodblock color misalignment and vintage charm.

  Lower one-third: centered text area. Top: small hiragana しか; large Japanese kanji 鹿; below it romaji shika; then English "Deer". Bottom: bilingual example — Japanese: 鹿が桜の花を見ている。English: The deer is looking at the cherry blossoms. All black text with slight brush calligraphy texture, matching Ukiyo-e antique style.
  ```
</Accordion>

![分屏概念海报](https://substack-post-media.s3.amazonaws.com/public/images/c814eef7-7df4-4f66-8889-e8325fe79dba_768x1360.png)

<Accordion title="提示词">
  ```text theme={null}
  Split-screen conceptual poster with vertical split composition, left half representing the present and future featuring a solid stone analog clock dial with bright red hands and red scale markings, set against a deeply cracked, dry, parched earth texture in muted cool gray tones, embodying slow, static structural decay and temporal erosion, right half representing the past that is violently disintegrating, dissolving and exploding into chaotic dust, debris, flying stone shards and swirling cosmic nebula energy with a deep blood red and black color palette, the circular clock frame itself is half solid weathered stone and half crumbling into particles merging the two worlds, with the red clock hands fully positioned on the left present/future side of the dial, embodying the concept of time, past vs future, slow decay vs violent collapse, hyper-realistic 3D render with cinematic dramatic lighting, high contrast, sharp details on the left side, motion blur and dynamic particle effects on the right side, photorealistic textures of cracked earth and floating dust, atmospheric haze, futuristic graphic design with minimalist red vertical UI elements and custom technical text overlays in the corners, bold red stylized title text "ETERNAL DAWN" in the top right corner, small red technical metadata text "SPECDARY BOTHUNG" directly below the main title in the top right, dense lines of small red technical data blocks including "TIMESTAMP: 00:00:00", "COLLAPSE RATE: 99.8%", "TEMPORAL ANOMALY DETECTED", "PAST DIMENSION: DECAYING" in the bottom right corner with a red horizontal accent bar and footer text "FOR DECAY OF THE EONS" below, small red header text "TEMPORAL SHIFT PROTOCOL" with vertical red accent line running down the left edge in the top left, vertical red accent line with small red technical text annotations including "PRESENT: STABLE", "FUTURE: UNFOLDING" along it in the bottom left, red text "WARNING: TEMPORAL DISINTEGRATION" curving around the center clock dial perimeter, small red footer text "PAST FADES, FUTURE RISES" spanning the split at the bottom center, shot in the style of a high-end sci-fi movie poster, 8K ultra-high resolution, photorealistic, cinematic composition, dramatic depth, moody and intense atmosphere, detailed particle simulation, photorealistic material rendering.
  ```
</Accordion>

### 电影级与风格化美学

![城市夜晚街景](https://substack-post-media.s3.amazonaws.com/public/images/d4f27467-4d1f-4f6d-8c15-ebc92983c29d_1360x768.png)

<Accordion title="提示词">
  ```text theme={null}
  First-person vertical real-world urban night photo. Narrow, wet, busy city street with strong depth; towering buildings on both sides with fire escapes, pipes, AC units, warm window lights. Red vertical "HOTEL" neon on left, bright blue "BAR" sign and yellow "OPEN 24 HOURS" box on right. Distant huge digital billboard glowing cyan "NEON CITY". Rough wet asphalt reflects neon lights; vintage yellow taxi with "TAXI" sign drives down center, red taillights on. Two pedestrians in dark coats with black umbrellas walk away on right sidewalk. Giant needle-like steel TV tower peeks through building gaps at end, red aircraft warning light glowing. Cinematic volumetric light, misty air, cool cyan-blue vs warm orange-red contrast, immersive and realistic.
  ```
</Accordion>

![时尚编辑摄影](https://substack-post-media.s3.amazonaws.com/public/images/3044c459-db9a-453c-88f8-32470fa2ecf9_1360x768.png)

<Accordion title="提示词">
  ```text theme={null}
  Full-body editorial fashion shot, elegant European woman aged 28-30 with soft natural blonde hair styled in a loose low bun, wearing a tailored soft cream ribbed knit long-sleeve maxi dress with a fitted waist and flowing floor-length skirt, minimalist nude leather mules and delicate gold jewelry, standing leaning against an ornate carved stone balustrade on a gravel terrace in the garden of a grand Lake Como villa, tall iconic Italian cypress trees framing the background, calm still Lake Como water stretching out to hazy misty Alpine mountains in the distance, overcast soft diffused natural light, muted warm earthy color palette, quiet luxury aesthetic, hyper-realistic editorial fashion photography, natural skin texture with subtle pores, soft bokeh foreground foliage, shallow depth of field, shot on a medium format camera with an 85mm f/1.4 lens, sharp focus on the subject, fine film grain, muted contrast, timeless sophisticated mood, shot by Lachlan Bailey in the style of Vogue editorial, 8K ultra-high resolution, photorealistic, cinematic composition following the rule of thirds, golden hour overcast lighting, atmospheric haze, refined Italian villa garden details.
  ```
</Accordion>

![拿咖啡的鸭子 3D 插图](https://substack-post-media.s3.amazonaws.com/public/images/01abb65b-6d3e-4b08-a0b2-d0ae539f6516_1024x1024.png)

<Accordion title="提示词">
  ```text theme={null}
  A charming, whimsical 3D illustration featuring a fluffy, plush-textured white duck sitting comfortably in a fuzzy coral-pink armchair, holding a bright red mug of steaming black coffee against a solid warm coral-red background; defined by its tactile, huggable fabric-like texture across all elements, a bold, minimalist warm color palette of creamy white, vibrant orange, and rich reds, gentle anthropomorphism that blends cuteness with relatable cozy relaxation, soft diffused lighting, and a subtle film grain that adds a nostalgic, handcrafted feel, creating a playful yet serene mood perfect for themes of calm downtime and morning routines.
  ```
</Accordion>

### 多面板构图

![北美原生物种信息图](https://substack-post-media.s3.amazonaws.com/public/images/4e9a2968-9f7c-4b2f-92e6-b0fa9a91ede2_1360x768.png)

<Accordion title="提示词">
  ```text theme={null}
  Educational comic book infographic. Five vertical panels side by side, earthy color palette, hand-drawn illustration style. Top title: "NORTH AMERICAN NATIVE SPECIES". Style: comic line art, watercolor fills, white panel backgrounds, bold headers.
  Panel 1: Gray squirrel holding an acorn. Header: "EASTERN GRAY SQUIRREL" Fact: "Buries acorns to help forests grow." Arrow → tail: "Bushy tail"

  Panel 2: Robin with orange-red breast on a branch. Header: "AMERICAN ROBIN" Fact: "A sign of spring returning." Arrow → breast: "Orange-red breast"

  Panel 3: Red maple tree with autumn leaves. Header: "RED MAPLE TREE" Fact: "Shelters wildlife year-round." Arrow → leaves: "Red in autumn"

  Panel 4: Deer with white tail raised. Header: "WHITE-TAILED DEER" Fact: "White tail signals danger." Arrow → tail: "Alarm signal"

  Panel 5: Monarch butterfly on a flower. Header: "MONARCH BUTTERFLY" Fact: "Migrates 3,000 miles each year." Arrow → wings: "Warning colors"
  ```
</Accordion>

![6 格漫画页面](https://substack-post-media.s3.amazonaws.com/public/images/adc8fe73-f431-4bdd-8578-1a18d717d4d7_1360x768.png)

<Accordion title="提示词">
  ```text theme={null}
  A 6-panel comic page, 2 columns × 3 rows, black border between each panel.

  Panel 1 (top-left): wide shot — a young woman in a red coat stands at a rainy train station. Caption box: "She had waited three years for this moment."
  Panel 2 (top-right): close-up on her face — anxious eyes, rain on her cheek. No text.
  Panel 3 (mid-left): medium shot — a train arrives, doors slide open, steam rising. Sound effect text: "WHOOOOSH"
  Panel 4 (mid-right): her point-of-view — a man in a gray jacket steps out, back to camera.
  Panel 5 (bottom-left): extreme close-up — her hand trembling as she reaches forward.
  Panel 6 (bottom-right): wide shot — they face each other under one umbrella. Caption box: "Some arrivals change everything."

  Ink and watercolor style, cool blue-gray palette, expressive line art. Same character design consistent across all 6 panels.
  ```
</Accordion>
