> ## Documentation Index
> Fetch the complete documentation index at: https://docs.comfy.org/llms.txt
> Use this file to discover all available pages before exploring further.

# Gemma 4 ComfyUI 工作流示例

> Gemma 4 是 Google 的新一代多模态开源 LLM 系列，支持文本生成、图像理解、视频分析和音频转录，上下文窗口最高达 256K。提供 2B、4B、31B 三种尺寸。

<Tip>
  <Tabs>
    <Tab title="便携版或手动安装用户">
      请确保你的 ComfyUI 已经更新。

      * [ComfyUI 下载](https://www.comfy.org/download)
      * [ComfyUI 更新教程](/zh/installation/update_comfyui)

      本指南里的工作流可以在 ComfyUI 的[工作流模板](/zh/interface/features/template)中找到。如果找不到，可能是 ComfyUI 没有更新。

      如果加载工作流时有节点缺失，可能原因有：

      1. 你用的不是最新开发版（nightly）。
      2. 你用的是稳定版或桌面版（没有包含最新的更新）。
      3. 启动时有些节点导入失败。
    </Tab>

    <Tab title="桌面版或云端用户">
      * 桌面版是基于 ComfyUI 稳定版本构建的，它会在有新的桌面稳定版本发布时自动更新。
      * [Cloud](https://cloud.comfy.org) 会在 ComfyUI 稳定版本发布后更新，我们会同步更新 Cloud。

      所以，如果你发现本教程中有任何核心节点缺失，那是因为对应的节点支持还在开发中没有发布正式的稳定版，请等待下一个稳定版本发布。
    </Tab>
  </Tabs>
</Tip>

**Gemma 4** 是 Google DeepMind 的新一代轻量级开源 LLM 系列，专为文本生成、图像理解、视频分析、音频转录和结构化工具调用而设计。在 ComfyUI 中作为原生 **文本生成（Text Generation）** 模型提供原生支持。

**模型亮点**：

* **原生多模态** — 可同时接收文本、图像、视频和音频输入
* **三种尺寸可选**：
  * **E2B（2B）** — 快速轻量，适合消费级 GPU
  * **E4B（4B）** — 性能均衡，推荐默认选择
  * **31B** — 最佳质量，需要更高显存
* **思考模式** — 内置逐步推理能力，生成答案前先进行逻辑推演
* **长上下文** — 最高 128K tokens（E2B/E4B）和 256K tokens（31B）
* **多语言** — 开箱支持 35+ 种语言，预训练覆盖 140+
* **函数调用** — 原生支持结构化工具调用和 Agent 工作流
* **ComfyUI 原生支持** — 通过内置的 `TextGenerate` 和 `CLIPLoader` 节点加载和使用

**相关链接**：

* [Hugging Face (Comfy-Org/gemma-4)](https://huggingface.co/Comfy-Org/gemma-4)
* [Google AI for Developers](https://ai.google.dev/gemma)
* [ComfyUI 源码 (nodes\_textgen.py)](https://github.com/Comfy-Org/ComfyUI/blob/master/comfy_extras/nodes_textgen.py)

## 可用工作流

### Gemma 4：文本生成

<Card title="下载工作流" icon="download" href="https://github.com/Comfy-Org/workflow_templates/blob/main/templates/llm_gemma4_text_gen.json">
  下载 JSON 或在模板库中搜索 "Gemma 4 Text Generation"
</Card>

<Card title="在 Comfy Cloud 中运行" icon="cloud" href="https://cloud.comfy.org/?template=llm_gemma4_text_gen&utm_source=docs&utm_medium=referral&utm_campaign=gemma4">
  在 Comfy Cloud 中打开
</Card>

![Gemma 4 文本生成工作流](https://raw.githubusercontent.com/Comfy-Org/workflow_templates/main/templates/llm_gemma4_text_gen-1.webp)

该工作流展示了 Gemma 4 的核心**文本生成**能力。它可以在文本提示词之外，额外接受可选的图像、音频或视频作为上下文输入，并生成自然语言输出——支持推理、编程和多语言提示。

**输入**：

* **文本提示词** — 你的问题或指令
* **图像**（可选）— 用于视觉理解任务（OCR、目标检测、图表阅读等）
* **音频**（可选）— 用于语音识别或转录
* **视频**（可选）— 用于视频帧理解（内部按 1 FPS 采样）

**关键控制参数**：

* **Max length** — 生成的最大 token 数（默认 256）
* **Sampling mode** — 开关采样，调节 temperature、top-k、top-p、重复惩罚和随机种子
* **Thinking mode** — 启用逐步推理，在最终答案前展示思考过程
* **Use default template** — 使用模型内置的系统提示词模板

**输出**：

* **Generated text** — 模型生成的文本响应

<Card title="了解 Subgraph" icon="book-open" href="/zh/interface/features/subgraph">
  该工作流使用 Subgraph 节点实现模块化处理。查看 Subgraph 文档了解如何自定义和扩展工作流。
</Card>

## 模型下载

Gemma 4 模型在 ComfyUI 中以文本编码器（text encoder）形式加载。下载对应的模型文件并放入正确的目录：

<Card title="Gemma 4 2B (E2B IT FP8)" icon="download" href="https://huggingface.co/Comfy-Org/gemma-4/resolve/main/text_encoders/gemma4_e2b_it_fp8_scaled.safetensors">
  快速轻量，推荐消费级 GPU 使用。
</Card>

<Card title="Gemma 4 4B (E4B IT FP8)" icon="download" href="https://huggingface.co/Comfy-Org/gemma-4/resolve/main/text_encoders/gemma4_e4b_it_fp8_scaled.safetensors">
  性能均衡，工作流默认使用此模型。
</Card>

<Card title="查看所有变体" icon="external-link" href="https://huggingface.co/Comfy-Org/gemma-4/tree/main/text_encoders">
  浏览所有 Gemma 4 模型权重。
</Card>

将下载的 `.safetensors` 文件放入以下目录：

```
📂 ComfyUI/
├── 📂 models/
│   └── 📂 text_encoders/
│       └── gemma4_e4b_it_fp8_scaled.safetensors
```
