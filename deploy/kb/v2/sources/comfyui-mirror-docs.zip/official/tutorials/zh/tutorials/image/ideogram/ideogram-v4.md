> ## Documentation Index
> Fetch the complete documentation index at: https://docs.comfy.org/llms.txt
> Use this file to discover all available pages before exploring further.

# ComfyUI Ideogram 4.0 开源模型教程

> 了解如何在 ComfyUI 中使用 Ideogram 4.0 开源模型

Ideogram 4.0 是 Ideogram 最新推出的文生图模型，已作为开源模型发布，可以在本地完全运行。它具有出色的照片级真实感、精准的文字渲染和风格控制能力。你可以使用自然语言或 **结构化 JSON Prompts** 来实现对布局、颜色和图片内文字的精细控制。

<Tip>
  <Tabs>
    <Tab title="便携版或手动安装用户">
      请确保你的 ComfyUI 已经更新。

      * [ComfyUI 下载](https://www.comfy.org/download)
      * [ComfyUI 更新教程](/zh/installation/update_comfyui)

      本指南里的工作流可以在 ComfyUI 的[工作流模板](/zh/interface/features/template)中找到。如果找不到，可能是 ComfyUI 没有更新。

      如果加载工作流时有节点缺失，可能原因有：

      1. 你用的不是最新开发版（nightly）。
      2. 你用的是稳定版或桌面版（没有包含最新的更新）。
      3. 启动时有些节点导入失败。
    </Tab>

    <Tab title="桌面版或云端用户">
      * 桌面版是基于 ComfyUI 稳定版本构建的，它会在有新的桌面稳定版本发布时自动更新。
      * [Cloud](https://cloud.comfy.org) 会在 ComfyUI 稳定版本发布后更新，我们会同步更新 Cloud。

      所以，如果你发现本教程中有任何核心节点缺失，那是因为对应的节点支持还在开发中没有发布正式的稳定版，请等待下一个稳定版本发布。
    </Tab>
  </Tabs>
</Tip>

## Ideogram 4.0 文生图工作流

<Card title="在 Comfy Cloud 中运行" icon="cloud" href="https://cloud.comfy.org/?template=image_ideogram4_t2i&utm_source=docs&utm_medium=referral&utm_campaign=ideogram-v4">
  在 Comfy Cloud 中打开
</Card>

<Card title="下载工作流文件" icon="download" href="https://github.com/Comfy-Org/workflow_templates/blob/main/templates/image_ideogram4_t2i.json">
  下载 JSON 或在模板库中搜索"Ideogram v4: Text to Image"
</Card>

![Ideogram 4.0 生成示例](https://raw.githubusercontent.com/Comfy-Org/workflow_templates/main/output/image_ideogram4_t2i.png)
*Ideogram 4.0 开源模型生成示例*

### Prompt 格式

开源工作流支持两种 prompt 模式：

1. **自然语言** — 快速简单，适合简单想法
2. **结构化 JSON** — 精细控制布局、颜色和风格

工作流中包含一个 prompt 构建模板，你可以配合任何 LLM 使用来生成匹配的 JSON prompt。

工作流内的提示说明：

> 该模型基于结构化 JSON 描述训练（场景摘要、风格块、背景、以及可选的对象级描述，包含边界框和十六进制颜色调色板）。官方推理会根据该 schema 对 prompt 进行验证。

### Ideogram 4.0 模型下载

你可以在 Hugging Face 的 [Comfy-Org/Ideogram-4](https://huggingface.co/Comfy-Org/Ideogram-4) 找到所有重新打包的模型文件。

<Card title="ideogram4_fp8_scaled.safetensors" icon="download" href="https://huggingface.co/Comfy-Org/Ideogram-4/resolve/main/diffusion_models/ideogram4_fp8_scaled.safetensors">
  Ideogram 4.0 扩散模型（\~13.8 GB）。放入 <code>models/diffusion\_models/</code>
</Card>

<Card title="ideogram4_unconditional_fp8_scaled.safetensors" icon="download" href="https://huggingface.co/Comfy-Org/Ideogram-4/resolve/main/diffusion_models/ideogram4_unconditional_fp8_scaled.safetensors">
  Ideogram 4.0 无条件扩散模型（\~13.8 GB）。放入 <code>models/diffusion\_models/</code>
</Card>

<Card title="qwen3vl_8b_fp8_scaled.safetensors" icon="download" href="https://huggingface.co/Comfy-Org/Qwen3-VL/resolve/main/text_encoders/qwen3vl_8b_fp8_scaled.safetensors">
  Ideogram 4.0 文本编码器（\~8 GB）。放入 <code>models/text\_encoders/</code>
</Card>

<Card title="gemma4_e4b_it_fp8_scaled.safetensors" icon="download" href="https://huggingface.co/Comfy-Org/gemma-4/resolve/main/text_encoders/gemma4_e4b_it_fp8_scaled.safetensors">
  Ideogram 4.0 文本编码器（\~2 GB）。放入 <code>models/text\_encoders/</code>
</Card>

<Card title="flux2-vae.safetensors" icon="download" href="https://huggingface.co/Comfy-Org/flux2-dev/resolve/main/split_files/vae/flux2-vae.safetensors">
  Ideogram 4.0 VAE（\~335 MB）。放入 <code>models/vae/</code>
</Card>

**模型存放路径**

```
📂 ComfyUI/
├── 📂 models/
│   ├── 📂 diffusion_models/
│   │   ├── ideogram4_fp8_scaled.safetensors
│   │   └── ideogram4_unconditional_fp8_scaled.safetensors
│   ├── 📂 text_encoders/
│   │   ├── qwen3vl_8b_fp8_scaled.safetensors
│   │   └── gemma4_e4b_it_fp8_scaled.safetensors
│   └── 📂 vae/
│       └── flux2-vae.safetensors
```

<CardGroup cols={2}>
  <Card title="了解 Subgraph 子图" icon="book-open" href="/zh/interface/features/subgraph">
    该工作流使用了 Subgraph 子图节点进行模块化处理。查看子图文档了解如何定制和扩展。
  </Card>
</CardGroup>

### 工作流步骤

1. 下载模型并放入正确目录（见上表）
2. 下载并将工作流文件拖入 ComfyUI
3. 在 Ideogram4 子图节点中输入你的 prompt（自然语言或结构化 JSON）
4. （可选）使用 `ResolutionSelector` 节点调整分辨率
5. 点击 `Run` 或使用快捷键 `Ctrl(cmd) + Enter` 生成图片
6. 在 `Save Image` 节点查看结果 — 输出文件保存在 `ComfyUI/output/`

### 关于安全过滤器的注意事项

如果你看到“Image blocked by safety filter”，这是 Ideogram 4.0 内置的安全过滤器。非 JSON（纯文本）提示词误报率较高。使用结构化 JSON 提示词可降低提示词被阻止的可能性。

更多详情，请参阅 [Ideogram 4 官方提示指南](https://github.com/ideogram-oss/ideogram4/blob/main/docs/prompting.md#safety-filter)。

## Ideogram & ComfyOrg 创始人对谈

一场特别的直播对谈，嘉宾为 Mohammad Norouzi（Ideogram CEO）和 Yoland Yan（ComfyOrg CEO），由 Purz 和 Rob 主持。

<iframe className="w-full aspect-video rounded-xl" src="https://www.youtube.com/embed/gO-D5eO8VlA?si=ehD_qzll3yCzirpP" title="Ideogram 4.0 Live Conversation" allow="accelerometer; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowFullScreen />
