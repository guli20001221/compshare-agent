> ## Documentation Index
> Fetch the complete documentation index at: https://docs.comfy.org/llms.txt
> Use this file to discover all available pages before exploring further.

# ComfyUI Flux.1 fill dev 示例

> 本文将使用Flux.1 fill dev 来完成 Inpainting 和 Outpainting 的工作流示例。

<img src="https://mintcdn.com/dripart/TwfNQ2dEaWQA7tIL/images/tutorial/flux/flux-fill-dev-demo.jpeg?fit=max&auto=format&n=TwfNQ2dEaWQA7tIL&q=85&s=e9b567aff5fbd43dce197d819f5f028e" alt="Flux.1 fill dev" width="2425" height="1439" data-path="images/tutorial/flux/flux-fill-dev-demo.jpeg" />

## Flux.1 fill dev 模型介绍

Flux.1 fill dev 是 [Black Forest Labs](https://blackforestlabs.ai/) 推出的 ​[FLUX.1 Tools 套件](https://blackforestlabs.ai/flux-1-tools/) 中的核心工具之一，专为图像修复和扩展设计。

Flux.1 fill dev 的核心特点：

* 强大的图像重绘(Inpainting)和扩绘(Outpainting)能力，生成效果仅次于商业版的 FLUX.1 Fill \[pro]。
* 出色的提示词理解和跟随能力，能够精确捕捉用户意图并与原图保持高度一致性。
* 采用先进的引导蒸馏训练技术，使模型在保持高质量输出的同时更加高效。
* 友好的许可条款，生成的输出可用于个人、科学和商业目的，具体请参见 [FLUX.1 \[dev\] 非商业许可证](https://huggingface.co/black-forest-labs/FLUX.1-dev/blob/main/LICENSE.md)。

模型开源地址：[FLUX.1 \[dev\]](https://huggingface.co/black-forest-labs/FLUX.1-dev)

本文将基于 Flux.1 fill dev 模型来完成 Inpainting 和 Outpainting 的工作流，
如果你不太了解 Inpainting 和 Outpainting 的工作流可以参考 [ComfyUI 布局重绘示例](/zh/tutorials/basic/inpaint) 和 [ComfyUI 扩图示例](/zh/tutorials/basic/outpaint)，部分的相关说明。

## Flux.1 Fill dev 工作流模型安装

在开始之前，让我们先完成 Flux.1 Fill dev 模型文件的安装， inpainting 和 outpainting 的工作流中会使用完全相同的模型文件，如果你之前使用过完整版本的 [Flux.1 文生图工作流](/zh/tutorials/flux/flux-1-text-to-image)，那么在这个部分你仅需要下载 **flux1-fill-dev.safetensors** 这个模型文件。

不过由于下载对应模型需要同意对应的使用协议，所以请访问 [black-forest-labs/FLUX.1-Fill-dev](https://huggingface.co/black-forest-labs/FLUX.1-Fill-dev)页面，确保你参照下图同意了对应的协议。

<img src="https://mintcdn.com/dripart/TwfNQ2dEaWQA7tIL/images/tutorial/flux/flux1_fill_dev_agreement.jpg?fit=max&auto=format&n=TwfNQ2dEaWQA7tIL&q=85&s=388a26b32b5841dbf6ef32f31537e43d" alt="Flux Agreement" width="2000" height="1091" data-path="images/tutorial/flux/flux1_fill_dev_agreement.jpg" />

完整模型列表：

* [clip\_l.safetensors](https://huggingface.co/comfyanonymous/flux_text_encoders/resolve/main/clip_l.safetensors?download=true)
* [t5xxl\_fp16.safetensors](https://huggingface.co/comfyanonymous/flux_text_encoders/resolve/main/t5xxl_fp16.safetensors?download=true)
* [ae.safetensors](https://huggingface.co/black-forest-labs/FLUX.1-schnell/resolve/main/ae.safetensors?download=true)
* [flux1-fill-dev.safetensors](https://huggingface.co/black-forest-labs/FLUX.1-Fill-dev/resolve/main/flux1-fill-dev.safetensors?download=true)

文件保存位置：

```
ComfyUI/
├── models/
│   ├── text_encoders/
│   │    ├── clip_l.safetensors
│   │    └── t5xxl_fp16.safetensors
│   ├── vae/
│   │    └── ae.safetensors
│   └── diffusion_models/
│        └── flux1-fill-dev.safetensors
```

## Flux.1 Fill dev inpainting 工作流

### 1. Inpainting 工作流及相关素材

<a className="prose" target="_blank" href="https://raw.githubusercontent.com/Comfy-Org/example_workflows/main/flux/inpaint/flux_fill_inpaint.png" style={{ display: 'inline-block', backgroundColor: '#0078D6', color: '#ffffff', padding: '10px 20px', borderRadius: '8px', borderColor: "transparent", textDecoration: 'none', fontWeight: 'bold', marginRight: '10px'}}>
  <p className="prose" style={{ margin: 0, fontSize: "0.8rem" }}>下载工作流图片</p>
</a>

<a className="prose" target="_blank" href="https://cloud.comfy.org/?template=flux_fill_inpaint_example&utm_source=docs" style={{ display: 'inline-block', backgroundColor: '#28a745', color: '#ffffff', padding: '10px 20px', borderRadius: '8px', borderColor: "transparent", textDecoration: 'none', fontWeight: 'bold'}}>
  <p className="prose" style={{ margin: 0, fontSize: "0.8rem" }}>在 Comfy Cloud 上运行</p>
</a>

请下载下面的图片，并拖入 ComfyUI 以加载对应的工作流
![ComfyUI Flux.1 inpaint](https://raw.githubusercontent.com/Comfy-Org/example_workflows/main/flux/inpaint/flux_fill_inpaint.png)

请下载下面的图片，我们将使用它来作为输入图片
![ComfyUI Flux.1 inpaint input](https://raw.githubusercontent.com/Comfy-Org/example_workflows/main/flux/inpaint/flux_fill_inpaint_input.png)

<Note>
  对应的图片已经包含 alpha 通道，所以你不需要额外进行蒙版的绘制, 如果你想要自己进行蒙版的绘制请[点击这里](https://raw.githubusercontent.com/Comfy-Org/example_workflows/main/flux/inpaint/flux_fill_inpaint_input_original.png)获取不带蒙版的版本，并参考 [ComfyUI 布局重绘示例](/zh/tutorials/basic/inpaint) 中的 MaskEditor 的使用部分来了解如何在`Load Image`节点中绘制蒙版。
</Note>

### 2. 参照图片序号检查完成工作流运行

<img src="https://mintcdn.com/dripart/TwfNQ2dEaWQA7tIL/images/tutorial/flux/flow_diagram_inpaint.jpg?fit=max&auto=format&n=TwfNQ2dEaWQA7tIL&q=85&s=8d4238c0487b7ddf527ec044aa02d578" alt="ComfyUI Flux.1 Fill dev Inpainting 工作流" width="4000" height="2163" data-path="images/tutorial/flux/flow_diagram_inpaint.jpg" />

1. 确保在`Load Diffusion Model`节点加载了`flux1-fill-dev.safetensors`
2. 确保在`DualCLIPLoader`节点中下面的模型已加载：
   * clip\_name1: t5xxl\_fp16.safetensors
   * clip\_name2: clip\_l.safetensors
3. 确保在`Load VAE`节点中加载了`ae.safetensors`
4. 在`Load Image`节点中上传了文档中提供的输入图片，如果你使用的是不带蒙版的版本，记得使用遮罩编辑器完成蒙版的绘制
5. 点击 `Queue` 按钮，或者使用快捷键 `Ctrl(cmd) + Enter(回车)` 来运行工作流

## Flux.1 Fill dev Outpainting 工作流

### 1. Outpainting 工作流

请下载下面的图片，并拖入 ComfyUI 以加载对应的工作流
![ComfyUI Flux.1 outpaint](https://raw.githubusercontent.com/Comfy-Org/example_workflows/main/flux/outpaint/flux_fill_dev_outpaint.png)

请下载下面的图片，我们将使用它来作为输入图片
![ComfyUI Flux.1 outpaint input](https://raw.githubusercontent.com/Comfy-Org/example_workflows/main/flux/outpaint/flux_fill_dev_outpaint_input.png)

### 2. 参照图片序号检查完成工作流运行

<img src="https://mintcdn.com/dripart/TwfNQ2dEaWQA7tIL/images/tutorial/flux/flow_diagram_outpaint.jpg?fit=max&auto=format&n=TwfNQ2dEaWQA7tIL&q=85&s=5f152f459be5f120b3895636685cb3d3" alt="ComfyUI Flux.1 Fill dev Outpainting 工作流" width="4000" height="2159" data-path="images/tutorial/flux/flow_diagram_outpaint.jpg" />

1. 确保在`Load Diffusion Model`节点加载了`flux1-fill-dev.safetensors`
2. 确保在`DualCLIPLoader`节点中下面的模型已加载：
   * clip\_name1: t5xxl\_fp16.safetensors
   * clip\_name2: clip\_l.safetensors
3. 确保在`Load VAE`节点中加载了`ae.safetensors`
4. 在`Load Image`节点中上传了文档中提供的输入图片
5. 点击 `Queue` 按钮，或者使用快捷键 `Ctrl(cmd) + Enter(回车)` 来运行工作流
