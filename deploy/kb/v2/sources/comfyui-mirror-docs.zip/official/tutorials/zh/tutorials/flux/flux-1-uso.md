> ## Documentation Index
> Fetch the complete documentation index at: https://docs.comfy.org/llms.txt
> Use this file to discover all available pages before exploring further.

# 字节跳动 USO ComfyUI 原生工作流示例

> 使用字节跳动 USO 模型实现统一风格和主体驱动生成

**USO (Unified Style-Subject Optimized)** 是字节跳动 UXO 团队开发的模型，统一了风格驱动和主体驱动生成任务。
基于 FLUX.1-dev 架构构建，该模型通过解耦学习和风格奖励学习 (SRL) 实现了风格相似性和主体一致性。

USO 支持三种主要方法：

* **主体驱动**：将主体放置到新场景中，同时保持身份一致性
* **风格驱动**：基于参考图像将艺术风格应用于新内容
* **组合模式**：同时使用主体和风格参考

**相关链接**

* [项目主页](https://bytedance.github.io/USO/)
* [GitHub](https://github.com/bytedance/USO)
* [模型权重](https://huggingface.co/bytedance-research/USO)

## 字节跳动 USO ComfyUI 原生工作流

<Tip>
  <Tabs>
    <Tab title="便携版或手动安装用户">
      请确保你的 ComfyUI 已经更新。

      * [ComfyUI 下载](https://www.comfy.org/download)
      * [ComfyUI 更新教程](/zh/installation/update_comfyui)

      本指南里的工作流可以在 ComfyUI 的[工作流模板](/zh/interface/features/template)中找到。如果找不到，可能是 ComfyUI 没有更新。

      如果加载工作流时有节点缺失，可能原因有：

      1. 你用的不是最新开发版（nightly）。
      2. 你用的是稳定版或桌面版（没有包含最新的更新）。
      3. 启动时有些节点导入失败。
    </Tab>

    <Tab title="桌面版或云端用户">
      * 桌面版是基于 ComfyUI 稳定版本构建的，它会在有新的桌面稳定版本发布时自动更新。
      * [Cloud](https://cloud.comfy.org) 会在 ComfyUI 稳定版本发布后更新，我们会同步更新 Cloud。

      所以，如果你发现本教程中有任何核心节点缺失，那是因为对应的节点支持还在开发中没有发布正式的稳定版，请等待下一个稳定版本发布。
    </Tab>
  </Tabs>
</Tip>

### 1. 工作流和输入

下载下方图像并拖拽到 ComfyUI 中以加载对应的工作流。

![工作流](https://raw.githubusercontent.com/Comfy-Org/example_workflows/refs/heads/main/flux/bytedance-uso/bytedance-uso.png)

<a className="prose" target="_blank" href="https://raw.githubusercontent.com/Comfy-Org/workflow_templates/refs/heads/main/templates/flux1_dev_uso_reference_image_gen.json" style={{ display: 'inline-block', backgroundColor: '#0078D6', color: '#ffffff', padding: '10px 20px', borderRadius: '8px', borderColor: "transparent", textDecoration: 'none', fontWeight: 'bold', marginRight: '10px'}}>
  <p className="prose" style={{ margin: 0, fontSize: "0.8rem" }}>下载 JSON 工作流</p>
</a>

<a className="prose" target="_blank" href="https://cloud.comfy.org/?template=flux1_dev_uso_reference_image_gen&utm_source=docs" style={{ display: 'inline-block', backgroundColor: '#28a745', color: '#ffffff', padding: '10px 20px', borderRadius: '8px', borderColor: "transparent", textDecoration: 'none', fontWeight: 'bold'}}>
  <p className="prose" style={{ margin: 0, fontSize: "0.8rem" }}>在 Comfy Cloud 上运行</p>
</a>

使用下面的图片作为输入

![输入图像](https://raw.githubusercontent.com/Comfy-Org/example_workflows/refs/heads/main/flux/bytedance-uso/input.png)

### 2. 模型链接

**checkpoints**

* [flux1-dev-fp8.safetensors](https://huggingface.co/Comfy-Org/flux1-dev/resolve/main/flux1-dev-fp8.safetensors)

**loras**

* [uso-flux1-dit-lora-v1.safetensors](https://huggingface.co/Comfy-Org/USO_1.0_Repackaged/resolve/main/split_files/loras/uso-flux1-dit-lora-v1.safetensors)

**model\_patches**

* [uso-flux1-projector-v1.safetensors](https://huggingface.co/Comfy-Org/USO_1.0_Repackaged/resolve/main/split_files/model_patches/uso-flux1-projector-v1.safetensors)

**clip\_visions**

* [sigclip\_vision\_patch14\_384.safetensors](https://huggingface.co/Comfy-Org/sigclip_vision_384/resolve/main/sigclip_vision_patch14_384.safetensors)

请下载所有模型并将它们放置在以下目录中：

```
📂 ComfyUI/
├── 📂 models/
│   ├── 📂 checkpoints/
│   │   └── flux1-dev-fp8.safetensors
│   ├── 📂 loras/
│   │   └── uso-flux1-dit-lora-v1.safetensors
│   ├── 📂 model_patches/
│   │   └── uso-flux1-projector-v1.safetensors
│   ├── 📂 clip_visions/
│   │   └── sigclip_vision_patch14_384.safetensors
```

### 3. 工作流说明

<img src="https://mintcdn.com/dripart/3zBG7o3F8mQK7Rdk/images/tutorial/flux/flux1_uso_reference_image_gen.jpg?fit=max&auto=format&n=3zBG7o3F8mQK7Rdk&q=85&s=60e1dc7cccd4b732ff2a6e24767d7630" alt="工作流说明" width="2000" height="1188" data-path="images/tutorial/flux/flux1_uso_reference_image_gen.jpg" />

1. 加载模型：
   * 1.1 确保 `Load Checkpoint` 节点已加载 `flux1-dev-fp8.safetensors`
   * 1.2 确保 `LoraLoaderModelOnly` 节点已加载 `dit_lora.safetensors`
   * 1.3 确保 `ModelPatchLoader` 节点已加载 `projector.safetensors`
   * 1.4 确保 `Load CLIP Vision` 节点已加载 `sigclip_vision_patch14_384.safetensors`
2.

* 2.1 点击 `Upload` 上传我们提供的输入图像
* 2.2 `ImageScaleToMaxDimension` 节点将会缩放你的输入图像用于内容参考，512px 会保留更多的角色特征，但如果你仅使用角色头部作为输入，最终输出图像往往会有角色占据太多空间的问题(或者结果很糟)。设置为 1024px 会得到更好的结果。

3. 在示例中，我们只使用 `content reference` 图像输入。如果你想使用 `style reference` 图像输入，可以使用 `Ctrl+B` 绕过标记的节点组。
4. 编写你的提示词或保持默认设置
5. 如果需要调整输出图像尺寸
6. EasyCache 节点用于推理加速，但也会牺牲一些质量和细节。如果不需要使用，可以用 `Ctrl+B` 绕过它。
7. 点击 `Run` 按钮，或使用快捷键 `Ctrl(Cmd) + Enter` 运行工作流

### 4. 补充说明

1. 仅使用风格参考：

我们在同一个工作流中也提供了仅使用风格参考的版本

<img src="https://mintcdn.com/dripart/6BfRVG5RoFiMLPEQ/images/tutorial/flux/flux1_uso_reference_image_gen_style_reference_only.jpg?fit=max&auto=format&n=6BfRVG5RoFiMLPEQ&q=85&s=d5f16dbe97ac74b1bf01587aaabe12b8" alt="工作流" width="4366" height="2498" data-path="images/tutorial/flux/flux1_uso_reference_image_gen_style_reference_only.jpg" />

唯一的区别是我们替换了 `content reference` 节点，仅使用 `Empty Latent Image` 节点来创建一个我们需要的图像大小

2. 你也可以 **绕过（Ctrl+B）** 整个 `Style Reference` 组，将工作流用作文本到图像的工作流，也就是这个文本存在 4 个变体

* 仅使用内容（主体）参考
* 仅使用风格参考
* 混合内容及风格参考
* 作为文生图工作流
