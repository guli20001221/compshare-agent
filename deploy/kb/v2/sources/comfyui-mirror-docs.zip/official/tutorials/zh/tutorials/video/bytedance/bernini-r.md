> ## Documentation Index
> Fetch the complete documentation index at: https://docs.comfy.org/llms.txt
> Use this file to discover all available pages before exploring further.

# ComfyUI Bernini-R 官方示例

> 了解如何在 ComfyUI 中使用 Bernini-R 进行图像和视频编辑——重光照、风格转换、主体插入等。

# ComfyUI Bernini-R 简介

[Bernini-R](https://github.com/bytedance/Bernini) 是字节跳动的 **仅渲染器** Wan 2.2 模型，专为上下文内图像和视频条件控制设计。它使用一组条件流（源视频、参考图像、参考视频）来引导生成——无需 LoRA 训练或微调。

主要能力：

* **多种任务类型合一**：图像/视频生成、编辑、重光照、风格转换、主体插入
* **上下文内条件控制**：参考图像/视频作为视觉提示，以令牌方式注入
* **轻量级**：仅渲染器模型——无需基于扩散的文本到视频骨干
* **灵活输入支持**：单图或多图参考、视频到视频、参考引导编辑

Bernini-R 支持的六种任务类型：

| 任务        | 输入         | 说明                 |
| --------- | ---------- | ------------------ |
| **t2v**   | 文本提示       | 文生视频               |
| **v2v**   | 源视频        | 视频到视频风格转换          |
| **rv2v**  | 源视频 + 参考图像 | 参考引导视频编辑（重光照、主体插入） |
| **r2v**   | 参考图像       | 参考到视频生成            |
| **ads2v** | 源视频 + 参考视频 | 将图像/视频内容插入源视频      |
| **img**   | 源图像        | 图像编辑               |

<Tip>
  <Tabs>
    <Tab title="便携版或手动安装用户">
      请确保你的 ComfyUI 已经更新。

      * [ComfyUI 下载](https://www.comfy.org/download)
      * [ComfyUI 更新教程](/zh/installation/update_comfyui)

      本指南里的工作流可以在 ComfyUI 的[工作流模板](/zh/interface/features/template)中找到。如果找不到，可能是 ComfyUI 没有更新。

      如果加载工作流时有节点缺失，可能原因有：

      1. 你用的不是最新开发版（nightly）。
      2. 你用的是稳定版或桌面版（没有包含最新的更新）。
      3. 启动时有些节点导入失败。
    </Tab>

    <Tab title="桌面版或云端用户">
      * 桌面版是基于 ComfyUI 稳定版本构建的，它会在有新的桌面稳定版本发布时自动更新。
      * [Cloud](https://cloud.comfy.org) 会在 ComfyUI 稳定版本发布后更新，我们会同步更新 Cloud。

      所以，如果你发现本教程中有任何核心节点缺失，那是因为对应的节点支持还在开发中没有发布正式的稳定版，请等待下一个稳定版本发布。
    </Tab>
  </Tabs>
</Tip>

<Tip>
  ComfyUI 现已原生支持 Bernini-R 节点。开始前请确保已更新到最新版本的 [ComfyUI](https://github.com/Comfy-Org/ComfyUI)。
</Tip>

## 模型下载

下载所需的模型权重并将其保存到对应的 ComfyUI 文件夹：

**text\_encoders:**

* [umt5\_xxl\_fp8\_e4m3fn\_scaled.safetensors](https://huggingface.co/Comfy-Org/Wan_2.1_ComfyUI_repackaged/resolve/main/split_files/text_encoders/umt5_xxl_fp8_e4m3fn_scaled.safetensors?download=true)

**vae:**

* [Wan2\_1\_VAE\_bf16.safetensors](https://huggingface.co/Kijai/WanVideo_comfy/resolve/main/Wan2_1_VAE_bf16.safetensors?download=true)

**loras:**

* [lightx2v\_T2V\_14B\_cfg\_step\_distill\_v2\_lora\_rank64\_bf16.safetensors](https://huggingface.co/Kijai/WanVideo_comfy/resolve/main/lightx2v_T2V_14B_cfg_step_distill_v2_lora_rank64_bf16.safetensors?download=true)

**diffusion\_models:**

* [wan2.2\_bernini\_r\_fp16.safetensors](https://huggingface.co/Comfy-Org/Bernini-R/resolve/main/wan2.2_bernini_r_fp16.safetensors)

```
ComfyUI/
├── models/
│   ├── text_encoders/
│   │   └── umt5_xxl_fp8_e4m3fn_scaled.safetensors
│   ├── vae/
│   │   └── Wan2_1_VAE_bf16.safetensors
│   ├── loras/
│   │   └── lightx2v_T2V_14B_cfg_step_distill_v2_lora_rank64_bf16.safetensors
│   ├── diffusion_models/
│   │   └── wan2.2_bernini_r_fp16.safetensors
```

## 示例工作流

***

## 1. 图像编辑

**功能说明：** 生成具有匹配光照的编辑图像，并查看前/后并排对比。适用于人像和产品重光照、照片集一致的光照、电商目录摄影。

<CardGroup cols={2}>
  <Card title="下载工作流" icon="download" href="https://github.com/Comfy-Org/workflow_templates/blob/main/templates/video_bernini_r_image_editing.json">
    下载 JSON 或在模板库中搜索 "Bernini-R"
  </Card>

  <Card title="在 Comfy Cloud 运行" icon="cloud" href="https://cloud.comfy.org/?template=video_bernini_r_image_editing&utm_source=docs&utm_medium=referral&utm_campaign=bernini-r">
    在 Comfy Cloud 中打开
  </Card>
</CardGroup>

<div style={{display: 'flex', gap: '1rem', flexWrap: 'wrap'}}>
  <img src="https://raw.githubusercontent.com/Comfy-Org/workflow_templates/main/templates/video_bernini_r_image_editing-1.webp" alt="Bernini-R 图像编辑输出" style={{maxWidth: '48%', height: 'auto'}} />

  <img src="https://raw.githubusercontent.com/Comfy-Org/workflow_templates/main/templates/video_bernini_r_image_editing-2.webp" alt="Bernini-R 图像编辑对比" style={{maxWidth: '48%', height: 'auto'}} />
</div>

### 运行步骤

1. **选择任务类型** — 选择你的任务（Image Editing、Subject to Image 等）
2. **连接输入** — 加载源图像和可选参考图像
3. **编写提示词** — 描述所需的编辑
4. **运行** — 点击 Queue 或使用 `Cmd+Enter`

**参考图像输入：** 当需要一张或多张参考图像时使用（主体、服装、场景、道具）。在提示词中使用 `image0`、`image1` 等来引用每张图像。**图像编辑（Image Editing）** 任务不需要此项——该任务使用 `source_image` 代替。

<Card title="了解子图" icon="book-open" href="/zh/interface/features/subgraph">
  此工作流使用子图节点进行模块化处理。查看子图文档了解如何自定义和扩展工作流。
</Card>

***

## 2. 视频编辑

**功能说明：** 使用 Bernini-R 生成具有一致重光照的编辑视频。连接源视频、可选的参考图像或参考视频，选择任务类型，编写提示词，然后运行。

<CardGroup cols={2}>
  <Card title="下载工作流" icon="download" href="https://github.com/Comfy-Org/workflow_templates/blob/main/templates/video_bernini_r_video_editing.json">
    下载 JSON 或在模板库中搜索 "Bernini-R"
  </Card>

  <Card title="在 Comfy Cloud 运行" icon="cloud" href="https://cloud.comfy.org/?template=video_bernini_r_video_editing&utm_source=docs&utm_medium=referral&utm_campaign=bernini-r">
    在 Comfy Cloud 中打开
  </Card>
</CardGroup>

![Bernini-R 视频编辑预览](https://raw.githubusercontent.com/Comfy-Org/workflow_templates/main/templates/video_bernini_r_video_editing-1.webp)

### 运行步骤

1. **加载源视频** — 连接输入视频
2. **（可选）加载参考** — 参考图像或参考视频
3. **选择任务类型** — v2v、rv2v、r2v 或 ads2v
4. **编写提示词** — 描述所需的编辑
5. **运行** — 点击 Queue 或使用 `Cmd+Enter`

**参考图像输入：** 当需要一张或多张参考图像时使用（rv2v、r2v、多件服装）。每张批处理的图像成为自己的上下文内令牌。如果参考物扮演不同角色，在提示词中使用 `image0`、`image1` 等。

<Card title="了解子图" icon="book-open" href="/zh/interface/features/subgraph">
  此工作流使用子图节点进行模块化处理。查看子图文档了解如何自定义和扩展工作流。
</Card>

## 社区资源

* [Bernini GitHub (bytedance/Bernini)](https://github.com/bytedance/Bernini) — 研究论文和任务文档
* [Comfy-Org/Bernini-R](https://huggingface.co/Comfy-Org/Bernini-R) — 官方 ComfyUI 模型权重
* [Bernini: Latent Semantic Planning for Video Diffusion](https://arxiv.org/abs/2605.22344) — 研究论文
