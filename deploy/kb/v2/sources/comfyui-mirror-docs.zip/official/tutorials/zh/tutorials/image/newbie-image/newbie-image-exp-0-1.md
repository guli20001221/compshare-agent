> ## Documentation Index
> Fetch the complete documentation index at: https://docs.comfy.org/llms.txt
> Use this file to discover all available pages before exploring further.

# ComfyUI NewBie-image-Exp0.1 工作流示例

> NewBie-image-Exp0.1 是一个基于 Next-DiT 架构的 35 亿参数动漫风格文生图模型，针对高质量动漫图像生成进行了优化，支持 XML 结构化提示词。

**NewBie-image-Exp0.1** 是由 NewBieAI Lab 开发的 35 亿参数 DiT 模型，专为动漫风格文生图设计。基于 Next-DiT 架构构建，能够生成细节丰富、视觉效果出色的动漫图像。

**核心特性**：

* **35 亿参数模型**：高效且强大的模型规模，适合高质量动漫生成
* **Next-DiT 架构**：基于 Lumina 架构研究，采用全新设计的 NewBie 架构
* **双文本编码器**：使用 Gemma3-4B-it 作为主编码器，配合 Jina CLIP v2 提升提示词理解能力
* **FLUX VAE**：采用 FLUX.1-dev 16 通道 VAE，呈现更丰富的色彩和更精细的纹理细节
* **XML 结构化提示词**：支持 XML 格式，实现更好的注意力绑定和属性解耦

**相关链接**：

* [GitHub](https://github.com/NewBieAI-Lab/NewBie-image-Exp0.1)
* [Hugging Face](https://huggingface.co/NewBie-AI/NewBie-image-Exp0.1)
* [入门指南](https://ai.feishu.cn/wiki/P3sgwUUjWih8ZWkpr0WcwXSMnTb)

## NewBie-image 文生图工作流

<a className="prose" target="_blank" href="https://raw.githubusercontent.com/Comfy-Org/workflow_templates/refs/heads/main/templates/image_newbieimage_exp0_1-t2i.json" style={{ display: 'inline-block', backgroundColor: '#0078D6', color: '#ffffff', padding: '10px 20px', borderRadius: '8px', borderColor: "transparent", textDecoration: 'none', fontWeight: 'bold', marginRight: '10px'}}>
  <p className="prose" style={{ margin: 0, fontSize: "0.8rem" }}>下载 JSON 工作流文件</p>
</a>

<a className="prose" target="_blank" href="https://cloud.comfy.org/?template=image_newbieimage_exp0_1-t2i&utm_source=docs" style={{ display: 'inline-block', backgroundColor: '#28a745', color: '#ffffff', padding: '10px 20px', borderRadius: '8px', borderColor: "transparent", textDecoration: 'none', fontWeight: 'bold'}}>
  <p className="prose" style={{ margin: 0, fontSize: "0.8rem" }}>在 ComfyUI Cloud 上运行</p>
</a>

<Tip>
  <Tabs>
    <Tab title="便携版或手动安装用户">
      请确保你的 ComfyUI 已经更新。

      * [ComfyUI 下载](https://www.comfy.org/download)
      * [ComfyUI 更新教程](/zh/installation/update_comfyui)

      本指南里的工作流可以在 ComfyUI 的[工作流模板](/zh/interface/features/template)中找到。如果找不到，可能是 ComfyUI 没有更新。

      如果加载工作流时有节点缺失，可能原因有：

      1. 你用的不是最新开发版（nightly）。
      2. 你用的是稳定版或桌面版（没有包含最新的更新）。
      3. 启动时有些节点导入失败。
    </Tab>

    <Tab title="桌面版或云端用户">
      * 桌面版是基于 ComfyUI 稳定版本构建的，它会在有新的桌面稳定版本发布时自动更新。
      * [Cloud](https://cloud.comfy.org) 会在 ComfyUI 稳定版本发布后更新，我们会同步更新 Cloud。

      所以，如果你发现本教程中有任何核心节点缺失，那是因为对应的节点支持还在开发中没有发布正式的稳定版，请等待下一个稳定版本发布。
    </Tab>
  </Tabs>
</Tip>

## 模型下载链接

**text\_encoders**

* [gemma\_3\_4b\_it\_bf16.safetensors](https://huggingface.co/Comfy-Org/NewBie-image-Exp0.1_repackaged/resolve/main/split_files/text_encoders/gemma_3_4b_it_bf16.safetensors)
* [jina\_clip\_v2\_bf16.safetensors](https://huggingface.co/Comfy-Org/NewBie-image-Exp0.1_repackaged/resolve/main/split_files/text_encoders/jina_clip_v2_bf16.safetensors)

**diffusion\_models**

* [NewBie-Image-Exp0.1-bf16.safetensors](https://huggingface.co/Comfy-Org/NewBie-image-Exp0.1_repackaged/resolve/main/split_files/diffusion_models/NewBie-Image-Exp0.1-bf16.safetensors)

**vae**

* [ae.safetensors](https://huggingface.co/Comfy-Org/z_image_turbo/resolve/main/split_files/vae/ae.safetensors)

**模型存放位置**

```
ComfyUI/
├── models/
│   ├── text_encoders/
│   │      ├── gemma_3_4b_it_bf16.safetensors
│   │      └── jina_clip_v2_bf16.safetensors
│   ├── diffusion_models/
│   │      └── NewBie-Image-Exp0.1-bf16.safetensors
│   └── vae/
│          └── ae.safetensors
```

## 提示词格式

NewBie-image 是一个针对角色生成优化的动漫图像生成模型。它使用 XML 结构化提示词进行训练，每个 `<>` 标签定义一个类别（如 `<appearance>`、`<clothing>`），`</>` 作为结束标记。标签内部使用标准的 Danbooru 标签。这种结构能够精确控制多角色场景，实现更好的属性绑定。

完整的提示词编写指南请参阅[官方文档](https://ai.feishu.cn/wiki/NZl9wm7V1iuNzmkRKCUcb1USnsh)。

NewBie-image-Exp0.1 支持三种提示词格式：

* **自然语言**：标准文本描述
* **标签**：Danbooru 风格标签
* **XML 结构化格式**：推荐用于多角色场景

### XML 结构化提示词

对于多角色场景，使用 XML 结构化提示词通常能获得更准确的图像生成结果，具有更好的注意力绑定和属性解耦效果。

```xml theme={null}
<character_1>
<n>$character_1$</n>
<gender>1girl</gender>
<appearance>chibi, red_eyes, blue_hair, long_hair, hair_between_eyes, head_tilt, tareme, closed_mouth</appearance>
<clothing>school_uniform, serafuku, white_sailor_collar, white_shirt, short_sleeves, red_neckerchief, bow, blue_skirt, miniskirt, pleated_skirt, blue_hat, mini_hat, thighhighs, grey_thighhighs, black_shoes, mary_janes</clothing>
<expression>happy, smile</expression>
<action>standing, holding, holding_briefcase</action>
<position>center_left</position>
</character_1>

<character_2>
<n>$character_2$</n>
<gender>1girl</gender>
<appearance>chibi, red_eyes, pink_hair, long_hair, very_long_hair, multi-tied_hair, open_mouth</appearance>
<clothing>school_uniform, serafuku, white_sailor_collar, white_shirt, short_sleeves, red_neckerchief, bow, red_skirt, miniskirt, pleated_skirt, hair_bow, multiple_hair_bows, white_bow, ribbon_trim, ribbon-trimmed_bow, white_thighhighs, black_shoes, mary_janes, bow_legwear, bare_arms</clothing>
<expression>happy, smile</expression>
<action>standing, holding, holding_briefcase, waving</action>
<position>center_right</position>
</character_2>

<general_tags>
<count>2girls, multiple_girls</count>
<style>anime_style, digital_art</style>
<background>white_background, simple_background</background>
<atmosphere>cheerful</atmosphere>
<quality>high_resolution, detailed</quality>
<objects>briefcase</objects>
<other>alternate_costume</other>
</general_tags>
```

### XML 标签参考

| 标签             | 描述                 |
| -------------- | ------------------ |
| `<n>`          | 角色名称/标识符           |
| `<gender>`     | 角色性别（1girl、1boy 等） |
| `<appearance>` | 外貌特征（头发、眼睛、体型）     |
| `<clothing>`   | 服装和配饰              |
| `<expression>` | 面部表情               |
| `<action>`     | 姿势和动作              |
| `<position>`   | 图像中的位置             |
| `<count>`      | 角色数量               |
| `<style>`      | 艺术风格               |
| `<background>` | 背景描述               |
| `<atmosphere>` | 整体氛围               |
| `<quality>`    | 质量标签               |
| `<objects>`    | 场景中的物品             |
| `<other>`      | 其他标签               |
