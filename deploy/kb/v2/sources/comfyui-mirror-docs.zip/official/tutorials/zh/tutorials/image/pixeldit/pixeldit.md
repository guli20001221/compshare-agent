> ## Documentation Index
> Fetch the complete documentation index at: https://docs.comfy.org/llms.txt
> Use this file to discover all available pages before exploring further.

# PixelDiT ComfyUI 工作流示例

> PixelDiT 是 NVIDIA 的像素空间扩散变换器，用于生成 1024px 文本到图像。它直接在像素空间生成图像，无需 VAE 编解码。

**PixelDiT** 是 NVIDIA 开发的像素空间扩散变换器，用于 **1024px** 文本到图像生成。与传统在潜空间操作的扩散模型不同，PixelDiT 使用双层 DiT 架构直接在像素空间生成图像——结合了 patch 级 DiT 和像素级 DiT，并通过 MM-DiT 融合实现文本和图像 token 之间的联合注意力。

**模型亮点**：

* **无需 VAE** — 直接在像素空间生成，无需传统的 VAE 编解码
* **双层 DiT** — patch 级 DiT + 像素级 DiT，实现高质量生成
* **多宽高比** — 1024px 基准分辨率，支持多种宽高比
* **约 1.3B 参数** — 消费级 GPU 即可运行
* **许可协议**：NSCLv1（仅限非商业研究/评估使用）

**相关链接**：

* [Hugging Face 官方模型](https://huggingface.co/nvidia/PixelDiT-1300M-1024px)
* [Comfy-Org/PixelDiT](https://huggingface.co/Comfy-Org/PixelDiT)

## PixelDiT 文生图工作流

<img src="https://raw.githubusercontent.com/Comfy-Org/workflow_templates/main/templates/image_pixeldit_t2i-1.webp" alt="PixelDiT 文生图工作流" />

<Card title="下载工作流" icon="download" href="https://github.com/Comfy-Org/workflow_templates/blob/main/templates/image_pixeldit_t2i.json">
  下载 JSON 或在模板库中搜索 "PixelDiT"
</Card>

<Tip>
  <Tabs>
    <Tab title="便携版或手动安装用户">
      请确保你的 ComfyUI 已经更新。

      * [ComfyUI 下载](https://www.comfy.org/download)
      * [ComfyUI 更新教程](/zh/installation/update_comfyui)

      本指南里的工作流可以在 ComfyUI 的[工作流模板](/zh/interface/features/template)中找到。如果找不到，可能是 ComfyUI 没有更新。

      如果加载工作流时有节点缺失，可能原因有：

      1. 你用的不是最新开发版（nightly）。
      2. 你用的是稳定版或桌面版（没有包含最新的更新）。
      3. 启动时有些节点导入失败。
    </Tab>

    <Tab title="桌面版或云端用户">
      * 桌面版是基于 ComfyUI 稳定版本构建的，它会在有新的桌面稳定版本发布时自动更新。
      * [Cloud](https://cloud.comfy.org) 会在 ComfyUI 稳定版本发布后更新，我们会同步更新 Cloud。

      所以，如果你发现本教程中有任何核心节点缺失，那是因为对应的节点支持还在开发中没有发布正式的稳定版，请等待下一个稳定版本发布。
    </Tab>
  </Tabs>
</Tip>

工作流由三个主要节点组成：

1. **ResolutionSelector** — 选择所需的输出分辨率
2. **文生图 (PixelDiT) 子图** — 核心生成节点，暴露了提示词、种子、模型选择和分辨率等控制参数
3. **SaveImage** — 保存生成的图像

<Card title="了解子图" icon="book-open" href="/zh/interface/features/subgraph">
  本工作流使用子图节点进行模块化处理。查看子图文档了解如何自定义和扩展工作流。
</Card>

### 工作流控制参数

**文生图 (PixelDiT)** 子图节点暴露的控件包括：

| 控制参数                | 说明               |
| ------------------- | ---------------- |
| **Positive Prompt** | 描述你想要生成的图像的文本提示词 |
| **Negative Prompt** | 描述要避免的内容的文本      |
| **Seed**            | 用于结果可复现的随机种子     |
| **UNet Model**      | PixelDiT 模型检查点选择 |
| **CLIP Model**      | 文本编码器模型选择        |

## 模型下载

PixelDiT 使用两个模型文件：文本编码器和扩散模型。

<Card title="文本编码器" icon="download" href="https://huggingface.co/Comfy-Org/PixelDiT/resolve/main/text_encoders/gemma_2_2b_it_elm_bf16.safetensors">
  gemma\_2\_2b\_it\_elm\_bf16.safetensors — Gemma-2-2B-IT 文本编码器
</Card>

<Card title="扩散模型" icon="download" href="https://huggingface.co/Comfy-Org/PixelDiT/resolve/main/diffusion_models/pixeldit_1300m_1024px_bf16.safetensors">
  pixeldit\_1300m\_1024px\_bf16.safetensors — PixelDiT 1300M 1024px 扩散模型
</Card>

### 模型存放位置

```
📂 ComfyUI/
├── 📂 models/
│   ├── 📂 text_encoders/
│   │      └── gemma_2_2b_it_elm_bf16.safetensors
│   └── 📂 diffusion_models/
│          └── pixeldit_1300m_1024px_bf16.safetensors
```
