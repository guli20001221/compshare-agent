> ## Documentation Index
> Fetch the complete documentation index at: https://docs.comfy.org/llms.txt
> Use this file to discover all available pages before exploring further.

# Wan2.2-S2V 音频驱动视频生成 ComfyUI 原生工作流示例

> 这是一个基于 ComfyUI 的 Wan2.2-S2V 音频驱动视频生成原生工作流示例。

我们很高兴地宣布，先进的音频驱动视频生成模型 Wan2.2-S2V 现已原生支持 ComfyUI！这个强大的 AI 模型可以将静态图片和音频输入转化为动态视频内容，支持对话、唱歌、表演等多种创意内容需求。

**模型亮点**

* **音频驱动视频生成**：将静态图片和音频转化为同步视频
* **电影级画质**：生成具有自然表情和动作的高质量视频
* **分钟级生成**：支持长时长视频创作
* **多格式支持**：适用于全身和半身角色
* **增强动作控制**：可根据文本指令生成动作和环境

Wan2.2 S2V 代码仓库：[Github](https://github.com/aigc-apps/VideoX-Fun)
Wan2.2 S2V 模型仓库：[Hugging Face](https://huggingface.co/Wan-AI/Wan2.2-S2V-14B)

## Wan2.2 S2V ComfyUI 原生工作流

<UpdateReminder />

### 1. 工作流文件下载

下载以下工作流文件并拖入 ComfyUI 中加载工作流。

<video controls className="w-full aspect-video" src="https://raw.githubusercontent.com/Comfy-Org/example_workflows/refs/heads/main/video/wan/wan2.2_s2v/wan2.2-s2v.mp4" />

<a className="prose" target="_blank" href="https://raw.githubusercontent.com/Comfy-Org/workflow_templates/refs/heads/main/templates/video_wan2_2_14B_s2v.json" style={{ display: 'inline-block', backgroundColor: '#0078D6', color: '#ffffff', padding: '10px 20px', borderRadius: '8px', borderColor: "transparent", textDecoration: 'none', fontWeight: 'bold'}}>
  <p className="prose" style={{ margin: 0, fontSize: "0.8rem" }}>Download JSON Workflow</p>
</a>

<a className="prose" target="_blank" href="https://cloud.comfy.org/?template=video_wan2_2_14B_s2v&utm_source=docs" style={{ display: 'inline-block', backgroundColor: '#28A745', color: '#FFFFFF', padding: '10px 20px', borderRadius: '8px', borderColor: "transparent", textDecoration: 'none', fontWeight: 'bold'}}>
  <p className="prose" style={{ margin: 0, fontSize: "0.8rem" }}>Run on Comfy Cloud</p>
</a>

下载下面的图片及音频作为输入:
![input](https://raw.githubusercontent.com/Comfy-Org/example_workflows/refs/heads/main/video/wan/wan2.2_s2v/input.jpg)

<a className="prose" target="_blank" href="https://raw.githubusercontent.com/Comfy-Org/example_workflows/refs/heads/main/video/wan/wan2.2_s2v/input_audio.MP3" style={{ display: 'inline-block', backgroundColor: '#0078D6', color: '#ffffff', padding: '10px 20px', borderRadius: '8px', borderColor: "transparent", textDecoration: 'none', fontWeight: 'bold'}}>
  <p className="prose" style={{ margin: 0, fontSize: "0.8rem" }}>下载输入音频</p>
</a>

### 2. 模型链接

你可以在 [我们的仓库](https://huggingface.co/Comfy-Org/Wan_2.2_ComfyUI_Repackaged) 中找到所有模型。

**diffusion\_models**

* [wan2.2\_s2v\_14B\_fp8\_scaled.safetensors](https://huggingface.co/Comfy-Org/Wan_2.2_ComfyUI_Repackaged/resolve/main/split_files/diffusion_models/wan2.2_s2v_14B_fp8_scaled.safetensors)
* [wan2.2\_s2v\_14B\_bf16.safetensors](https://huggingface.co/Comfy-Org/Wan_2.2_ComfyUI_Repackaged/resolve/main/split_files/diffusion_models/wan2.2_s2v_14B_bf16.safetensors)

**audio\_encoders**

* [wav2vec2\_large\_english\_fp16.safetensors](https://huggingface.co/Comfy-Org/Wan_2.2_ComfyUI_Repackaged/resolve/main/split_files/audio_encoders/wav2vec2_large_english_fp16.safetensors)

**vae**

* [wan\_2.1\_vae.safetensors](https://huggingface.co/Comfy-Org/Wan_2.2_ComfyUI_Repackaged/resolve/main/split_files/vae/wan_2.1_vae.safetensors)

**text\_encoders**

* [umt5\_xxl\_fp8\_e4m3fn\_scaled.safetensors](https://huggingface.co/Comfy-Org/Wan_2.1_ComfyUI_repackaged/resolve/main/split_files/text_encoders/umt5_xxl_fp8_e4m3fn_scaled.safetensors)

```
ComfyUI/
├───📂 models/
│   ├───📂 diffusion_models/
│   │   ├──── wan2.2_s2v_14B_fp8_scaled.safetensors
│   │   └─── wan2.2_s2v_14B_bf16.safetensors
│   ├───📂 text_encoders/
│   │   └─── umt5_xxl_fp8_e4m3fn_scaled.safetensors 
│   ├───📂 audio_encoders/ # 如果这个文件夹不存在请手动创建一个
│   │   └─── wav2vec2_large_english_fp16.safetensors 
│   └───📂 vae/
│       └── wan_2.1_vae.safetensors
```

### 3. 工作流说明

<img src="https://mintcdn.com/dripart/ht3vzHrjy1qaRsl9/images/tutorial/video/wan/wan_2.2_14b_s2v.jpg?fit=max&auto=format&n=ht3vzHrjy1qaRsl9&q=85&s=295f87179e12d937cbfbcc3e21d474c0" alt="工作流说明" width="4000" height="2131" data-path="images/tutorial/video/wan/wan_2.2_14b_s2v.jpg" />

#### 3.1 关于 Lightning LoRA

#### 3.2 关于 fp8\_scaled 和 bf16 模型

你可以在 [这里](https://huggingface.co/Comfy-Org/Wan_2.2_ComfyUI_Repackaged/tree/main/split_files/diffusion_models) 找到两种模型：

* [wan2.2\_s2v\_14B\_fp8\_scaled.safetensors](https://huggingface.co/Comfy-Org/Wan_2.2_ComfyUI_Repackaged/resolve/main/split_files/diffusion_models/wan2.2_s2v_14B_fp8_scaled.safetensors)
* [wan2.2\_s2v\_14B\_bf16.safetensors](https://huggingface.co/Comfy-Org/Wan_2.2_ComfyUI_Repackaged/resolve/main/split_files/diffusion_models/wan2.2_s2v_14B_bf16.safetensors)

本模板使用 `wan2.2_s2v_14B_fp8_scaled.safetensors`，它需要更少的显存。但你可以尝试 `wan2.2_s2v_14B_bf16.safetensors` 来减少质量损失。

#### 3.3 逐步操作说明

**步骤 1：加载模型**

1. **Load Diffusion Model**：加载 `wan2.2_s2v_14B_fp8_scaled.safetensors` 或 `wan2.2_s2v_14B_bf16.safetensors`
   * 提供工作流使用 `wan2.2_s2v_14B_fp8_scaled.safetensors`，它需要更少的显存
   * 但你可以尝试 `wan2.2_s2v_14B_bf16.safetensors` 来减少质量损失

2. **Load CLIP**：加载 `umt5_xxl_fp8_e4m3fn_scaled.safetensors`

3. **Load VAE**：加载 `wan_2.1_vae.safetensors`

4. **AudioEncoderLoader**：加载 `wav2vec2_large_english_fp16.safetensors`

5. **LoraLoaderModelOnly**：加载 `wan2.2_t2v_lightx2v_4steps_lora_v1.1_high_noise.safetensors`（Lightning LoRA）
   * 测试了所有 wan2.2 lightning LoRAs，由于这并不是一个专门为 Wan2.2 S2V 训练的 LoRA，很多键值不匹配，但由于它能大幅减少生成时间，后续将继续优化这个模板
   * 使用它会导致极大的动态和质量损失
   * 如果你发现输出质量太差，可以尝试原始的 20 步工作流

6. **LoadAudio**：上传我们提供的音频文件，或者你自己的音频

7. **Load Image**：上传参考图片

8. **Batch sizes**：根据你添加的 Video S2V Extend 子图节点数量设置
   * 每个 Video S2V Extend 子图会为最终输出添加 77 帧
   * 例如：如果添加了 2 个 Video S2V Extend 子图，批处理大小应设为 3, 也就是这里应为所有总采样次数
   * **Chunk Length**：保持默认值 77

9. **采样器设置**: 根据是否使用 Lightning LoRA 选择不同设置
   * 使用 4 步 Lightning LoRA: steps: 4, cfg: 1.0
   * 不使用 4 步 Lightning LoRA: steps: 20, cfg: 6.0

10. **尺寸设置**: 设置输出视频的尺寸

11. **Video S2V Extend**：视频扩展子图节点，由于我们默认的每次采样帧数为 77, 由于这是一个 16fps 的模型，所以每个扩展将会生成 77 / 16 = 4.8125 秒的视频
    * 你需要一定的计算来使得视频扩展子图节点的数量和输入音频数量匹配，如： 输入音频为 14s, 则需要的总帧数为 14x16=224, 每个视频扩展为 77 帧，所以你需要 224/77 = 2.9 向上取整则为 3 个视频扩展子图节点

12. 使用 Ctrl-Enter 或者点击 运行按钮来运行工作流
