> ## Documentation Index
> Fetch the complete documentation index at: https://docs.comfy.org/llms.txt
> Use this file to discover all available pages before exploring further.

# ComfyUI MoGe 使用示例

> 本指南演示如何在 ComfyUI 中使用 MoGe 进行单目几何估计：公尺度点云、深度图、法线图和网格生成。

# ComfyUI MoGe 介绍

[MoGe](https://github.com/microsoft/MoGe)（CVPR 2025，来自微软研究院）是一个强大的单目 3D 几何恢复模型，可以从开放领域的单张图像中恢复 3D 几何信息。它在一个前向推理中同时输出公尺度点云、公尺度深度图、法线图和相机 FOV。

核心能力：

* **精确的 3D 几何估计**：单张图像同时输出点云、深度图和法线图——一个模型，一次推理
* **公尺度**（MoGe-2）：点云和深度图使用真实世界尺度
* **灵活的分辨率支持**：支持多种分辨率和宽高比（2:1 到 1:2）
* **快速推理**：A100 / RTX 3090 上约 60ms/张（FP16，ViT-L）
* **从透视和全景图生成网格**

MoGe 提供两个版本：

| 文件                        | 版本         | 公尺度 | 法线图 |  参数量 |
| ------------------------- | ---------- | :-: | :-: | :--: |
| `moge_1_vitl_fp16`        | **MoGe-1** |  -  |  -  | 314M |
| `moge_2_vitl_normal_fp16` | **MoGe-2** |  ✅  |  ✅  | 331M |

> MoGe-2 新增了公尺度支持和高质量法线图估计，视觉细节更清晰，推理延迟更低。**推荐使用 MoGe-2 with normal（`moge_2_vitl_normal_fp16`）。**

<Tip>
  <Tabs>
    <Tab title="便携版或手动安装用户">
      请确保你的 ComfyUI 已经更新。

      * [ComfyUI 下载](https://www.comfy.org/download)
      * [ComfyUI 更新教程](/zh/installation/update_comfyui)

      本指南里的工作流可以在 ComfyUI 的[工作流模板](/zh/interface/features/template)中找到。如果找不到，可能是 ComfyUI 没有更新。

      如果加载工作流时有节点缺失，可能原因有：

      1. 你用的不是最新开发版（nightly）。
      2. 你用的是稳定版或桌面版（没有包含最新的更新）。
      3. 启动时有些节点导入失败。
    </Tab>

    <Tab title="桌面版或云端用户">
      * 桌面版是基于 ComfyUI 稳定版本构建的，它会在有新的桌面稳定版本发布时自动更新。
      * [Cloud](https://cloud.comfy.org) 会在 ComfyUI 稳定版本发布后更新，我们会同步更新 Cloud。

      所以，如果你发现本教程中有任何核心节点缺失，那是因为对应的节点支持还在开发中没有发布正式的稳定版，请等待下一个稳定版本发布。
    </Tab>
  </Tabs>
</Tip>

<Tip>
  ComfyUI 现已原生支持 MoGe 节点。开始前请确保已更新到最新版本的 [ComfyUI](https://github.com/Comfy-Org/ComfyUI)。

  生成的 `.glb` 模型将输出到 `ComfyUI/output/mesh` 文件夹。
</Tip>

## 模型安装

下载 MoGe 检查点并保存到相应的 ComfyUI 文件夹：

* **MoGe-2（推荐）**：[moge\_2\_vitl\_normal\_fp16.safetensors](https://huggingface.co/Comfy-Org/MoGe/resolve/main/moge_2_vitl_normal_fp16.safetensors)
* **MoGe-1（基线版本）**：[moge\_1\_vitl\_fp16.safetensors](https://huggingface.co/Comfy-Org/MoGe/resolve/main/moge_1_vitl_fp16.safetensors)

```
ComfyUI/
├── models/
│   ├── geometry_estimation/
│   │   ├── moge_2_vitl_normal_fp16.safetensors
│   │   └── moge_1_vitl_fp16.safetensors
```

## 工作流示例

***

## 1. 深度估计

**功能：** 输入一张图片，输出公尺度深度图、彩色深度预览和遮罩——即 MoGe 一次推理得到的公尺度深度结果。适合作为场景深度参考用于合成、深度特效，或作为生成网格的前置步骤。

MoGe 还会自动估计图片的相机 FOV，也可以手动输入真实 FOV 以获得更精确的结果。

<Card title="下载工作流" icon="download" href="https://github.com/Comfy-Org/workflow_templates/blob/main/templates/utility_moge_depth_estimation.json">
  下载 JSON 或在模板库中搜索 "MoGe Depth Estimation"
</Card>

<Card title="下载示例素材" icon="image" href="https://raw.githubusercontent.com/Comfy-Org/workflow_templates/main/input/alien_world.png">
  获取本工作流所用的示例输入图片
</Card>

### 1.1 运行步骤

1. 确保 `LoadMoGeModel` 节点已加载 MoGe 检查点
2. 在 `Load Image` 节点中加载一张图片
3. 点击 `Queue` 按钮，或使用快捷键 `Ctrl(cmd) + Enter` 运行
4. 工作流将输出彩色深度预览、原始深度图和遮罩

***

## 2. 透视照片转 3D 网格

**功能：** 将单张透视照片转换为带纹理的 GLB 网格，同时生成法线和深度预览。MoGe 从可见场景中估计点云、深度和法线，再转换为网格。这是**单目几何估计**——遮挡区域和物体背面会缺失或出现碎片。适合场景快速原型、参考几何体，或将深度/法线可视化展示为网格，不能替代多视角 3D 重建。

<Card title="下载工作流" icon="download" href="https://github.com/Comfy-Org/workflow_templates/blob/main/templates/3d_moge_perspective_to_mesh.json">
  下载 JSON 或在模板库中搜索 "3D MoGe Perspective to Mesh"
</Card>

<Card title="下载示例素材" icon="image" href="https://raw.githubusercontent.com/Comfy-Org/workflow_templates/main/input/modern_living_room.png">
  获取本工作流所用的示例输入图片
</Card>

### 2.1 运行步骤

1. 确保 `LoadMoGeModel` 节点已加载 MoGe 检查点
2. 在 `Load Image` 节点中加载一张透视照片
3. （可选）查看 OpenGL 和 DirectX 法线预览
4. 点击 `Queue` 或使用 `Ctrl(cmd) + Enter` 运行

***

## 3. 全景图转 3D 网格

**功能：** 将 360° 等距柱状全景图转换为带纹理的 GLB 网格。该工作流使用 `MoGePanoramaInference` 将全景图分割为 12 个透视视角，分别独立进行单目几何估计后合并为单个网格。每个分段仍然是单视图估计，因此结果是粗略的场景重建——适合获得 360° 场景的空间概览，但遮挡区域和表面后的几何结构会缺失或碎片化。

<Card title="下载工作流" icon="download" href="https://github.com/Comfy-Org/workflow_templates/blob/main/templates/3d_moge_panorama_to_mesh.json">
  下载 JSON 或在模板库中搜索 "3D MoGe Panorama to Mesh"
</Card>

<Card title="下载示例素材" icon="image" href="https://raw.githubusercontent.com/Comfy-Org/workflow_templates/main/input/lego_street_panorama.png">
  获取本工作流所用的示例输入图片
</Card>

### 3.1 运行步骤

1. 确保 `LoadMoGeModel` 节点已加载 MoGe 检查点
2. 在 `Load Image` 节点中加载一张等距柱状投影全景图
3. 点击 `Queue` 按钮，或使用快捷键 `Ctrl(cmd) + Enter` 运行

***

## 社区资源

* [MoGe GitHub (microsoft/MoGe)](https://github.com/microsoft/MoGe) — 研究论文和代码
* [Comfy-Org/MoGe](https://huggingface.co/Comfy-Org/MoGe) — 官方 ComfyUI 模型权重
