<!-- compatibility: compatibility-reference; mirror baseline ComfyUI 0.21.0 -->

> ## Documentation Index
> Fetch the complete documentation index at: https://docs.comfy.org/llms.txt
> Use this file to discover all available pages before exploring further.

# Nodes 2.0

> 了解 Nodes 2.0，ComfyUI 中全新的基于 Vue 的节点渲染系统，实现更快的开发速度和更丰富的交互体验。

Nodes 2.0 现已在 Comfy Desktop、便携版和稳定版中提供。此更新将节点系统从 LiteGraph.js Canvas 渲染过渡到基于 Vue 的架构，实现更快的迭代和更丰富的交互。

## 为什么要做这个改变？

之前的 Canvas 渲染系统已成为开发瓶颈。即使是小的 UI 更改也常常需要深度修改，可能需要数天才能实现。这减慢了响应社区反馈的能力，也使开发者难以进行节点自定义。

新的基于 Vue 的系统带来：

* **更快的功能开发** - UI 更改可以更快地实现
* **更丰富的交互** - 动态小部件、可展开节点和更好的组件
* **更灵活的基础** - 更好地支持未来的工具和自定义

## 当前状态和已知问题

我们正在积极改进，并希望对当前的限制保持透明：

| 领域       | 状态                               |
| -------- | -------------------------------- |
| **性能**   | 仍在优化以达到 Canvas 级别的性能。某些场景可能表现不同。 |
| **兼容性**  | 一些自定义节点可能需要更新才能完全支持。             |
| **边缘情况** | 在极端缩放级别或非常大的工作流中，可能会出现轻微的视觉问题。   |

我们正在收集反馈以确定改进优先级。LiteGraph.js 渲染系统仍然可用，你可以随时在两个系统之间切换。

## 如何试用

### 启用 Nodes 2.0

1. 访问 [cloud.comfy.org](https://cloud.comfy.org) 或更新到最新版本的 Comfy Desktop、便携版或稳定版
2. 启动 ComfyUI 时点击顶部横幅上的 **Try it out**

### 测试内容

在日常工作流中使用 Nodes 2.0 并与我们分享反馈：

* **基本交互** - 拖动、调整大小、选择
* **日常工作流** - 执行、参数、自定义节点
* **性能** - 特别是复杂工作流

## 如何提供反馈

遇到问题或有交互改进建议？

* **支持中心** - [ComfyUI 帮助中心](https://support.comfy.org)
* **GitHub Issues** - [在 ComfyUI\_frontend 创建 issue](https://github.com/Comfy-Org/ComfyUI_frontend/issues)

<Tip>
  报告问题时，包含复现步骤、截图和系统信息会非常有帮助。
</Tip>

## 切换回旧版

如果遇到问题：

1. 点击 **ComfyUI 图标** 打开菜单
2. 切换 **Nodes 2.0** 以返回之前的界面

<img src="https://mintcdn.com/dripart/qbw4z6UfFGJ-L3Cc/images/interface/nodes_2.0.jpg?fit=max&auto=format&n=qbw4z6UfFGJ-L3Cc&q=85&s=859a3a5b4faefd96adb24044ced72f72" alt="ComfyUI 菜单中 Nodes 2.0 切换位置" width="1253" height="1022" data-path="images/interface/nodes_2.0.jpg" />

你的反馈帮助我们确定改进优先级。在设置中启用 Nodes 2.0，开始探索新的节点设计！
