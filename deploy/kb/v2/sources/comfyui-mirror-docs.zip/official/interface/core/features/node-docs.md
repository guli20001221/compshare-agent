<!-- compatibility: core; mirror baseline ComfyUI 0.21.0 -->

> ## Documentation Index
> Fetch the complete documentation index at: https://docs.comfy.org/llms.txt
> Use this file to discover all available pages before exploring further.

# 节点文档 - 查看任何节点的文档

> 了解如何在 ComfyUI 中访问节点的内置文档,包括内置节点和自定义节点。

节点文档提供了快速访问工作流中任何节点文档的功能。您可以直接在 ComfyUI 中查看有关节点功能、参数和使用示例的详细信息。

## 如何查看节点文档

<img src="https://mintcdn.com/dripart/ji4eb8uUyJy_Qth0/images/interface/features/nod-docs/node-docs-1.jpg?fit=max&auto=format&n=ji4eb8uUyJy_Qth0&q=85&s=de1f3d4778383721cc577017281b1ffe" alt="节点文档" width="2004" height="1264" data-path="images/interface/features/nod-docs/node-docs-1.jpg" />

1. **选择节点:**\
   点击工作流中的任何节点以选择它。

2. **打开节点文档:**\
   点击选择工具箱中的节点信息图标以打开节点文档页面。

3. **退出节点文档:**\
   如果您想退出节点文档,可以点击左上角的箭头图标退出节点文档。

## 内置节点文档

ComfyUI 内置节点的文档维护在 [embedded-docs 仓库](https://github.com/Comfy-Org/embedded-docs)中。

**为内置节点文档做贡献:**

* 用户可以为内置节点文档贡献改进和补充
* 向 [embedded-docs 仓库](https://github.com/Comfy-Org/embedded-docs)提交拉取请求
* 帮助改善整个 ComfyUI 社区的文档质量

## 自定义节点文档

自定义节点也可以包含自己的文档。当自定义节点作者提供文档时,当您选择他们的节点时,文档将自动显示在节点文档面板中。

<Card title="开发者指南:添加节点文档" icon="code" href="/zh/custom-nodes/help_page">
  了解如何为您的自定义节点创建丰富的文档
</Card>
