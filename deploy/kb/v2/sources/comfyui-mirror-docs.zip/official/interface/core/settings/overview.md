<!-- compatibility: core; mirror baseline ComfyUI 0.21.0 -->

> ## Documentation Index
> Fetch the complete documentation index at: https://docs.comfy.org/llms.txt
> Use this file to discover all available pages before exploring further.

# ComfyUI 设置概览

> ComfyUI 设置概览的详细说明

这个部分是关于 ComfyUI 前端设置菜单中详细的设置说明， 对于所有的用户设置将会自动保存到 `ComfyUI/user/default/comfy.settings.json` 文件夹

你可以使用 `ctrl + ,` 快捷键来打开设置面板， 然后点击对应的设置选项进行设置。

由于自定义节点也可以在菜单中注册对应的设置类目，在我们的官方文档说明中目前仅包含原生的设置内容，另外有部分选项设置 **仅针对 Comfy 桌面版** 有效，我们也在对应页面中做了注释说明。

## ComfyUI 设置菜单

<Columns cols={3}>
  <Card title="用户" icon="user" href="/zh/interface/user">
    用户设置与 ComfyUI 账户相关，主要用于登录 ComfyUI 账户，以使用 API 节点
  </Card>

  <Card title="积分" icon="credit-card" href="/zh/interface/credits">
    购买积分及积分余额的历史入口，仅在登录 ComfyUI 账户后可见
  </Card>

  <Card title="Comfy" icon="sliders" href="/zh/interface/settings/comfy">
    ComfyUI 核心设置选项的详细说明
  </Card>

  <Card title="画面" icon="diagram-project" href="/zh/interface/settings/lite-graph">
    ComfyUI 中画面（Lite Graph）设置选项的详细说明
  </Card>

  <Card title="外观" icon="palette" href="/zh/interface/appearance">
    修改 ComfyUI 的外观选项，如主题、背景色、侧边栏位置等等
  </Card>

  <Card title="扩展" icon="puzzle-piece" href="/zh/interface/settings/extension">
    管理 ComfyUI 中前端扩展插件的启用/禁用状态
  </Card>

  <Card title="3D" icon="cube" href="/zh/interface/settings/3d">
    针对 3D 节点初始化时的一些设置选项
  </Card>

  <Card title="Comfy桌面版" icon="desktop" href="/zh/interface/settings/comfy-desktop">
    桌面版更新设置，镜像设置等(仅针对 Comfy 桌面版有效)
  </Card>

  <Card title="Mask Editor" icon="brush" href="/zh/interface/settings/mask-editor">
    调整蒙版编辑器的使用偏好
  </Card>

  <Card title="快捷键" icon="keyboard" href="/zh/interface/shortcuts">
    修改 ComfyUI 的快捷键设置
  </Card>

  <Card title="关于" icon="info" href="/zh/interface/settings/about">
    了解当前的 ComfyUI 版本信息，设备运行信息等，这在日常反馈中非常有用
  </Card>

  <Card title="服务器配置" icon="server" href="/zh/interface/settings/server-config">
    修改 ComfyUI 的配置文件， 此设置仅针对 Comfy 桌面版有效
  </Card>
</Columns>
