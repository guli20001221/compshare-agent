<!-- compatibility: core; mirror baseline ComfyUI 0.21.0 -->

> ## Documentation Index
> Fetch the complete documentation index at: https://docs.comfy.org/llms.txt
> Use this file to discover all available pages before exploring further.

# ComfyUI 界面概览

> 在本篇中，我们将简要介绍 ComfyUI 的基础用户界面，带你熟悉了解 ComfyUI 界面的各个部分，

可视化界面是目前绝大数用户使用 ComfyUI 来调用 [ComfyUI Server](/zh/development/comfyui-server/comms_overview) 进行相应媒体资源生成的方式，它提供了一个可供用户操作和组织工作流的可视化界面，用于组织和调试工作流，并生成令人惊叹的作品。

在本篇我们将粗略介绍 ComfyUI 的界面以及各个部分的功能，在后续的章节中我们将详细介绍各个部分的功能和使用方法。

通常，当你当你启动 ComfyUI 后你可以看到下面这样的一个界面：

<img src="https://mintcdn.com/dripart/ypWEPMPDkbY_QhNi/images/interface/overview/comfyui_new_interface.jpg?fit=max&auto=format&n=ypWEPMPDkbY_QhNi&q=85&s=db199ae509fd06fc6aa9e47fcc4f361c" alt="ComfyUI 基础界面" width="2000" height="1203" data-path="images/interface/overview/comfyui_new_interface.jpg" />

如果你是较为早期的用户，你应该还见过之前的这样的菜单界面：

<img src="https://mintcdn.com/dripart/qYv6P0RgI3co7-eH/images/interface/overview/comfyui_old_interface.jpg?fit=max&auto=format&n=qYv6P0RgI3co7-eH&q=85&s=267da568996a69c02267d78196edece2" alt="ComfyUI 旧界面" width="2000" height="1334" data-path="images/interface/overview/comfyui_old_interface.jpg" />

这两个菜单界面可以通过设置进行切换，但随着 ComfyUI 的功能日益强大和复杂，我们建议你使用新版的菜单界面来获得更好的使用体验。

目前 ComfyUI前端是一个独立的项目，作为一个独立的 ComfyUI 依赖进行发布和更新维护，如果你想要参与贡献，可以 fork 这个[仓库](https://github.com/Comfy-Org/ComfyUI_frontend)，并进行 pull request。

## 本地化支持

目前 ComfyUI 支持：包括英文、中文、俄罗斯语、法语、日文、韩文。
如果你需要切换界面语言到你需要的语言可以点击 **设置齿轮图标** 然后在 `Comfy` --> `Locale` 中选择你需要的语言。

<img src="https://mintcdn.com/dripart/qYv6P0RgI3co7-eH/images/interface/overview/locale.jpg?fit=max&auto=format&n=qYv6P0RgI3co7-eH&q=85&s=e5f9d37eb8ea17027846273e69bf292e" alt="ComfyUI 本地化支持" width="1508" height="936" data-path="images/interface/overview/locale.jpg" />

## 新版菜单界面

### 界面分区（Workspace）

下面是主要的 ComfyUI 的界面分区以及各部分的简要介绍。

<img src="https://mintcdn.com/dripart/ypWEPMPDkbY_QhNi/images/interface/overview/comfyui-new-interface-main.png?fit=max&auto=format&n=ypWEPMPDkbY_QhNi&q=85&s=4d8a98690f3a7f78a194b8dfffa63ace" alt="ComfyUI 工作区" width="4000" height="2436" data-path="images/interface/overview/comfyui-new-interface-main.png" />

目前 ComfyUI 的界面除开主要的工作流界面，主要分为以下几个部分：

1. **主菜单**：点击展开功能菜单，含文件操作、帮助菜单等。

**左侧导航栏：**
2\. **左侧面板入口**：

* **ASSETS**：显示生成的图像、视频等资产。
* **Nodes**：列出 ComfyUI 原生及第三方节点。
* **Models**：展示 ComfyUI 启动后检测到的模型信息，启动后若有模型下载等，按快捷键 `r` 刷新节点定义获取最新模型。
* **Workflows**：展示本地保存的工作流。
* **Templates**：提供 ComfyUI 内置工作流模板。

**底部左侧工具栏：**
3\. **底部工具栏**：含帮助、控制台（打开运行日志）、快捷键（显示快捷键面板）、设置（打开设置面板）按钮。

**顶部标题栏：**
4\. **顶部区域**：显示当前已打开工作流。
5\. **新建工作流按钮**：点击新建空白工作流文件。
6\. **右侧控制区**：运行和队列控制管理，可运行工作流、查看队列。
7\. **登录状态**：默认不显示，仅在登录后显示，用于需闭源 API 节点时。
8\. **快捷按钮**：打开右侧面板。

**底部右侧画布控制：**
9\. **画布导航工具**：可切换移动或平移模式，打开小地图、切换节点连线显示。

### 侧边栏面板按钮

<img src="https://mintcdn.com/dripart/qYv6P0RgI3co7-eH/images/interface/overview/side-panel.png?fit=max&auto=format&n=qYv6P0RgI3co7-eH&q=85&s=138181422006bac20c5d092f729f00b3" alt="ComfyUI 侧边栏面板" width="1909" height="1007" data-path="images/interface/overview/side-panel.png" />

在目前的 ComfyUI 中，我们提供了四个侧边面板包含了以下功能：

1. 工作流历史队列(Queue)： 所有 ComfyUI 执行媒体内容生成的队列信息
2. 节点库(Node Library)： 所有 ComfyUI 中的节点包括`Comfy Core` 和你安装的自定义节点都会可以在这里进行查找
3. 模型库(Model Library)： 你本地的`ComfyUI/models` 目录下的模型可以在这里被查找到
4. 本地用户工作流(Workflows)： 你本地保存的工作流可以在这里被查找到

## 旧版菜单

目前 ComfyUI 默认启用新版界面，如果你更偏好使用旧版界面，可以点击 **设置齿轮图标** 然后在 `Comfy` --> `菜单(Menu)` 将 `使用新菜单(Use new menu)` 设置为 `disabled` 即可切换到旧版本的菜单。

<Note>
  旧版菜单界面仅支持英文。
</Note>

旧版本菜单界面功能标注说明如下：

<img src="https://mintcdn.com/dripart/SIDaLac8vBogzwm7/images/zh/interface/comfyui-old-menu.png?fit=max&auto=format&n=SIDaLac8vBogzwm7&q=85&s=01c840da5ea420dea500a0e0160e1f1b" alt="ComfyUI 旧版菜单" width="884" height="1126" data-path="images/zh/interface/comfyui-old-menu.png" />
