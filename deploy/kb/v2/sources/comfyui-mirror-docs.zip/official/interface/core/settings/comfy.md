<!-- compatibility: core; mirror baseline ComfyUI 0.21.0 -->

> ## Documentation Index
> Fetch the complete documentation index at: https://docs.comfy.org/llms.txt
> Use this file to discover all available pages before exploring further.

# Comfy 设置

> ComfyUI 核心设置选项的详细说明

<Info>
  本页面中描述的设置项位于 **ComfyUI 软件内的设置菜单**中。你可以通过点击 **设置**（齿轮图标）或使用 `Ctrl + ,` 快捷键打开设置面板，然后选择对应的分类来查看和配置这些选项。
</Info>

## 开发者模式

### 启用开发模式选项（API 保存等）

* **默认值**：禁用
* **功能**：启用开发者模式选项（如API保存等）

## 编辑令牌权重

### Ctrl+上/下 精度

* **默认值**：0.01
* **功能**：当你在使用类型 CLIPTextEncode 或者文本框输入类的节点组件时，使用 Ctrl+上/下 可以快速调整权重，这个选项会改变每次调整的权重值

<video controls>
  <source src="https://mintcdn.com/dripart/qYv6P0RgI3co7-eH/images/interface/setting/comfy/token_weight.mp4?fit=max&auto=format&n=qYv6P0RgI3co7-eH&q=85&s=d65dd660f6b706e509bab75387c0b1bc" type="video/mp4" data-path="images/interface/setting/comfy/token_weight.mp4" />
</video>

## 区域设置（本地化）

### 语言

* **选项**：中文 (Chinese)、English (英文)、日本語 (日文)、한국어 (韩文)、Русский (俄文)、Español (西班牙语)、Français (法语)
* **默认值**：自动检测浏览器语言
* **功能**：修改 ComfyUI 界面显示语言

## 菜单

### 使用新菜单

* **默认值**：顶部
* **功能**：选择菜单界面和位置，目前仅支持顶部、底部、禁用

<Tabs>
  <Tab title="顶部">
    菜单界面将会显示在工作界面的顶部

    <img src="https://mintcdn.com/dripart/qYv6P0RgI3co7-eH/images/interface/setting/comfy/UseNewMenu_top.jpg?fit=max&auto=format&n=qYv6P0RgI3co7-eH&q=85&s=b370775415cd976a1d4bb3dd1034789f" alt="顶部菜单" width="2684" height="1436" data-path="images/interface/setting/comfy/UseNewMenu_top.jpg" />
  </Tab>

  <Tab title="底部">
    菜单栏界面将会显示工作界面的底部

    <img src="https://mintcdn.com/dripart/qYv6P0RgI3co7-eH/images/interface/setting/comfy/UseNewMenu_bottom.jpg?fit=max&auto=format&n=qYv6P0RgI3co7-eH&q=85&s=f32277b0016b128cf57783fc09b2ec18" alt="底部菜单" width="2700" height="1436" data-path="images/interface/setting/comfy/UseNewMenu_bottom.jpg" />
  </Tab>

  <Tab title="禁用">
    如果你偏好早期旧版菜单，可以尝试使用这个选项。

    <Tip>
      由于我们在不断更新，一些新功能支持并不会在旧版菜单中同步支持。
    </Tip>

    <img src="https://mintcdn.com/dripart/qYv6P0RgI3co7-eH/images/interface/setting/comfy/UseNewMenu_disable.jpg?fit=max&auto=format&n=qYv6P0RgI3co7-eH&q=85&s=516d891c3cda836135b996b7b5a23b69" alt="旧版菜单" width="2680" height="1444" data-path="images/interface/setting/comfy/UseNewMenu_disable.jpg" />
  </Tab>
</Tabs>

## 模型库

模型库指的是 ComfyUI 侧边菜单栏中的模型管理功能，你可以通过这个功能来查看你在 `ComfyUI/models` 及额外配置的模型文件夹中的模型

<img src="https://mintcdn.com/dripart/NmGUk_QSXQXRVtZP/images/interface/sidepanel/model_library.jpg?fit=max&auto=format&n=NmGUk_QSXQXRVtZP&q=85&s=f501edd3ce0fa0b80ba641efafdb5998" alt="模型库" width="1050" height="1401" data-path="images/interface/sidepanel/model_library.jpg" />

### 模型库名称格式

* **默认值**：标题
* **功能**：选择在模型库树视图中显示的名称格式，目前仅支持文件名、标题

### 自动加载所有模型文件夹

* **默认值**：禁用
* **功能**：是否在点击模型库时自动检测所有文件夹下的模型文件，启用可能导致加载延迟（需要循环遍历所有文件夹），禁用时只有点击文件夹名称才会加载对应文件夹下的文件

## 节点

在 ComfyUI 的迭代过程中，我们会对一些节点进行调整，也会启用一些节点，这些节点可能在未来版本中发生重大变化或被移除，但是为了保证兼容性类似弃用的节点并没有被移除，你可以通过下面的设置来启用是否显示 **实验性节点** 和 **已弃用节点**

### 在搜索中显示已弃用节点

* **默认值**：禁用
* **功能**：控制是否在搜索中显示已弃用的节点，已弃用节点在UI中默认隐藏，但在现有工作流中仍然有效

<img src="https://mintcdn.com/dripart/qYv6P0RgI3co7-eH/images/interface/setting/comfy/depr_node.jpg?fit=max&auto=format&n=qYv6P0RgI3co7-eH&q=85&s=be33ca36eb10dc84a8f83aa8955738e4" alt="在搜索中显示已弃用节点" width="1582" height="1056" data-path="images/interface/setting/comfy/depr_node.jpg" />

### 在搜索中显示实验性节点

* **默认值**：启用
* **功能**：控制是否在搜索中显示实验性节点，实验性节点是一些新的功能支持，但未完全稳定，可能在未来版本中发生变化或被移除

<img src="https://mintcdn.com/dripart/qYv6P0RgI3co7-eH/images/interface/setting/comfy/beta_node.jpg?fit=max&auto=format&n=qYv6P0RgI3co7-eH&q=85&s=df6bf1a7220de526ab8f115744dcfde4" alt="在搜索中显示实验性节点" width="1582" height="1314" data-path="images/interface/setting/comfy/beta_node.jpg" />

## 节点搜索框

### 节点建议数量

* **默认值**：5
* **功能**：用于修改相关节点上下文菜单中推荐的节点数量，数值越大显示的相关推荐节点数量越多

<img src="https://mintcdn.com/dripart/qYv6P0RgI3co7-eH/images/interface/setting/comfy/node_suggestions.jpg?fit=max&auto=format&n=qYv6P0RgI3co7-eH&q=85&s=5dc8c7cc67b5ac49fd5a0d733cb73c04" alt="节点建议数量" width="2046" height="924" data-path="images/interface/setting/comfy/node_suggestions.jpg" />

### 显示节点频率

* **默认值**：禁用
* **功能**：控制是否在搜索结果中显示节点使用频率

<img src="https://mintcdn.com/dripart/qYv6P0RgI3co7-eH/images/interface/setting/comfy/node_frequency.png?fit=max&auto=format&n=qYv6P0RgI3co7-eH&q=85&s=fd5b96762d9d576791799c7c2752f6ab" alt="节点频率" width="1364" height="790" data-path="images/interface/setting/comfy/node_frequency.png" />

### 显示节点ID名称

* **默认值**：禁用
* **功能**：控制是否在搜索结果中显示节点ID名称

<img src="https://mintcdn.com/dripart/qYv6P0RgI3co7-eH/images/interface/setting/comfy/node_id_name.jpg?fit=max&auto=format&n=qYv6P0RgI3co7-eH&q=85&s=e199bad550b5b9cb99454e2722ce3bf0" alt="节点ID名称" width="1364" height="790" data-path="images/interface/setting/comfy/node_id_name.jpg" />

### 显示节点类别

* **默认值**：启用
* **功能**：控制是否在搜索结果中显示节点类别，帮助用户了解节点的分类信息

### 节点预览

* **默认值**：启用
* **功能**：控制是否在搜索结果中显示节点预览，方便你快速预览节点

### 节点搜索框

* **默认值**：默认
* **功能**： 选择节点搜索框的实现方式（实验性功能），如果选择 `litegraph（旧版）` 则会切换到早期的 ComfyUI 的搜索框

## 节点组件

### 组件控制模式

* **选项**：之前、之后
* **功能**：控制节点组件值的更新时机是在工作流运行之前还是滞后，比如更新 seed 种子的值

### 文本框组件拼写检查

* **默认值**：禁用
* **功能**：控制文本域小部件是否启用拼写检查, 在文本输入时提供拼写检查功能, 这一功能是通过浏览器的 spellcheck 属性实现的

## 队列

### 队列历史大小

* **默认值**：100
* **功能**：控制侧边栏队列历史面板里记录的队列历史大小，数值越大记录的队列历史越多，数量多大时加载页面时也会占用更多内存

## 执行按钮

### 批处理计数限制

* **默认值**：100
* **功能**：设置单次点击添加到队列的最大任务数量，防止意外添加过多任务到队列

## 验证

### 验证节点定义（慢）

* **默认值**：禁用
* **功能**：控制是否在启动时验证所有节点定义（慢），仅推荐给节点开发者使用，当启用时系统会使用 Zod 模式对每个节点定义进行严格验证，这一功能会消耗更多内存和时间
* **错误处理**：验证失败的节点定义会被跳过，并在控制台输出警告信息

<Tip>
  由于需要对所有节点定义进行详细的模式验证，这个功能会显著增加启动时间，因此默认关闭，仅推荐给节点开发者使用
</Tip>

### 校验工作流

* **默认值**：启用
* **功能**：确保工作流的结构和连接正确性, 如果启用，系统会调用 `useWorkflowValidation().validateWorkflow()` 对工作流数据进行验证
* **验证过程**：验证过程包含两个步骤：
  * 模式验证: 使用 Zod 模式验证工作流结构
  * 链接修复: 检查并修复节点间的连接问题
* **错误处理**：验证失败时会显示错误提示，但不会阻止工作流加载

## 窗口

### 关闭窗口时显示确认

* **默认值**：启用
* **功能**：当存在已修改但未保存的工作流时，控制关闭浏览器窗口或标签页时是否显示确认，防止意外关闭窗口导致未保存的工作流丢失

## 工作流

### 持久化工作流状态并在页面（重新）加载时恢复

* **默认值**：启用
* **功能**：控制是否在页面（重新）加载时恢复工作流状态，在页面刷新后保持工作流内容

### 自动保存

* **默认值**：关闭
* **功能**：控制工作流的自动保存行为，自动保存工作流更改，避免数据丢失

### 自动保存延迟（毫秒）

* **默认值**：1000
* **功能**：设置自动保存的延迟时间，仅在自动保存设置为"延迟后"时生效

### 删除工作流时显示确认

* **默认值**：启用
* **功能**：控制在侧边栏删除工作流时是否显示确认对话框，防止意外删除重要工作流

### 在工作流中保存和恢复视图位置及缩放

* **默认值**：启用
* **功能**：控制是否在工作流中保存和恢复画布位置和缩放级别，在重新打开工作流时恢复之前的视图状态

### 已打开工作流位置

* **选项**：侧边栏、顶部栏、顶部栏（第二行）
* **默认值**：顶部栏
* **功能**：控制打开的工作流标签的显示位置，目前仅支持侧边栏、顶部栏、顶部栏（第二行）

### 保存工作流时提示文件名

* **默认值**：启用
* **功能**：控制保存工作流时是否提示输入文件名，允许用户自定义工作流文件名

### 保存工作流时排序节点ID

* **默认值**：禁用
* **功能**：决定保存工作流时是否对节点ID进行排序，使工作流文件格式更规范，便于版本控制

### 显示缺失节点警告

* **默认值**：启用
* **功能**：控制是否显示工作流中缺失节点的警告，帮助用户识别工作流中不可用的节点

### 显示缺失模型警告

* **默认值**：启用
* **功能**： 我们支持在工作流文件中对 widget 的值添加模型链接信息，用于加载模型文件时的提示，当启用时如果你本地没有对应的模型文件则会显示工作流中缺失模型的警告

### 清除工作流时需要确认

* **默认值**：启用
* **功能**：控制清除工作流时是否显示确认对话框，防止意外清除工作流内容

### 保存节点ID到工作流

* **默认值**：启用
* **功能**：控制是否在保存工作流时保存节点ID，使工作流文件格式更规范，便于版本控制
