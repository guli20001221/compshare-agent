<!-- compatibility: core; mirror baseline ComfyUI 0.21.0 -->

> ## Documentation Index
> Fetch the complete documentation index at: https://docs.comfy.org/llms.txt
> Use this file to discover all available pages before exploring further.

# 遮罩编辑器 - 在 ComfyUI 中创建和编辑遮罩

> 讲解 ComfyUI 中遮罩编辑器（Mask Editor）的使用方法，包括工具、图层、设置和快捷键

遮罩编辑器是 ComfyUI 内置的一个实用工具，让你可以直接在图像上创建和编辑遮罩，无需借助外部图像编辑软件。它支持多种绘图工具、图层管理、撤回/重做、画布变换以及 GPU 加速的笔刷渲染。

***

## 如何打开

有三种方式可以打开遮罩编辑器：

1. **选择工具栏** — 选中一个 Load Image 节点，然后点击节点上方选择工具栏中的 Mask 图标按钮。
2. **图像叠加层** — 悬停在图像预览（gallery 模式）上，点击左上角出现的「Edit or mask image」按钮（mask 图标）。
3. **右键菜单** — 右键点击 Load Image 节点，从菜单中选择「在蒙版编辑器中打开」。

> 遮罩编辑器在**图形模式**和**应用模式**下均可使用。

<img src="https://mintcdn.com/dripart/deAUfL_Wa99SBtzt/images/interface/maskeditor/maskeditor_3ways_to_open_maskeditor.png?fit=max&auto=format&n=deAUfL_Wa99SBtzt&q=85&s=1d23aa1f54e8869c1fb5fcb27297d085" alt="三种打开遮罩编辑器的方式：Selection Toolbox、Image Overlay、右键菜单" width="3628" height="1685" data-path="images/interface/maskeditor/maskeditor_3ways_to_open_maskeditor.png" />

***

## 界面概览

<img src="https://mintcdn.com/dripart/deAUfL_Wa99SBtzt/images/interface/maskeditor/maskeditor_main_editor.jpg?fit=max&auto=format&n=deAUfL_Wa99SBtzt&q=85&s=43acb2c6acf54fe64d7e69f08f3be0bb" alt="遮罩编辑器主界面：工具面板、画布、设置面板" width="4000" height="2561" data-path="images/interface/maskeditor/maskeditor_main_editor.jpg" />

遮罩编辑器以模态对话框打开，包含四个主要区域：

| # | 区域       | 位置 | 说明                           |
| - | -------- | -- | ---------------------------- |
| 1 | **顶部栏**  | 顶部 | 标题栏，包含撤回/重做、画布变换、反转/清除、保存/取消 |
| 2 | **工具面板** | 左侧 | 工具选择和缩放信息                    |
| — | **画布区域** | 中央 | 主画布区域，用于绘制和编辑                |
| 3 | **侧边面板** | 右侧 | 工具专属设置和图层控制                  |

***

## 工具

左侧工具面板提供了五种工具。选择工具激活后，右侧面板会显示对应的设置项。

<img src="https://mintcdn.com/dripart/deAUfL_Wa99SBtzt/images/interface/maskeditor/maskeditor_tool_panel.jpg?fit=max&auto=format&n=deAUfL_Wa99SBtzt&q=85&s=ff9ac93d88947155aa19d529c7f0cbea" alt="遮罩编辑器工具面板，5 种工具带编号" style={{maxWidth: '300px'}} width="1226" height="1404" data-path="images/interface/maskeditor/maskeditor_tool_panel.jpg" />

| # | 工具               | 图层        | 说明                                                                  |
| - | ---------------- | --------- | ------------------------------------------------------------------- |
| 1 | **Mask Pen**     | 遮罩层       | 主要遮罩绘制工具。左键拖拽在图像上绘制遮罩。                                              |
| 2 | **Paint Pen**    | 绘画层（RGB）  | 直接在图像的 RGB 层上绘制。适用于局部重绘或原图修补。                                       |
| 3 | **Eraser**       | 遮罩层 / 绘画层 | 擦除已有遮罩或绘画层的部分内容。                                                    |
| 4 | **Paint Bucket** | 遮罩层       | 基于颜色相似性的洪水填充工具。点击像素填充连通区域创建遮罩；点击已有遮罩的区域则擦除遮罩。阈值（Tolerance）控制填充扩散范围。 |
| 5 | **Color Select** | 遮罩层       | 选择性地遮罩与目标颜色匹配的所有像素，支持高级匹配算法（Simple / HSL / LAB）。                    |

***

## TopBar 操作

<img src="https://mintcdn.com/dripart/deAUfL_Wa99SBtzt/images/interface/maskeditor/maskeditor_topbar_actions.jpg?fit=max&auto=format&n=deAUfL_Wa99SBtzt&q=85&s=d390383a7c11e4f19ec500eab58b6e99" alt="遮罩编辑器 TopBar 操作标注 1–10" width="3598" height="870" data-path="images/interface/maskeditor/maskeditor_topbar_actions.jpg" />

顶部栏提供了画布级别的操作：

| #  | 操作                            | 说明             |
| -- | ----------------------------- | -------------- |
| 1  | **撤回**（Ctrl+Z）                | 撤回上一步操作        |
| 2  | **重做**（Ctrl+Shift+Z / Ctrl+Y） | 重做被撤回的操作       |
| 3  | **向左旋转**                      | 将所有图层逆时针旋转 90° |
| 4  | **向右旋转**                      | 将所有图层顺时针旋转 90° |
| 5  | **水平翻转**                      | 水平翻转所有图层       |
| 6  | **垂直翻转**                      | 垂直翻转所有图层       |
| 7  | **反转**                        | 反转遮罩（黑白互换）     |
| 8  | **清除**                        | 清除整个遮罩         |
| 9  | **保存**                        | 保存遮罩并关闭编辑器     |
| 10 | **取消**                        | 关闭编辑器，不保存      |

> **注意**：旋转和翻转操作会同时影响所有三个图层（遮罩层、绘画层和原图层）。GPU 加速纹理会在变换后重新创建。

***

## 图层

右侧面板底部包含 **图层** 区域，可以独立控制每个图层的显示/隐藏：

* **遮罩层**：遮罩叠加层。可调整**遮罩不透明度**和**遮罩混合设置**：
  * `黑` — 遮罩以黑色叠加显示
  * `白` — 遮罩以白色叠加显示
  * `负面` — 反转遮罩渲染
* **绘画层**：RGB 绘画层（使用 Paint Pen 时可见）
* **基础图像层**：原始源图像

点击图层上的 **活跃层** 可切换绘制焦点到该图层。

参照上方主界面截图 — 右侧面板包含笔刷设置和底部的图层区域。

***

## 笔刷设置

当基于笔刷的工具（Mask Pen、Paint Pen 或 Eraser）激活时，侧边面板显示笔刷设置：

| 设置项      | 范围         | 说明                     |
| -------- | ---------- | ---------------------- |
| **笔刷形状** | Arc / Rect | 圆形笔刷或方形笔刷              |
| **色彩选取** | 任意十六进制颜色   | 绘制颜色（Paint Pen 用）或遮罩颜色 |
| **厚度**   | 1–250      | 画笔直径（像素）               |
| **不透明度** | 0–1        | 画笔笔触透明度                |
| **硬度**   | 0–1        | 边缘柔和度。1 = 硬边缘，0 = 非常柔和 |
| **间距**   | 1–100      | 画笔点之间的间距。值越低笔触越平滑      |

使用 **重置为默认** 恢复默认画笔参数。

***

## 画布导航与快捷键

| 快捷键                                 | 操作                         |
| ----------------------------------- | -------------------------- |
| **Space + 拖拽**                      | 平移画布                       |
| **Ctrl + 滚轮**                       | 放大/缩小                      |
| **点击缩放百分比**                         | 将缩放重置为 100%                |
| **Ctrl + Z**                        | 撤回                         |
| **Ctrl + Shift + Z** 或 **Ctrl + Y** | 重做                         |
| **Alt + 右键拖拽**                      | 调整笔刷：左右改变**大小**，上下改变**硬度** |

***

## 设置

在 ComfyUI 的设置面板中，可以配置以下遮罩编辑器选项：

| 设置项                                        | 分类                                                 | 默认值           | 说明                          |
| ------------------------------------------ | -------------------------------------------------- | ------------- | --------------------------- |
| **Brush adjustment speed multiplier**      | Mask Editor → Brush Adjustment → Sensitivity       | 1.0 (0.1–2.0) | 控制 Alt+右键拖拽调整笔刷时的速度，值越大变化越快 |
| **Lock brush adjustment to dominant axis** | Mask Editor → Brush Adjustment → Use Dominant Axis | 开启            | 开启后，调整仅基于移动的主轴方向影响大小或硬度     |

***

## 演示视频

<video controls>
  <source src="https://mintcdn.com/dripart/EgZuQyCGLVUEw53Z/images/interface/maskeditor/maskeditor.mp4?fit=max&auto=format&n=EgZuQyCGLVUEw53Z&q=85&s=f2f905b202074a6f51d1021e799d894d" type="video/mp4" data-path="images/interface/maskeditor/maskeditor.mp4" />

  你的浏览器不支持 video 标签。
</video>

> **说明**：该视频展示的是旧版遮罩编辑器（Nodes 1.0 UI），演示了笔刷粗细调整和遮罩预览创建的基本流程。当前版本的核心工作流与此相同。
