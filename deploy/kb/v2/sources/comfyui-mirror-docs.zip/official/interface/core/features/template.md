<!-- compatibility: core; mirror baseline ComfyUI 0.21.0 -->

> ## Documentation Index
> Fetch the complete documentation index at: https://docs.comfy.org/llms.txt
> Use this file to discover all available pages before exploring further.

# 工作流模板 - ComfyUI 内置工作流模板

> 模板中提供了 ComfyUI 原生支持的模型工作流以及自定义节点提供的示例工作流，你可以在模板中找到目前已被支持的相关模型的工作流并进行使用

工作流模板是 ComfyUI 中原生支持的模型工作流及自定义节点提供的模型工作流的浏览窗口。

在 ComfyUI 的工作流模板功能中，你可以找到以下内容：

* 原生支持的模型工作流
* 自定义节点提供的示例工作流

<img src="https://mintcdn.com/dripart/7m9lukFrTCZs7Mhj/images/interface/features/template/template_library.png?fit=max&auto=format&n=7m9lukFrTCZs7Mhj&q=85&s=d9f27d6bda046bb48c6b618be8ac85da" alt="Template" width="2422" height="1726" data-path="images/interface/features/template/template_library.png" />

## 如何打开 ComfyUI 的模板

在侧边栏点击 **Templates** 图标即可打开工作流模板。你也可以通过菜单 **工作流** → **浏览工作流模板** 打开。

<img src="https://mintcdn.com/dripart/7m9lukFrTCZs7Mhj/images/interface/features/template/template.png?fit=max&auto=format&n=7m9lukFrTCZs7Mhj&q=85&s=36d5b46c782c6235ec56bfba9d1ff346" alt="Template" width="1137" height="1010" data-path="images/interface/features/template/template.png" />

## 如何使用模板

1. 加载模板： 点击你需要使用的任意模板以加载对应的模板工作流
2. 下载模型： 在加载模板时，ComfyUI 会自动检查模型文件是否存在，如果模型文件不完整，则会提示你下载模型
3. 使用工作流： 确定工作流的需要的各种要素如模型、输入图片、提示词等是完整的，即可点击运行按钮开始使用工作流

### 模型保存位置

每个工作流模板都嵌入了对应的模型链接，在首次使用时如果没有检测到对应的模型文件，则会提示下载信息

<img src="https://mintcdn.com/dripart/EgZuQyCGLVUEw53Z/images/interface/features/template/missing_models.jpg?fit=max&auto=format&n=EgZuQyCGLVUEw53Z&q=85&s=8c1d9ac6dd0acf6d220eda2842a41434" alt="Missing Models" width="1458" height="1102" data-path="images/interface/features/template/missing_models.jpg" />

1. 对于桌面版，当你点击`下载`按钮后， 桌面程序会自动为你完成模型文件的下载
2. 其它版本则会通过浏览器下载对应模型，你需要下载后将对应的模型保存到 `ComfyUI/models` 对应的文件夹，比如截图中对应的模型应保存的位置为：

```
📂 ComfyUI/
├── 📂 models/
│   ├── 📂 diffusion_models/
│   │   └── qwen_image_fp8_e4m3fn.safetensors
│   ├── 📂 vae/
│   │   └── qwen_image_vae.safetensors
│   └── 📂 text_encoders/
│       └── qwen_2.5_vl_7b_fp8_scaled.safetensors
```

在目前版本中，模板的缺失文件检测仅支持检测模型是否在对应的一级目录下是否有同名文件，也就是文件需要在 `ComfyUI/models/diffusion_models` 下存在，
如果你已经下载好了模型并存放在类似：`ComfyUI/models/diffusion_models/wan_video` 的子文件夹，那么你可以忽略弹窗提示，在对应的模型加载节点确保对应的模型被加载选择即可。

如果你好奇我们是如何做到嵌入模型链接的，我们在对应节点的 `properties` 中添加了 `models` 信息， 下面是嵌入了模型信息的 `DualCLIPLoader` 节点的完整片段：

```json theme={null}
    {
      "id": 40,
      "type": "DualCLIPLoader",
      "pos": [
        -320,
        290
      ],
      "size": [
        270,
        130
      ],
      "flags": {},
      "order": 0,
      "mode": 0,
      "inputs": [],
      "outputs": [
        {
          "name": "CLIP",
          "type": "CLIP",
          "links": [
            64
          ]
        }
      ],
      "properties": {
        "Node name for S&R": "DualCLIPLoader",
        "cnr_id": "comfy-core",
        "ver": "0.3.40",
        "models": [
          {
            "name": "clip_l.safetensors",
            "url": "https://huggingface.co/comfyanonymous/flux_text_encoders/resolve/main/clip_l.safetensors",
            "directory": "text_encoders"
          },
          {
            "name": "t5xxl_fp16.safetensors",
            "url": "https://huggingface.co/comfyanonymous/flux_text_encoders/resolve/main/t5xxl_fp16.safetensors",
            "directory": "text_encoders"
          }
        ]
      },
      "widgets_values": [
        "clip_l.safetensors",
        "t5xxl_fp16.safetensors",
        "flux",
        "default"
      ]
    }
```

在 `properties` 中新增了 `models`, 对应的模型信息包含了对应的 `name`、`url` 以及 `directory` 信息。

* `name` 对应了模型文件的名称
* `url` 对应了模型文件的下载链接(可直接下载的文件链接，而不是仓库地址)
* `directory` 对应了模型文件的下载后应存储到的 ComfyUI/models 目录下的哪个子目录， 如 `vae` 则对应 `ComfyUI/models/vae` 目录

目前模型链接仅支持 huggingface 和 civitai 来源的链接，并且要求模型格式为安全的模型格式如 `.safetensors`, `.sft` 格式等，类似  `.gguf`, 不安全格式在嵌入后会提示不安全并不显示链接

你可以使用[这个工具](https://comfyui-wiki.github.io/ComfyUI-Workflow-JSON-Editor/)来编辑工作流模板中的模型信息，但目前 [@ComfyUI-Wiki](https://github.com/ComfyUI-Wiki) 仅对原生的节点增加了支持。

## 如何更新模板？

目前模板是通过一个单独依赖的形式进行管理和更新的，对应的地址为：[comfyui-workflow-templates](https://pypi.org/project/comfyui-workflow-templates/)

如果你在更新 ComfyUI 后发现没有文档或者我们的更新说明中新增的模板，那么可能是你没有在更新 ComfyUI 之后更新对应的依赖, 你可以访问 [ComfyUI/requirements.txt](https://github.com/Comfy-Org/ComfyUI/blob/master/requirements.txt) 来查看对应的依赖版本

通常下面的三个依赖是每次更新 ComfyUI 时我们也可能会同时升级的

```
comfyui-frontend-package==1.24.4
comfyui-workflow-templates==0.1.52
comfyui-embedded-docs==0.2.4
```

如果你不了解如何正确更新，请参考 [更新 ComfyUI](/zh/installation/update_comfyui) 章节了解如何更新 ComfyUI 和对应的依赖

## 如何向 ComfyUI 官方贡献模板？

目前所有的模板都托管在 [workflow\_templates](https://github.com/Comfy-Org/workflow_templates/) 仓库中，你可以通过提交 PR 的方式来贡献模板，对于官方模板我们要求如下：

1. 不使用任何的第三方节点（避免用户因为缺失节点导致需要额外的安装）
2. 对应的模板不与已有模板重复， 需要是已支持的相关模型功能
3. 你可以在对应的仓库提交 issue 进行提问

## 自定义节点模板

如果自定义节点作者有提供了模板和示例工作流，你也可以在模板浏览里找到，通常只需要找到对应的节点名称的分类即可看到作者提供的所有目录。

如果你是自定义节点作者，请注意目前我们仅支持模板文件夹下的一级目录，并不支持多级目录，且仅支持 JSON 格式的模板

## 如何为自定义节点添加模板？

[自定义节点模板](/zh/custom-nodes/workflow_templates) 中介绍了如何为你开发的自定义节点添加工作流模板，你也可以向自定义节点作者提交 PR 来贡献自定义节点模板
