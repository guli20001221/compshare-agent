---
title: ComfyUI 自定义节点（插件）安装及更新教程
source_url: https://www.comfyorg.cn/1162.html
source_site: comfyorg.cn
captured_at: 2026-07-15T05:28:35.492029+00:00
category: community_core
fetch_method: jina_reader
---

Title: ComfyUI 自定义节点（插件）安装及更新教程 - ComfyUI资源网

URL Source: https://www.comfyorg.cn/1162.html

Markdown Content:
ComfyUI Manger 是一个实用的插件，它可以帮你自动安装插件，下载模型等等，你可以把这个插件当成一个大的资源库，你可以随时使用它来进行下载内容，不过如果你在中国国内，可能会因为网络访问问题，导致下载体验不佳，但是ComfyUI Manager 可以方便我们日常的 ComfyUI 的使用，查找缺失节点等等

本文会涉及以下集中插件安装方式：

*       *   ComfyUI Manager 安装插件（推荐）
    *   Git安装： 使用 Git 命令进行安装
    *   手动安装：压缩包手动安装 ComfyUI 插件插件
    *   秋叶启动器安装插件
    *   中国境内使用 Gitee 克隆 Github 插件仓库

以上的这几种方式，除了手动安装，其实基本上都是通过 Git 来进行安装的，只不过使用了不同的方式来使用 Git , 但是在中国境内对于 Github 的访问可能存在问题，所以在文章最后我也会补充介绍在中国境内如何把对应插件仓库的克隆到类似 Gitee 这样的平台来进行安装。然后通常在安装完节点之后还需要进行对应的依赖安装，每个自定义节点都存在一个requirements.txt文件包含了对应节点的需要的 python 依赖，在我们完成所有的安装方式的讲解后，我们统一来讲解如何进行不同自定义节点依赖的安装。

目前 ComfyUI Desktop 已经预装了 ComfyUI Manager 插件，所以你不需要再手动这个插件，如果你的网络环境没有问题，我都建议你使用 ComfyUI Manager 来安装插件

### 一、使用 ComfyUI Manager 安装插件

### 1.ComfyUI Manager 新版本菜单入口位置

![Image 1: ComfyUI 自定义节点（插件）安装及更新教程](https://www.comfyorg.cn/wp-content/uploads/replace/0e8b897fc0238c9999ca93c7ab58d667.jpeg)

如图所示如果你的 ComfyUI 安装无误，则在最新版本的菜单界面中 ComfyUI Manager 位置如上图

### 2.ComfyUI Manager 旧版本菜单入口位置

如果安装成功了，打开 ComfyUI 的界面后你应该可以看到下面这张图片的效果（旧版本）

![Image 2: ComfyUI 自定义节点（插件）安装及更新教程](https://www.comfyorg.cn/wp-content/uploads/replace/ca7e2f4e392f848316bce981e1ebea05.jpeg)

在菜单的选项中会新增一个 _Manager_ 的选项，这就是ComfyUI Manager 的入口

### 3.ComfyUI Manager 安装插件

**步骤一：**在弹出的 ComfyUI Manager Menu 中，你可以看到有**Custom Nodes Manager(安装新插件)**的入口，点击对应按钮即可，如下图

![Image 3: ComfyUI 自定义节点（插件）安装及更新教程](https://www.comfyorg.cn/wp-content/uploads/replace/ba660517ebda008b1c64e95a2dd62f0c.jpeg)

在这个步骤这里，你也可以点击界面中的**Install via Git URL**按钮，然后输入对应的 Git 地址进行安装

**步骤二：**下图是对应的**Custom Nodes Manager**界面

![Image 4: ComfyUI 自定义节点（插件）安装及更新教程](https://www.comfyorg.cn/wp-content/uploads/replace/bf3d9e28d300a5cd051b602d4c815507.jpeg)

1.   在`1`处，在搜索框中输入你想要安装的插件名称，如**ComfyUI-Manager**
2.   在`2`处，找到你需要的插件，点击**Install**按钮进行安装
3.   在`3`处，你也可以使用对应 Git 地址进行安装
4.   等待安装完成，有时可能需要重启 ComfyUI 才能应用对应的安装

### 4.ComfyUI Manager 更新插件

更新插件与安装插件相同，在对应的插件过滤（Filter）筛选出已安装的插件，然后点击**Try Update**按钮进行更新

## 二、使用 Git 安装 ComfyUI 插件

这里我介绍两种安装方法

1.   Git 命令行安装 (需要预先安装[Git](https://www.comfyorg.cn/url?url=aHR0cHM6Ly9naXQtc2NtLmNvbS8=)**推荐使用**)
2.   Github Desktop 安装 (对于不熟悉 Git 的相对使用起来比较友好)

非常建议你了解并初步学习一下 Git，具体你可以查看Git 安装及入门指南部分

### 1. Git 命令行安装 ComfyUI 插件

#### 如何找到对应插件的 Git 地址

*   git 软件下载：[https://git-scm.com/](https://www.comfyorg.cn/url?url=aHR0cHM6Ly9naXQtc2NtLmNvbS8=)

首先找到你要安装的插件的 Git 仓库，如[https://github.com/ltdrdata/ComfyUI-Manager](https://www.comfyorg.cn/url?url=aHR0cHM6Ly9naXRodWIuY29tL2x0ZHJkYXRhL0NvbWZ5VUktTWFuYWdlcg==)

![Image 5: ComfyUI 自定义节点（插件）安装及更新教程](https://www.comfyorg.cn/wp-content/uploads/replace/769c40a305896c0867aa2145d25b67ca.jpeg)

1.   点击页面中 绿色的**<>code**按钮
2.   点击弹窗的**https**选项下输入框后的复制按钮
3.   你将复制得到[https://github.com/ltdrdata/ComfyUI-Manager.git](https://www.comfyorg.cn/url?url=aHR0cHM6Ly9naXRodWIuY29tL2x0ZHJkYXRhL0NvbWZ5VUktTWFuYWdlci5naXQ=)的链接

#### 如何使用 Git 命令行安装插件

1.   打开你的 CMD 终端，首先使用`cd`命令进入你ComfyUI 插件所在文件夹，如 E:/ComfyUI_windows_portable/ComfyUI/custom_nodes

1.   `cd E:/ComfyUI_windows_portable/ComfyUI/custom_nodes`

1.   然后使用`git clone`命令克隆对应的代码仓库

1.   `git clone https://github.com/ltdrdata/ComfyUI-Manager.git`

1.   等待成功提示
2.   重启 ComfyUI ，查看插件是否安装完成

注: 中国国内环境使用 Github 容易导致失败，你可以先将对应插件仓库同步到 Gitee 等国内代码仓库，增大成功率

#### 如何使用 Git 更新对应插件？

使用 Git 更新对应插件，和之前的步骤一样，你需要使用`cd`先进入对应的插件目录，然后使用`git pull`命令进行更新

1.   `# 进入插件目录cd E:/ComfyUI_windows_portable/ComfyUI/custom_nodes/ComfyUI-Manager# 使用 git pull 命令更新git pull`

### 2. Github Desktop 安装与更新插件

使用 Github Desktop 其实不是一个很推荐的方式，其实 Git 的掌握也不会很复杂，

1.   首先你需要先在 github 上注册一个账号，GitHub 注册地址：[https://github.com/](https://www.comfyorg.cn/url?url=aHR0cHM6Ly9naXRodWIuY29tLw==)
2.   然后你需要先下载 Github Desktop ，下载地址：[https://desktop.github.com/](https://www.comfyorg.cn/url?url=aHR0cHM6Ly9kZXNrdG9wLmdpdGh1Yi5jb20v)
3.   下载并安装完成以后，打开软件并完成对应的账号登录

#### 使用 Github Desktop 安装插件

使用 Github Desktop 安装插件步骤如下：

![Image 6: ComfyUI 自定义节点（插件）安装及更新教程](https://www.comfyorg.cn/wp-content/uploads/replace/8159c2835e54ab43491b8bd4858eb970.jpeg)

1.   点击`File`菜单，选择`Clone repository`选项

![Image 7: ComfyUI 自定义节点（插件）安装及更新教程](https://www.comfyorg.cn/wp-content/uploads/replace/9daa3b3dedd27496d7bbbc8ea1e5b642.jpeg)

1.   在弹出的窗口中选择最后项 URL 的 Clone 的方式
2.   选择你要安装的插件的目录，一般是你的 ComfyUI 安装目录下的`custom_nodes`目录，在我提供的截图里我先设置了`D:ComfyUI_windows_portableComfyUIcustom_nodes`目录，这个是我的 ComfyUI 安装目录

> 你可以看到页面会有一个提示”This folder contains files.Git Can only clone empty folders”，这个是提示你这个目录下有文件，Git 只能克隆内容到空目录里，这个不用担心，当我们输入插件的 Github 仓库地址以后目录会更新这个提示也会消失的

![Image 8: ComfyUI 自定义节点（插件）安装及更新教程](https://www.comfyorg.cn/wp-content/uploads/replace/2083d42aa18bd3180c546d2f8c2b1f74.jpeg)

1.   在 URL 输入框中输入你要安装的插件的 Git 仓库地址，如[https://github.com/kijai/ComfyUI-Hunyuan3DWrapper](https://www.comfyorg.cn/url?url=aHR0cHM6Ly9naXRodWIuY29tL2tpamFpL0NvbWZ5VUktSHVueXVhbjNEV3JhcHBlcg==),你会注意到对应的安装目录随着我们的输入的地址也会更新
2.   点击`Clone`按钮，等待安装完成

重启 ComfyUI ,等待界面完成必要的依赖安装，这样你就完成了对应插件的安装

#### 使用 Github Desktop 更新插件

![Image 9: ComfyUI 自定义节点（插件）安装及更新教程](https://www.comfyorg.cn/wp-content/uploads/replace/8413646a3aa54a71adc1f6eafec44786.jpeg)

从上面的截图里你可以看到，我使用 Github Desktop 安装了几个不同作者的 git 仓库

1.   点击我标了序号 1 的位置，会打开使用 Github Desktop 安装的git 仓库的地址
2.   如果对应的插件有更新，你可以看到一个类似序号 2 处的箭头提示
3.   点击对应的菜单，切换到对应的仓库，然后界面里你一般可以看见和序号 3 处一样的更新提示，点击`Pull Origin`按钮，就可以完成插件的更新

首先访问对应仓库地址：[https://github.com/ltdrdata/ComfyUI-Manager](https://www.comfyorg.cn/url?url=aHR0cHM6Ly9naXRodWIuY29tL2x0ZHJkYXRhL0NvbWZ5VUktTWFuYWdlcg==)

> 💡通常我不太推荐使用手动安装的方式，因为这个过程中可能会丢失 Git 仓库的信息，然而很多插件都会有较为频繁的更新，使用手动安装的更新可能没有办法向使用 Git 安装那样方便更新

*   通常对应的仓库有提供对应的Readme 安装说明，你可以参照安装说明进行安装

![Image 10: ComfyUI 自定义节点（插件）安装及更新教程](https://www.comfyorg.cn/wp-content/uploads/replace/a04accdbc4456a40463a891d51f1b741.jpeg)

1.   点击页面中 绿色的**<>code**按钮
2.   点击弹窗的**Download ZIP**按钮
3.   下载完成后解压压缩包
4.   将解压后的文件夹复制到`comfyui/custom_nodes`的插件目录下
5.   重启 ComfyUI ，查看插件是否安装完成

使用这种方式如果要更新对应的插件，只能重复安装方式再进行一遍手动安装

## 四、秋叶启动器安装插件

1.   确保 ComfyUI 没有在运行，
2.   在秋叶启动器中选择`版本管理安装扩展`（下图使用的是英文版本界面）

![Image 11: ComfyUI 自定义节点（插件）安装及更新教程](https://www.comfyorg.cn/wp-content/uploads/2025/06/20250610071648237471.png)

1.   搜索或浏览找到你想要安装的插件，点击安装即可
2.   如果没有，你可以可以通过这个界面的`Extension URL`将对应的 插件 Git 地址安装到此处，就可以使用 Git 来安装了（和 Git 安装类似）

### 如何使用秋叶启动器更新插件

同样还是在版本管理安装扩展界面，你可以点击刷新，让软件检测对应的 Git 仓库有没有更新，如果有更新手动更新或者切换版本即可

## 五、中国境内使用 Gitee 克隆 Github 插件仓库

如果你在中国境内，很可能会因为 Github 访问问题导致安装失败，这时候你可以使用 Gitee 来克隆对应的 Github 仓库，然后获取到克隆后的你的仓库地址，然后使用这个地址来通过以上的方式来安装。

不过这种方式的缺点也非常明显，由于它是转存了 Github 仓库，所以你无法获取到上游 Github 仓库的最新更新，每次需要更新插件的时候你都需要通过 Gitee 来获取到上游的更新，然后再检测更新

首先你需要先在 gitee 上注册一个账号，Gitee 注册地址：[https://gitee.com/](https://www.comfyorg.cn/url?url=aHR0cHM6Ly9naXRlZS5jb20v)

1.   注册完成后，点击`+新建`按钮，选择新建仓库

![Image 12: ComfyUI 自定义节点（插件）安装及更新教程](https://www.comfyorg.cn/wp-content/uploads/replace/1dbc281baa9a88ee7d4337df0901eb2a.jpeg)

1.   新建仓库页面选择`点击导入`选项

![Image 13: ComfyUI 自定义节点（插件）安装及更新教程](https://www.comfyorg.cn/wp-content/uploads/replace/c6d135663ed3d79a5ba2b601eb8ed303.jpeg)

1.   在导入仓库页面，选择从 URL 导入

![Image 14: ComfyUI 自定义节点（插件）安装及更新教程](https://www.comfyorg.cn/wp-content/uploads/replace/423863c195a8d947f9e853e34fff1e03.jpeg)

并填写对应的仓库地址链接如：

*   [https://github.com/ltdrdata/ComfyUI-Manager.git](https://www.comfyorg.cn/url?url=aHR0cHM6Ly9naXRodWIuY29tL2x0ZHJkYXRhL0NvbWZ5VUktTWFuYWdlci5naXQ=)
*   [https://github.com/ltdrdata/ComfyUI-Manager](https://www.comfyorg.cn/url?url=aHR0cHM6Ly9naXRodWIuY29tL2x0ZHJkYXRhL0NvbWZ5VUktTWFuYWdlcg==)

这两种格式都可以被接受

1.   填写完成后点击导入

导入完成之后对应的仓库就会被克隆到你的账号之下 后期如果你想要更新插件代码，请记得只有你先更新你克隆的仓库，然后你才能获取到上游的更新

![Image 15: ComfyUI 自定义节点（插件）安装及更新教程](https://www.comfyorg.cn/wp-content/uploads/replace/c4511074635f54382571690015c6d08b.jpeg)

1.   序号 5 处的按钮是用来更新同步上游仓库代码的
2.   点击**克隆/下载**按钮，你就可以获取到对应的仓库地址

![Image 16: ComfyUI 自定义节点（插件）安装及更新教程](https://www.comfyorg.cn/wp-content/uploads/replace/fe1c029bbc50715946c4751e2274c353.jpeg)

在节点完成安装完成后，为了保证对应节点的功能能够正常使用，还需要安装对应的依赖，下面我将正对不同版本的 ComfyUI 的依赖安装进行一个补充，然后针对特殊地区比如中国境内，在使用对应依赖安装命令时候，需要使用中国国内的镜像地址来进行安装

## 六、ComfyUI 自定义节点依赖的安装

这个部分是针对不同版本的 ComfyUI 的依赖安装进行一个补充，针对你使用的 ComfyUI 版本和安装方式，你可以选择对应的依赖安装方式。

💡

如果不同的节点依赖了同一个包的不同版本，则有可能会出现依赖冲突的问题。

### ComfyUI 便携版（Portable）版本

便携版（Portable）版本，使用的是嵌入式 Python 版本，所以需要使用嵌入式 Python 来安装对应的依赖，需要在使用命令行进入 portable 的插件目录

1.   `cd E:/ComfyUI_windows_portable/`

然后使用嵌入式 Python 来安装对应的依赖

1.   `python_embededpython.exe -m pip install -r ComfyUIcustom_nodesComfyUI-Managerrequirements.txt`

### Python 虚拟环境

如果你自己创建了 ComfyUI 的 Python 虚拟环境，那么你需要进入对应的插件文件夹，比如在本文中，我们安装了 ComfyUI-Manager 插件，所以我们要找到对应插件依赖文件的目录

1.   `E:/ComfyUI_windows_portable/ComfyUI/custom_nodes/ComfyUI-Manager/requirements.txt`

然后我们使用`pip`命令来安装对应的依赖

1.   `pip install -r E:/ComfyUI_windows_portable/ComfyUI/custom_nodes/ComfyUI-Manager/requirements.txt`

### 使用中国国内镜像源

对于中国大陆用户，由于网络限制，在安装依赖时可能会遇到问题。可以使用国内镜像源加速下载。只需在使用pip命令时添加`-i`参数指定镜像源：

1.   `# 使用清华大学镜像pip install -r E:/ComfyUI_windows_portable/ComfyUI/custom_nodes/ComfyUI-Manager/requirements.txt -i https://pypi.tuna.tsinghua.edu.cn/simple # 便携版本使用方法python_embededpython.exe -m pip install -r ComfyUIcustom_nodesComfyUI-Managerrequirements.txt -i https://pypi.tuna.tsinghua.edu.cn/simple`

常用的国内镜像源包括：

*   清华大学：[https://pypi.tuna.tsinghua.edu.cn/simple](https://www.comfyorg.cn/url?url=aHR0cHM6Ly9weXBpLnR1bmEudHNpbmdodWEuZWR1LmNuL3NpbXBsZQ==)
*   阿里云：[https://mirrors.aliyun.com/pypi/simple/](https://www.comfyorg.cn/url?url=aHR0cHM6Ly9taXJyb3JzLmFsaXl1bi5jb20vcHlwaS9zaW1wbGUv)
*   中国科技大学：[https://pypi.mirrors.ustc.edu.cn/simple/](https://www.comfyorg.cn/url?url=aHR0cHM6Ly9weXBpLm1pcnJvcnMudXN0Yy5lZHUuY24vc2ltcGxlLw==)

温馨提示：本站提供的一切软件、教程和内容信息都来自网络收集整理，仅限用于学习和研究目的；不得将上述内容用于商业或者非法用途，否则，一切后果请用户自负，版权争议与本站无关。在未征得本站同意时，禁止复制、盗用、采集、发布本站内容到任何网站、书籍等各类媒体平台。如若本站内容侵犯了原著者的合法权益，可联系我们进行处理。
