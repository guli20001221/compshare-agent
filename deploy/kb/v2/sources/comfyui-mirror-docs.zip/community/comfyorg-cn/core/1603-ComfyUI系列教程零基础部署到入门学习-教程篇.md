---
title: ComfyUI系列教程零基础部署到入门学习-教程篇
source_url: https://www.comfyorg.cn/1603.html
source_site: comfyorg.cn
captured_at: 2026-07-15T05:28:35.582190+00:00
category: community_core
fetch_method: jina_reader
---

Title: ComfyUI系列教程零基础部署到入门学习-教程篇 - ComfyUI资源网

URL Source: https://www.comfyorg.cn/1603.html

Markdown Content:
## 一. 基础介绍

ComfyUI 是一个为Stable Diffusion专门设计的基于节点的图形用户界面（GUI）。它使用户能够通过链接不同的块（称为节点）来构建复杂的图像生成工作流程。这些节点可以包括各种任务，如加载检查点模型、输入提示、指定采样器等。

它实际上就是一个比较专业的 Stable Diffusion 运行界面，只不过是**_节点式_**的。这种节点式界面其实广泛的存在于各种专业的生产力工具中，例如Blender、虚幻引擎、达芬奇等。

官方介绍：

**_WebUI 与 ComfyUI 对比_**

ComfyUI 提供了极高的自由度和灵活性，支持高度的定制化和工作流复用，同时对系统配置的要求较低，并且能够加快原始图像的生成速度。然而，由于它拥有众多的插件节点，以及较为复杂的操作流程，学习起来相对困难。

另一方面，WebUI 特点是拥有固定的操作界面，使得其易于学习和快速上手。经过一年多的发展，它已经建立了一个成熟且稳定的开源生态系统。但相比 ComfyUI，在性能方面可能稍逊一筹，且在工作流程复制方面存在局限性，用户需在每次操作时手动进行设置。

因此，建议初学者从 WebUI 开始入手，熟悉后再考虑转向 ComfyUI，以充分利用 AI 工作流程，实现效率的最大化。

![Image 1: ComfyUI系列教程零基础部署到入门学习-教程篇](https://www.comfyorg.cn/wp-content/uploads/replace/54168f10668657e6f6bf39e5ea2f8c8d.png)

### 01.下载安装

目前的有两种常用的安装方法，分别是使用官方提供的整合包以及使用秋叶的一键启动器。这两种安装方式都很简单，安装方法也差不多一样。

![Image 2: ComfyUI系列教程零基础部署到入门学习-教程篇](https://www.comfyorg.cn/wp-content/uploads/replace/24d9580049acd466c3163d91d00f93be.png)

官网链接：

如果你担心使用官方整合包会出现各种奇怪的报错，那么可以安装一键启动器，他能规避一些报错。秋叶的启动器会内置一些插件和模型，拥有专属的图形化界面，后续更新版本以及安装插件比较方便。

怎么简单怎么来，当然就选择秋叶整合包啦！~直接下载下来，解压即可使用

秋叶大佬网盘链接：[https://www.comfyorg.cn/894.html](https://www.comfyorg.cn/894.html)

转百度网盘：

## 秋叶-comfyui

提取码：`1111`复制

解压码：无

解压后打开 ComfyUI 的根目录，找到启动器文件，直接双击启动

### 02.安装模型

**_2.1. 独立模型安装_**

首先我们先来说下，在 ComfyUI 中如何安装大模型、Lora等一系列模型。进入到 ComfyUI 根目录，找到这个「Models」文件夹，双击进去。

进来之后你就会看到以模型名称命名的文件夹，如 Checkpoints（大模型）、Loras、controlnet 等，我们只需要进入对应的文件夹，把相应的模型复制进去即可。

![Image 3: ComfyUI系列教程零基础部署到入门学习-教程篇](https://www.comfyorg.cn/wp-content/uploads/replace/67caab4b02d47e68685b721b52e022c9.png)

**_2.2. 共享WebUI模型_**

除了 ComfyUI 独立安装模型以外，它还支持与 WebUI 共享同个模型文件夹，好处是不用重新安装之前安装过的模型，同时也是避免占用硬盘空间，这步操作大家都应该学会。

第一步：打开 ComfyUI 根目录，找到这个「extra_model_paths.yaml.example」文件，重命名并删掉后缀（.example）后的得到extra_model_paths.yaml 文件。

![Image 4: ComfyUI系列教程零基础部署到入门学习-教程篇](https://www.comfyorg.cn/wp-content/uploads/replace/38f76de2e1869a445c3689707766b29e.png)

第二步：用记事本打开该文件，然后在记事本中，找到「base_path」后面的路径换成 WebUI 的根目录地址并保存。

![Image 5: ComfyUI系列教程零基础部署到入门学习-教程篇](https://www.comfyorg.cn/wp-content/uploads/replace/e8c7c0650ff60928b35ee31b101b202e.png)

注意路径前的空格与最后的斜杠/

***这里要重点说下controlnet模型，其默认地址为：controlnet: models/ControlNet。但正常情况我们的Controlnet都是放在插件目录下的，所以这里的路径要改成：controlnet: extensions/sd-webui-controlnet/models

同样的界面，同样的风格，一键启动吧。

![Image 6: ComfyUI系列教程零基础部署到入门学习-教程篇](https://www.comfyorg.cn/wp-content/uploads/replace/cfaa08efd9b5c4c334cbf08fcd441841.png)

### 03.设置中文语言

点击右边的设置小按钮，在弹窗里找到语言栏，选择中文即可。

![Image 7: ComfyUI系列教程零基础部署到入门学习-教程篇](https://www.comfyorg.cn/wp-content/uploads/replace/b86614199996f6cf840da604d72843b5.png)

### 04.推荐网站

国内首推哩布：

NovelAI(侧重于辅助功能） :

C站（国外）：

Hugging Face:

## 三. 基本界面

下面来说说ComfyUI用户界面，包含基本操作，菜单设置，节点操作等常见用户界面选项。

### _1.菜单面板_

![Image 8: ComfyUI系列教程零基础部署到入门学习-教程篇](https://www.comfyorg.cn/wp-content/uploads/replace/f141ce706df0ac62cf4842dc975f9536.jpeg)

如上图，对应功能说明已注释，下面为对应说明内容：

如上图，对应功能说明已注释，下面为对应说明内容：

*   拖动按钮: 点击后可以拖动菜单面板移动位置
*   队列大小： 当前图片生成任务数量
*   设置按钮： 点击后打开ComfyUI设置面板
*   添加提示词队列： 将将当前工作流加入图片生成队列（最后面的位置），快捷键 Ctrl+Enter
*   更多选项： 图片生成相关选项，如单次生成数量，当参数变化时自动执行图片生成任务等

![Image 9: ComfyUI系列教程零基础部署到入门学习-教程篇](https://www.comfyorg.cn/wp-content/uploads/replace/5787fb3864b7388744c051b45d8fa1b6.png)

勾选后显示折叠

批次数量： 单次图片生成的图片数 Auto Queue(自动队列)： 根据设定条件将当前工作流自动加入生图队列

*   instant-实时： 实时生成
*   change-有变化时： 当工作流存在参数变动时，执行图片生成

前台队列： 将当前工作流加入图片生成队列并作为最优先的队列

显示队列： 显示当前的图片生成任务列表

![Image 10: ComfyUI系列教程零基础部署到入门学习-教程篇](https://www.comfyorg.cn/wp-content/uploads/replace/9f6d9e048f7a1873ce1bb608fbe18bb3.png)

*   运行中： 当前正在进行图片生成的队列
*   等待中： 当前正在排队进行图片生成的队列
*   清除队列： 删除生图队列信息
*   重刷新： 刷新队列信息

显示历史： 显示图片生成的历史记录和信息

![Image 11: ComfyUI系列教程零基础部署到入门学习-教程篇](https://www.comfyorg.cn/wp-content/uploads/replace/55a4d16e574580ed74f20a1da104e852.png)

历史列表： 图片生成的历史记录，点击加载可将对应的图片生成参数载入工作流中，点击删除则删除对应图片生成记录信息。清除历史： 删除图片生成的历史记录。 重刷新： 刷新历史记录。

*   保存： 将当前工作流保存为JSON文件
*   加载： 从JSON文件或者comfyUI生成的图片中加载工作流
*   重刷新： 刷新当前界面
*   剪贴空间： 显示复制到剪贴空间的内容

当你完成图片生成后，可以在预览/保存图片节点上，右键复制对应的图片，此时再点击剪贴空间，可展示当前复制的图片，你可将图片载入支持粘贴的节点（如： 加载图像节点）

![Image 12: ComfyUI系列教程零基础部署到入门学习-教程篇](https://www.comfyorg.cn/wp-content/uploads/replace/d66ed34473b05c862123ad05bb2c3663.png)

*   清除： 清除当前工作空间所有节点内容
*   加载默认： 加载ComfyUI默认工作流

### 2.快捷键

> 【Ctrl + Enter】：将当前图形排队以供生成
> 
>  【Ctrl + Shift + Enter】：将当前图作为第一个生成队列
> 
>  【Alt + C】和【双击节点左上角灰色圆点】：折叠/取消折叠选中的节
> 
>  【Ctrl + M】：禁用/启用所选节点
> 
>  【Ctrl + B】：忽略节点
> 
>  【Delete/Backspace】：删除选中的节点
> 
>  【Ctrl + Delete 】：删除当前图
> 
>  【空格+鼠标左键】：移动画布
> 
>  【Ctrl+鼠标左键】：将单击的节点添加和减选到选择中（点选，框选都可以）
> 
>  【Shift + 拖动】：对齐网格/同时移动多个选中的节点
> 
>  【Ctrl + C/Ctrl + V】：复制并粘贴选中的节点(不维持与未选中节点的输出的连接)
> 
>  【Ctrl + A】：选择所有节点
> 
>  【Ctrl + S】：保存工作流
> 
>  【Ctrl + O】：加载工作流程
> 
>  【Alt + 拖动】：复制当前选择
> 
>  【Ctrl + D】：加载默认工作流
> 
>  【Q】：切换队列的显示已隐藏
> 
>  【H】：切换历史显示与隐藏
> 
>  【R】：刷新工作流
> 
>  【双击鼠标左键(LMB)】：打开节点快速搜索面板（使用英文搜索）
> 
>  【Ctrl + ↑】加权重 【Ctrl + ↓】减权重

![Image 13: ComfyUI系列教程零基础部署到入门学习-教程篇](https://www.comfyorg.cn/wp-content/uploads/replace/ae3742d1a143ee98ea8b37856b8dc13d.png)

## 四.插件安装

### _1.Manager_

一款管理插件的插件，如果是用的秋叶安装包，就不需要单独再安装了，**_系统已经自带了_**。

它提供管理功能来**安装、删除、禁用和启用**ComfyUI 的各种自定义节点。此外，此扩展还提供中心功能和便利功能，可访问 ComfyUI 中的各种信息。

![Image 14: ComfyUI系列教程零基础部署到入门学习-教程篇](https://www.comfyorg.cn/wp-content/uploads/replace/50b7ed479947609a0e719a024ad3ec28.png)

管理插件的插件

**_安装方法:_**

1.   ComfyUI/custom_nodes打开插件目录
2.   下载插件，地址：[https://github.com/ltdrdata/ComfyUI-Manager.git](https://www.comfyorg.cn/url?url=aHR0cHM6Ly9naXRodWIuY29tL2x0ZHJkYXRhL0NvbWZ5VUktTWFuYWdlci5naXQ=)
3.   解压到插件目录即可。（后面就不需要用这个方法了，直接用manager插件去搜索并安装，方便多了）
4.   重启 ComfyUI

### _2.Translation汉化_

第二个要安装的肯定就是翻译插件了。（秋叶安装包自带）

多语言翻译插件，该插件实现常驻菜单栏/搜索栏/右键菜单/节点等的翻译.

![Image 15: ComfyUI系列教程零基础部署到入门学习-教程篇](https://www.comfyorg.cn/wp-content/uploads/replace/60928db8b620e1b5a0e6b9acd5f4b3a5.png)

直接用manager插件去搜索并安装

菜单栏中的小设置按钮点进，找到语言，设置成中文即可。也可以通过菜单栏下的语言切换（switch local)来切换语言.

![Image 16: ComfyUI系列教程零基础部署到入门学习-教程篇](https://www.comfyorg.cn/wp-content/uploads/replace/a49b499b2d7601bcee21caaf19fb0504.png)

也可以通过菜单栏下的语言切换来切换语言

如果出现半汉化情况的，可以去秋叶启动器里把版本退一个版本试试，本人就出现过最新版本半汉化问题，网上找了好久也没找到原因，后来想起自己只更新过版本，退回那个版本马上就好了

## 五.节点说明

接下来，我们将用通俗易懂的语言对 ComfyUI 的核心节点进行系统梳理，并详细解释每个参数。希望大家在学习过程中培养自我思考的能力，真正掌握和理解各个节点的用法与功能。在实践中不断提升自己的技术水平。只有通过不断的探索和总结，才能在面对复杂的工作流时游刃有余。

在Comfyui里面，我们可以看到有着密密麻麻的各种各样的节点，但这些都是插件类的节点，很多都是极少用到的，但这里面有5类基础节点，几乎在每个工作流里面都是一定会用上的，下面我们来一一了解一下:

[![Image 17: ComfyUI系列教程零基础部署到入门学习-教程篇](https://www.comfyorg.cn/wp-content/uploads/replace/53f14f36dce35342c91af91983c5f339.jpeg)](https://www.comfyorg.cn/url?url=aHR0cHM6Ly96aHVhbmxhbi56aGlodS5jb20vcC8zMzU3MjcwMDg2)

### _1.K采样器_

该节点专门用于逐步减少潜在空间图像中的噪声，改善图像质量和清晰度。

把它拿出来第一个说就说明这个节点的重要性，所有的工作流都是围绕着它来进行扩散的。

![Image 18: ComfyUI系列教程零基础部署到入门学习-教程篇](https://www.comfyorg.cn/wp-content/uploads/replace/cb6a694fc7502ef22f14e8c0c1814343.png)

先从简单的开始

**输入：**

模型model -> 接收来自**大模型**的数据流 positive -> 接收经过 clip 编码后的**正向提示词**的条件信息（CONDITIONING） negative -> 接收经过 clip 编码后的**反向提示词**的条件信息（CONDITIONING） latent_image -> 接收**潜空间图**像信息

![Image 19: ComfyUI系列教程零基础部署到入门学习-教程篇](https://www.comfyorg.cn/wp-content/uploads/replace/5499a083206c1f114d059215d508b6d6.png)

**输出：**

LATENT -> 经过KSampler采样器进行去噪后的潜空间图像

**参数：**

> **随机种**seed -> 在去除图像噪声过程中使用的随机数种子。种子数有限，影响噪声生成的结果。
> 
> 
> **运行后操作**-> 指定种子生成后的控制方式。
> 
> **_固定fixed_**代表固定种子，保持不变；
> 
> **_增加 increment_**代表每次增加 1；
> 
> **_减少decrement_**代表每次减少 1 ；
> 
> **_随机randomize_**代表随机选择种子 。
> 
> 
> **步数steps**-> 对潜在空间图像进行去噪的步数。步数越多，去除噪声的效果可能越显著。 一般设置为 30-40 左右；
> 
> 
> **CFG**-> 提示词引导系数，表示提示词对最终结果的影响程度。过高的值可能会产生不良影响。 参数越大，图片效果越接近提示词。参数越小，AI 发挥空间越大，图片效果与提示词差异越大。一般设置在 10 左右就好，默认为 8。
> 
> 
> **采样器**-> 选择的采样器名称，不同的采样器可以影响生成图像的效果，大家可以根据需求进行选择和实验。（后面细说）
> 
> 
> **调度器scheduler**-> 选择的调度器名称，影响生成过程中的采样和控制策略，推荐配置可提供更好的结果。
> 
> 
> **降噪denoise**-> 去噪或重绘的幅度，数值越大，图像变化和影响越显著。在高清修复等任务中，通常使用较小的值以保持图像细节和质量。

**采样器+调度器参数：**

我们之前最熟悉的采样器，有euler、dpmpp_2m，包括后来的ddpm、ddim、uni_pc和ipndm等。

![Image 20: ComfyUI系列教程零基础部署到入门学习-教程篇](https://www.comfyorg.cn/wp-content/uploads/replace/faf654b021fcf3f2ac23ad1051d008d5.jpeg)

**_采样器：_**

采样器有点多，看起来有点蒙逼。其实可以把它分成三类:

> **01欧拉:**euler和heun
> 
> **02dpm :**所有以dpm开头
> 
> **03 其它类**

**_对比测试_**

建立一个XY图表，横坐标是步数，从第5步开始，间隔四步，总共8个数值；纵坐标是上面介绍的各种采样器。

![Image 21: ComfyUI系列教程零基础部署到入门学习-教程篇](https://www.comfyorg.cn/wp-content/uploads/replace/85136cc5237a39c934394931b7a5cb6a.png)

从上图中不难发现如下规律:

> ·名字以a或sde结尾的，确实不会收敛，每一步选代图像都会发生变化
> 
>  ·euler，heun和ddim采样器在第9步就已经出图，对于简单图来说，确实是又好又快。
> 
>  ·dpmpp_2m和uni_pc采样器在第14步出图，其中dpmpp_2m在第18步开始收敛，效果很好
> 
>  ·不要被dpm adaptive采样器骗了，虽然第5步就已经收敛，但是该采样器速度特别慢。后续我又单独进行了测试，实际第2步就已经收敛，但是速度很慢。
> 
>  ·Ims采样器表现最差。

**如何选择采样器？**

没有最好的采样器，只有最适合的采样器。

> 如果想要稳定可重现的图像，请避免选择任何祖先采样器(名字以a或sde结尾的)
> 
>  如果想要简单的图，建议选择euler,heun(可以减少步骤以节省时间)
> 
>  如果想快速生成质量不错的图片，建议选择dpmpp_2m(20-30步)、uni_pc(15-25步)
> 
>  如果想要每次生成不一样的图像，可以选择不收敛的祖先采样器(名字里面带a或sde)

**_调度器则就相对来得简单些：_**

> 最常见的normal似乎已不太适用于FLUX生态
> 
>  以往最常用的karras也在**sgm_uniform**、**simple**、ddim_uniform和**beta**出现后被慢慢淡化。
> 
>  其中，ddim_uniform这个调度器，会随着采样的步数，构图画面会发生一定的变化，因为它有点像高级的调度器dpm一样，是不收敛的，则出图的多样性随机性会随着步数增加更强，变化更多。
> 
>  对于调度器exponential，则较多用于扩图放大等情况。

国外有位大佬对Flux各种采样器和调度器进行组合测试出最适合的采样模式。表格中的绿色标记表示该组合可用，红色标记表示不可用。

![Image 22: ComfyUI系列教程零基础部署到入门学习-教程篇](https://www.comfyorg.cn/wp-content/uploads/replace/9b2b9252d8488e23c93bb6548318cd24.png)

**_推荐的采样器和调度器组合:_**

> euler + normal：适用于快速生成图像，但细节可能不够精细。（生成时间20s）
> 
> 
> heunpp2 + ddim_uniform：适用于生成细节丰富的图像，但速度较慢。（生成时间54s）
> 
> 
> uni_pc +beta：适用于平衡速度和质量，是大多数情况下的推荐选择。（生成时间20s）
> 
> 
> DPM2+ SIMPLE是我最近比较喜欢的组合，能够提供非常好的图片精细度。（生成时间37s）
> 
> 
> DEIS+DDIM_UNIFORM是新出现的组合，非常好的把握光影明暗。（生成时间20s）

## 六、文生图

![Image 23: ComfyUI系列教程零基础部署到入门学习-教程篇](https://www.comfyorg.cn/wp-content/uploads/replace/047031d1a23f1f5cf20a284e69f24731.jpeg)

ComfyUI 除了自由度和灵活性高，它还有最大一个特点就是可以直接复用别人分享的工作流。

## 七.提示词

### 1.关于提示词

提示词，即prompt、tag，也被戏称为咒语，分为正向提示词和反向提示词

正向提示词：在正向提示词框里，写出需要生成内容的提示词。

反向提示词：在反向提示词框里，写出不需要生成内容的提示词。

**_提示词相关性_**

关于人物类的提示词，一般将提示词相关性控制在 7-15 之间。

关于建筑等大场景类的提示词，一般控制在3-7左右。

**_提示词语法_**

我们可以发现这些提示词里面，不仅仅是英语单词的简单罗列，还会有括号等符号，下面就来详细说说这些语法的详细意思。

### **2.括号的语法**

在提示词中使用英文括号，代表着增减权重。()每用一次代表**_权重提高_**1.1 倍，[]每用一次代表**_权重降低_**1.1 倍，以此类推。也可以直接在括号里输入冒号后面直接写上权重的数值。举例说明：

1.   `(word)//将括号内的提示词权重提高 1.1 倍`
2.   `((word))//将括号内的提示词权重提高 1.21 倍 （= 1.1 * 1.1）`
3.   `[word]//将括号内的提示词权重降低 1.1 倍`
4.   `(word:1.5)//将括号内的提示词权重提高 1.5 倍`
5.   `(word:0.25)//将括号内的提示词权重减少4 倍（= 1 * 0.25）`

- 实际运用中，较少使用大括号，用小括号居多，也可以多个括号使用，因为调整起来也比较便捷。

### **3.元素融合 （交替词语法)**

元素融合一般采用"|"或者“:”符号。

此提示词语法代表每隔一步换一个提示词交替绘制，此语法可以绘制出各种融合怪四不像，很有意思！

**3.1. "｜",用竖杠的话，会在两个元素之间循环往复绘制。**

比如，我想实现红色和蓝色头发渐变效果，可以写成red hair | blue hair。会按照画一步红头发，画一步蓝头发循环往复的方式进行。

这种这种表达方式也支持加权(red hair：1.2) | (blue hair：1.3)，用竖杠来元素融合，可以不必考虑两个元素之间的权重之和是否等于100%。

举个例子：

1.   `[cat|tiger]`

也可以多个一起用再举个例子：

1.   `[cow|donkey|horse|zebra|deer|elephant] in a field`

**02. 用":"用冒号的话,表达式为----"tag1:tag2:切入时机"**其中，切入时机为0～1之间的一个数值

举例说明：

1.   `[tree:background:0.5]代表前50%步画树，后50%步画背景。`
2.   `[tree:0.5]代表后50%步开始画树。`
3.   `[tree::0.5]代表前50%步画树，然后到了50%步数就结束画树。`

举例：red hair:blue hair:0.5，会在前面50%的步骤画红头发，后面50%的步骤画蓝头发

假设你的采样步数是30，那么30*0.5=15,代表前15步画红头发，后面15步画蓝头发。切入时机也可以直接写步数比如red hair:blue hair:15。

1.   `[orange:apple:15] on table`

第15步切换为苹果

### **4.可组合扩散**

"+",用加号表示的是同时满足两个元素条件，"+"与"AND"作用一样。此语法使用大写 AND ，以使两者权重保持一致。

一般来说，用来控制一些微观细节，比如：

1.   `a lion AND a bear`

另外此语法支持指定权重值：默认权重值为 1，也可以指定每个提示词的权重，比如：

1.   `a cat :1.3 AND a dog :1.2 AND a panda :2.6`

### 5.书写结构

**所以提示词原理有两个核心原则：**

**1、Stable Diffusion不是什么都懂。**有些词如果库里没有，它是无法理解的。所以我们要更多地使用Web UI中给出的常用提示词。

**2、提示词之间会相互污染。**所以提示词不是越多越好，要尽可能地做减法。

**_提示词一般构成：_**

**画面质量**（通用tag）+**画面风格**（绘画风格、构图方式等描述）+**画面主体**（人体、物体等细节描述）+**画面场景**（环境、点缀等细节描述）+**其他**（视角、特色描述等）

> **（1）画面质量：**一般通用masterpiece,best quality,official art。
> 
> **（2）画面风格：**例如extremely detailed CG unity 8k wallpaper,（CG壁纸） Line Art,（线条/线稿/素描）或者有指向性的风格如：Genshin Impact,（原神） Arknights,（明日方舟）等。
> 
> **（3）画面主体：**altera (fate)阿提拉(Fate)；alisa ilinichina amiella亚莉莎·伊莉妮提娜·阿米耶拉(噬神者系列)；akuma homura恶魔焰(魔法少女小圆)。
> 
>  人物描述的如：类型(萝莉、青年、1girl等）、姿势（手部、站位等，背后、叉腰）、头发（发型、发色等）、面部（五官、表情等）、躯干（A B C D等）、腿部（站着、坐着、跪着等）、服饰（水手服、裙子、公主鞋等）
> 
> **（4）画面场景：**描述所处环境，如白天、太阳、海边、城市、花园等。
> 
> **（5）其他：**视角（从上往下看，专注腿部、脸部，雪花飘落、星星等等）。

**_正向示例：_**

> masterpiece,best quality,official art,extremely detailed CG unity 8k wallpaper,(1girl, (very long hair, blonde hair, high ponytail), ((purple eyes, sparkling eyes), light smile), medium breasts, japanese_clothes, slippers, (hand on hip)), walking, in a meadow,

**_一些提示词的网址分享：_**

首推：

NovelAI tag在线生成器：

标签超市：

### 6.常用提示词

1、内容型提示词

**人物及主体特征**

 服饰穿搭 white dress

 发型发色 blonde hair，long hair

 五官特征 small eye，big mouth

 面部表情 smiling

 肢体动作 stretching arms

 beautiful detailed eyes 美丽细致的眼睛

 highly detailed skin 高度细致的皮肤

 extremely delicate and beautiful girls 非常精致和美丽的女孩

**场景特征**

 室内/室外 indoor/outdoor

 大场景 forest，city，street

 小细节 tree，bush，white flower

 underwater(水下）

 shinto shrine(神社）

**环境光照**

 白天/黑夜 day/night

 特定时段 morning/sunset

 光环境 sunlight，bright，dark

 天空 blue sky，starry sky

 cinematic lighting(电影光)

 dynamic lighting(动感光)

 soft lighting（柔和的照明） rim light（边缘光） dimly lit（昏暗照明）

**视线**

 looking at viewer 看着观众

 looking at another 看另一个

 looking away 斜视

 looking back 回头看

 looking up 仰望、仰视、抬头

**画幅视角**

 距离 close-up，distant

 人物比例 full body，upper body

 观察视角 from above，view of back

 镜头类型 wide angle，Sony A7 III

 dynamic angle 动态角度

 from above 从上方

 from below 从下面

 wide shot 广角镜头

 Aerial View 空中摄影照片、航摄照片、鸟（俯）瞰图

**主体远近的相关提示词**

 full body shot 全身

 cowboy shot 半身

 close-up shot 接近

**人物表情**

 blush 脸红

 wet sweat 大汗

 flying sweatdrops 飞汗

**衣服指定**

 china dress 旗袍

 sailor dress 水手服

 school uniform 校服

 sailor senshi uniform 水手服战士

**姿势指定**

 hands on 手上的 例hands on own face, hands on feet, hands on breast

 kneeling 跪着的

 hand between legs 手放在两腿之间

 hair flip 头发翻转

 skirt flip 裙摆翻转

**画风提示词**

 插画风 illustration,paining,painthbrush

 二次元 anime,comic,game CG

 写实系 photorealistic,realistic,photograph

 手绘风 sketch, one-hour drawing challenge

2、标准化提示词

**特定高分辨率类型**

 extremely detailed CG unity 8K wallpaper 超精细的8K Unity游戏CG

 unreal engine rendered 虚拟引擎渲染

**起手式输入下述提示词，生成图片质量就会提高**

 best quality, ultra-detailed, masterpiece, finely detail, highres, 8k wallpaper

**画人时添加下列提示词，可大幅提升人物细节精细度。**

 beautiful detailed eyes

 highly detailed skin

 extremely delicate and beautiful girls

 1 girl,（1个女孩）

 detailed beautiful skin,（细致美丽的肌肤）

 kind smile,（亲切的微笑）

 absurdres,（夸张）

 detailed-beautiful-face,（精致美丽的容颜）

 petite figure,（身材娇小）

 detailed skin texture,（细致的皮肤纹理）

 pale skin,（白皙肌肤）

 detailed hair,（细致的头发）

 random hair style,（随意发型，）

 detailed eyes,（细致的眼睛）

 glistening skin,（晶莹剔透肌肤）

 clean face,pretty face,sexy, cool, naughty face,((twintails))

**转手绘**

product design,no humans, white background, traditional media, simple background, monochrome, sketch, english text, greyscale, still life, artist name, pencil,

产品设计，无人类，白色背景，传统媒体，简单背景，单色，素描，英文文本，灰度，静物，艺术家姓名，铅笔，

### **7.常用提示词起手式**

1.   msterpiece,best quality,absurdres,photorealistic，raw photo 这个指令的意思是我要生成一个最佳杰作的，最高质量,高分辨率的具有照片写实的图像，可以理解为给这个要生成的图像指定了一个基本的框架！

2.cinematic angle ,cinematic look

这个指令的意思是把这个写实的照片用电影拍摄的手法，拍出电影一样的感觉，也就是说在刚才写实照片的基础上做了进一步的限制

3.stunning visual,film grainng

这个指令的意思是进一步给出了AI一个指令就是用惊艳的视角生成电影感的人像写真原片照片。

**_常用正面提示词：_**

> (masterpiece:1. 4, best quality), unity 8k wallpaper, ultra detailed, beautiful and aesthetic, perfect lighting, detailed background, realistic, solo, perfect detailed face, detailed eyes, highly detailed,
> 
>  （杰作：1.4，最佳品质），统一 8k 壁纸，超详细，美丽和美学，完美的灯光，详细的背景，逼真，独奏，完美细节的脸部，细节的眼睛，高度详细，

**_常用基础负面提示：_**

> worst quality, normal quality, low quality, low res, blurry, text, watermark, logo, banner, extra digits, cropped, jpeg artifacts, signature, username, error, sketch ,duplicate, ugly, monochrome, horror, geometry, mutation, disgusting
> 
> 
> 最差质量、正常质量、低质量、低分辨率、模糊、文字、水印、标志、横幅、额外数字、裁剪、JPEG伪影、签名、用户名、错误、素描、重复、丑陋、单色、恐怖、几何、突变、恶心

**_动画角色的负面提示：_**

> bad anatomy, bad hands, three hands, three legs, bad arms, missing legs, missing arms, poorly drawn face, bad face, fused face, cloned face, worst face, three crus, extra crus, fused crus, worst feet, three feet, fused feet, fused thigh, three thigh, fused thigh, extra thigh, worst thigh, missing fingers, extra fingers, ugly fingers, long fingers, horn, realistic photo, extra eyes, huge eyes, 2girl, amputation, disconnected limbs
> 
> 
> 解剖不佳、手势不佳、三只手、三条腿、臂部不佳、缺失腿部、缺失臂部、面部绘制不佳、面部不佳、面部融合、面部克隆、最差面部、三条腿、额外腿、腿融合、最差脚部、三只脚、脚融合、腿融合、额外腿、最差腿、缺失手指、额外手指、丑陋手指、长手指、角、真实照片、额外眼睛、巨大眼睛、2女孩、截肢、断臂

**_真实角色的负面提示：_**

> bad anatomy, bad hands, three hands, three legs, bad arms, missing legs, missing arms, poorly drawn face, bad face, fused face, cloned face, worst face, three crus, extra crus, fused crus, worst feet, three feet, fused feet, fused thigh, three thigh, fused thigh, extra thigh, worst thigh, missing fingers, extra fingers, ugly fingers, long fingers, horn, extra eyes, huge eyes, 2girl, amputation, disconnected limbs, cartoon, cg, 3d, unreal, animate
> 
> 
> 解剖不佳、手势不佳、三只手、三条腿、臂部不佳、缺失腿部、缺失臂部、面部绘制不佳、面部不佳、面部融合、面部克隆、最差面部、三条腿、额外腿、腿融合、最差脚部、三只脚、脚融合、腿融合、额外腿、最差腿、缺失手指、额外手指、丑陋手指、长手指、角、额外眼睛、巨大眼睛、2女孩、截肢、断臂、卡通、CG、3D、不真实、动态

**_真实角色的负面提示2：_**

> (worst quality:2),(low quality:2),(normal quality:2),lowres,normal quality,((monochrome)),((grayscale)),skin spots,acnes,skin blemishes,age spots,(ugly:1.3),(duplicate:1.3),(morbid:1.2),(mutilated:1.2),(tranny:1.3),mutated hands,(poorly drawn hands:1.5),blurry,(bad anatomy:1.2),(bad proportions:1.3),extra limbs,(disfigured:1.3),(more than 2 nipples:1.3),(missing arms:1.3),(extra legs:1.1),(fused fingers:1.6),(too many fingers:1.6),(unclear eyes:1.3),bad hands,missing fingers,extra digit,(futa:1.1),bad hands,missing fingers,deformed iris,out of frame,signature,watermark,username,blurry,artist name,trademark,watermark,title,ugly face,multiple views,Multiple people,
> 
>  （最差质量：2）、（低质量：2）、（正常质量：2）、低分辨率、正常质量、（（单色））、（（灰度））、皮肤斑点、痤疮、皮肤瑕疵、老年斑、（丑陋：1.3）、（重复：1.3）、（病态：1.2）、（残缺：1.2）、（人妖：1.3）、变异的手、（画得很差的手：1.5）、模糊、（解剖结构不良：1.2）、（比例不良：1.3）、多余的肢体、（毁容：1.3）、（超过 2 个乳头：1.3）、（缺失手臂：1.3）、（多余的腿：1.1）、（融合的手指：1.6）、（手指太多：1.6）、（眼睛模糊：1.3）、坏手、缺失手指、多余的手指、（扶他：1.1）、坏手、缺失手指、畸形虹膜、超出框架、签名、水印、用户名、模糊、艺术家姓名、商标、水印、标题、丑陋的脸、多个视图、多个人，

## 八.保存工作流

在ComfyUI中要如何保存我已经设置好的工作流？

你可以通过以下方式保存你制作好的工作流文件

*   保存图片生成的PNG文件（comfyUI会将生成过程中的prompt信息及workflow设置写入PNG的Exif信息中）
*   在菜单面板中点击保存可以将当前工作流保存为JSON格式

![Image 24: ComfyUI系列教程零基础部署到入门学习-教程篇](https://www.comfyorg.cn/wp-content/uploads/replace/7ec07dfbed1bbef2f666c3de6ff2360f.jpeg)

## 九.导入工作流

在comfyUI右侧菜单面板中，点击加载 可以通过以下两种方式载入comfyUI工作流文件

1.   从工作流Json 文件中加载工作流
2.   从comfyUI生成的PNG图片中加载

### 01.网站推荐

不建议单个节点单个节点的去学，多看看别人的工作流，推荐网站.

ComfyUI官网示范：

工作流分享网站:

下面我们就来下载一个工作流，加载看看。如图所示，出现报错了，出现这样的问题是因为缺失节点，​

思考一下前面说的，节点是不是需要下载安装才能使用，而我们复用别人的工作流，他用的节点你不一定下载了，因为目前有 600 多个节点，你不可能全部下载了吧，所以我们日后使用别人的工作流，你会经常出现这样的问题。​

![Image 25: ComfyUI系列教程零基础部署到入门学习-教程篇](https://www.comfyorg.cn/wp-content/uploads/replace/857a3abc6e2143ffded343d6447ee226.png)

问题不大，我们有解决办法，还记得前面教大家安装的【ComfyUI Manager】节点管理器吗，通过它我们就可以很方便的解决这个问题，下面跟着我操作一下即可。​

 ​

 启用管理器，然后你会看到有一个【安装缺失节点】，顾名思义就是它了。​

​

 点开后就可以看到我一个缺失 17 个节点，那么就需要把这些节点都安装（可多选同时安装）。​

 ​

![Image 26: ComfyUI系列教程零基础部署到入门学习-教程篇](https://www.comfyorg.cn/wp-content/uploads/replace/7e63c5ed41690ea15fb6ac3ef57f8461.png)

再装完 17 个节点之后，点击刷新或者是重新启动运用后台（如果节点还是报错），那么这套工作流我们就可以正常的使用了。​

![Image 27: ComfyUI系列教程零基础部署到入门学习-教程篇](https://www.comfyorg.cn/wp-content/uploads/replace/3bb4dae31fa997f3d66a99bfc17bc8e0.png)

温馨提示：本站提供的一切软件、教程和内容信息都来自网络收集整理，仅限用于学习和研究目的；不得将上述内容用于商业或者非法用途，否则，一切后果请用户自负，版权争议与本站无关。在未征得本站同意时，禁止复制、盗用、采集、发布本站内容到任何网站、书籍等各类媒体平台。如若本站内容侵犯了原著者的合法权益，可联系我们进行处理。
