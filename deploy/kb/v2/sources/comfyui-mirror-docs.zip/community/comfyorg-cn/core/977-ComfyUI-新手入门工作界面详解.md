---
title: ComfyUI 新手入门工作界面详解
source_url: https://www.comfyorg.cn/977.html
source_site: comfyorg.cn
captured_at: 2026-07-15T05:28:38.291927+00:00
category: community_core
fetch_method: jina_reader
---

Title: ComfyUI 新手入门工作界面详解 - ComfyUI资源网

URL Source: https://www.comfyorg.cn/977.html

Markdown Content:
今天，让我们借助文生图最简[工作流](https://www.comfyorg.cn/tag/%e5%b7%a5%e4%bd%9c%e6%b5%81 "View all posts in 工作流")，一同探索 ComfyUI 的工作界面，深入了解每一个按钮的功能，为今后熟练运用 ComfyUI 筑牢根基。本教程将围绕文生图最简工作流的搭建与运行展开，以直观、沉浸式的方式，帮助大家全面掌握工作界面中各个按钮的用途。

 启动 ComfyUI 后，系统会自动在浏览器中打开链接：http://127.0.0.1:8188。页面加载完成后，中间区域默认会呈现一个文生图最简工作流。

[https://www.comfyorg.cn/894.html](https://www.comfyorg.cn/894.html)

当我们打开工作界面后，默认是英文的，我们可以切换为中文的，如下图：

![Image 1: ComfyUI 新手入门工作界面详解](https://www.comfyorg.cn/wp-content/uploads/replace/fa0d61d48596c5653dcbe0ea4037276a.jpeg)

首先我们来新建一个工作流，点击工作流 -> 点击新建，如下图：

![Image 2: ComfyUI 新手入门工作界面详解](https://www.comfyorg.cn/wp-content/uploads/replace/12c11dc63c327f6a244cf1c77acb5c81.jpeg)

点击新建之后，界面中就呈现一个空白的工作流画布，如下图：

![Image 3: ComfyUI 新手入门工作界面详解](https://www.comfyorg.cn/wp-content/uploads/replace/7ca0edc49ba58f22ac78445362396772.jpeg)

也可以在工作流管理中新建一个空白工作流，点击+，就可以新建一个空白工作流，如下图：

![Image 4: ComfyUI 新手入门工作界面详解](https://www.comfyorg.cn/wp-content/uploads/replace/5459ceffe8b56a3b9d236309df5afcc9.jpeg)

下面，我们将在这片空白画布上搭建工作流（大家暂不必掌握搭建过程，后续会有专门教程讲解工作流搭建方法）。点击最左侧形似 “书” 的标志按钮，就能看到节点库。这里的节点按类别有序存放，其中既有系统内置节点，也包含第三方[插件](https://www.comfyorg.cn/tag/%e6%8f%92%e4%bb%b6 "View all posts in 插件")提供的节点。

搭建工作流时，通常我们会在节点库中找寻所需节点，然后按住鼠标左键，将其拖动至画布中。就像下图中的「Checkpoint 加载器 (简易)」节点，操作方式便是如此。

![Image 5: ComfyUI 新手入门工作界面详解](https://www.comfyorg.cn/wp-content/uploads/replace/814b020949e272e10810095cd2996cee.jpeg)

由于节点库中的节点较多，如果我们一个一个去找，就会很麻烦，我们可以输入节点名称进行节点搜索，如下图：

![Image 6: ComfyUI 新手入门工作界面详解](https://www.comfyorg.cn/wp-content/uploads/replace/5c108b8ee4053c7178bd83548f5cd606.jpeg)

我们输入：k 采样器，并将需要的 K 采样器拖入画布。也可以限制筛选类型，进而缩小筛选范围，如下图：

![Image 7: ComfyUI 新手入门工作界面详解](https://www.comfyorg.cn/wp-content/uploads/replace/9d13771f6c7108eebcc3536412b07f8d.jpeg)

同时我们也可以用鼠标双击画布空白处调出节点筛选组件，输入我们需要的节点名称，这里节点名称支持模糊搜索，不需要输入精准的节点名称，如下图：

![Image 8: ComfyUI 新手入门工作界面详解](https://www.comfyorg.cn/wp-content/uploads/replace/969d443fcc719a069d86123150efb408.jpeg)

然后我们把这个文生图最简工作流补充完整：

![Image 9: ComfyUI 新手入门工作界面详解](https://www.comfyorg.cn/wp-content/uploads/replace/1e31b639a3c8ed6c78be8ee2928eaf15.jpeg)

以上我们手动搭建了一个基本工作流，当我们需要频繁搭建工作流的时候，搭建基本工作流就显得太过没必要，因此 ComfyUI 也给我们提供了 4 个基本工作流，方便我们搭建最基本的工作流，然后我们在这个基本工作流之上进行扩展，我们点击 浏览模版，如下图：

![Image 10: ComfyUI 新手入门工作界面详解](https://www.comfyorg.cn/wp-content/uploads/replace/4f5e08c77f5c10f09c4e0ef55d23ffca.jpeg)

可以看到有 4 个基本工作流，如下图：

![Image 11: ComfyUI 新手入门工作界面详解](https://www.comfyorg.cn/wp-content/uploads/replace/704a21db62cd0e0d07d1c0abbce182a9.jpeg)

这四个默认工作流分别是：

1.   文生图基本工作流
2.   图生图基本工作流
3.   潜空间二次采样放大工作流
4.   [Flux](https://www.comfyorg.cn/tag/flux "View all posts in Flux") Shnell 文生图工作流

我们也可以在工作流管理中，打开工作流模版，如下图：

![Image 12: ComfyUI 新手入门工作界面详解](https://www.comfyorg.cn/wp-content/uploads/replace/cf577c8f2b581336b81e18a2d37ad3cf.jpeg)

当我们搭建好工作流之后，下一步就是执行工作流了，有三种执行方式，如下图：

![Image 13: ComfyUI 新手入门工作界面详解](https://www.comfyorg.cn/wp-content/uploads/replace/42b6a936a34daa84c277714d7063e6cc.jpeg)

**执行队列**

需要用户主动点击执行按钮才会触发工作流的运行，点击一次，工作流运行一次。

**执行队列 立刻**

开启后工作流会自动连续生成，直到再次切换到 执行队列。

**执行队列 变动**

当工作流存在参数变动时，会自动执行图片生成任务，这种方式合适改动参数并立刻验证参数效果场景，不需要我们改动参数后手动点击 执行队列。

注意：这三种执行方式的名字在 ComfyUI 的不同版本可能会略有不同，但表达的意思都是一样的，大家注意一下就可以。

执行队列右边的 3 个按钮：

![Image 14: ComfyUI 新手入门工作界面详解](https://www.comfyorg.cn/wp-content/uploads/replace/5467ca022a5235570f953f43478df950.jpeg)

从左到右：

1.   数字 1 表示一次执行队列执行 1 次生图任务，如果改为 4，就表示点击一次 执行队列，将连续执行 4 次。
2.   终止当前执行的任务，比如说一次执行很漫长，就可以点击这个按钮进行终止。
3.   终止排队的任务：如果执行队列中有 4 个任务，当前执行到第 1 个，点击这个按钮，可以终止后面 3 个生图任务。

当我们运行工作流的时候，会消耗系统的内存，CPU，显存，我们可以通过实时监控查看，如下图：

![Image 15: ComfyUI 新手入门工作界面详解](https://www.comfyorg.cn/wp-content/uploads/replace/a9b95f454f47289b243438c3cb21c7c1.jpeg)

这里可以查看 CPU，RAM(内存消耗)，GPU（[显卡](https://www.comfyorg.cn/tag/%e6%98%be%e5%8d%a1 "View all posts in 显卡")消耗），VRAM(虚拟内存)，Temp（机器温度）这 5 个机器指标。

如果我们的内存和显存消耗过高，可以通过点击下面两个按钮来释放内存，缓解紧张的机器资源，如下图：

![Image 16: ComfyUI 新手入门工作界面详解](https://www.comfyorg.cn/wp-content/uploads/replace/443460474621da05b446f773f9ce2b43.jpeg)

左边的按钮：unload models 表示卸载[模型](https://www.comfyorg.cn/tag/%e6%a8%a1%e5%9e%8b "View all posts in 模型")，重新执行队列不会重新加载模型。

右边的按钮：free model and node cache 表示释放模型和节点缓存，重新执行队列对重新加载模型。

随着我们执行队列，我们就可以生成不同的[图像](https://www.comfyorg.cn/tag/%e5%9b%be%e5%83%8f "View all posts in 图像")，我们可以在 预览图像 节点中查看生成的图像：

![Image 17: ComfyUI 新手入门工作界面详解](https://www.comfyorg.cn/wp-content/uploads/replace/7f1b2364f27a1f9fdc143334efa24a3a.jpeg)

同时你可以看到在面板底部也可以查看生图历史记录：

![Image 18: ComfyUI 新手入门工作界面详解](https://www.comfyorg.cn/wp-content/uploads/replace/570fbac19445aed0fb729caf4f6fae0f.jpeg)

这里是生图列表，feed size 是图像大小，column 是一行有多少张图。

点击右下角的 Clear，可以清理历史图像。

点击右下角的❌，可以隐藏这个区域。

通过点击右上角的按钮，可以再次显示这个区域：

![Image 19: ComfyUI 新手入门工作界面详解](https://www.comfyorg.cn/wp-content/uploads/replace/4d883f000d8389a187e4ef1c5c8323e7.jpeg)

同时我们在左侧也可以查看生图历史记录，如下图：

![Image 20: ComfyUI 新手入门工作界面详解](https://www.comfyorg.cn/wp-content/uploads/replace/3cba587b491390894ded4366b3e30c48.jpeg)

这里生图历史记录会按照次序排列，每张图还能看到生图耗时，点击图像还可以进行大图预览，右键这张图，可以删除该图，加载工作流可以将生成改图的工作流导入到画布，前往节点是在画布中直接定位到该图的图像节点。拖动右边框可以缩放这块区域，

上面我们搭建好工作流，并成功运行了工作流，我们希望将这个工作流保存下来，以便于我们下次不用再搭建相同的工作流，而是打来直接运行。我们点击 工作流，可以看到有两个按钮：保存，保存为。

![Image 21: ComfyUI 新手入门工作界面详解](https://www.comfyorg.cn/wp-content/uploads/replace/a61d55f8705bb389fa79c4c108eebbc1.jpeg)

**1. 保存**

保存是将工作流文件保存到磁盘里，点击 保存 按钮，弹出命名窗口，我们输入一个合适名字，并点击确定按钮：

![Image 22: ComfyUI 新手入门工作界面详解](https://www.comfyorg.cn/wp-content/uploads/replace/1ba6f3dd4937f0bc71edd1a6b4f7bf2f.jpeg)

保存的默认位置是：ComfyUI-aki-v1.5userdefaultworkflows，如下图：

![Image 23: ComfyUI 新手入门工作界面详解](https://www.comfyorg.cn/wp-content/uploads/replace/d5952e0ddf6db2a858df8c9cd3972547.jpeg)

可以看到工作流就是一个 json 文件，json 文件中定义了工作流的工作逻辑。

**2. 保存为**

保存为是复制当前工作流，并对复制后的工作流进行重命名，并将该工作流存放在磁盘的另一个地方：

![Image 24: ComfyUI 新手入门工作界面详解](https://www.comfyorg.cn/wp-content/uploads/replace/dd10fa46c9698143d27b2d0d7089d54c.jpeg)

保存为的应用场景是在工作流 1 的基础上进行继续搭建，但是又不想破坏工作流 1 的结构，这时候就可以通过另存为来实现。

**3. 导出**

导出实际上是下载，将当前工作流下载到本地，因此对于本地使用 ComfyUI 的情况，这个功能和另存为是一样的，对于云端使用 ComfyUI 的情况，就是把网络上的工作流下载到本地，点击之后，我们重命名和选择保存目录之后，工作流就下载到本地相应的位置了。

![Image 25: ComfyUI 新手入门工作界面详解](https://www.comfyorg.cn/wp-content/uploads/replace/6572964a339f9b31ffec82edcaf406db.jpeg)

**4. 导出(API)**

将工作流以 API 格式导出，以便通过 API 接口在外部程序或平台上使用该工作流进行图像生成等操作。这种方式我们一般应用不到。

当我们通过保存、保存为、导出将工作流保存到本地之后，下一次我们就可以打开它并运行它，点击打开按钮，从本地选择一个工作流并加载到工作流画布中，如下图：

![Image 26: ComfyUI 新手入门工作界面详解](https://www.comfyorg.cn/wp-content/uploads/replace/3265354c166c6b8052b2f1e50395a973.jpeg)

同时我们在工作流管理中，也可以打开工作流，如下图：

![Image 27: ComfyUI 新手入门工作界面详解](https://www.comfyorg.cn/wp-content/uploads/replace/e5846d3cfe087f957871064c004d9625.jpeg)

![Image 28: ComfyUI 新手入门工作界面详解](https://www.comfyorg.cn/wp-content/uploads/replace/849754d34b28a8a09b5d6909e05dfad6.jpeg)

**1. 撤销**

当我们操作工作流之后，发现不对，就可以通过撤销按钮，撤销上一步操作，这个按钮可以用 Ctrl+z 来进行替代。

**2. 重做**

重做上一步撤销的操作

**3. Refresh Node Definitions**

刷新工作流节点，通过执行该操作，可以不用重启 ComfyUI 就可以加载新添加的模型。而对于新添加的插件，可以需要重启 ComfyUI，最右侧有一个 r 字母，表示通过点击 r 字母，也可以起到刷新节点的作用。

**4. 清空工作流**

将当前工作流清空，一般用于重新搭建工作流的场景。

**5. 剪贴板**

这个不常用，这里不再赘述。

将自己本地的工作流分享到以下平台：

![Image 29: ComfyUI 新手入门工作界面详解](https://www.comfyorg.cn/wp-content/uploads/replace/11906f4033aaa8a1b1f3841373d047e0.jpeg)

![Image 30: ComfyUI 新手入门工作界面详解](https://www.comfyorg.cn/wp-content/uploads/replace/a15a40218ca6e2d3348ad9968dfd7d38.jpeg)

可以将当前工作流分享到各个平台。

这里我们可以对打开的工作流进行删除，插入，搜索、重命名、新建和打开工作流，如下图：

![Image 31: ComfyUI 新手入门工作界面详解](https://www.comfyorg.cn/wp-content/uploads/replace/dd40b9278512a0b6a9f3452bb7c61b0f.jpeg)

![Image 32: ComfyUI 新手入门工作界面详解](https://www.comfyorg.cn/wp-content/uploads/replace/a0bd45d274fb686c017949eb47903d82.jpeg)

鼠标右键工作流，可以对这个工作流进行重命名、删除和插入到画布中。

![Image 33: ComfyUI 新手入门工作界面详解](https://www.comfyorg.cn/wp-content/uploads/replace/97832960d7a251ee94d3604a71c06ca9.jpeg)

① 加号：放大工作流（等同于向上滚动鼠标滚轮）

② 减号：缩小工作流（等同于向下滚动鼠标滚轮）

③ 方块：将画布中的工作流居中展示，这个功能可以让我们将画布之外的工作流一键居中。

④ 平移/选择

![Image 34: ComfyUI 新手入门工作界面详解](https://www.comfyorg.cn/wp-content/uploads/replace/2d27137f80ff6475d52d343836aab6d8.jpeg)

![Image 35: ComfyUI 新手入门工作界面详解](https://www.comfyorg.cn/wp-content/uploads/replace/ff284b6996fdacadbd9d9487db03319c.jpeg)

平移模式下，可以用鼠标拖动工作流整体进行平移。

选择模式下，可以用鼠标选择拖动工作流中的某个节点进行移动。

⑤ 显示/隐藏连线

![Image 36: ComfyUI 新手入门工作界面详解](https://www.comfyorg.cn/wp-content/uploads/replace/6000009b153e7b2908e12c067ad42c7e.jpeg)

![Image 37: ComfyUI 新手入门工作界面详解](https://www.comfyorg.cn/wp-content/uploads/replace/99213032c92de08b6bac10fa6f5be139.jpeg)

关闭小眼睛：隐藏工作流中的连线

打开小眼睛：显示工作流中的连线

![Image 38: ComfyUI 新手入门工作界面详解](https://www.comfyorg.cn/wp-content/uploads/replace/99f2211f13ebb20b82e99cf4b4eac6e1.jpeg)

点击侧边栏中的设置按钮，就来到了设置面板，如下图：

![Image 39: ComfyUI 新手入门工作界面详解](https://www.comfyorg.cn/wp-content/uploads/replace/ca439a79d9cf20ba7dc403cd69ab4f3d.jpeg)

**1. 菜单位置：可选项：禁用、上、下**

![Image 40: ComfyUI 新手入门工作界面详解](https://www.comfyorg.cn/wp-content/uploads/replace/43f1acc8e9fc4faf7914ad4f598ca0b3.jpeg)

禁用：点击禁用，界面切换为老版本，菜单项都集中在一个区域内，如下图：

![Image 41: ComfyUI 新手入门工作界面详解](https://www.comfyorg.cn/wp-content/uploads/replace/05374f3c5019288716264cb9e33d4266.jpeg)

上和下是针对于新版本来说的，区别如下图：

![Image 42: ComfyUI 新手入门工作界面详解](https://www.comfyorg.cn/wp-content/uploads/replace/f23b3543a17cc0ff0d45b6e1d4d766e1.jpeg)

![Image 43: ComfyUI 新手入门工作界面详解](https://www.comfyorg.cn/wp-content/uploads/replace/28662440e367f1a792b5fe9c9b07a485.jpeg)

**2. 侧面版**

这个设置主要是调整侧面版的尺寸和位置

![Image 44: ComfyUI 新手入门工作界面详解](https://www.comfyorg.cn/wp-content/uploads/replace/6af21e16adc9f0f87d3fa0f86c37d1bd.jpeg)

**3. 连线形状**

![Image 45: ComfyUI 新手入门工作界面详解](https://www.comfyorg.cn/wp-content/uploads/replace/2b29146b15d12e6632dce7364d503846.jpeg)

支持 4 种形状：直角线、直线、曲线、隐藏

![Image 46: ComfyUI 新手入门工作界面详解](https://www.comfyorg.cn/wp-content/uploads/replace/4395e216fb66d2509f0d6942727f5ff5.jpeg)

![Image 47: ComfyUI 新手入门工作界面详解](https://www.comfyorg.cn/wp-content/uploads/replace/59b7ee20fd5ba4ce6d44a2d6c1206a0e.jpeg)

![Image 48: ComfyUI 新手入门工作界面详解](https://www.comfyorg.cn/wp-content/uploads/replace/2568a1ddad33a44604dd12000bb98625.jpeg)

![Image 49: ComfyUI 新手入门工作界面详解](https://www.comfyorg.cn/wp-content/uploads/replace/dbb06d4cde47816ebabc09760fbadeff.jpeg)

![Image 50: ComfyUI 新手入门工作界面详解](https://www.comfyorg.cn/wp-content/uploads/replace/3fe5cbadd2d0016263744ae46cb25f83.jpeg)

今天的分享内容就到这里，其中菜单中的“管理器”在本节暂不展开，后续会有一节专门的一节进行分享，希望今天的分享对你有所帮助！

温馨提示：本站提供的一切软件、教程和内容信息都来自网络收集整理，仅限用于学习和研究目的；不得将上述内容用于商业或者非法用途，否则，一切后果请用户自负，版权争议与本站无关。在未征得本站同意时，禁止复制、盗用、采集、发布本站内容到任何网站、书籍等各类媒体平台。如若本站内容侵犯了原著者的合法权益，可联系我们进行处理。
