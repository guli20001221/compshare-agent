---
title: 如何在 ComfyUI 中安装不同类型的模型
source_url: https://www.comfyorg.cn/1180.html
source_site: comfyorg.cn
captured_at: 2026-07-15T05:28:35.858746+00:00
category: community_core
fetch_method: jina_reader
---

Title: 如何在 ComfyUI 中安装不同类型的模型 - ComfyUI资源网

URL Source: https://www.comfyorg.cn/1180.html

Markdown Content:
[![Image 6](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/logo.png)](https://www.comfyorg.cn/)

*   [首页](https://www.comfyorg.cn/)
*   [🍂ComfyUI秋叶](https://www.comfyorg.cn/894.html)
*   [🔥满血整合包](https://www.comfyorg.cn/shop/1680.html)
*   [🎭应用广场](https://www.comfyorg.cn/shop)
*   [🍌AI绘画](https://www.comfyorg.cn/aidesign)

[文章](javascript:void(0))

[文章](javascript:void(0))[用户](javascript:void(0))[商铺](javascript:void(0))[文档](javascript:void(0))

[](https://www.comfyorg.cn/message)

登录 快速注册

[![Image 7](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/logo.png)](https://www.comfyorg.cn/)

*   [科技前沿](https://www.comfyorg.cn/kjqy)
    *   [![Image 8: 创新项目](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico1.png)创新项目 14篇](https://www.comfyorg.cn/kjqy/cxxm)
    *   [![Image 9: 办公软件](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico2.png)必备工具 11篇](https://www.comfyorg.cn/kjqy/bbgj)
    *   [![Image 10: 办公软件](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico2.png)办公软件 6篇](https://www.comfyorg.cn/kjqy/bruanjian)
    *   [![Image 11: API聚合](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/icon42.png)API聚合](https://api.oagi.com.cn/)

*   [常用模型](https://www.comfyorg.cn/cynx)
    *   [![Image 12: 主模型](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico3.png)主模型 36篇](https://www.comfyorg.cn/cynx/zmx)
    *   [![Image 13: 微调模型](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico4.png)微调模型 17篇](https://www.comfyorg.cn/cynx/lora)
    *   [![Image 14: Flux模型](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico5.png)Flux模型 20篇](https://www.comfyorg.cn/cynx/fluxmodel)
    *   [![Image 15: 加速模型](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico6.png)加速模型 14篇](https://www.comfyorg.cn/cynx/qrmx)
    *   [![Image 16: 控制模型](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico7.png)控制模型 24篇](https://www.comfyorg.cn/cynx/controlnet)
    *   [![Image 17: 增强模型](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico8.png)增强模型 34篇](https://www.comfyorg.cn/cynx/zqmx)
    *   [![Image 18: Wan模型](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico9.png)Wan模型 19篇](https://www.comfyorg.cn/cynx/wanmodel)
    *   [![Image 19: 关联模型](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico10.png)关联模型 18篇](https://www.comfyorg.cn/cynx/glmx)
    *   [![Image 20: 音视频模型](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico11.png)音视频模型 54篇](https://www.comfyorg.cn/cynx/scenemodel)
    *   [![Image 21: Qwen-image模型](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico12.png)Qwen-image模型 26篇](https://www.comfyorg.cn/cynx/qwenmodel)
    *   [![Image 22: 辅助模型](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico13.png)辅助模型 33篇](https://www.comfyorg.cn/cynx/fzmx)

*   [工作流](https://www.comfyorg.cn/workflow)
    *   [![Image 23: 基础工作流](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico14.png)基础工作流 57篇](https://www.comfyorg.cn/workflow/basic-workflow)
    *   [![Image 24: 模型排行榜](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico15.png)照片修复 38篇](https://www.comfyorg.cn/workflow/ai-repair)
    *   [![Image 25: 电商应用](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico16.png)电商应用 34篇](https://www.comfyorg.cn/workflow/ai-commerce)
    *   [![Image 26: Qwen-image](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico17.png)Qwen-image 29篇](https://www.comfyorg.cn/workflow/qwen-image)
    *   [![Image 27: 角色设计](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico18.png)角色设计 18篇](https://www.comfyorg.cn/workflow/ai-character)
    *   [![Image 28: 海报设计](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico19.png)海报设计 26篇](https://www.comfyorg.cn/workflow/ai-poster)
    *   [![Image 29: 风格转换](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico20.png)风格转换 17篇](https://www.comfyorg.cn/workflow/ai-stylistic)
    *   [![Image 30: ControlNet](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico21.png)Flux工作流 38篇](https://www.comfyorg.cn/workflow/ai-flux)
    *   [![Image 31: 音视频](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico22.png)音视频 60篇](https://www.comfyorg.cn/workflow/audio-video)
    *   [![Image 32: 人像摄影](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico23.png)人像摄影 29篇](https://www.comfyorg.cn/workflow/ai-photography)
    *   [![Image 33: 实用工具](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico24.png)实用工具 41篇](https://www.comfyorg.cn/workflow/utilities)
    *   [![Image 34: 高级工作流（商用）](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico25.png)高级工作流（商用） 11篇](https://www.comfyorg.cn/workflow/advanced-workflow)

*   [插件](https://www.comfyorg.cn/chajian)
    *   [![Image 35: 基础插件](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico30.png)基础插件 40篇](https://www.comfyorg.cn/chajian/basicplugins)
    *   [![Image 36: 提示词插件](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico31.png)提示词插件 11篇](https://www.comfyorg.cn/chajian/promptplugin)
    *   [![Image 37: ControlNet](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico21.png)ControlNet 11篇](https://www.comfyorg.cn/chajian/controlnetplug)
    *   [![Image 38: 图片插件](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico33.png)图片插件 35篇](https://www.comfyorg.cn/chajian/imgplug)
    *   [![Image 39: 视频插件](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico34.png)视频插件 42篇](https://www.comfyorg.cn/chajian/videoplug)
    *   [![Image 40: Flux插件](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico32.png)Flux插件 18篇](https://www.comfyorg.cn/chajian/fluxplugin)
    *   [![Image 41: 3D插件](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico35.png)3D插件 2篇](https://www.comfyorg.cn/chajian/3dplug)
    *   [![Image 42: 其他插件](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico36.png)其他插件 32篇](https://www.comfyorg.cn/chajian/otherplugins)

*   [自学课程](https://www.comfyorg.cn/tutorial)
    *   [![Image 43: 基础教程](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico26.png)基础教程 27篇](https://www.comfyorg.cn/tutorial/basic)
    *   [![Image 44: 进阶教程](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico27.png)进阶教程 27篇](https://www.comfyorg.cn/tutorial/advanced)
    *   [![Image 45: 高级教程](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico28.png)高级教程 8篇](https://www.comfyorg.cn/tutorial/gaoji)
    *   [![Image 46: 其他](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico29.png)其他 9篇](https://www.comfyorg.cn/tutorial/yqt)

*   [视频教程](https://www.comfyorg.cn/videojc)
*   [更多](https://www.comfyorg.cn/1180.html#)
    *   [![Image 47: 模型排行榜](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico15.png)站长运维 6篇](https://www.comfyorg.cn/kjqy/zzyw)
    *   [![Image 48: 模型排行榜](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico15.png)模型排行榜](https://www.comfyorg.cn/document/2371.html)
    *   [![Image 49: 疑难解答](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico41.png)疑难解答](https://www.comfyorg.cn/ask)

[投稿](javascript:void(0))

# 如何在 ComfyUI 中安装不同类型的模型

*   [基础教程](https://www.comfyorg.cn/tutorial/basic) 
*   1 年前
*   **212.9k**
*   **0**

[](https://www.comfyorg.cn/users/1)

![Image 50](https://www.comfyorg.cn/wp-content/uploads/thumb/2025/06/fill_w120_h120_g0_mark_20250612030820830302.png)

**ComfyUI教程**免费资源

关注 私信

本指南提供了在 ComfyUI 中安装各种模型的全面概述。它涵盖了不同类型模型的安装过程，包括 Stable Diffusion 检查点、LoRA 模型、嵌入、VAE、ControlNet 模型和放大器。通过遵循本指南，您将学习如何扩展 ComfyUI 的功能，并使用这些基本模型增强您的 AI 图像生成工作流程。

### 安装Checkpoint模型:

下载Stable diffusion 的渠道有很多，Hugging Face 、Civitai 等等,这里我建议你使用 Civitai 这个网站，这个内容比较丰富，也有很多的模型可以下载

1.   打开 Civitai 模型板块[https://civitai.com/models](https://www.comfyorg.cn/url?url=aHR0cHM6Ly9jaXZpdGFpLmNvbS9tb2RlbHM=)
2.   在页面菜单点击筛选器`Filters`
3.   在`Filters`的弹窗中`Model types`中选择`Checkpoint`
4.   如果你需要特定的模型版本则可以在`Base model`这个分类这里，选择特定的模型版本
5.   浏览页面，通常封面都是效果预览，你可以选择一个你需要的模型
6.   点击模型卡片进入详情页，你可以看到蓝色的`Download`按钮，点击下载
7.   等待下载完成，进行下一步

### 第二步：在 ComfyUI 中安装对应的模型

1.   `📁ComfyUI_windows_portable`
2.   `// ComfyUI 官方便携版├── 📁ComfyUI`
3.   `// comfy UI主要文件夹│  ├──📁 models`
4.   `// 模型安装文件夹│  |  ├── 📁 checkpoints`
5.   `// 💡 你需要把下载到的模型文件放到这个文件夹│`
6.   `│  └── ...`
7.   `│  └── ...`
8.   `└── ...`

由于不同版本的 Stable diffusion 模型所使用的其它模型如 LoRA、CotrlNet、Embedding模型等他们的模型版本都需要对应，所以我非常建议你在安装时多新建一个文件夹用来区分模型版本 比如像下面这样的结构

1.   `📁ComfyUI_windows_portable`
2.   `├── 📁ComfyUI`
3.   `│  ├──📁 models`
4.   `│  |  └── 📁 checkpoints`
5.   `│  │       ├── 📁 SD1.5`
6.   `│  │       ├── 📁 SD2.0`
7.   `│  │       ├── 📁 SDXL`
8.   `│  │       ├── 📁 FLUX`
9.   `│  │       └── ...`
10.   `│  └── ...`
11.   `└── ...`

将你的模型文件存放到对应的文件夹内，请放心，ComfyUI 可以识别到你的文件层级，这样在日常的使用中更容易区分

![Image 51: 3步出图！最新图片编辑模型BooGu：Boogu-Image-0.1生图模型硬刚Qwen](https://www.comfyorg.cn/wp-content/themes/b2/Assets/fontend/images/default-img.jpg)

### 安装 ControlNet 模型

从上述资源页面下载所需的 ControlNet 模型文件。这些文件通常以`.pth`或`.safetensors`为扩展名。

**放置模型文件**

将下载的 ControlNet 模型文件放入 ComfyUI 的指定目录:

1.   `ComfyUI/models/controlnet/`

### 安装 Embeddings（Textual Inversion） 模型

![Image 52: 3步出图！最新图片编辑模型BooGu：Boogu-Image-0.1生图模型硬刚Qwen](https://www.comfyorg.cn/wp-content/themes/b2/Assets/fontend/images/default-img.jpg)

Embeddings（Textual Inversion）模型，通常在模型站上，我们可以看到embedding模型，它能够输出特定的风格。例如，它可以生成平面风格的图像，或者使画面中的人物具备某些特征，甚至让整个画面呈现特定的艺术风格。此外，embedding模型的体积通常很小，只有几KB。 你可以把它简单理解为一个提示词(prompt)的`压缩包`，原本你需要很复杂的文本描述才可以达到的效果，通过 Embedding 模型都可以轻易做到，再加上他的体积很小，所以使用起来非常方便

Embeddings（Textual Inversion）模型的作用主要是 用于在图像中嵌入特定的元素特征，如画面风格、人物特点、场景特征等，从而让模型生成符合这些特征的图像。

### 放置模型文件

模型存放位置在

`“ComfyUI/models/embeddings”`

重启或者刷新 ComfyUI 界面即可加载对应的 embedding 模型

> 💡因为模型需要区分版本，为了方便你后期的使用，我建议你对模型文件进行重命名加上一个模型版本前缀如”SD1.5-模型名称”,或者不重新命名，在 对应模型 目录下新建一个文件夹，用大模型版本来命名如“SD1.5”，然后将你的模型文件复制到如`“ComfyUI_windows_portable/ComfyUI/models/embedding/sSD1.5”里面去`

1.   `📁ComfyUI`
2.   `├── 📁models│`
3.   `└── 📁embeddings`
4.   `│       └── 📁SD1.5`
5.   `// 存放embedding模型`

### 安装使用 Hypernetwork 模型

Hypernetwork(超网络)，就像是一个有特殊能力的助手，它可以帮助其他的神经网络变得更聪明。想象一下，你有一支足球队，每个球员都有自己的位置和技能。现在，如果有一个教练，他可以根据比赛的需要，临时给球员们一些额外的技能或建议，让球队表现得更好。Hypernetwork(超网络)在这个比喻中，就扮演了那个教练的角色。

**ComfyUI中 Hypernetwork 模型如何安装？**

模型存放位置在

`“ComfyUI/models/hypernetworks”`

然后重启或者刷新 ComfyUI 界面即可加载对应的 LoRA 模型

> 💡因为模型需要区分版本，为了方便你后期的使用，我建议你对模型文件进行重命名加上一个模型版本前缀如”SD1.5-模型名称”,或者不重新命名，在 对应模型 目录下新建一个文件夹，用大模型版本来命名如“SD1.5”，然后将你的模型文件复制到如 “ComfyUI/models/hypernetworks/SD1.5” 里面去.如果你是与其它GUI共享模型文件，请参照 [安装comfyui](https://www.comfyorg.cn/1028.html) 中共享模型部分的说明，将对应的模型文件复制安装到对应的文件夹去

### 安装使用 LoRA 模型

![Image 53: 3步出图！最新图片编辑模型BooGu：Boogu-Image-0.1生图模型硬刚Qwen](https://www.comfyorg.cn/wp-content/themes/b2/Assets/fontend/images/default-img.jpg)

想象一下，你有一个多功能的机器人厨师，它可以做出各种基本的菜肴。但是，如果你想让这个机器人厨师做出一些特别的、有特定风味的菜肴，比如意大利的披萨或者中国的饺子，你就需要给它一些额外的“食谱”。

*   Stable Diffusion Stable Diffusion 就像是这个多功能的机器人厨师，它可以根据不同的食材（描述）做出各种各样的菜肴（图片）。它非常擅长理解你的要求，并创造出符合你描述的美味佳肴。
*   LoRA 模型 LoRA 模型就像是给这个机器人厨师提供的额外“食谱”。这些“食谱”可以帮助机器人厨师学会制作一些特别的菜肴，让它的烹饪技巧更加丰富。

**作用**

1.   **个性化**：使用 LoRA，机器人厨师可以制作出更加个性化的菜肴，满足你对特定风味的需求。
2.   **灵活性**：即使学会了新的“食谱”，机器人厨师仍然可以制作其他任何菜肴，这就像是它变得更加多才多艺了。
3.   **效率**：LoRA 允许机器人厨师在不忘记原有烹饪技巧的情况下学习新的“食谱”，这样它就可以更快地制作出你想要的菜肴。

**ComfyUI中 LoRA 模型如何安装？**

模型存放位置

`“ComfyUI/models/loras”`

然后重启或者刷新 ComfyUI 界面即可加载对应的 LoRA 模型

> 💡因为模型需要区分版本，为了方便你后期的使用，我建议你对模型文件进行重命名加上一个模型版本前缀如”SD1.5-模型名称”,或者不重新命名，在 对应模型 目录下新建一个文件夹，用大模型版本来命名如“SD1.5”，然后将你的模型文件复制到如`“ComfyUI/models/loras/SD1.5”`里面去

### 安装VAE模型

VAE(Variational AutoEncoder)变分自编码器是一种重要的生成模型。想象一下,VAE就像一个非常聪明的画家:

1.   **编码器(Encoder)**: 首先,这个画家会仔细观察一幅画,并把画中的关键特征记在脑子里。这就像是把复杂的画压缩成简单的要点。

2.   **潜在空间(Latent Space)**: 画家脑子里记下的这些要点,就形成了一个想象空间。在这个空间里,画家可以自由组合这些特征。

3.   **解码器(Decoder)**: 然后,画家就可以根据脑子里的这些要点,重新画出一幅相似但又不完全一样的画。这就像是把简单的要点又还原成复杂的画作。

VAE模型在AI绘图中的作用就是帮助模型更好地理解和生成图像的细节,特别是在处理复杂的视觉元素时。

**下载VAE模型文件**

从上述渠道下载VAE模型文件,通常是以`.pt`或`.safetensors`为扩展名。

**放置模型文件**

将下载的VAE模型文件放入ComfyUI的指定目录:

1.   `ComfyUI_windows_portable/ComfyUI/models/vae`

> 💡为了更好地管理模型,建议你可以在vae目录下创建子文件夹,按照大模型版本或其他分类方式组织VAE模型文件，因为通常不同类型的绘图模型比如 不同版本的stable diffusion模型之间 和 Flux绘图模型 的 VAE 不一定能够通用，例如:`ComfyUI_windows_portable/ComfyUI/models/vae/SD1.5your_vae_model.safetensors`

温馨提示：本站提供的一切软件、教程和内容信息都来自网络收集整理，仅限用于学习和研究目的；不得将上述内容用于商业或者非法用途，否则，一切后果请用户自负，版权争议与本站无关。在未征得本站同意时，禁止复制、盗用、采集、发布本站内容到任何网站、书籍等各类媒体平台。如若本站内容侵犯了原著者的合法权益，可联系我们进行处理。

按需赞赏，扩展网盘空间

给TA打赏

共1人

**1**5人已打赏

*   [![Image 54](https://www.comfyorg.cn/wp-content/themes/b2/Assets/fontend/images/default-avatar.png)](https://www.comfyorg.cn/users/3473)

**海报分享****收藏**

**0****0**

 2 条回复 **A**_文章作者_**M**_管理员_

签到和评论活跃账户，均可获得积分免费下载此资源！ 

您必须登录或注册以后才能发表评论

登录

![Image 55](https://www.comfyorg.cn/wp-content/themes/b2/Assets/fontend/images/default-avatar.png)

欢迎您，新朋友，感谢参与互动！

确认修改

细 中 粗

😁😊😎😤😥😂😍😏😙😟😖😜😱😲😭😚💀👻👍💪👊

取消回复 提交

1.   ![Image 56: 3步出图！最新图片编辑模型BooGu：Boogu-Image-0.1生图模型硬刚Qwen](https://www.comfyorg.cn/wp-content/themes/b2/Assets/fontend/images/default-img.jpg)[鍚城寒枫](https://www.comfyorg.cn/users/3473)**学前班**_lv0_  3 个月前  鍚城寒枫 给作者打赏了￥10  0 0 置顶 回复       
    *   ![Image 57: 3步出图！最新图片编辑模型BooGu：Boogu-Image-0.1生图模型硬刚Qwen](https://www.comfyorg.cn/wp-content/themes/b2/Assets/fontend/images/default-img.jpg)[ComfyUI教程](https://www.comfyorg.cn/users/1)**A****M**@[鍚城寒枫](https://www.comfyorg.cn/users/3473)**永久会员****博导**_lv7_  3 个月前  😱谢谢老板 0 0 回复       

1/1 页 前往 

❮❯

## 关于作者 关注 私信

![Image 58](https://www.comfyorg.cn/wp-content/uploads/thumb/2025/06/fill_w192_h192_g0_mark_20250612030820830302.png)

[](https://www.comfyorg.cn/users/1)
ComfyUI教程

**博导**_lv7_**永久会员**

文章

291

评论

106

关注

0

粉丝

198

[[文章] 3步出图！最新图片编辑模型BooGu：Boogu-Image-0.1生图模型硬刚Qwen](https://www.comfyorg.cn/3529.html)

[[文章] Bernini：全能Wan视频编辑与生成模型，AI视频编辑先理解再动手](https://www.comfyorg.cn/3521.html)

[[文章] Krea2 Turbo模型：多风格生成工作流，人像效果足以撼动Z-Image人像王座的最新模型](https://www.comfyorg.cn/3502.html)

[[文章] 清华团队开源SCAIL-2： 动作转移、分段队列换装、人物替换多角色+动物全支持](https://www.comfyorg.cn/3497.html)

[Ta的全部动态](https://www.comfyorg.cn/tastream/1)

*   [](https://www.comfyorg.cn/1180.html#)[](https://www.comfyorg.cn/1180.html#)   
*   [](https://www.comfyorg.cn/1180.html#)[](https://www.comfyorg.cn/1180.html#)   
*   [](https://www.comfyorg.cn/1180.html#)[](https://www.comfyorg.cn/1180.html#)   
*   [](https://www.comfyorg.cn/1180.html#)[](https://www.comfyorg.cn/1180.html#)   
*   [](https://www.comfyorg.cn/1180.html#)[](https://www.comfyorg.cn/1180.html#)   
*   [](https://www.comfyorg.cn/1180.html#)[](https://www.comfyorg.cn/1180.html#)   

[签到排行](https://www.comfyorg.cn/mission)

点击领取今天的签到奖励！

今日签到

连续签到

*   [![Image 59](https://www.comfyorg.cn/wp-content/themes/b2/Assets/fontend/images/default-avatar.png)](https://www.comfyorg.cn/users/5043)[七千海里](https://www.comfyorg.cn/users/5043)
7 小时后 4  
*   [![Image 60](https://www.comfyorg.cn/wp-content/themes/b2/Assets/fontend/images/default-avatar.png)](https://www.comfyorg.cn/users/3695)[qiutian](https://www.comfyorg.cn/users/3695)
7 小时后 5  
*   [![Image 61](https://www.comfyorg.cn/wp-content/themes/b2/Assets/fontend/images/default-avatar.png)](https://www.comfyorg.cn/users/4027)[嫁衣神功](https://www.comfyorg.cn/users/4027)
6 小时后 4  
*   [![Image 62](https://www.comfyorg.cn/wp-content/themes/b2/Assets/fontend/images/default-avatar.png)](https://www.comfyorg.cn/users/4242)[辫子叔叔](https://www.comfyorg.cn/users/4242)
6 小时后 3  
*   [![Image 63](https://www.comfyorg.cn/wp-content/themes/b2/Assets/fontend/images/default-avatar.png)](https://www.comfyorg.cn/users/3548)[烈火](https://www.comfyorg.cn/users/3548)
6 小时后 5  
*   [![Image 64](https://www.comfyorg.cn/wp-content/themes/b2/Assets/fontend/images/default-avatar.png)](https://www.comfyorg.cn/users/2354)[歸去來兮](https://www.comfyorg.cn/users/2354)
5 小时后 3  

[签到排行](https://www.comfyorg.cn/mission)

## 猜你喜欢

*   TOP1 ![Image 65: 清华团队开源SCAIL-2： 动作转移、分段队列换装、人物替换多角色+动物全支持](https://www.comfyorg.cn/wp-content/uploads/thumb/2026/06/fill_w100_h62_g0_mark_20260621142134698333.jpg) ## 清华团队开源SCAIL-2： 动作转移、分段队列换装、人物替换多角色+动物全支持

3 周前  [](https://www.comfyorg.cn/3497.html)
*   TOP2 ![Image 66: Krea2 Turbo模型：多风格生成工作流，人像效果足以撼动Z-Image人像王座的最新模型](https://www.comfyorg.cn/wp-content/uploads/thumb/2026/06/fill_w100_h62_g0_mark_20260629140138899269.png) ## Krea2 Turbo模型：多风格生成工作流，人像效果足以撼动Z-Image人像王座的最新模型

2 周前  [](https://www.comfyorg.cn/3502.html)
*   TOP3 ![Image 67: Bernini：全能Wan视频编辑与生成模型，AI视频编辑先理解再动手](https://www.comfyorg.cn/wp-content/uploads/thumb/2026/07/fill_w100_h62_g0_mark_20260705052219113732.jpg) ## Bernini：全能Wan视频编辑与生成模型，AI视频编辑先理解再动手

1 周前  [](https://www.comfyorg.cn/3521.html)
*   ![Image 68: 3步出图！最新图片编辑模型BooGu：Boogu-Image-0.1生图模型硬刚Qwen](https://www.comfyorg.cn/wp-content/themes/b2/Assets/fontend/images/default-img.jpg) ## 3步出图！最新图片编辑模型BooGu：Boogu-Image-0.1生图模型硬刚Qwen

3 天前  [](https://www.comfyorg.cn/3529.html)

×

![Image 69](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/logo.png)

使用邀请码，您将获得一份特殊的礼物！

请输入邀请码

[获取邀请码](https://www.comfyorg.cn/1180.html#)

**跳过**提交

**登录**

**可爱的昵称** **登录邮箱**
用作登录：字母或数字的组合，最少6位字符

用作登录

 **验证码****发送验证码** **密码** **重复新密码**
最少6位字符

 

快速登录

[忘记密码？](javascript:void(0))新用户？[注册](javascript:void(0))

社交登录:

## 请输入验证码

请输入图片中的验证码

点击发送按钮获取验证码

[取消](javascript:void(0))发送

![Image 70](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/logo.png)

×

搜索一下可能来得更快

搜索

×

## 公告

2026-6-10 0:00:19

[📢 ComfyUI资源网新功能上线公告](https://www.comfyorg.cn/announcement/704.html)

GPT-Image-2已上线ComfyUI资源网：文字渲染准确率99%+、原生4K、无损编辑、单次批量生成8张且角色一致，在线即可使用。

[前往查看详情](https://www.comfyorg.cn/announcement/704.html)

![Image 71](https://www.comfyorg.cn/1180.html)

×

取消 发送

×

![Image 72](https://www.comfyorg.cn/1180.html)

￥undefined

请打开手机使用 微信 扫码支付

「」

×

## ....支付确认中....

「」

×

支付金额

_￥_

请输入金额

 undefined 

×

 积分支付 

您当前的积分为 0

 您当前的积分不足，请 [购买积分](https://www.comfyorg.cn/gold/credit)

支付

检测到您未绑定微信账户，请先绑定微信

[立刻绑定](https://www.comfyorg.cn/1180.html)

[确定](javascript:void(0))

![Image 73](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/logo.png)

×

使用邀请码，您将获得一份特殊的礼物！

请输入邀请码

[获取邀请码](https://www.comfyorg.cn/1180.html#)

**跳过**提交

打开微信扫一扫

扫码并「关注我们的公众号」安全快捷登录

×

![Image 74](https://www.comfyorg.cn/1180.html)

为了确保您的账户安全

请您设置一个**登录用户名**和密码

**登录用户名**
请填写您的的登录用户名

 **验证码****发送验证码** **密码**
最少6位字符

 

提交

×

分享到：

微博 QQ好友 QQ空间

下载海报：

海报创建中

个人中心

购物车

优惠劵

今日签到

私信列表

搜索

客服

*   ![Image 75](blob:http://localhost/53424a1827e689a48e78c8de34cef38b)
扫码打开当前页

返回顶部

Copyright © 2026[ComfyUI资源网](https://www.comfyorg.cn/)

 本站已稳定运行：603 天 17 时 50 分 29 秒

 查询 85 次，耗时 0.1055 秒 

[**首页**](https://www.comfyorg.cn/)[**专题**](https://www.comfyorg.cn/collection)[**认证**](https://www.comfyorg.cn/verify)

[**搜索**](javascript:void(0))[**菜单**](javascript:void(0))[**我的**](javascript:void(0))

发布文章

创建圈子

发表话题

提交工单
