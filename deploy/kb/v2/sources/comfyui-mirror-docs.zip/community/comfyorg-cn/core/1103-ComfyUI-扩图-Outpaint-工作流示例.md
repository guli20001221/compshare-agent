---
title: ComfyUI 扩图（Outpaint）工作流示例
source_url: https://www.comfyorg.cn/1103.html
source_site: comfyorg.cn
captured_at: 2026-07-15T05:28:37.941697+00:00
category: community_core
fetch_method: jina_reader
---

Title: ComfyUI 扩图（Outpaint）工作流示例 - ComfyUI资源网

URL Source: https://www.comfyorg.cn/1103.html

Markdown Content:
[![Image 9](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/logo.png)](https://www.comfyorg.cn/)

*   [首页](https://www.comfyorg.cn/)
*   [🍂ComfyUI秋叶](https://www.comfyorg.cn/894.html)
*   [🔥满血整合包](https://www.comfyorg.cn/shop/1680.html)
*   [🎭应用广场](https://www.comfyorg.cn/shop)
*   [🍌AI绘画](https://www.comfyorg.cn/aidesign)

[文章](javascript:void(0))

[文章](javascript:void(0))[用户](javascript:void(0))[商铺](javascript:void(0))[文档](javascript:void(0))

[](https://www.comfyorg.cn/message)

登录 快速注册

[![Image 10](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/logo.png)](https://www.comfyorg.cn/)

*   [科技前沿](https://www.comfyorg.cn/kjqy)
    *   [![Image 11: 创新项目](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico1.png)创新项目 14篇](https://www.comfyorg.cn/kjqy/cxxm)
    *   [![Image 12: 办公软件](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico2.png)必备工具 11篇](https://www.comfyorg.cn/kjqy/bbgj)
    *   [![Image 13: 办公软件](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico2.png)办公软件 6篇](https://www.comfyorg.cn/kjqy/bruanjian)
    *   [![Image 14: API聚合](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/icon42.png)API聚合](https://api.oagi.com.cn/)

*   [常用模型](https://www.comfyorg.cn/cynx)
    *   [![Image 15: 主模型](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico3.png)主模型 36篇](https://www.comfyorg.cn/cynx/zmx)
    *   [![Image 16: 微调模型](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico4.png)微调模型 17篇](https://www.comfyorg.cn/cynx/lora)
    *   [![Image 17: Flux模型](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico5.png)Flux模型 20篇](https://www.comfyorg.cn/cynx/fluxmodel)
    *   [![Image 18: 加速模型](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico6.png)加速模型 14篇](https://www.comfyorg.cn/cynx/qrmx)
    *   [![Image 19: 控制模型](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico7.png)控制模型 24篇](https://www.comfyorg.cn/cynx/controlnet)
    *   [![Image 20: 增强模型](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico8.png)增强模型 34篇](https://www.comfyorg.cn/cynx/zqmx)
    *   [![Image 21: Wan模型](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico9.png)Wan模型 19篇](https://www.comfyorg.cn/cynx/wanmodel)
    *   [![Image 22: 关联模型](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico10.png)关联模型 18篇](https://www.comfyorg.cn/cynx/glmx)
    *   [![Image 23: 音视频模型](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico11.png)音视频模型 54篇](https://www.comfyorg.cn/cynx/scenemodel)
    *   [![Image 24: Qwen-image模型](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico12.png)Qwen-image模型 26篇](https://www.comfyorg.cn/cynx/qwenmodel)
    *   [![Image 25: 辅助模型](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico13.png)辅助模型 33篇](https://www.comfyorg.cn/cynx/fzmx)

*   [工作流](https://www.comfyorg.cn/workflow)
    *   [![Image 26: 基础工作流](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico14.png)基础工作流 57篇](https://www.comfyorg.cn/workflow/basic-workflow)
    *   [![Image 27: 模型排行榜](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico15.png)照片修复 38篇](https://www.comfyorg.cn/workflow/ai-repair)
    *   [![Image 28: 电商应用](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico16.png)电商应用 34篇](https://www.comfyorg.cn/workflow/ai-commerce)
    *   [![Image 29: Qwen-image](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico17.png)Qwen-image 29篇](https://www.comfyorg.cn/workflow/qwen-image)
    *   [![Image 30: 角色设计](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico18.png)角色设计 18篇](https://www.comfyorg.cn/workflow/ai-character)
    *   [![Image 31: 海报设计](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico19.png)海报设计 26篇](https://www.comfyorg.cn/workflow/ai-poster)
    *   [![Image 32: 风格转换](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico20.png)风格转换 17篇](https://www.comfyorg.cn/workflow/ai-stylistic)
    *   [![Image 33: ControlNet](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico21.png)Flux工作流 38篇](https://www.comfyorg.cn/workflow/ai-flux)
    *   [![Image 34: 音视频](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico22.png)音视频 60篇](https://www.comfyorg.cn/workflow/audio-video)
    *   [![Image 35: 人像摄影](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico23.png)人像摄影 29篇](https://www.comfyorg.cn/workflow/ai-photography)
    *   [![Image 36: 实用工具](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico24.png)实用工具 41篇](https://www.comfyorg.cn/workflow/utilities)
    *   [![Image 37: 高级工作流（商用）](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico25.png)高级工作流（商用） 11篇](https://www.comfyorg.cn/workflow/advanced-workflow)

*   [插件](https://www.comfyorg.cn/chajian)
    *   [![Image 38: 基础插件](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico30.png)基础插件 40篇](https://www.comfyorg.cn/chajian/basicplugins)
    *   [![Image 39: 提示词插件](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico31.png)提示词插件 11篇](https://www.comfyorg.cn/chajian/promptplugin)
    *   [![Image 40: ControlNet](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico21.png)ControlNet 11篇](https://www.comfyorg.cn/chajian/controlnetplug)
    *   [![Image 41: 图片插件](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico33.png)图片插件 35篇](https://www.comfyorg.cn/chajian/imgplug)
    *   [![Image 42: 视频插件](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico34.png)视频插件 42篇](https://www.comfyorg.cn/chajian/videoplug)
    *   [![Image 43: Flux插件](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico32.png)Flux插件 18篇](https://www.comfyorg.cn/chajian/fluxplugin)
    *   [![Image 44: 3D插件](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico35.png)3D插件 2篇](https://www.comfyorg.cn/chajian/3dplug)
    *   [![Image 45: 其他插件](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico36.png)其他插件 32篇](https://www.comfyorg.cn/chajian/otherplugins)

*   [自学课程](https://www.comfyorg.cn/tutorial)
    *   [![Image 46: 基础教程](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico26.png)基础教程 27篇](https://www.comfyorg.cn/tutorial/basic)
    *   [![Image 47: 进阶教程](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico27.png)进阶教程 27篇](https://www.comfyorg.cn/tutorial/advanced)
    *   [![Image 48: 高级教程](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico28.png)高级教程 8篇](https://www.comfyorg.cn/tutorial/gaoji)
    *   [![Image 49: 其他](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico29.png)其他 9篇](https://www.comfyorg.cn/tutorial/yqt)

*   [视频教程](https://www.comfyorg.cn/videojc)
*   [更多](https://www.comfyorg.cn/1103.html#)
    *   [![Image 50: 模型排行榜](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico15.png)站长运维 6篇](https://www.comfyorg.cn/kjqy/zzyw)
    *   [![Image 51: 模型排行榜](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico15.png)模型排行榜](https://www.comfyorg.cn/document/2371.html)
    *   [![Image 52: 疑难解答](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico41.png)疑难解答](https://www.comfyorg.cn/ask)

[投稿](javascript:void(0))

# ComfyUI 扩图（Outpaint）工作流示例

*   [基础教程](https://www.comfyorg.cn/tutorial/basic) 
*   1 年前
*   **23.4k**
*   **0**

[](https://www.comfyorg.cn/users/1)

![Image 53](https://www.comfyorg.cn/wp-content/uploads/thumb/2025/06/fill_w120_h120_g0_mark_20250612030820830302.png)

**ComfyUI教程**免费资源

关注 私信

本篇指南将带你了解 ComfyUI 中的扩图工作流，带你完成一个扩图的示例

 本篇将引导了解 AI 绘图中扩图的概念，并在 ComfyUI 中完成扩图工作流生成。我们将接触以下内容：

*   使用扩图工作流完成画面的扩展
*   了解并使用 ComfyUI 中的扩图相关节点
*   掌握扩图的基本操作流程

### 关于扩图

在 AI 图像生成过程中，我们经常会遇到这样的需求：已有的图片构图很好，但是画面范围太小，需要扩展画布来获得更大的场景，这时候就需要用到扩图功能。

这就像让画家(AI 绘图模型)在已有的画作基础上，向外延伸绘制更大的场景。我们需要告诉画家需要扩展的方向和范围，画家会根据已有的画面内容，合理地延伸和扩展场景。

基本上它要求的内容与[局部重绘](https://www.comfyorg.cn/1061.html)相似，只不过我们用来**构建遮罩（Mask）的节点不同**

扩图的应用场景包括：

*   **场景扩展：**扩大原有画面的场景范围，展现更完整的环境
*   **构图调整：**通过扩展画布来优化整体构图
*   **内容补充：**为原有画面添加更多相关的场景元素

### ComfyUI 扩图工作流示例讲解

**准备工作**

#### 1. 模型安装

请确保你已经在`ComfyUI/models/checkpoints`文件夹至少有一个 SD1.5 的模型文件，如果你还不了解如何安装模型，请参[开始 ComfyUI 的 AI 绘图之旅](https://www.comfyorg.cn/977.html)章节中关于模型安装的部分说明。

你可以使用下面的这些模型：

*   v1-5-pruned-emaonly-fp16.safetensors
*   Dreamshaper 8
*   Anything V5
*   512-inpainting-ema.safetensors

#### 2. 输入图片

请准备一张你想要进行扩展的图片。在本例中，我们将使用下面这张图片作为示例：

![Image 54: 3步出图！最新图片编辑模型BooGu：Boogu-Image-0.1生图模型硬刚Qwen](https://www.comfyorg.cn/wp-content/themes/b2/Assets/fontend/images/default-img.jpg)

#### 3. 扩图工作流

请下载下面的图片，并将其**拖入**ComfyUI 界面或使用菜单**工作流(Workflow)**—>**打开工作流(Open,快捷键`Ctrl + O`)**来加载这个扩图工作流

![Image 55: 3步出图！最新图片编辑模型BooGu：Boogu-Image-0.1生图模型硬刚Qwen](https://www.comfyorg.cn/wp-content/themes/b2/Assets/fontend/images/default-img.jpg)

### 扩图工作流使用讲解

![Image 56: 3步出图！最新图片编辑模型BooGu：Boogu-Image-0.1生图模型硬刚Qwen](https://www.comfyorg.cn/wp-content/themes/b2/Assets/fontend/images/default-img.jpg)

扩图工作流的关键步骤如下：

1.   请在`加载模型(Load Checkpoint)`节点中加载你本地安装的模型文件
2.   请在`加载图片(Load Image)`节点中点击`Upload`按钮上传
3.   点击`Queue`按钮，或者使用快捷键`Ctrl + Enter(回车)`来执行图片生成

在这个工作流中主要是通过`Pad Image for outpainting`节点来控制图片的扩展方向和范围，其实这也是一个[局部重绘(Inpaint)](https://www.comfyorg.cn/1061.html)工作流，只不过我们用来构建遮罩（Mask）的节点不同。

### Pad Image for outpainting 节点

![Image 57: 3步出图！最新图片编辑模型BooGu：Boogu-Image-0.1生图模型硬刚Qwen](https://www.comfyorg.cn/wp-content/themes/b2/Assets/fontend/images/default-img.jpg)

这个节点接受一个输入图片，并输出一张扩展过的图像和对应的遮罩（Mask），其中遮罩由于对应的节点参数构建。

#### 输入参数

| 参数名称 | 作用 |
| --- | --- |
| `image` | 输入图片 |
| `left` | 左侧填充量 |
| `top` | 顶部填充量 |
| `right` | 右侧填充量 |
| `bottom` | 底部填充量 |
| `feathering` | 控制原始图像与添加的填充内容之间的过渡平滑度，越大越平滑 |

#### 输出参数

| 参数名称 | 作用 |
| --- | --- |
| `image` | 输出`image`代表已填充的图像 |
| `mask` | 输出`mask`指示原始图像和添加的填充区域 |

#### 节点输出内容

经过`Pad Image for outpainting`节点处理后，输出的图片和蒙版预览如下：

![Image 58: 3步出图！最新图片编辑模型BooGu：Boogu-Image-0.1生图模型硬刚Qwen](https://www.comfyorg.cn/wp-content/themes/b2/Assets/fontend/images/default-img.jpg)

你可以看到对应的输出结果

*   `Image`输出的是扩展后的图像
*   `Mask`输出的是标记了扩展区域的蒙版

温馨提示：本站提供的一切软件、教程和内容信息都来自网络收集整理，仅限用于学习和研究目的；不得将上述内容用于商业或者非法用途，否则，一切后果请用户自负，版权争议与本站无关。在未征得本站同意时，禁止复制、盗用、采集、发布本站内容到任何网站、书籍等各类媒体平台。如若本站内容侵犯了原著者的合法权益，可联系我们进行处理。

按需赞赏，扩展网盘空间

给TA打赏

共0人

长期项目：下载网盘空间快满了，需要你的赞助！

**海报分享****收藏**

**0****0**

 0 条回复 **A**_文章作者_**M**_管理员_

在未征得本站同意时，禁止复制、盗用、采集、发布本站内容到任何网站、书籍等各类媒体平台。

您必须登录或注册以后才能发表评论

登录

![Image 59](https://www.comfyorg.cn/wp-content/themes/b2/Assets/fontend/images/default-avatar.png)

欢迎您，新朋友，感谢参与互动！

确认修改

细 中 粗

😁😊😎😤😥😂😍😏😙😟😖😜😱😲😭😚💀👻👍💪👊

取消回复 提交

暂无讨论，说说你的看法吧

/0 页 前往 

❮❯

## 关于作者 关注 私信

![Image 60](https://www.comfyorg.cn/wp-content/uploads/thumb/2025/06/fill_w192_h192_g0_mark_20250612030820830302.png)

[](https://www.comfyorg.cn/users/1)
ComfyUI教程

**博导**_lv7_**永久会员**

文章

291

评论

106

关注

0

粉丝

198

[[文章] 3步出图！最新图片编辑模型BooGu：Boogu-Image-0.1生图模型硬刚Qwen](https://www.comfyorg.cn/3529.html)

[[文章] Bernini：全能Wan视频编辑与生成模型，AI视频编辑先理解再动手](https://www.comfyorg.cn/3521.html)

[[文章] Krea2 Turbo模型：多风格生成工作流，人像效果足以撼动Z-Image人像王座的最新模型](https://www.comfyorg.cn/3502.html)

[[文章] 清华团队开源SCAIL-2： 动作转移、分段队列换装、人物替换多角色+动物全支持](https://www.comfyorg.cn/3497.html)

[Ta的全部动态](https://www.comfyorg.cn/tastream/1)

*   [](https://www.comfyorg.cn/1103.html#)[](https://www.comfyorg.cn/1103.html#)   
*   [](https://www.comfyorg.cn/1103.html#)[](https://www.comfyorg.cn/1103.html#)   
*   [](https://www.comfyorg.cn/1103.html#)[](https://www.comfyorg.cn/1103.html#)   
*   [](https://www.comfyorg.cn/1103.html#)[](https://www.comfyorg.cn/1103.html#)   
*   [](https://www.comfyorg.cn/1103.html#)[](https://www.comfyorg.cn/1103.html#)   
*   [](https://www.comfyorg.cn/1103.html#)[](https://www.comfyorg.cn/1103.html#)   

[签到排行](https://www.comfyorg.cn/mission)

点击领取今天的签到奖励！

今日签到

连续签到

*   [![Image 61](https://www.comfyorg.cn/wp-content/themes/b2/Assets/fontend/images/default-avatar.png)](https://www.comfyorg.cn/users/5043)[七千海里](https://www.comfyorg.cn/users/5043)
7 小时后 4  
*   [![Image 62](https://www.comfyorg.cn/wp-content/themes/b2/Assets/fontend/images/default-avatar.png)](https://www.comfyorg.cn/users/3695)[qiutian](https://www.comfyorg.cn/users/3695)
6 小时后 5  
*   [![Image 63](https://www.comfyorg.cn/wp-content/themes/b2/Assets/fontend/images/default-avatar.png)](https://www.comfyorg.cn/users/4027)[嫁衣神功](https://www.comfyorg.cn/users/4027)
6 小时后 4  
*   [![Image 64](https://www.comfyorg.cn/wp-content/themes/b2/Assets/fontend/images/default-avatar.png)](https://www.comfyorg.cn/users/4242)[辫子叔叔](https://www.comfyorg.cn/users/4242)
6 小时后 3  
*   [![Image 65](https://www.comfyorg.cn/wp-content/themes/b2/Assets/fontend/images/default-avatar.png)](https://www.comfyorg.cn/users/3548)[烈火](https://www.comfyorg.cn/users/3548)
5 小时后 5  
*   [![Image 66](https://www.comfyorg.cn/wp-content/themes/b2/Assets/fontend/images/default-avatar.png)](https://www.comfyorg.cn/users/2354)[歸去來兮](https://www.comfyorg.cn/users/2354)
5 小时后 3  

[签到排行](https://www.comfyorg.cn/mission)

## 猜你喜欢

*   TOP1 ![Image 67: 清华团队开源SCAIL-2： 动作转移、分段队列换装、人物替换多角色+动物全支持](https://www.comfyorg.cn/wp-content/uploads/thumb/2026/06/fill_w100_h62_g0_mark_20260621142134698333.jpg) ## 清华团队开源SCAIL-2： 动作转移、分段队列换装、人物替换多角色+动物全支持

3 周前  [](https://www.comfyorg.cn/3497.html)
*   TOP2 ![Image 68: Krea2 Turbo模型：多风格生成工作流，人像效果足以撼动Z-Image人像王座的最新模型](https://www.comfyorg.cn/wp-content/uploads/thumb/2026/06/fill_w100_h62_g0_mark_20260629140138899269.png) ## Krea2 Turbo模型：多风格生成工作流，人像效果足以撼动Z-Image人像王座的最新模型

2 周前  [](https://www.comfyorg.cn/3502.html)
*   TOP3 ![Image 69: Bernini：全能Wan视频编辑与生成模型，AI视频编辑先理解再动手](https://www.comfyorg.cn/wp-content/uploads/thumb/2026/07/fill_w100_h62_g0_mark_20260705052219113732.jpg) ## Bernini：全能Wan视频编辑与生成模型，AI视频编辑先理解再动手

1 周前  [](https://www.comfyorg.cn/3521.html)
*   ![Image 70: 3步出图！最新图片编辑模型BooGu：Boogu-Image-0.1生图模型硬刚Qwen](https://www.comfyorg.cn/wp-content/themes/b2/Assets/fontend/images/default-img.jpg) ## 3步出图！最新图片编辑模型BooGu：Boogu-Image-0.1生图模型硬刚Qwen

3 天前  [](https://www.comfyorg.cn/3529.html)

×

![Image 71](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/logo.png)

使用邀请码，您将获得一份特殊的礼物！

请输入邀请码

[获取邀请码](https://www.comfyorg.cn/1103.html#)

**跳过**提交

**登录**

**可爱的昵称** **登录邮箱**
用作登录：字母或数字的组合，最少6位字符

用作登录

 **验证码****发送验证码** **密码** **重复新密码**
最少6位字符

 

快速登录

[忘记密码？](javascript:void(0))新用户？[注册](javascript:void(0))

社交登录:

## 请输入验证码

请输入图片中的验证码

点击发送按钮获取验证码

[取消](javascript:void(0))发送

![Image 72](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/logo.png)

×

搜索一下可能来得更快

搜索

×

## 公告

2026-6-10 0:00:19

[📢 ComfyUI资源网新功能上线公告](https://www.comfyorg.cn/announcement/704.html)

GPT-Image-2已上线ComfyUI资源网：文字渲染准确率99%+、原生4K、无损编辑、单次批量生成8张且角色一致，在线即可使用。

[前往查看详情](https://www.comfyorg.cn/announcement/704.html)

![Image 73](https://www.comfyorg.cn/1103.html)

×

取消 发送

×

![Image 74](https://www.comfyorg.cn/1103.html)

￥undefined

请打开手机使用 微信 扫码支付

「」

×

## ....支付确认中....

「」

×

支付金额

_￥_

请输入金额

 undefined 

×

 积分支付 

您当前的积分为 0

 您当前的积分不足，请 [购买积分](https://www.comfyorg.cn/gold/credit)

支付

检测到您未绑定微信账户，请先绑定微信

[立刻绑定](https://www.comfyorg.cn/1103.html)

[确定](javascript:void(0))

![Image 75](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/logo.png)

×

使用邀请码，您将获得一份特殊的礼物！

请输入邀请码

[获取邀请码](https://www.comfyorg.cn/1103.html#)

**跳过**提交

打开微信扫一扫

扫码并「关注我们的公众号」安全快捷登录

×

![Image 76](https://www.comfyorg.cn/1103.html)

为了确保您的账户安全

请您设置一个**登录用户名**和密码

**登录用户名**
请填写您的的登录用户名

 **验证码****发送验证码** **密码**
最少6位字符

 

提交

×

分享到：

微博 QQ好友 QQ空间

下载海报：

海报创建中

个人中心

购物车

优惠劵

今日签到

私信列表

搜索

客服

*   ![Image 77](blob:http://localhost/1c49101e0bbde8f72f39c13ce7dbe5b2)
扫码打开当前页

返回顶部

Copyright © 2026[ComfyUI资源网](https://www.comfyorg.cn/)

 本站已稳定运行：603 天 17 时 52 分 53 秒

 查询 79 次，耗时 0.1020 秒 

[**首页**](https://www.comfyorg.cn/)[**专题**](https://www.comfyorg.cn/collection)[**认证**](https://www.comfyorg.cn/verify)

[**搜索**](javascript:void(0))[**菜单**](javascript:void(0))[**我的**](javascript:void(0))

发布文章

创建圈子

发表话题

提交工单
