---
title: Comfyui常见术语表
source_url: https://www.comfyorg.cn/1708.html
source_site: comfyorg.cn
captured_at: 2026-07-15T05:28:35.093893+00:00
category: community_core
fetch_method: jina_reader
---

Title: Comfyui常见术语表 - ComfyUI资源网

URL Source: https://www.comfyorg.cn/1708.html

Markdown Content:
[![Image 5](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/logo.png)](https://www.comfyorg.cn/)

*   [首页](https://www.comfyorg.cn/)
*   [🍂ComfyUI秋叶](https://www.comfyorg.cn/894.html)
*   [🔥满血整合包](https://www.comfyorg.cn/shop/1680.html)
*   [🎭应用广场](https://www.comfyorg.cn/shop)
*   [🍌AI绘画](https://www.comfyorg.cn/aidesign)

[文章](javascript:void(0))

[文章](javascript:void(0))[用户](javascript:void(0))[商铺](javascript:void(0))[文档](javascript:void(0))

[](https://www.comfyorg.cn/message)

登录 快速注册

[![Image 6](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/logo.png)](https://www.comfyorg.cn/)

*   [科技前沿](https://www.comfyorg.cn/kjqy)
    *   [![Image 7: 创新项目](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico1.png)创新项目 14篇](https://www.comfyorg.cn/kjqy/cxxm)
    *   [![Image 8: 办公软件](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico2.png)必备工具 11篇](https://www.comfyorg.cn/kjqy/bbgj)
    *   [![Image 9: 办公软件](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico2.png)办公软件 6篇](https://www.comfyorg.cn/kjqy/bruanjian)
    *   [![Image 10: API聚合](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/icon42.png)API聚合](https://api.oagi.com.cn/)

*   [常用模型](https://www.comfyorg.cn/cynx)
    *   [![Image 11: 主模型](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico3.png)主模型 36篇](https://www.comfyorg.cn/cynx/zmx)
    *   [![Image 12: 微调模型](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico4.png)微调模型 17篇](https://www.comfyorg.cn/cynx/lora)
    *   [![Image 13: Flux模型](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico5.png)Flux模型 20篇](https://www.comfyorg.cn/cynx/fluxmodel)
    *   [![Image 14: 加速模型](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico6.png)加速模型 14篇](https://www.comfyorg.cn/cynx/qrmx)
    *   [![Image 15: 控制模型](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico7.png)控制模型 24篇](https://www.comfyorg.cn/cynx/controlnet)
    *   [![Image 16: 增强模型](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico8.png)增强模型 34篇](https://www.comfyorg.cn/cynx/zqmx)
    *   [![Image 17: Wan模型](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico9.png)Wan模型 19篇](https://www.comfyorg.cn/cynx/wanmodel)
    *   [![Image 18: 关联模型](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico10.png)关联模型 18篇](https://www.comfyorg.cn/cynx/glmx)
    *   [![Image 19: 音视频模型](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico11.png)音视频模型 54篇](https://www.comfyorg.cn/cynx/scenemodel)
    *   [![Image 20: Qwen-image模型](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico12.png)Qwen-image模型 26篇](https://www.comfyorg.cn/cynx/qwenmodel)
    *   [![Image 21: 辅助模型](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico13.png)辅助模型 33篇](https://www.comfyorg.cn/cynx/fzmx)

*   [工作流](https://www.comfyorg.cn/workflow)
    *   [![Image 22: 基础工作流](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico14.png)基础工作流 57篇](https://www.comfyorg.cn/workflow/basic-workflow)
    *   [![Image 23: 模型排行榜](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico15.png)照片修复 38篇](https://www.comfyorg.cn/workflow/ai-repair)
    *   [![Image 24: 电商应用](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico16.png)电商应用 34篇](https://www.comfyorg.cn/workflow/ai-commerce)
    *   [![Image 25: Qwen-image](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico17.png)Qwen-image 29篇](https://www.comfyorg.cn/workflow/qwen-image)
    *   [![Image 26: 角色设计](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico18.png)角色设计 18篇](https://www.comfyorg.cn/workflow/ai-character)
    *   [![Image 27: 海报设计](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico19.png)海报设计 26篇](https://www.comfyorg.cn/workflow/ai-poster)
    *   [![Image 28: 风格转换](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico20.png)风格转换 17篇](https://www.comfyorg.cn/workflow/ai-stylistic)
    *   [![Image 29: ControlNet](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico21.png)Flux工作流 38篇](https://www.comfyorg.cn/workflow/ai-flux)
    *   [![Image 30: 音视频](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico22.png)音视频 60篇](https://www.comfyorg.cn/workflow/audio-video)
    *   [![Image 31: 人像摄影](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico23.png)人像摄影 29篇](https://www.comfyorg.cn/workflow/ai-photography)
    *   [![Image 32: 实用工具](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico24.png)实用工具 41篇](https://www.comfyorg.cn/workflow/utilities)
    *   [![Image 33: 高级工作流（商用）](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico25.png)高级工作流（商用） 11篇](https://www.comfyorg.cn/workflow/advanced-workflow)

*   [插件](https://www.comfyorg.cn/chajian)
    *   [![Image 34: 基础插件](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico30.png)基础插件 40篇](https://www.comfyorg.cn/chajian/basicplugins)
    *   [![Image 35: 提示词插件](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico31.png)提示词插件 11篇](https://www.comfyorg.cn/chajian/promptplugin)
    *   [![Image 36: ControlNet](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico21.png)ControlNet 11篇](https://www.comfyorg.cn/chajian/controlnetplug)
    *   [![Image 37: 图片插件](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico33.png)图片插件 35篇](https://www.comfyorg.cn/chajian/imgplug)
    *   [![Image 38: 视频插件](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico34.png)视频插件 42篇](https://www.comfyorg.cn/chajian/videoplug)
    *   [![Image 39: Flux插件](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico32.png)Flux插件 18篇](https://www.comfyorg.cn/chajian/fluxplugin)
    *   [![Image 40: 3D插件](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico35.png)3D插件 2篇](https://www.comfyorg.cn/chajian/3dplug)
    *   [![Image 41: 其他插件](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico36.png)其他插件 32篇](https://www.comfyorg.cn/chajian/otherplugins)

*   [自学课程](https://www.comfyorg.cn/tutorial)
    *   [![Image 42: 基础教程](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico26.png)基础教程 27篇](https://www.comfyorg.cn/tutorial/basic)
    *   [![Image 43: 进阶教程](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico27.png)进阶教程 27篇](https://www.comfyorg.cn/tutorial/advanced)
    *   [![Image 44: 高级教程](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico28.png)高级教程 8篇](https://www.comfyorg.cn/tutorial/gaoji)
    *   [![Image 45: 其他](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico29.png)其他 9篇](https://www.comfyorg.cn/tutorial/yqt)

*   [视频教程](https://www.comfyorg.cn/videojc)
*   [更多](https://www.comfyorg.cn/1708.html#)
    *   [![Image 46: 模型排行榜](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico15.png)站长运维 6篇](https://www.comfyorg.cn/kjqy/zzyw)
    *   [![Image 47: 模型排行榜](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico15.png)模型排行榜](https://www.comfyorg.cn/document/2371.html)
    *   [![Image 48: 疑难解答](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico41.png)疑难解答](https://www.comfyorg.cn/ask)

[投稿](javascript:void(0))

# Comfyui常见术语表

*   [基础教程](https://www.comfyorg.cn/tutorial/basic) 
*   1 年前
*   **34.7k**
*   **0**

[](https://www.comfyorg.cn/users/1)

![Image 49](https://www.comfyorg.cn/wp-content/uploads/thumb/2025/06/fill_w120_h120_g0_mark_20250612030820830302.png)

**ComfyUI教程**免费资源

关注 私信

## Load Checkpoint（加载模型）

**【Load Checkpoint】节点用于选择大模型。点击【ckpt_name】可以显示可用的模型列表。**

## CLIP Text Encode（CLIP 文本编码）

节点用于输入正向提示词和负向提示词。该节点获取提示词并将输入到 CLIP 语言模型中。CLIP 是 OpenAI 的语言模型，将提示词中的每个单词转换为 `embeddings`。

## diffusion model 扩散模型

扩散模型是一种生成模型，通过逐渐添加噪声到数据中，然后训练模型以去除噪声，从而生成数据。它在生成图像和其他类型的数据中显示出很强的能力。扩散模型的训练过程包括一个前向过程（添加噪声）和一个反向过程（去除噪声）。

![Image 50: Comfyui常见术语表](https://www.comfyorg.cn/wp-content/uploads/replace/8299c60777e592585a03f70b459c8b52.jpeg)

## denoise 降噪

降噪是指从带有噪声的图像或数据中恢复出清晰的信息。在扩散模型中，降噪指的是模型通过逐步减少噪声来恢复数据的过程，使生成的图像尽可能接近真实图像。

## Latent 潜像

潜像指的是在生成模型中，用于表示数据的隐含表示或特征。它是通过编码器将数据（例如图像）转换为一种低维的、抽象的表示，这种表示包含了数据的核心特征。

## Latent space 潜空间

潜空间是一个高维空间，用于表示数据的潜在特征。在生成模型中，数据首先被映射到潜空间中，然后通过解码器从潜空间中生成新数据。潜空间的特性使得模型能够生成各种复杂的数据样本。

## KSample（采样器）

【KSample】节点是 Stable Diffusion 中图像生成的核心。采样器将随机图像进行逐步降噪，来生成与提示词相匹配的图像。

【KSample】节点主要有以下参数：

*   seed（随机种子）：随机种子值控制清晰图像的初始噪声，从而控制最终图像的组成。
*   control_after_generate（生成后操作）：表示每次生成图片后，随机种子将如何变化。 
    *   fixed（固定）：保持种子不变；
    *   increment（增量）：增加`1`；
    *   decrement（减量）：减少`1`；
    *   randomize（随机）：随机值。

*   steps（采样步数）：采样步骤数。
*   cfg（提示词相关性）：CFG（Classifier Free Guidance）表示为无分类器信息引导规模。CFG 是控制稳定扩散应遵循文本提示的紧密程度的设置，即提示词相关性。
*   sampler_name（采样器名称）：用于选择采样器。
*   scheduler（调度程序）：控制噪声水平在每个步骤中如何变化。
*   denoise（降噪）：降噪过程应消除多少百分比的初始噪声。`1`表示全部。

## VAE

VAE（Variational Autoencoder）是一种生成模型，旨在通过编码器和解码器来学习数据的潜在表示。编码器将输入数据映射到潜空间，解码器则从潜空间中的潜像生成新的数据。VAE的目标是最大化数据的对数似然函数，同时最小化潜空间的分布与预设分布之间的差距。

温馨提示：本站提供的一切软件、教程和内容信息都来自网络收集整理，仅限用于学习和研究目的；不得将上述内容用于商业或者非法用途，否则，一切后果请用户自负，版权争议与本站无关。在未征得本站同意时，禁止复制、盗用、采集、发布本站内容到任何网站、书籍等各类媒体平台。如若本站内容侵犯了原著者的合法权益，可联系我们进行处理。

按需赞赏，扩展网盘空间

给TA打赏

共0人

长期项目：下载网盘空间快满了，需要你的赞助！

**海报分享****收藏**

**0****0**

 0 条回复 **A**_文章作者_**M**_管理员_

在未征得本站同意时，禁止复制、盗用、采集、发布本站内容到任何网站、书籍等各类媒体平台。

您必须登录或注册以后才能发表评论

登录

![Image 51](https://www.comfyorg.cn/wp-content/themes/b2/Assets/fontend/images/default-avatar.png)

欢迎您，新朋友，感谢参与互动！

确认修改

细 中 粗

😁😊😎😤😥😂😍😏😙😟😖😜😱😲😭😚💀👻👍💪👊

取消回复 提交

暂无讨论，说说你的看法吧

/0 页 前往 

❮❯

## 关于作者 关注 私信

![Image 52](https://www.comfyorg.cn/wp-content/uploads/thumb/2025/06/fill_w192_h192_g0_mark_20250612030820830302.png)

[](https://www.comfyorg.cn/users/1)
ComfyUI教程

**博导**_lv7_**永久会员**

文章

291

评论

106

关注

0

粉丝

198

[[文章] 3步出图！最新图片编辑模型BooGu：Boogu-Image-0.1生图模型硬刚Qwen](https://www.comfyorg.cn/3529.html)

[[文章] Bernini：全能Wan视频编辑与生成模型，AI视频编辑先理解再动手](https://www.comfyorg.cn/3521.html)

[[文章] Krea2 Turbo模型：多风格生成工作流，人像效果足以撼动Z-Image人像王座的最新模型](https://www.comfyorg.cn/3502.html)

[[文章] 清华团队开源SCAIL-2： 动作转移、分段队列换装、人物替换多角色+动物全支持](https://www.comfyorg.cn/3497.html)

[Ta的全部动态](https://www.comfyorg.cn/tastream/1)

*   [](https://www.comfyorg.cn/1708.html#)[](https://www.comfyorg.cn/1708.html#)   
*   [](https://www.comfyorg.cn/1708.html#)[](https://www.comfyorg.cn/1708.html#)   
*   [](https://www.comfyorg.cn/1708.html#)[](https://www.comfyorg.cn/1708.html#)   
*   [](https://www.comfyorg.cn/1708.html#)[](https://www.comfyorg.cn/1708.html#)   
*   [](https://www.comfyorg.cn/1708.html#)[](https://www.comfyorg.cn/1708.html#)   
*   [](https://www.comfyorg.cn/1708.html#)[](https://www.comfyorg.cn/1708.html#)   

[签到排行](https://www.comfyorg.cn/mission)

点击领取今天的签到奖励！

今日签到

连续签到

*   [![Image 53](https://www.comfyorg.cn/wp-content/themes/b2/Assets/fontend/images/default-avatar.png)](https://www.comfyorg.cn/users/5043)[七千海里](https://www.comfyorg.cn/users/5043)
7 小时后 4  
*   [![Image 54](https://www.comfyorg.cn/wp-content/themes/b2/Assets/fontend/images/default-avatar.png)](https://www.comfyorg.cn/users/3695)[qiutian](https://www.comfyorg.cn/users/3695)
6 小时后 5  
*   [![Image 55](https://www.comfyorg.cn/wp-content/themes/b2/Assets/fontend/images/default-avatar.png)](https://www.comfyorg.cn/users/4027)[嫁衣神功](https://www.comfyorg.cn/users/4027)
6 小时后 4  
*   [![Image 56](https://www.comfyorg.cn/wp-content/themes/b2/Assets/fontend/images/default-avatar.png)](https://www.comfyorg.cn/users/4242)[辫子叔叔](https://www.comfyorg.cn/users/4242)
6 小时后 3  
*   [![Image 57](https://www.comfyorg.cn/wp-content/themes/b2/Assets/fontend/images/default-avatar.png)](https://www.comfyorg.cn/users/3548)[烈火](https://www.comfyorg.cn/users/3548)
5 小时后 5  
*   [![Image 58](https://www.comfyorg.cn/wp-content/themes/b2/Assets/fontend/images/default-avatar.png)](https://www.comfyorg.cn/users/2354)[歸去來兮](https://www.comfyorg.cn/users/2354)
5 小时后 3  

[签到排行](https://www.comfyorg.cn/mission)

## 猜你喜欢

*   TOP1 ![Image 59: 清华团队开源SCAIL-2： 动作转移、分段队列换装、人物替换多角色+动物全支持](https://www.comfyorg.cn/wp-content/uploads/thumb/2026/06/fill_w100_h62_g0_mark_20260621142134698333.jpg) ## 清华团队开源SCAIL-2： 动作转移、分段队列换装、人物替换多角色+动物全支持

3 周前  [](https://www.comfyorg.cn/3497.html)
*   TOP2 ![Image 60: Krea2 Turbo模型：多风格生成工作流，人像效果足以撼动Z-Image人像王座的最新模型](https://www.comfyorg.cn/wp-content/uploads/thumb/2026/06/fill_w100_h62_g0_mark_20260629140138899269.png) ## Krea2 Turbo模型：多风格生成工作流，人像效果足以撼动Z-Image人像王座的最新模型

2 周前  [](https://www.comfyorg.cn/3502.html)
*   TOP3 ![Image 61: Bernini：全能Wan视频编辑与生成模型，AI视频编辑先理解再动手](https://www.comfyorg.cn/wp-content/uploads/thumb/2026/07/fill_w100_h62_g0_mark_20260705052219113732.jpg) ## Bernini：全能Wan视频编辑与生成模型，AI视频编辑先理解再动手

1 周前  [](https://www.comfyorg.cn/3521.html)
*   ![Image 62: 3步出图！最新图片编辑模型BooGu：Boogu-Image-0.1生图模型硬刚Qwen](https://www.comfyorg.cn/wp-content/themes/b2/Assets/fontend/images/default-img.jpg) ## 3步出图！最新图片编辑模型BooGu：Boogu-Image-0.1生图模型硬刚Qwen

3 天前  [](https://www.comfyorg.cn/3529.html)

×

![Image 63](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/logo.png)

使用邀请码，您将获得一份特殊的礼物！

请输入邀请码

[获取邀请码](https://www.comfyorg.cn/1708.html#)

**跳过**提交

**登录**

**可爱的昵称** **登录邮箱**
用作登录：字母或数字的组合，最少6位字符

用作登录

 **验证码****发送验证码** **密码** **重复新密码**
最少6位字符

 

快速登录

[忘记密码？](javascript:void(0))新用户？[注册](javascript:void(0))

社交登录:

## 请输入验证码

请输入图片中的验证码

点击发送按钮获取验证码

[取消](javascript:void(0))发送

![Image 64](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/logo.png)

×

搜索一下可能来得更快

搜索

×

## 公告

2026-6-10 0:00:19

[📢 ComfyUI资源网新功能上线公告](https://www.comfyorg.cn/announcement/704.html)

GPT-Image-2已上线ComfyUI资源网：文字渲染准确率99%+、原生4K、无损编辑、单次批量生成8张且角色一致，在线即可使用。

[前往查看详情](https://www.comfyorg.cn/announcement/704.html)

![Image 65](https://www.comfyorg.cn/1708.html)

×

取消 发送

×

![Image 66](https://www.comfyorg.cn/1708.html)

￥undefined

请打开手机使用 微信 扫码支付

「」

×

## ....支付确认中....

「」

×

支付金额

_￥_

请输入金额

 undefined 

×

 积分支付 

您当前的积分为 0

 您当前的积分不足，请 [购买积分](https://www.comfyorg.cn/gold/credit)

支付

检测到您未绑定微信账户，请先绑定微信

[立刻绑定](https://www.comfyorg.cn/1708.html)

[确定](javascript:void(0))

![Image 67](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/logo.png)

×

使用邀请码，您将获得一份特殊的礼物！

请输入邀请码

[获取邀请码](https://www.comfyorg.cn/1708.html#)

**跳过**提交

打开微信扫一扫

扫码并「关注我们的公众号」安全快捷登录

×

![Image 68](https://www.comfyorg.cn/1708.html)

为了确保您的账户安全

请您设置一个**登录用户名**和密码

**登录用户名**
请填写您的的登录用户名

 **验证码****发送验证码** **密码**
最少6位字符

 

提交

×

分享到：

微博 QQ好友 QQ空间

下载海报：

海报创建中

个人中心

购物车

优惠劵

今日签到

私信列表

搜索

客服

*   ![Image 69](blob:http://localhost/85dbd8b56f2370c300c8b7463a2fb669)
扫码打开当前页

返回顶部

Copyright © 2026[ComfyUI资源网](https://www.comfyorg.cn/)

 本站已稳定运行：603 天 17 时 52 分 22 秒

 查询 79 次，耗时 0.1001 秒 

[**首页**](https://www.comfyorg.cn/)[**专题**](https://www.comfyorg.cn/collection)[**认证**](https://www.comfyorg.cn/verify)

[**搜索**](javascript:void(0))[**菜单**](javascript:void(0))[**我的**](javascript:void(0))

发布文章

创建圈子

发表话题

提交工单
