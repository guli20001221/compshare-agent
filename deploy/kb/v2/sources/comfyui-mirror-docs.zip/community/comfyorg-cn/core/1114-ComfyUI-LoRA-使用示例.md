---
title: ComfyUI LoRA 使用示例
source_url: https://www.comfyorg.cn/1114.html
source_site: comfyorg.cn
captured_at: 2026-07-15T05:28:39.221675+00:00
category: community_core
fetch_method: jina_reader
---

Title: ComfyUI LoRA 使用示例 - ComfyUI资源网

URL Source: https://www.comfyorg.cn/1114.html

Markdown Content:
[![Image 9](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/logo.png)](https://www.comfyorg.cn/)

*   [首页](https://www.comfyorg.cn/)
*   [🍂ComfyUI秋叶](https://www.comfyorg.cn/894.html)
*   [🔥满血整合包](https://www.comfyorg.cn/shop/1680.html)
*   [🎭应用广场](https://www.comfyorg.cn/shop)
*   [🍌AI绘画](https://www.comfyorg.cn/aidesign)

[文章](javascript:void(0))

[文章](javascript:void(0))[用户](javascript:void(0))[商铺](javascript:void(0))[文档](javascript:void(0))

[](https://www.comfyorg.cn/message)

登录 快速注册

[![Image 10](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/logo.png)](https://www.comfyorg.cn/)

*   [科技前沿](https://www.comfyorg.cn/kjqy)
    *   [![Image 11: 创新项目](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico1.png)创新项目 14篇](https://www.comfyorg.cn/kjqy/cxxm)
    *   [![Image 12: 办公软件](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico2.png)必备工具 11篇](https://www.comfyorg.cn/kjqy/bbgj)
    *   [![Image 13: 办公软件](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico2.png)办公软件 6篇](https://www.comfyorg.cn/kjqy/bruanjian)
    *   [![Image 14: API聚合](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/icon42.png)API聚合](https://api.oagi.com.cn/)

*   [常用模型](https://www.comfyorg.cn/cynx)
    *   [![Image 15: 主模型](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico3.png)主模型 36篇](https://www.comfyorg.cn/cynx/zmx)
    *   [![Image 16: 微调模型](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico4.png)微调模型 17篇](https://www.comfyorg.cn/cynx/lora)
    *   [![Image 17: Flux模型](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico5.png)Flux模型 20篇](https://www.comfyorg.cn/cynx/fluxmodel)
    *   [![Image 18: 加速模型](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico6.png)加速模型 14篇](https://www.comfyorg.cn/cynx/qrmx)
    *   [![Image 19: 控制模型](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico7.png)控制模型 24篇](https://www.comfyorg.cn/cynx/controlnet)
    *   [![Image 20: 增强模型](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico8.png)增强模型 34篇](https://www.comfyorg.cn/cynx/zqmx)
    *   [![Image 21: Wan模型](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico9.png)Wan模型 19篇](https://www.comfyorg.cn/cynx/wanmodel)
    *   [![Image 22: 关联模型](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico10.png)关联模型 18篇](https://www.comfyorg.cn/cynx/glmx)
    *   [![Image 23: 音视频模型](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico11.png)音视频模型 54篇](https://www.comfyorg.cn/cynx/scenemodel)
    *   [![Image 24: Qwen-image模型](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico12.png)Qwen-image模型 26篇](https://www.comfyorg.cn/cynx/qwenmodel)
    *   [![Image 25: 辅助模型](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico13.png)辅助模型 33篇](https://www.comfyorg.cn/cynx/fzmx)

*   [工作流](https://www.comfyorg.cn/workflow)
    *   [![Image 26: 基础工作流](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico14.png)基础工作流 57篇](https://www.comfyorg.cn/workflow/basic-workflow)
    *   [![Image 27: 模型排行榜](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico15.png)照片修复 38篇](https://www.comfyorg.cn/workflow/ai-repair)
    *   [![Image 28: 电商应用](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico16.png)电商应用 34篇](https://www.comfyorg.cn/workflow/ai-commerce)
    *   [![Image 29: Qwen-image](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico17.png)Qwen-image 29篇](https://www.comfyorg.cn/workflow/qwen-image)
    *   [![Image 30: 角色设计](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico18.png)角色设计 18篇](https://www.comfyorg.cn/workflow/ai-character)
    *   [![Image 31: 海报设计](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico19.png)海报设计 26篇](https://www.comfyorg.cn/workflow/ai-poster)
    *   [![Image 32: 风格转换](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico20.png)风格转换 17篇](https://www.comfyorg.cn/workflow/ai-stylistic)
    *   [![Image 33: ControlNet](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico21.png)Flux工作流 38篇](https://www.comfyorg.cn/workflow/ai-flux)
    *   [![Image 34: 音视频](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico22.png)音视频 60篇](https://www.comfyorg.cn/workflow/audio-video)
    *   [![Image 35: 人像摄影](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico23.png)人像摄影 29篇](https://www.comfyorg.cn/workflow/ai-photography)
    *   [![Image 36: 实用工具](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico24.png)实用工具 41篇](https://www.comfyorg.cn/workflow/utilities)
    *   [![Image 37: 高级工作流（商用）](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico25.png)高级工作流（商用） 11篇](https://www.comfyorg.cn/workflow/advanced-workflow)

*   [插件](https://www.comfyorg.cn/chajian)
    *   [![Image 38: 基础插件](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico30.png)基础插件 40篇](https://www.comfyorg.cn/chajian/basicplugins)
    *   [![Image 39: 提示词插件](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico31.png)提示词插件 11篇](https://www.comfyorg.cn/chajian/promptplugin)
    *   [![Image 40: ControlNet](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico21.png)ControlNet 11篇](https://www.comfyorg.cn/chajian/controlnetplug)
    *   [![Image 41: 图片插件](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico33.png)图片插件 35篇](https://www.comfyorg.cn/chajian/imgplug)
    *   [![Image 42: 视频插件](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico34.png)视频插件 42篇](https://www.comfyorg.cn/chajian/videoplug)
    *   [![Image 43: Flux插件](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico32.png)Flux插件 18篇](https://www.comfyorg.cn/chajian/fluxplugin)
    *   [![Image 44: 3D插件](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico35.png)3D插件 2篇](https://www.comfyorg.cn/chajian/3dplug)
    *   [![Image 45: 其他插件](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico36.png)其他插件 32篇](https://www.comfyorg.cn/chajian/otherplugins)

*   [自学课程](https://www.comfyorg.cn/tutorial)
    *   [![Image 46: 基础教程](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico26.png)基础教程 27篇](https://www.comfyorg.cn/tutorial/basic)
    *   [![Image 47: 进阶教程](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico27.png)进阶教程 27篇](https://www.comfyorg.cn/tutorial/advanced)
    *   [![Image 48: 高级教程](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico28.png)高级教程 8篇](https://www.comfyorg.cn/tutorial/gaoji)
    *   [![Image 49: 其他](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico29.png)其他 9篇](https://www.comfyorg.cn/tutorial/yqt)

*   [视频教程](https://www.comfyorg.cn/videojc)
*   [更多](https://www.comfyorg.cn/1114.html#)
    *   [![Image 50: 模型排行榜](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico15.png)站长运维 6篇](https://www.comfyorg.cn/kjqy/zzyw)
    *   [![Image 51: 模型排行榜](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico15.png)模型排行榜](https://www.comfyorg.cn/document/2371.html)
    *   [![Image 52: 疑难解答](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico41.png)疑难解答](https://www.comfyorg.cn/ask)

[投稿](javascript:void(0))

# ComfyUI LoRA 使用示例

*   [基础教程](https://www.comfyorg.cn/tutorial/basic) 
*   1 年前
*   **23.8k**
*   **0**

[](https://www.comfyorg.cn/users/1)

![Image 53](https://www.comfyorg.cn/wp-content/uploads/thumb/2025/06/fill_w120_h120_g0_mark_20250612030820830302.png)

**ComfyUI教程**免费资源

关注 私信

本篇将引导了解并完成单个 LoRA 模型的使用

**LoRA 模型（Low-Rank Adaptation）**是一种用于微调大型生成模型（如 Stable Diffusion）的高效技术。 它通过在预训练模型的基础上引入可训练的低秩矩阵，仅调整部分参数，而非重新训练整个模型，从而以较低的计算成本实现特定任务的优化，相对于类似 SD1.5 这样的大模型，LoRA 模型更小，更容易训练。

![Image 54: ComfyUI LoRA 使用示例](https://www.comfyorg.cn/wp-content/uploads/replace/e494b055e266aebc700c49f4242c8a1c.png)

上面的图片对比了同样参数下dreamshaper_8直接生成和使用blindbox_V1MixLoRA 模型生成的图片对比，我们可以看到通过使用 LoRA 模型，可以在不调整基础模型的情况下，生成更符合我们需求的图片。

我们将演示如何使用 LoRA 的示例。所有 LoRA 变体：Lycoris, loha, lokr, locon, 等… 都是以这种方式使用。

在本示例中，我们将完成以下内容来学习[ComfyUI](https://www.comfyorg.cn/894.html)中加载并使用 LoRA 模型，将涉及以下内容：

1.   安装 LoRA 模型
2.   使用 LoRA 模型生成图片
3.   `Load LoRA`节点的简单介绍

请下载dreamshaper_8.safetensors并保存至`ComfyUI/models/checkpoints`目录

请下载blindbox_V1Mix.safetensors并保存至`ComfyUI/models/loras`目录

请下载下面的工作流图片,并拖入 ComfyUI 以加载工作流

![Image 55: ComfyUI LoRA 使用示例](https://www.comfyorg.cn/wp-content/uploads/replace/4e18b827299ce011c93684c0a2bfd78c.png)

Metadata 中包含工作流 json 的图片可直接拖入 ComfyUI 或使用菜单`Workflows`->`Open（ctrl+o）`来加载对应的工作流。

请参照下图步骤，来确保对应的工作流可以正常运行

![Image 56: 3步出图！最新图片编辑模型BooGu：Boogu-Image-0.1生图模型硬刚Qwen](https://www.comfyorg.cn/wp-content/themes/b2/Assets/fontend/images/default-img.jpg)

1.   确保`Load Checkpoint`加载了`dreamshaper_8.safetensors`
2.   确保`Load LoRA`加载了`blindbox_V1Mix.safetensors`
3.   点击`Queue`按钮，或者使用快捷键`Ctrl(cmd) + Enter(回车)`来执行图片的生成

![Image 57: 3步出图！最新图片编辑模型BooGu：Boogu-Image-0.1生图模型硬刚Qwen](https://www.comfyorg.cn/wp-content/themes/b2/Assets/fontend/images/default-img.jpg)

位于`ComfyUImodelsloras`的模型会被 ComfyUI 检测到，并在这个节点中加载

| 参数名称 | 作用 |
| --- | --- |
| model | 连接基础模型 |
| clip | 连接 CLIP 模型 |
| lora_name | 选择要加载使用的 LoRA 模型 |
| strength_model | 影响 LoRA 对 模型权重（model）的影响程度，数值越大 LoRA 风格越强 |
| strength_clip | 影响 LoRA 对 CLIP 词嵌入（clip）的影响程度 |

| 参数名称 | 作用 |
| --- | --- |
| model | 输出应用了 LoRA 调整的模型 |
| clip | 输出应用了 LoRA 调整的 CLIP 模型 |

该节点支持链式连接，可以将多个Load LoRA节点串联来应用多个 LoRA 模型，具体请参考ComfyUI 应用多个 LoRA 示例

![Image 58: 3步出图！最新图片编辑模型BooGu：Boogu-Image-0.1生图模型硬刚Qwen](https://www.comfyorg.cn/wp-content/themes/b2/Assets/fontend/images/default-img.jpg)

1.   试着修改提示词，或者调整`Load LoRA`节点的不同参数，比如`strength_model`，来观察生成图片的变化，熟悉对应节点。
2.   访问网站[www.comfyorg.cn](https://www.comfyorg.cn/)，下载其它风格的 LoRA 模型，尝试使用。

温馨提示：本站提供的一切软件、教程和内容信息都来自网络收集整理，仅限用于学习和研究目的；不得将上述内容用于商业或者非法用途，否则，一切后果请用户自负，版权争议与本站无关。在未征得本站同意时，禁止复制、盗用、采集、发布本站内容到任何网站、书籍等各类媒体平台。如若本站内容侵犯了原著者的合法权益，可联系我们进行处理。

按需赞赏，扩展网盘空间

给TA打赏

共0人

长期项目：下载网盘空间快满了，需要你的赞助！

**海报分享****收藏**

**0****0**

 0 条回复 **A**_文章作者_**M**_管理员_

签到和评论活跃账户，均可获得积分免费下载此资源！ 

您必须登录或注册以后才能发表评论

登录

![Image 59](https://www.comfyorg.cn/wp-content/themes/b2/Assets/fontend/images/default-avatar.png)

欢迎您，新朋友，感谢参与互动！

确认修改

细 中 粗

😁😊😎😤😥😂😍😏😙😟😖😜😱😲😭😚💀👻👍💪👊

取消回复 提交

暂无讨论，说说你的看法吧

/0 页 前往 

❮❯

## 关于作者 关注 私信

![Image 60](https://www.comfyorg.cn/wp-content/uploads/thumb/2025/06/fill_w192_h192_g0_mark_20250612030820830302.png)

[](https://www.comfyorg.cn/users/1)
ComfyUI教程

**博导**_lv7_**永久会员**

文章

291

评论

106

关注

0

粉丝

198

[[文章] 3步出图！最新图片编辑模型BooGu：Boogu-Image-0.1生图模型硬刚Qwen](https://www.comfyorg.cn/3529.html)

[[文章] Bernini：全能Wan视频编辑与生成模型，AI视频编辑先理解再动手](https://www.comfyorg.cn/3521.html)

[[文章] Krea2 Turbo模型：多风格生成工作流，人像效果足以撼动Z-Image人像王座的最新模型](https://www.comfyorg.cn/3502.html)

[[文章] 清华团队开源SCAIL-2： 动作转移、分段队列换装、人物替换多角色+动物全支持](https://www.comfyorg.cn/3497.html)

[Ta的全部动态](https://www.comfyorg.cn/tastream/1)

*   [](https://www.comfyorg.cn/1114.html#)[](https://www.comfyorg.cn/1114.html#)   
*   [](https://www.comfyorg.cn/1114.html#)[](https://www.comfyorg.cn/1114.html#)   
*   [](https://www.comfyorg.cn/1114.html#)[](https://www.comfyorg.cn/1114.html#)   
*   [](https://www.comfyorg.cn/1114.html#)[](https://www.comfyorg.cn/1114.html#)   
*   [](https://www.comfyorg.cn/1114.html#)[](https://www.comfyorg.cn/1114.html#)   
*   [](https://www.comfyorg.cn/1114.html#)[](https://www.comfyorg.cn/1114.html#)   

[签到排行](https://www.comfyorg.cn/mission)

点击领取今天的签到奖励！

今日签到

连续签到

*   [![Image 61](https://www.comfyorg.cn/wp-content/themes/b2/Assets/fontend/images/default-avatar.png)](https://www.comfyorg.cn/users/5043)[七千海里](https://www.comfyorg.cn/users/5043)
7 小时后 4  
*   [![Image 62](https://www.comfyorg.cn/wp-content/themes/b2/Assets/fontend/images/default-avatar.png)](https://www.comfyorg.cn/users/3695)[qiutian](https://www.comfyorg.cn/users/3695)
6 小时后 5  
*   [![Image 63](https://www.comfyorg.cn/wp-content/themes/b2/Assets/fontend/images/default-avatar.png)](https://www.comfyorg.cn/users/4027)[嫁衣神功](https://www.comfyorg.cn/users/4027)
6 小时后 4  
*   [![Image 64](https://www.comfyorg.cn/wp-content/themes/b2/Assets/fontend/images/default-avatar.png)](https://www.comfyorg.cn/users/4242)[辫子叔叔](https://www.comfyorg.cn/users/4242)
6 小时后 3  
*   [![Image 65](https://www.comfyorg.cn/wp-content/themes/b2/Assets/fontend/images/default-avatar.png)](https://www.comfyorg.cn/users/3548)[烈火](https://www.comfyorg.cn/users/3548)
5 小时后 5  
*   [![Image 66](https://www.comfyorg.cn/wp-content/themes/b2/Assets/fontend/images/default-avatar.png)](https://www.comfyorg.cn/users/2354)[歸去來兮](https://www.comfyorg.cn/users/2354)
5 小时后 3  

[签到排行](https://www.comfyorg.cn/mission)

## 猜你喜欢

*   TOP1 ![Image 67: 清华团队开源SCAIL-2： 动作转移、分段队列换装、人物替换多角色+动物全支持](https://www.comfyorg.cn/wp-content/uploads/thumb/2026/06/fill_w100_h62_g0_mark_20260621142134698333.jpg) ## 清华团队开源SCAIL-2： 动作转移、分段队列换装、人物替换多角色+动物全支持

3 周前  [](https://www.comfyorg.cn/3497.html)
*   TOP2 ![Image 68: Krea2 Turbo模型：多风格生成工作流，人像效果足以撼动Z-Image人像王座的最新模型](https://www.comfyorg.cn/wp-content/uploads/thumb/2026/06/fill_w100_h62_g0_mark_20260629140138899269.png) ## Krea2 Turbo模型：多风格生成工作流，人像效果足以撼动Z-Image人像王座的最新模型

2 周前  [](https://www.comfyorg.cn/3502.html)
*   TOP3 ![Image 69: Bernini：全能Wan视频编辑与生成模型，AI视频编辑先理解再动手](https://www.comfyorg.cn/wp-content/uploads/thumb/2026/07/fill_w100_h62_g0_mark_20260705052219113732.jpg) ## Bernini：全能Wan视频编辑与生成模型，AI视频编辑先理解再动手

1 周前  [](https://www.comfyorg.cn/3521.html)
*   ![Image 70: 3步出图！最新图片编辑模型BooGu：Boogu-Image-0.1生图模型硬刚Qwen](https://www.comfyorg.cn/wp-content/themes/b2/Assets/fontend/images/default-img.jpg) ## 3步出图！最新图片编辑模型BooGu：Boogu-Image-0.1生图模型硬刚Qwen

3 天前  [](https://www.comfyorg.cn/3529.html)

×

![Image 71](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/logo.png)

使用邀请码，您将获得一份特殊的礼物！

请输入邀请码

[获取邀请码](https://www.comfyorg.cn/1114.html#)

**跳过**提交

**登录**

**可爱的昵称** **登录邮箱**
用作登录：字母或数字的组合，最少6位字符

用作登录

 **验证码****发送验证码** **密码** **重复新密码**
最少6位字符

 

快速登录

[忘记密码？](javascript:void(0))新用户？[注册](javascript:void(0))

社交登录:

## 请输入验证码

请输入图片中的验证码

点击发送按钮获取验证码

[取消](javascript:void(0))发送

![Image 72](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/logo.png)

×

搜索一下可能来得更快

搜索

×

## 公告

2026-6-10 0:00:19

[📢 ComfyUI资源网新功能上线公告](https://www.comfyorg.cn/announcement/704.html)

GPT-Image-2已上线ComfyUI资源网：文字渲染准确率99%+、原生4K、无损编辑、单次批量生成8张且角色一致，在线即可使用。

[前往查看详情](https://www.comfyorg.cn/announcement/704.html)

![Image 73](https://www.comfyorg.cn/1114.html)

×

取消 发送

×

![Image 74](https://www.comfyorg.cn/1114.html)

￥undefined

请打开手机使用 微信 扫码支付

「」

×

## ....支付确认中....

「」

×

支付金额

_￥_

请输入金额

 undefined 

×

 积分支付 

您当前的积分为 0

 您当前的积分不足，请 [购买积分](https://www.comfyorg.cn/gold/credit)

支付

检测到您未绑定微信账户，请先绑定微信

[立刻绑定](https://www.comfyorg.cn/1114.html)

[确定](javascript:void(0))

![Image 75](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/logo.png)

×

使用邀请码，您将获得一份特殊的礼物！

请输入邀请码

[获取邀请码](https://www.comfyorg.cn/1114.html#)

**跳过**提交

打开微信扫一扫

扫码并「关注我们的公众号」安全快捷登录

×

![Image 76](https://www.comfyorg.cn/1114.html)

为了确保您的账户安全

请您设置一个**登录用户名**和密码

**登录用户名**
请填写您的的登录用户名

 **验证码****发送验证码** **密码**
最少6位字符

 

提交

×

分享到：

微博 QQ好友 QQ空间

下载海报：

海报创建中

个人中心

购物车

优惠劵

今日签到

私信列表

搜索

客服

*   ![Image 77](blob:http://localhost/6fc44d7f4e6a993b51500ae1490a1079)
扫码打开当前页

返回顶部

Copyright © 2026[ComfyUI资源网](https://www.comfyorg.cn/)

 本站已稳定运行：603 天 17 时 52 分 45 秒

 查询 78 次，耗时 0.1150 秒 

[**首页**](https://www.comfyorg.cn/)[**专题**](https://www.comfyorg.cn/collection)[**认证**](https://www.comfyorg.cn/verify)

[**搜索**](javascript:void(0))[**菜单**](javascript:void(0))[**我的**](javascript:void(0))

发布文章

创建圈子

发表话题

提交工单
