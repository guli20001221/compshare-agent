---
title: Comfyui实用基础工作流教程合集
source_url: https://www.comfyorg.cn/1632.html
source_site: comfyorg.cn
captured_at: 2026-07-15T05:28:36.847998+00:00
category: community_core
fetch_method: jina_reader
---

Title: Comfyui实用基础工作流教程合集 - ComfyUI资源网

URL Source: https://www.comfyorg.cn/1632.html

Markdown Content:
## 01.文生图

ComfyUI的默认界面是最基本的SD1.5文生图工作流。工作流程由节点和线组成，节点是矩形块，用于执行某种任务，线是连接节点之间的输入和输出的线。

![Image 1: Comfyui实用基础工作流教程合集](https://www.comfyorg.cn/wp-content/uploads/replace/5499a083206c1f114d059215d508b6d6.png)

默认生成的基础文生图

在“空Latent”节点中设置图片尺寸。

在“K采样器”节点中设置采样器、步数、CFG、降噪等参数。

点击“执行队列”运行工作流程，运行完毕后，你会看到生成的第一张图片。

## 02.图生图

*   **文生图**是通过输入一段描述性文字来生成图像。用户通过文本描述来指导AI生成符合预期的图片，可以控制画面的风格、内容和构图，适用于各种风格和载体的图像生成。
*   **图生图**则是通过上传一张基础图像，AI根据提示词进行加工，生成一张混合了原始图像和文本描述的新图像。这种方法在保留原始图像结构的基础上，可以融入新的风格或变化

图生图与文生图基本一样，文生图是给**潜空间图**一个空的latent,用来定义生成图片的大小。而图生图则是需要给到潜空间一张图片做参考，而图片无法直接给到潜空间，这时就需要在中间加个VAE编码了。

![Image 2: Comfyui实用基础工作流教程合集](https://www.comfyorg.cn/wp-content/uploads/replace/da0ca8032b2f37eb47232fca26ae9fb4.jpeg)

K采样中降噪越大，重绘幅度越大

文生图是通过latent来定义生成图片的大小，而图生图则是通过加载图像的系数来生成。有时加载的图像可能会过大或过小，这时我们就可以在中间加个缩放图像大小节点来控制。

![Image 3: Comfyui实用基础工作流教程合集](https://www.comfyorg.cn/wp-content/uploads/replace/61ef219c93bdb348d689b17b7bf000c7.jpeg)

需要注意图像比例，要不就会被拉伸

## 03.局部重绘

1.   `标准局部重绘就是在图生图的基础上增加一个遮罩；让重绘只对遮罩部分生效，有点像PS的蒙板`

右键单击图片，在菜单中选择“在遮罩编辑器中打开”，在图片上使用画笔涂抹要修复的区域，使用鼠标滚轮控制画笔大小，按住ALT键可以擦除涂抹的区域。

![Image 4: Comfyui实用基础工作流教程合集](https://www.comfyorg.cn/wp-content/uploads/replace/1f8a170c971b6cf8ea4bc7b54d58d7cc.jpeg)

在编码与K采样中间加一个遮罩节点

![Image 5: Comfyui实用基础工作流教程合集](https://www.comfyorg.cn/wp-content/uploads/replace/1d4d54645ec7472690d4ac8eb2a36979.jpeg)

你可以在K采样器节点中调整重绘强度，但是设置得太高可能会导致图像不连贯。

点击“执行队列”开始生成修复的图片。

此工作流程适用于低重绘强度，如果必须使用高重绘强度，则需要使用接下来的工作流程。

![Image 6: Comfyui实用基础工作流教程合集](https://www.comfyorg.cn/wp-content/uploads/replace/631dc4c4c91a725f2ab95d641472efe7.jpeg)

所以，局部重绘就是想办法选择出要重绘的部分，标准的方法就是在遮罩编辑器中打开进行涂抹。这个方法不够精准，所以就有了用其它插件的方法。比如：语义分割segment、直接上传遮罩、

## 04.局部重绘工作流

上面讲到用涂抹遮罩的局部重绘的方法，下面就来讲讲语义分割segment当遮罩选取的方法

通过segment anything和BrushNet插件，让产品与背景有很好的融合交互效果。

工作流下载：

## 产品更换背景工作流

提取码：`yu7f`复制

解压码：`无`复制

**1.安装插件**

插件安装地址

BrushNet：[https://github.com/nullquant/ComfyUI-BrushNet](https://www.comfyorg.cn/url?url=aHR0cHM6Ly9naXRodWIuY29tL251bGxxdWFudC9Db21meVVJLUJydXNoTmV0)

segment anything：[https://github.com/storyicon/comfyui_segment_anything](https://www.comfyorg.cn/url?url=aHR0cHM6Ly9naXRodWIuY29tL3N0b3J5aWNvbi9jb21meXVpX3NlZ21lbnRfYW55dGhpbmc=)

直接产品管理器里搜索并安装

![Image 7: Comfyui实用基础工作流教程合集](https://www.comfyorg.cn/wp-content/uploads/replace/761da24ba0225182fbd4247bf5db9317.png)

**segment anything语义分割，在这里的作用就是抠图使用。**

**_它需要用到模型：如果目录里没有，就自己建个文件夹_**

1.   `01.bert-base-uncased`
2.   `下载：config.json`
3.   `model.safetensors`
4.   `tokenizer_config.json`
5.   `tokenizer.json`
6.   `vocab.txt`
7.   `模型到models/bert-base-uncased里面；`
8.   `地址：https://huggingface.co/google-bert/bert-base-uncased/tree/main`

10.   `02.SAM的三个模型：放到comfyui根目录modelssams里面；`
11.   `03.GroundingDINO模型:放到comfyui根目录modelsgrounding-dino里面；`
12.   `地址：https://github.com/storyicon/comfyui_segment_anything?tab=readme-ov-file`

**BrushNet：对抠出来的蒙版区域进行重绘。**

1.   `brushnet模型:放到comfyui根目录/models/inpaint`

这些模型系统会在使用时自动下载，但速度比较慢，可以去以下地址下载：

## 产品更换背景工作流

提取码：`yu7f`复制

解压码：`无`复制

### Segment anything

1.   `segment anything语义分割，在这里的作用就是抠图使用,根据关键词进行抠图。`

看起来不是眼熟，像不像WebUI里的Inpaint anything的阉割版。

![Image 8: Comfyui实用基础工作流教程合集](https://www.comfyorg.cn/wp-content/uploads/replace/9623c657311fb50c59d869200f6be6bd.png)

G-DinoSAM语义分割输入：SAM模型、G-Dino模型和加载图像；

![Image 9: Comfyui实用基础工作流教程合集](https://www.comfyorg.cn/wp-content/uploads/replace/c851dded27010fe304f37a6d1230778e.png)

局部重绘中白色表示重绘部分

**提示词**->要选择对象的名称

阈值->提高识别的精度

输出遮罩—>给到BrushNet的遮罩节点

缺点：有些复杂的图片对象比较难用关键词去选取到对的对象，控制性不强。（人物识别没有问题）这情况我们可以选择使用PS扣图后当蒙版使用。

![Image 10: Comfyui实用基础工作流教程合集](https://www.comfyorg.cn/wp-content/uploads/replace/718115b3ffed7f34f17fb6d5cfcd6b60.png)

### BrushNet

1.   `BrushNet：对抠出来的蒙版区域进行重绘。局部重绘`

初始工作流呢也很简单，主要是 BrushNet 的两个节点，一个是「BrushNet加载器」节点，一个是「BrushNet」节点。

![Image 11: Comfyui实用基础工作流教程合集](https://www.comfyorg.cn/wp-content/uploads/replace/59b552f6f79d8675ca3946ef7642a86b.png)

BrushNet加载器节点主要就是加载我们的模型 BrushNet 模型,不带 sdxl 的模型只能针对 SD1.5 的模型，带 sdxl 的模型自然就是针对 SDXL 的模型啦！

里要是小伙伴们看的不爽，可以把 SD1.5 的模型和 SDXL 的模型分别放到不同的文件夹里。

![Image 12: Comfyui实用基础工作流教程合集](https://www.comfyorg.cn/wp-content/uploads/replace/e067ac8b3e17c308d17442db9e7e6b5b.png)

scale ->BrushNet 的"强度"，默认是 1，越大，BrushNet 对最终出图的影响也就越大；越小就影响越小。scale 设置为 0 的时候，和原图已经没有太多关系了。

start_at ->就是从哪一步开始影响图片的生成。

end_at ->就是从哪一步结束影响图片的生成。

**_3.完整工作流_**

01.从模板里新建一个标准的图生图工作流

![Image 13: Comfyui实用基础工作流教程合集](https://www.comfyorg.cn/wp-content/uploads/replace/99d881c197fcdf3a5da1a4241641f08e.png)

02.使用BrushNet局部重绘。

![Image 14: Comfyui实用基础工作流教程合集](https://www.comfyorg.cn/wp-content/uploads/replace/a45399363e2ee80f8b40377366deb726.png)

剩下图像/遮罩就是连Segment的

03.使用segmnet，加载模型，利用关键词生成遮罩。

![Image 15: Comfyui实用基础工作流教程合集](https://www.comfyorg.cn/wp-content/uploads/replace/7433e4e1b25eb990ecfcb217942856d1.png)

关键词选的蔬菜，想重绘的部分是背景，所以要再加个反转遮罩

### 更多遮罩方法

## 05.反推提示词

前面学了文生图、图生图、局部重绘，里面都需要填写关键词。特别是图生图，局部重绘，基本都是与图片相关的提示词。这时候就可以使用图片反推提示词，更加方便。

**反推插件很多，总结一下：**

*   wd 14 tagger速度快，但是元素少 ，风格识别不了
*   **easyuse（clip询问机），可以识别大部分元素，风格，但少量元素会丢失 (推荐）**
*   moondream，deepseek，florence可以识别大部分元素，但是风格识别不了
*   deepseek建议使用小模型，大模型时间太长（10-20分钟）
*   ollama识别元素详细丰富，识别不了风格。（与原图匹配度不高）
*   **Gemini可以识别大部分元素，风格 ；但节点需要魔法访问才行。（推荐）**

**个人觉得还是clip询问机经济高效，适用于大部分场景**

### Clip询问机（推荐）

首先需要在ComfyUI中通过插件管理器安装Comfyui-mixlab-nodes插件。

1.   `• Comfyui-mixlab-nodes插件 ：https://github.com/shadowcz007/comfyui-mixlab-nodes.git`

第一次运行时会自动下载模型，需要网络。

这也是经常有节点报错的原因（一般是绘世启动器的），在启动器中点设置-关闭国内镜像-再打开代理设置。

![Image 16: Comfyui实用基础工作流教程合集](https://www.comfyorg.cn/wp-content/uploads/replace/b7e528530c2b02f8806ff989f0dbd0c7.jpeg)

![Image 17: Comfyui实用基础工作流教程合集](https://www.comfyorg.cn/wp-content/uploads/replace/369efda3c8ae18e75a905277efd46ef4.jpeg)

随机样本--->会随机给出5种场景；（需要把图像分析打开）

提示词模式--->有4个模式：fast（快速）， classic（普通） ， best（最好） ，negative（负面）；一般使用fast就可以满足大部分要求。

可以使用合并字符将它们合并起来，分隔符里必须用上“，”

合并上质量词，给到正面提示词。

![Image 18: Comfyui实用基础工作流教程合集](https://www.comfyorg.cn/wp-content/uploads/replace/47010055597d403aedd6563275d55c75.jpeg)

完整工作流，缺点是需要翻墙网络

### WD1.4 Tagger

直接搜索并安装

模型默认加载时会自动下载，如果没有建议直接下载放到：

1.   `custom_nodes/models/ComfyUI-WD14-Tagger`

![Image 19: Comfyui实用基础工作流教程合集](https://www.comfyorg.cn/wp-content/uploads/replace/0364bb0dbdb50e96fd2e8e761fcf47f5.png)

置信度->默认值0.35，能满足绝大部分要求。值越小，生成的提示词就越详细。反之越高内容越精简。

替换下划线->关闭时词之间用下划线相连，例：white_background ; 开启后用空格替换下划线。

尾随逗号->词间末尾会加上逗号

区别：无法识别风格，细节上也会少一些。

## **07.Lora模型**

**_它是加强某一种风格的模型。_**

大模型和LoRA模型在大小和微调技术上有显著区别。大模型如CKPT体积大，学习大量数据生成能力强。LoRA模型小，用于微调大模型，提供更细粒度调整。

LoRA模型是一种微调模型，它不能独立生成图片，常常用作大模型的补充，用来生成某种特定主体或者风格的图片，比如插画风格、机械战衣、粘土风格等等。

我们举个更容易懂的例子：大模型就像素颜的人，LoRA模型就如同进行了化妆、整容或cosplay，但内在还在大模型的底子。

**当然LoRA模型不仅仅限制于人物，场景、动漫、风格都有相对应的LoRA。

**下载模型**

模型左上角会有一个模型类型的标记，CHECKPOINT 代表大模型，LORA 代表这是一个LoRA模型。

*   下载：点击下载到本地。LoRA模型文件一般比基础模型要小很多，只有几十、几百兆，将模型放在lora文件夹中，默认ComfyUI/models/loras。
*   触发词：有些模型需要在提示词中包含这些词语，才会生成对应风格的图片，记得复制粘贴到你的提示词中就行了。

**_加载LoRA模型_**

![Image 20: Comfyui实用基础工作流教程合集](https://www.comfyorg.cn/wp-content/uploads/replace/8a0b24f777c841e832a62448a3a2d070.jpeg)

用法很简单，将lora加载器串联在大模型与K采样中间

模型强度和CLIP强度都是用来控制LoRA模型对图片风格的影响力的，值越大生成的图片越贴近LoRA风格，但也有过拟合的风险，也就是生成出来的都是一个样子，缺少变化，或者不遵守提示词的描述。

但是也要注意到它们影响的方面不同:

**clip强度**影响的是模型对提示词的理解，较高的clip会让生成结果更准确；

**模型强度**则直接影响LoRA风格能否被应用到生成图像中。

使用不同的LoRA模型时，它们的推荐值也是不同的，一般可以在LoRA模型的下载页面上获取到作者的建议值，比如下图中的这个LoRA说明：

![Image 21: Comfyui实用基础工作流教程合集](https://www.comfyorg.cn/wp-content/uploads/replace/f1e1e11fc5077438085b82f58da8d873.jpeg)

还要注意，LoRA模型的算法版本要和SD基础模型匹配，要么都是SD1.5，要么都是SDXL，不能混用。

连接线2中间还可以串联了一个“CLIP设置停止层”，这个是可选的节点。怎么理解这个停止层呢？模型训练的时候，会学习到很多训练素材的特征，这些学习到的特征是分层的，越往后的层学习到的特征越细致，比如第一层学到一个人，第二层学到男人或女人，第三层学到长头发还是短头发，以此类推，会有很多层。

CLIP使用的层数越高，输出的结果更加稳定，但也有过拟合的风险，也就是生成的结果和训练数据过于相像，而我们可能不需要那么多细节的还原，设置clip停止层可以缓解此类问题，这个值一般设置为: -2。

## 09.光效匹配工作流

### IC-Light插件

IC-Light的全称是“Imposing Consistent Light”，由ControlNet的作者开发。这款工具利用先进的机器学习技术，能够根据简单的文本提示或背景图像，调整照片的光照效果，使其与新环境或设定的氛围完美融合。

![Image 22: Comfyui实用基础工作流教程合集](https://www.comfyorg.cn/wp-content/uploads/replace/020de5185fe8a5808a8bb188ec3f5374.jpeg)

SD中我也详细介绍过：

https://www.comfyorg.cn/1603.html

[![Image 23: Comfyui实用基础工作流教程合集](https://www.comfyorg.cn/wp-content/uploads/replace/b8e774e565e5d0062b49e9bb262724fb.jpeg)](https://www.comfyorg.cn/url?url=aHR0cHM6Ly96aHVhbmxhbi56aGlodS5jb20vcC83MTQ5NTE2OTA=)

**安装插件：**

![Image 24: Comfyui实用基础工作流教程合集](https://www.comfyorg.cn/wp-content/uploads/replace/d6255490df637d632ad4aa69e325a8f2.png)

管理器中搜索IC-Light并安装

**_它需要用到模型：_**

IC-Light模型放到ComfyUI安装目录的/models/unet/IC-Light文件夹里面（需要安装完IC-light插件重启comfyui才有的，如果没有，可以手动创建一个IC-Light文件夹）

模型链接:[https://www.comfyorg.cn/973.html](https://www.comfyorg.cn/973.html)

## 模型

提取码：`dwhy`复制

解压码：`无`复制

官网地址：[lllyasviel/ic-light at main](https://www.comfyorg.cn/url?url=aHR0cHM6Ly9odWdnaW5nZmFjZS5jby9sbGx5YXN2aWVsL2ljLWxpZ2h0L3RyZWUvbWFpbg==)

主要节点**应用ICLight条件和加载ICLight模型**

![Image 25: Comfyui实用基础工作流教程合集](https://www.comfyorg.cn/wp-content/uploads/replace/e3ba697d1e176f55c88c4c4a8b01ac9f.png)

**加载ICLight模型：**

> 需要与应用ICLight条件节点一起使用，加了加载模型节点与K采样中间 iclight_sd15_fbc.safetensors模型 -> 使用了背景调节的重新照明模型。 iclight_sd15_fc.safetensors模型 -> 默认的重新照明模型，以文本和前景为条件。您可以使用初始潜能来影响重新照明。

**应用ICLight：**

### 一、光效模型有三个：

*   **iclight_sd15_fc.safetensors**默认的照明模型，以文本和前景图为条件。
*   **iclight_sd15_fcon.safetensors**与“iclight_sd15_fc.safetensors”相同，使用偏移噪声进行训练。默认的“iclight_sd15_fc.safetensors”稍微优于此模型。
*   **iclight_sd15_fbc.safetensors**以文本、前景图和背景图为条件的重新照明模型。

**总结：fc和fcon功能一样（没有背景图时使用）但fc更好，fbc（有背景图时使用）。使用不对的会报错！**

### 二、文字提示不能影响光效，但是可以影响其他元素：

当没有背景图和光效laten时，文字描述任何光效基本都是无用的：

![Image 26: Comfyui实用基础工作流教程合集](https://www.comfyorg.cn/wp-content/uploads/2025/05/20250516095552456224.jpg)
第二种：遮罩地方 改成 上传 光源模板

![Image 27: Comfyui实用基础工作流教程合集](https://www.comfyorg.cn/wp-content/uploads/replace/82a7c1aae63b406172aa4832a2abc96b.png)

温馨提示：本站提供的一切软件、教程和内容信息都来自网络收集整理，仅限用于学习和研究目的；不得将上述内容用于商业或者非法用途，否则，一切后果请用户自负，版权争议与本站无关。在未征得本站同意时，禁止复制、盗用、采集、发布本站内容到任何网站、书籍等各类媒体平台。如若本站内容侵犯了原著者的合法权益，可联系我们进行处理。
