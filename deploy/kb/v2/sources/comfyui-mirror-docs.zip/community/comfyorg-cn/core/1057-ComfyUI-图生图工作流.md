---
title: ComfyUI 图生图工作流
source_url: https://www.comfyorg.cn/1057.html
source_site: comfyorg.cn
captured_at: 2026-07-15T05:28:42.725209+00:00
category: community_core
fetch_method: jina_reader
---

Title: ComfyUI 图生图工作流 - ComfyUI资源网

URL Source: https://www.comfyorg.cn/1057.html

Markdown Content:
[![Image 7](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/logo.png)](https://www.comfyorg.cn/)

*   [首页](https://www.comfyorg.cn/)
*   [🍂ComfyUI秋叶](https://www.comfyorg.cn/894.html)
*   [🔥满血整合包](https://www.comfyorg.cn/shop/1680.html)
*   [🎭应用广场](https://www.comfyorg.cn/shop)
*   [🍌AI绘画](https://www.comfyorg.cn/aidesign)

[文章](javascript:void(0))

[文章](javascript:void(0))[用户](javascript:void(0))[商铺](javascript:void(0))[文档](javascript:void(0))

[](https://www.comfyorg.cn/message)

登录 快速注册

[![Image 8](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/logo.png)](https://www.comfyorg.cn/)

*   [科技前沿](https://www.comfyorg.cn/kjqy)
    *   [![Image 9: 创新项目](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico1.png)创新项目 14篇](https://www.comfyorg.cn/kjqy/cxxm)
    *   [![Image 10: 办公软件](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico2.png)必备工具 11篇](https://www.comfyorg.cn/kjqy/bbgj)
    *   [![Image 11: 办公软件](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico2.png)办公软件 6篇](https://www.comfyorg.cn/kjqy/bruanjian)
    *   [![Image 12: API聚合](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/icon42.png)API聚合](https://api.oagi.com.cn/)

*   [常用模型](https://www.comfyorg.cn/cynx)
    *   [![Image 13: 主模型](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico3.png)主模型 36篇](https://www.comfyorg.cn/cynx/zmx)
    *   [![Image 14: 微调模型](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico4.png)微调模型 17篇](https://www.comfyorg.cn/cynx/lora)
    *   [![Image 15: Flux模型](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico5.png)Flux模型 20篇](https://www.comfyorg.cn/cynx/fluxmodel)
    *   [![Image 16: 加速模型](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico6.png)加速模型 14篇](https://www.comfyorg.cn/cynx/qrmx)
    *   [![Image 17: 控制模型](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico7.png)控制模型 24篇](https://www.comfyorg.cn/cynx/controlnet)
    *   [![Image 18: 增强模型](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico8.png)增强模型 34篇](https://www.comfyorg.cn/cynx/zqmx)
    *   [![Image 19: Wan模型](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico9.png)Wan模型 19篇](https://www.comfyorg.cn/cynx/wanmodel)
    *   [![Image 20: 关联模型](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico10.png)关联模型 18篇](https://www.comfyorg.cn/cynx/glmx)
    *   [![Image 21: 音视频模型](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico11.png)音视频模型 54篇](https://www.comfyorg.cn/cynx/scenemodel)
    *   [![Image 22: Qwen-image模型](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico12.png)Qwen-image模型 26篇](https://www.comfyorg.cn/cynx/qwenmodel)
    *   [![Image 23: 辅助模型](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico13.png)辅助模型 33篇](https://www.comfyorg.cn/cynx/fzmx)

*   [工作流](https://www.comfyorg.cn/workflow)
    *   [![Image 24: 基础工作流](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico14.png)基础工作流 57篇](https://www.comfyorg.cn/workflow/basic-workflow)
    *   [![Image 25: 模型排行榜](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico15.png)照片修复 38篇](https://www.comfyorg.cn/workflow/ai-repair)
    *   [![Image 26: 电商应用](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico16.png)电商应用 34篇](https://www.comfyorg.cn/workflow/ai-commerce)
    *   [![Image 27: Qwen-image](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico17.png)Qwen-image 29篇](https://www.comfyorg.cn/workflow/qwen-image)
    *   [![Image 28: 角色设计](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico18.png)角色设计 18篇](https://www.comfyorg.cn/workflow/ai-character)
    *   [![Image 29: 海报设计](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico19.png)海报设计 26篇](https://www.comfyorg.cn/workflow/ai-poster)
    *   [![Image 30: 风格转换](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico20.png)风格转换 17篇](https://www.comfyorg.cn/workflow/ai-stylistic)
    *   [![Image 31: ControlNet](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico21.png)Flux工作流 38篇](https://www.comfyorg.cn/workflow/ai-flux)
    *   [![Image 32: 音视频](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico22.png)音视频 60篇](https://www.comfyorg.cn/workflow/audio-video)
    *   [![Image 33: 人像摄影](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico23.png)人像摄影 29篇](https://www.comfyorg.cn/workflow/ai-photography)
    *   [![Image 34: 实用工具](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico24.png)实用工具 41篇](https://www.comfyorg.cn/workflow/utilities)
    *   [![Image 35: 高级工作流（商用）](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico25.png)高级工作流（商用） 11篇](https://www.comfyorg.cn/workflow/advanced-workflow)

*   [插件](https://www.comfyorg.cn/chajian)
    *   [![Image 36: 基础插件](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico30.png)基础插件 40篇](https://www.comfyorg.cn/chajian/basicplugins)
    *   [![Image 37: 提示词插件](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico31.png)提示词插件 11篇](https://www.comfyorg.cn/chajian/promptplugin)
    *   [![Image 38: ControlNet](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico21.png)ControlNet 11篇](https://www.comfyorg.cn/chajian/controlnetplug)
    *   [![Image 39: 图片插件](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico33.png)图片插件 35篇](https://www.comfyorg.cn/chajian/imgplug)
    *   [![Image 40: 视频插件](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico34.png)视频插件 42篇](https://www.comfyorg.cn/chajian/videoplug)
    *   [![Image 41: Flux插件](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico32.png)Flux插件 18篇](https://www.comfyorg.cn/chajian/fluxplugin)
    *   [![Image 42: 3D插件](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico35.png)3D插件 2篇](https://www.comfyorg.cn/chajian/3dplug)
    *   [![Image 43: 其他插件](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico36.png)其他插件 32篇](https://www.comfyorg.cn/chajian/otherplugins)

*   [自学课程](https://www.comfyorg.cn/tutorial)
    *   [![Image 44: 基础教程](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico26.png)基础教程 27篇](https://www.comfyorg.cn/tutorial/basic)
    *   [![Image 45: 进阶教程](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico27.png)进阶教程 27篇](https://www.comfyorg.cn/tutorial/advanced)
    *   [![Image 46: 高级教程](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico28.png)高级教程 8篇](https://www.comfyorg.cn/tutorial/gaoji)
    *   [![Image 47: 其他](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico29.png)其他 9篇](https://www.comfyorg.cn/tutorial/yqt)

*   [视频教程](https://www.comfyorg.cn/videojc)
*   [更多](https://www.comfyorg.cn/1057.html#)
    *   [![Image 48: 模型排行榜](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico15.png)站长运维 6篇](https://www.comfyorg.cn/kjqy/zzyw)
    *   [![Image 49: 模型排行榜](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico15.png)模型排行榜](https://www.comfyorg.cn/document/2371.html)
    *   [![Image 50: 疑难解答](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico41.png)疑难解答](https://www.comfyorg.cn/ask)

[投稿](javascript:void(0))

# ComfyUI 图生图工作流

*   [基础教程](https://www.comfyorg.cn/tutorial/basic) 
*   1 年前

[](https://www.comfyorg.cn/users/1)

![Image 51](https://www.comfyorg.cn/wp-content/uploads/thumb/2025/06/fill_w120_h120_g0_mark_20250612030820830302.png)

**ComfyUI教程**免费资源

我们经常希望能够对生成的图像进行更细致的调控，包括调整分辨率、修改图片的具体内容或者改变图片中的某些细节。为了实现这些高级功能，我们需要深入了解 Stable Diffusion 模型的两种核心工作流：重绘和参考。接下来，我们将详细介绍如何利用这两种方法来实现更精细的图像生成控制。这种方法通过将输入图片先添加噪声，然后再通过降噪过程生成新的图片，实际上是在原有图像的基础上进行重新创作。

## 什么是图生图

图生图（Image to Image）是 ComfyUI 中的一种工作流，它允许用户将一张图像作为输入，并生成一张新的图像。

图生图可以使用在以下场景中：

*   原始图像风格的转换，如把写实照片转为艺术风格
*   将线稿图像转换为写实图像
*   图像的修复
*   老照片着色
*   … 等其它场景

用一个比喻来讲解的话，大概是这样： 你需要画家根据你的参考图片，画出符合你要求特定效果的作品。

如果你仔细比对本篇教程和[文生图](https://www.comfyorg.cn/1040.html)教程，你会发现图生图的流程和文生图的流程非常相似，只是多了个输入的参考图片作为输入条件，也就是在文生图中，我们是让画家（绘图模型）根据我们的提示词生成自由发挥，而在图生图中，我们是让画家（绘图模型）根据我们的参考图片和提示词生成图片。

## ComfyUI 图生图工作流示例讲解

### 1. 模型安装

请确保你已经在`ComfyUI/models/checkpoints` 文件夹至少有一个 SD1.5 的模型文件，如果你还不了解如何安装模型，请参[ComfyUI零基础入门](https://www.comfyorg.cn/955.html)章节中关于模型安装的部分说明。

你可以使用下面的这些模型：

*   v1-5-pruned-emaonly-fp16.safetensors
*   Dreamshaper 8
*   Anything V5

### 2. 图生图工作流相关文件

保存并下载下面的图片到本地，然后**拖拽或使用 ComfyUI 打开**它，就会加载对应的工作流

![Image 52: 3步出图！最新图片编辑模型BooGu：Boogu-Image-0.1生图模型硬刚Qwen](https://www.comfyorg.cn/wp-content/themes/b2/Assets/fontend/images/default-img.jpg)

或在 ComfyUI 的**workflow template**中加载**image to image**工作流

下载下面的图片作为使用示例，我们会在后面的步骤中使用它

![Image 53: 3步出图！最新图片编辑模型BooGu：Boogu-Image-0.1生图模型硬刚Qwen](https://www.comfyorg.cn/wp-content/themes/b2/Assets/fontend/images/default-img.jpg)

### 3. 开始图生图工作流

![Image 54: 3步出图！最新图片编辑模型BooGu：Boogu-Image-0.1生图模型硬刚Qwen](https://www.comfyorg.cn/wp-content/themes/b2/Assets/fontend/images/default-img.jpg)

在加载图生图工作流后，请对照图片，按照序号完成以下操作，完成示例工作流的生成

1.   在**Load Checkpoint**节点中加载好你本地的绘图模型
2.   在**Load Image**节点点击`upload`按钮，上传准备步骤中提供的图片
3.   点击`Queue`按钮，或者使用快捷键`Ctrl + Enter(回车)`来执行图片生成

## 开始你自己的尝试

1.   试着修改**KSampler**节点中的`denoise`参数，逐渐从 1 到 0 变化，观察生成图片的变化
2.   更换你自己的提示词和参考图片，生成属于你自己的图片效果

## 图生图工作流核心要点

图生图工作流的核心在于在于`KSampler`节点中的`denoise`参数要是**小于 1**

如果你调整过`denoise`参数，进行生成后会发现：

*   `denoise`越小，生成图片和参考图片的差异就会越小，
*   `denoise`越大，生成图片和参考图片的差异就会越大。

因为`denoise`决定了对应图片转换为潜空间图像后，向潜在空间图像添加的噪声强度，如果`denoise`为 1，对应潜空间图像就会变成一个完全随机的噪声，那这样就和`empty latent image`节点生成的潜在空间一样了，就会丢失参考图片的所有特征。

对应原理可以参考[文生图](https://www.comfyorg.cn/1040.html)教程中的原理讲解。

温馨提示：本站提供的一切软件、教程和内容信息都来自网络收集整理，仅限用于学习和研究目的；不得将上述内容用于商业或者非法用途，否则，一切后果请用户自负，版权争议与本站无关。在未征得本站同意时，禁止复制、盗用、采集、发布本站内容到任何网站、书籍等各类媒体平台。如若本站内容侵犯了原著者的合法权益，可联系我们进行处理。

给TA打赏

共人

**海报分享****收藏**

 1 条回复 **A**_文章作者_**M**_管理员_

您必须登录或注册以后才能发表评论

登录

![Image 55](https://www.comfyorg.cn/wp-content/themes/b2/Assets/fontend/images/default-avatar.png)

欢迎您，新朋友，感谢参与互动！

确认修改

细 中 粗

😁😊😎😤😥😂😍😏😙😟😖😜😱😲😭😚💀👻👍💪👊

取消回复 提交

1.   ![Image 56: 3步出图！最新图片编辑模型BooGu：Boogu-Image-0.1生图模型硬刚Qwen](https://www.comfyorg.cn/wp-content/themes/b2/Assets/fontend/images/default-img.jpg)[江小鱼](https://www.comfyorg.cn/users/4775)**学前班**_lv0_  2 周前  谢谢 分享  置顶 回复       

1/1 页 前往 

❮❯

## 关于作者 关注 私信

![Image 57](https://www.comfyorg.cn/wp-content/uploads/thumb/2025/06/fill_w192_h192_g0_mark_20250612030820830302.png)

[](https://www.comfyorg.cn/users/1)
ComfyUI教程

**博导**_lv7_**永久会员**

文章

291

评论

106

关注

0

粉丝

198

[[文章] 3步出图！最新图片编辑模型BooGu：Boogu-Image-0.1生图模型硬刚Qwen](https://www.comfyorg.cn/3529.html)

[[文章] Bernini：全能Wan视频编辑与生成模型，AI视频编辑先理解再动手](https://www.comfyorg.cn/3521.html)

[[文章] Krea2 Turbo模型：多风格生成工作流，人像效果足以撼动Z-Image人像王座的最新模型](https://www.comfyorg.cn/3502.html)

[[文章] 清华团队开源SCAIL-2： 动作转移、分段队列换装、人物替换多角色+动物全支持](https://www.comfyorg.cn/3497.html)

[Ta的全部动态](https://www.comfyorg.cn/tastream/1)

*   [](https://www.comfyorg.cn/1057.html#)[](https://www.comfyorg.cn/1057.html#)   
*   [](https://www.comfyorg.cn/1057.html#)[](https://www.comfyorg.cn/1057.html#)   
*   [](https://www.comfyorg.cn/1057.html#)[](https://www.comfyorg.cn/1057.html#)   
*   [](https://www.comfyorg.cn/1057.html#)[](https://www.comfyorg.cn/1057.html#)   
*   [](https://www.comfyorg.cn/1057.html#)[](https://www.comfyorg.cn/1057.html#)   
*   [](https://www.comfyorg.cn/1057.html#)[](https://www.comfyorg.cn/1057.html#)   

[签到排行](https://www.comfyorg.cn/mission)

点击领取今天的签到奖励！

今日签到

连续签到

*   [![Image 58](https://www.comfyorg.cn/wp-content/themes/b2/Assets/fontend/images/default-avatar.png)](https://www.comfyorg.cn/users/5043)[七千海里](https://www.comfyorg.cn/users/5043)
6 小时后 4  
*   [![Image 59](https://www.comfyorg.cn/wp-content/themes/b2/Assets/fontend/images/default-avatar.png)](https://www.comfyorg.cn/users/3695)[qiutian](https://www.comfyorg.cn/users/3695)
6 小时后 5  
*   [![Image 60](https://www.comfyorg.cn/wp-content/themes/b2/Assets/fontend/images/default-avatar.png)](https://www.comfyorg.cn/users/4027)[嫁衣神功](https://www.comfyorg.cn/users/4027)
5 小时后 4  
*   [![Image 61](https://www.comfyorg.cn/wp-content/themes/b2/Assets/fontend/images/default-avatar.png)](https://www.comfyorg.cn/users/4242)[辫子叔叔](https://www.comfyorg.cn/users/4242)
5 小时后 3  
*   [![Image 62](https://www.comfyorg.cn/wp-content/themes/b2/Assets/fontend/images/default-avatar.png)](https://www.comfyorg.cn/users/3548)[烈火](https://www.comfyorg.cn/users/3548)
5 小时后 5  
*   [![Image 63](https://www.comfyorg.cn/wp-content/themes/b2/Assets/fontend/images/default-avatar.png)](https://www.comfyorg.cn/users/2354)[歸去來兮](https://www.comfyorg.cn/users/2354)
5 小时后 3  

[签到排行](https://www.comfyorg.cn/mission)

## 猜你喜欢

*   TOP1 ![Image 64: 清华团队开源SCAIL-2： 动作转移、分段队列换装、人物替换多角色+动物全支持](https://www.comfyorg.cn/wp-content/uploads/thumb/2026/06/fill_w100_h62_g0_mark_20260621142134698333.jpg) ## 清华团队开源SCAIL-2： 动作转移、分段队列换装、人物替换多角色+动物全支持

3 周前  [](https://www.comfyorg.cn/3497.html)
*   TOP2 ![Image 65: Krea2 Turbo模型：多风格生成工作流，人像效果足以撼动Z-Image人像王座的最新模型](https://www.comfyorg.cn/wp-content/uploads/thumb/2026/06/fill_w100_h62_g0_mark_20260629140138899269.png) ## Krea2 Turbo模型：多风格生成工作流，人像效果足以撼动Z-Image人像王座的最新模型

2 周前  [](https://www.comfyorg.cn/3502.html)
*   TOP3 ![Image 66: Bernini：全能Wan视频编辑与生成模型，AI视频编辑先理解再动手](https://www.comfyorg.cn/wp-content/uploads/thumb/2026/07/fill_w100_h62_g0_mark_20260705052219113732.jpg) ## Bernini：全能Wan视频编辑与生成模型，AI视频编辑先理解再动手

1 周前  [](https://www.comfyorg.cn/3521.html)
*   ![Image 67: 3步出图！最新图片编辑模型BooGu：Boogu-Image-0.1生图模型硬刚Qwen](https://www.comfyorg.cn/wp-content/themes/b2/Assets/fontend/images/default-img.jpg) ## 3步出图！最新图片编辑模型BooGu：Boogu-Image-0.1生图模型硬刚Qwen

3 天前  [](https://www.comfyorg.cn/3529.html)

×

![Image 68](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/logo.png)

使用邀请码，您将获得一份特殊的礼物！

请输入邀请码

[获取邀请码](https://www.comfyorg.cn/1057.html#)

**跳过**提交

**登录**

**可爱的昵称** **登录邮箱**
用作登录：字母或数字的组合，最少6位字符

用作登录

 **验证码****发送验证码** **密码** **重复新密码**
最少6位字符

 

快速登录

[忘记密码？](javascript:void(0))新用户？[注册](javascript:void(0))

社交登录:

## 请输入验证码

请输入图片中的验证码

点击发送按钮获取验证码

[取消](javascript:void(0))发送

![Image 69](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/logo.png)

×

搜索一下可能来得更快

搜索

×

## 公告

2026-6-10 0:00:19

[📢 ComfyUI资源网新功能上线公告](https://www.comfyorg.cn/announcement/704.html)

GPT-Image-2已上线ComfyUI资源网：文字渲染准确率99%+、原生4K、无损编辑、单次批量生成8张且角色一致，在线即可使用。

[前往查看详情](https://www.comfyorg.cn/announcement/704.html)

![Image 70](https://www.comfyorg.cn/1057.html)

×

取消 发送

×

![Image 71](https://www.comfyorg.cn/1057.html)

￥undefined

请打开手机使用 微信 扫码支付

「」

×

## ....支付确认中....

「」

×

支付金额

_￥_

请输入金额

 undefined 

×

 积分支付 

您当前的积分为 0

 您当前的积分不足，请 [购买积分](https://www.comfyorg.cn/gold/credit)

支付

检测到您未绑定微信账户，请先绑定微信

[立刻绑定](https://www.comfyorg.cn/1057.html)

[确定](javascript:void(0))

![Image 72](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/logo.png)

×

使用邀请码，您将获得一份特殊的礼物！

请输入邀请码

[获取邀请码](https://www.comfyorg.cn/1057.html#)

**跳过**提交

打开微信扫一扫

扫码并「关注我们的公众号」安全快捷登录

×

![Image 73](https://www.comfyorg.cn/1057.html)

为了确保您的账户安全

请您设置一个**登录用户名**和密码

**登录用户名**
请填写您的的登录用户名

 **验证码****发送验证码** **密码**
最少6位字符

 

提交

×

分享到：

微博 QQ好友 QQ空间

下载海报：

海报创建中

个人中心

购物车

优惠劵

今日签到

私信列表

搜索

客服

*   ![Image 74](blob:http://localhost/c7f58b5a8c81f88025cc02086abcf740)
扫码打开当前页

返回顶部

Copyright © 2026[ComfyUI资源网](https://www.comfyorg.cn/)

 本站已稳定运行：603 天 18 时 35 分 53 秒

 查询 86 次，耗时 0.1042 秒 

[**首页**](https://www.comfyorg.cn/)[**专题**](https://www.comfyorg.cn/collection)[**认证**](https://www.comfyorg.cn/verify)

[**搜索**](javascript:void(0))[**菜单**](javascript:void(0))[**我的**](javascript:void(0))

发布文章

创建圈子

发表话题

提交工单
