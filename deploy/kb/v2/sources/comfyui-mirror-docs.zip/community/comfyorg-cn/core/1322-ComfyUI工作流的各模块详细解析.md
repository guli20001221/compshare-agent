---
title: ComfyUI工作流的各模块详细解析
source_url: https://www.comfyorg.cn/1322.html
source_site: comfyorg.cn
captured_at: 2026-07-15T05:28:35.645367+00:00
category: community_core
fetch_method: jina_reader
---

Title: ComfyUI工作流的各模块详细解析 - ComfyUI资源网

URL Source: https://www.comfyorg.cn/1322.html

Markdown Content:
ComfyUI 中文生图最简工作流，通过这个最简工作流，我们来认识一下工作流的组成元素。

![Image 1: ComfyUI工作流的各模块详细解析](https://www.comfyorg.cn/wp-content/uploads/replace/8d3850a801f23a5491c280852378adda.jpeg)

工作流的组成也很简单，包括节点和连线，节点通过连线进行连接，共同协同完成一项 AI 绘画任务。

节点是工作流中的基本单元，每个节点代表一个特定的操作或功能。节点可以分为 3 大类：

**1. 仅有输出的节点**

![Image 2: ComfyUI工作流的各模块详细解析](https://www.comfyorg.cn/wp-content/uploads/replace/fe5f41fa474bd63d8e6ad10d699326d2.jpeg)

在最简工作流中，「Checkpoint 加载器(简易)」和「空 Latent」就属于这一类节点，可以看到这类节点没有左边的输入，有右边的输出，输出表示将本节点的模型或数据传递给下一个节点。

**2. 仅有输入的节点**

![Image 3: ComfyUI工作流的各模块详细解析](https://www.comfyorg.cn/wp-content/uploads/replace/a93afa2600800204700c27af995c7861.jpeg)

可以看到这类节点只有左边的输入，没有右边的输出

**3. 既有输入也有输出的节点**

![Image 4: ComfyUI工作流的各模块详细解析](https://www.comfyorg.cn/wp-content/uploads/replace/3e93c1e1adae74738e86b993191f1931.jpeg)

在最简工作流中，上图中的 4 个就属于这一类节点，可以看到这类节点既有左边的输入，也有右边的输出。接受从左边的数据输入，通过当前节点的处理，将数据再传递到下一个节点。

我们以 K 采样器为例，说明节点的组成：

![Image 5: ComfyUI工作流的各模块详细解析](https://www.comfyorg.cn/wp-content/uploads/replace/5533665fa891a92fa6f0f138a4f8634e.jpeg)

**1. 节点名称**

节点名称是每个节点的唯一标识，用于在工作流中识别和引用该节点。节点名称通常反映了节点的功能或操作类型。上图中，「K 采样器」就是节点名称，双击节点名称，还可以对节点名称进行重命名：

![Image 6: ComfyUI工作流的各模块详细解析](https://www.comfyorg.cn/wp-content/uploads/replace/3201eda8d4a4d588edd507708e41f6d0.jpeg)

**2. 输入参数**

输入参数是节点执行所需的数据或条件。每个节点可以有多个输入参数，这些参数可以来自其他节点的输出，也可以是用户手动输入的值。

上图中，「模型」「正面条件」「负面条件」「Latent」就是输入参数，它们的数据都是其他节点输入进来的。

![Image 7: ComfyUI工作流的各模块详细解析](https://www.comfyorg.cn/wp-content/uploads/replace/e5e7dafc291d4dcc6fc2a5b3ad3ec42d.jpeg)

**3. 输出参数**

输出参数是节点执行完成后产生的结果，这些结果可以作为其他节点的输入。每个节点可以有多个输出参数，这些参数的类型和数量取决于节点的功能。

![Image 8: ComfyUI工作流的各模块详细解析](https://www.comfyorg.cn/wp-content/uploads/replace/91c39146014b4cadf7449c61ef8c3f87.jpeg)

**4. 参数面板**

参数面板是节点的配置界面，用户可以通过这个面板设置节点的具体参数。参数面板通常包含输入框、选择框、滑动条等控件，用于输入或选择参数值。

① 输入框

![Image 9: ComfyUI工作流的各模块详细解析](https://www.comfyorg.cn/wp-content/uploads/replace/f65ce51d1a0c19d381549674d74445a4.jpeg)

② 选择框

选择框一般是选择列表中的一个选项，通过点选然后从下拉列表中选择一个参数

![Image 10: ComfyUI工作流的各模块详细解析](https://www.comfyorg.cn/wp-content/uploads/replace/49c22dab09070b29b425db1d1cbd2313.jpeg)

![Image 11: ComfyUI工作流的各模块详细解析](https://www.comfyorg.cn/wp-content/uploads/replace/09dce91ceebe31787c1e79179325d0af.jpeg)

以上就是可以进行选择的选择框。

![Image 12: ComfyUI工作流的各模块详细解析](https://www.comfyorg.cn/wp-content/uploads/replace/2b7c95bc7ed43d30d9ba9f8330423beb.jpeg)

例如，点击调度器，就会出现一个下拉列表，然后再选择其中一个参数。

③ 滑动条

滑动条针对的是数字类型的参数，可以通过按住鼠标左键，然后再左右滑动进行调整参数值，也可以进行点选，然后再输入参数的方式进行参数调整。

![Image 13: ComfyUI工作流的各模块详细解析](https://www.comfyorg.cn/wp-content/uploads/replace/6a712cf47e94b3b091d613a19ea4e6f7.jpeg)

**5. 注意事项**

① 参数类型

节点中的参数一般是有类型的，这些类型定义了参数的格式和用途。我们还是以 K 采样器为例说明：

![Image 14: ComfyUI工作流的各模块详细解析](https://www.comfyorg.cn/wp-content/uploads/replace/6fc1ef82047f1abb75d039ebf745eef7.jpeg)

上图中，输入参数「模型」的类型就是模型，它只能接收模型类型的输入：

![Image 15: ComfyUI工作流的各模块详细解析](https://www.comfyorg.cn/wp-content/uploads/replace/e5d88bdb06cf8c9ce897e416aa06f91a.jpeg)

上图中，输入参数「正面条件」和「负面条件」的类型就是字符串，它只能接收字符串类型的输入：

![Image 16: ComfyUI工作流的各模块详细解析](https://www.comfyorg.cn/wp-content/uploads/replace/2e9ddf68448788bf3e97825f643e7991.jpeg)

② 输入参数和参数面板的转换

输入参数：通过接收其他节点的输入设置参数的值。

参数面板：通过手动设置对参数进行设置。

我们可以通过调整将输入参数转为参数面板上的参数，也可以通过调整将参数面板上的参数转为输入参数：

操作：选中节点，鼠标右键节点，可以看到弹出框里有两项：

![Image 17: ComfyUI工作流的各模块详细解析](https://www.comfyorg.cn/wp-content/uploads/replace/1b3b6be370b29cca11ee8d0d57852777.jpeg)

1）转换为输入：将参数面板上的参数转为输入参数的形式。

以 CFG 值为例，转换后，CFG 参数就从参数面板消失了，然后出现在输入参数里：

![Image 18: ComfyUI工作流的各模块详细解析](https://www.comfyorg.cn/wp-content/uploads/replace/25f0f18949dda4fd16a5e3a60c6435c9.jpeg)

2）转换为组件：将输入参数转为参数面板上的参数形式

还是以 CFG 值为例，转换后，CFG 参数就从输入参数中消失了，然后出现在参数面板里。

需要注意的是：原来在输入参数上的参数，不能进行转换，只能将参数从面板上转为输入，然后再从输入转为面板。

③ 节点输入缺失

某些节点是必须输入的，如果没有输入，就会提示当前节点处于不工作状态，

1.   整个节点就会有红色框框住
2.   缺失输入的参数也会有一个红色的圆圈
3.   弹出报错信息

![Image 19: ComfyUI工作流的各模块详细解析](https://www.comfyorg.cn/wp-content/uploads/replace/1512adbb54f8c0f6b055b73f3b3b805b.jpeg)

**1. 移动单个节点**

用鼠标左键点住节点不放，移动鼠标即可移动单个节点。

**2. 移动多个节点**

1.   按住 Ctrl 框选多个节点，然后按住 Shift 不放，移动鼠标即可移动多个节点。
2.   也可以按住 Ctrl 框选多个节点，然后再按 Ctrl+g，这几个节点就会被蓝色的框框住，再移动蓝色框，就可以整体移动这几个节点了

![Image 20: ComfyUI工作流的各模块详细解析](https://www.comfyorg.cn/wp-content/uploads/replace/27c06b5421fcd09eaac7a7712cffac10.jpeg)

**3. 工作流整体移动**

![Image 21: ComfyUI工作流的各模块详细解析](https://www.comfyorg.cn/wp-content/uploads/replace/0af0644772a940162ad5dea64b9b3388.jpeg)

将空间设置为平移模式，然后用鼠标移动任何位置，工作流整体就会移动，当然也可以框选所有节点，然后 Shift+鼠标移动也可以整体移动工作流。

**1. 关键词搜索**

![Image 22: ComfyUI工作流的各模块详细解析](https://www.comfyorg.cn/wp-content/uploads/replace/56c84378b82d8e3800515e32c24d2a14.jpeg)

双击空白界面，出现搜索框，输入节点名称关键词，然后从列表中选择一个你需要的节点

**2. 添加节点筛选条件**

可以缩小筛选范围

![Image 23: ComfyUI工作流的各模块详细解析](https://www.comfyorg.cn/wp-content/uploads/replace/62f2f4a304455fdccec23d6a1f82256a.jpeg)

![Image 24: ComfyUI工作流的各模块详细解析](https://www.comfyorg.cn/wp-content/uploads/replace/08053b7f20901a42bef07c6fe3768b1b.jpeg)

**3. 从节点库中选择**

![Image 25: ComfyUI工作流的各模块详细解析](https://www.comfyorg.cn/wp-content/uploads/replace/6e651c0754ae1d6469879a80e58ae51f.jpeg)

也可以在节点库中筛选节点：

![Image 26: ComfyUI工作流的各模块详细解析](https://www.comfyorg.cn/wp-content/uploads/replace/183f5958d235450ce76fc4e23c3e0308.jpeg)

1.   框选目标节点，可以是单个，也可以是多个，然后 Ctrl+C 复制，再 Ctrl+V 进行粘贴。
2.   按住 Alt 键不放，然后拖动某个节点，就可以快速复制节点。

缩放：将鼠标悬浮在节点的右下角，当鼠标变为两边都是箭头的时候，拖动鼠标，就可以对节点的大小进行缩放。

![Image 27: ComfyUI工作流的各模块详细解析](https://www.comfyorg.cn/wp-content/uploads/replace/f41335500639cc61b094ec1ef586ed07.jpeg)

折叠：鼠标点击灰黑色的小圆点，就可以将节点折叠：

![Image 28: ComfyUI工作流的各模块详细解析](https://www.comfyorg.cn/wp-content/uploads/replace/048c397ddeee1e871e907a0f9272914d.jpeg)

折叠后：

![Image 29: ComfyUI工作流的各模块详细解析](https://www.comfyorg.cn/wp-content/uploads/replace/79b346326b943762ae34677adf051478.jpeg)

再次点击小圆点，可以再次展开节点。

![Image 30: ComfyUI工作流的各模块详细解析](https://www.comfyorg.cn/wp-content/uploads/replace/0566f7f52f598fa1654c2b642eb55627.jpeg)

鼠标右键节点，然后选择颜色，然后选择某个颜色，那么节点就会改变颜色。通过改变颜色来增加节点的辨识度。

![Image 31: ComfyUI工作流的各模块详细解析](https://www.comfyorg.cn/wp-content/uploads/replace/0a933fb47f9b29e41893162eb2518c7a.jpeg)

通过鼠标右键节点，然后点击固定：

![Image 32: ComfyUI工作流的各模块详细解析](https://www.comfyorg.cn/wp-content/uploads/replace/0566f7f52f598fa1654c2b642eb55627.jpeg)

固定后，节点名称右边出现一个别针，这样这个节点就固定了，无法拖动移动该节点：

![Image 33: ComfyUI工作流的各模块详细解析](https://www.comfyorg.cn/wp-content/uploads/replace/21899e64ccf75983e5bf124db44f946d.jpeg)

再次点击 Unpin，这个节点就又可以拖动移动了：

![Image 34: ComfyUI工作流的各模块详细解析](https://www.comfyorg.cn/wp-content/uploads/replace/46da80e2252ac962fbbd4af08c6e538f.jpeg)

可以根据自己的喜好，进行选择对应的节点形状：

![Image 35: ComfyUI工作流的各模块详细解析](https://www.comfyorg.cn/wp-content/uploads/replace/a1669c3fac2ebf94732fec3552306b58.jpeg)

连线的作用主要是连接节点，是工作流中节点之间数据流动和执行顺序的关键，如下图：

![Image 36: ComfyUI工作流的各模块详细解析](https://www.comfyorg.cn/wp-content/uploads/replace/323999a1bcc20b446dfda24014956017.jpeg)

连线只能从某个节点的输出端口连接到另一个节点的输入端口，且连线的两端必须是相同的类型。

![Image 37: ComfyUI工作流的各模块详细解析](https://www.comfyorg.cn/wp-content/uploads/replace/9f06a801d98d52cd62a69c8b3c612b00.jpeg)

**直线**

![Image 38: ComfyUI工作流的各模块详细解析](https://www.comfyorg.cn/wp-content/uploads/replace/c1c5d16c0c01e4bb77bba8e787f08323.jpeg)

**折线（线性）**

![Image 39: ComfyUI工作流的各模块详细解析](https://www.comfyorg.cn/wp-content/uploads/replace/63902969ea7e419d68b6645a3c199ec1.jpeg)

**曲线（样条）**

![Image 40: ComfyUI工作流的各模块详细解析](https://www.comfyorg.cn/wp-content/uploads/replace/bf6fa86a61fd37836ad6b614485d213e.jpeg)

![Image 41: ComfyUI工作流的各模块详细解析](https://www.comfyorg.cn/wp-content/uploads/replace/6f864c40beaabbece3a1a843431bd923.jpeg)

**1. 鼠标左键输出端的小圆圈，然后通过滚轮缩放视图找到目标节点**

**2. 转接点**

从输出端拖出连线，然后释放鼠标，弹出如下窗口，然后点击转接点：

![Image 42: ComfyUI工作流的各模块详细解析](https://www.comfyorg.cn/wp-content/uploads/replace/2c4566865ec718719e6df42e5bfe1e26.jpeg)

再将转接点连到目标节点：

![Image 43: ComfyUI工作流的各模块详细解析](https://www.comfyorg.cn/wp-content/uploads/replace/848619f982d0025eaa59fe2e7fc7c8b3.jpeg)

**3. 设置/获取节点**

设置节点

双击界面空白处，搜索：设置节点，并点击。然后给这个节点重命名为：大模型

![Image 44: ComfyUI工作流的各模块详细解析](https://www.comfyorg.cn/wp-content/uploads/replace/b95087a6f2de843241ba6ce8ab6487d3.jpeg)

![Image 45: 3步出图！最新图片编辑模型BooGu：Boogu-Image-0.1生图模型硬刚Qwen](https://www.comfyorg.cn/wp-content/themes/b2/Assets/fontend/images/default-img.jpg)

然后将模型连到这个节点，那么在其他地方就可以获取这个节点并使用它

![Image 46: 3步出图！最新图片编辑模型BooGu：Boogu-Image-0.1生图模型硬刚Qwen](https://www.comfyorg.cn/wp-content/themes/b2/Assets/fontend/images/default-img.jpg)

获取节点

![Image 47: 3步出图！最新图片编辑模型BooGu：Boogu-Image-0.1生图模型硬刚Qwen](https://www.comfyorg.cn/wp-content/themes/b2/Assets/fontend/images/default-img.jpg)

![Image 48: 3步出图！最新图片编辑模型BooGu：Boogu-Image-0.1生图模型硬刚Qwen](https://www.comfyorg.cn/wp-content/themes/b2/Assets/fontend/images/default-img.jpg)

我们将这个节点连到 K 采样器，这样我们就可以使用大模型了：

![Image 49: 3步出图！最新图片编辑模型BooGu：Boogu-Image-0.1生图模型硬刚Qwen](https://www.comfyorg.cn/wp-content/themes/b2/Assets/fontend/images/default-img.jpg)

最终的工作流：

![Image 50: 3步出图！最新图片编辑模型BooGu：Boogu-Image-0.1生图模型硬刚Qwen](https://www.comfyorg.cn/wp-content/themes/b2/Assets/fontend/images/default-img.jpg)

**4. 全局变量**

这个用法需要安装插件「Use Everywhere (UE Nodes)」，我们通过启动器进行安装这个插件：

![Image 51: 3步出图！最新图片编辑模型BooGu：Boogu-Image-0.1生图模型硬刚Qwen](https://www.comfyorg.cn/wp-content/themes/b2/Assets/fontend/images/default-img.jpg)

![Image 52: 3步出图！最新图片编辑模型BooGu：Boogu-Image-0.1生图模型硬刚Qwen](https://www.comfyorg.cn/wp-content/themes/b2/Assets/fontend/images/default-img.jpg)

关闭 ComfyUI，然后点击安装，安装成功后，重新启动 ComfyUI

双击界面，搜索：全局输入：

![Image 53: 3步出图！最新图片编辑模型BooGu：Boogu-Image-0.1生图模型硬刚Qwen](https://www.comfyorg.cn/wp-content/themes/b2/Assets/fontend/images/default-img.jpg)

![Image 54: 3步出图！最新图片编辑模型BooGu：Boogu-Image-0.1生图模型硬刚Qwen](https://www.comfyorg.cn/wp-content/themes/b2/Assets/fontend/images/default-img.jpg)

除了第一种方式，其他方式都可以方便的对节点进行长距离连接，而且连线不混乱。

温馨提示：本站提供的一切软件、教程和内容信息都来自网络收集整理，仅限用于学习和研究目的；不得将上述内容用于商业或者非法用途，否则，一切后果请用户自负，版权争议与本站无关。在未征得本站同意时，禁止复制、盗用、采集、发布本站内容到任何网站、书籍等各类媒体平台。如若本站内容侵犯了原著者的合法权益，可联系我们进行处理。
