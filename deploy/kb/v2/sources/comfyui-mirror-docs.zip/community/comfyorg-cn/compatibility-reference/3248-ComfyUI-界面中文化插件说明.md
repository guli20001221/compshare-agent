---
title: ComfyUI 界面中文化插件说明
source_url: https://www.comfyorg.cn/3248.html
source_site: comfyorg.cn
captured_at: 2026-07-15T05:28:44.972771+00:00
category: community_compatibility-reference
fetch_method: jina_reader
---

Title: 小白泪目！这个插件让ComfyUI界面全中文化，从此告别语言障碍！（纯干货，建议收藏） - ComfyUI资源网

URL Source: https://www.comfyorg.cn/3248.html

Markdown Content:
[![Image 13](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/logo.png)](https://www.comfyorg.cn/)

*   [首页](https://www.comfyorg.cn/)
*   [🍂ComfyUI秋叶](https://www.comfyorg.cn/894.html)
*   [🔥满血整合包](https://www.comfyorg.cn/shop/1680.html)
*   [🎭应用广场](https://www.comfyorg.cn/shop)
*   [🍌AI绘画](https://www.comfyorg.cn/aidesign)

[文章](javascript:void(0))

[文章](javascript:void(0))[用户](javascript:void(0))[商铺](javascript:void(0))[文档](javascript:void(0))

[](https://www.comfyorg.cn/message)

登录 快速注册

[![Image 14](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/logo.png)](https://www.comfyorg.cn/)

*   [科技前沿](https://www.comfyorg.cn/kjqy)
    *   [![Image 15: 创新项目](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico1.png)创新项目 14篇](https://www.comfyorg.cn/kjqy/cxxm)
    *   [![Image 16: 办公软件](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico2.png)必备工具 11篇](https://www.comfyorg.cn/kjqy/bbgj)
    *   [![Image 17: 办公软件](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico2.png)办公软件 6篇](https://www.comfyorg.cn/kjqy/bruanjian)
    *   [![Image 18: API聚合](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/icon42.png)API聚合](https://api.oagi.com.cn/)

*   [常用模型](https://www.comfyorg.cn/cynx)
    *   [![Image 19: 主模型](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico3.png)主模型 36篇](https://www.comfyorg.cn/cynx/zmx)
    *   [![Image 20: 微调模型](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico4.png)微调模型 17篇](https://www.comfyorg.cn/cynx/lora)
    *   [![Image 21: Flux模型](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico5.png)Flux模型 20篇](https://www.comfyorg.cn/cynx/fluxmodel)
    *   [![Image 22: 加速模型](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico6.png)加速模型 14篇](https://www.comfyorg.cn/cynx/qrmx)
    *   [![Image 23: 控制模型](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico7.png)控制模型 24篇](https://www.comfyorg.cn/cynx/controlnet)
    *   [![Image 24: 增强模型](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico8.png)增强模型 34篇](https://www.comfyorg.cn/cynx/zqmx)
    *   [![Image 25: Wan模型](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico9.png)Wan模型 19篇](https://www.comfyorg.cn/cynx/wanmodel)
    *   [![Image 26: 关联模型](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico10.png)关联模型 18篇](https://www.comfyorg.cn/cynx/glmx)
    *   [![Image 27: 音视频模型](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico11.png)音视频模型 54篇](https://www.comfyorg.cn/cynx/scenemodel)
    *   [![Image 28: Qwen-image模型](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico12.png)Qwen-image模型 26篇](https://www.comfyorg.cn/cynx/qwenmodel)
    *   [![Image 29: 辅助模型](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico13.png)辅助模型 33篇](https://www.comfyorg.cn/cynx/fzmx)

*   [工作流](https://www.comfyorg.cn/workflow)
    *   [![Image 30: 基础工作流](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico14.png)基础工作流 57篇](https://www.comfyorg.cn/workflow/basic-workflow)
    *   [![Image 31: 模型排行榜](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico15.png)照片修复 38篇](https://www.comfyorg.cn/workflow/ai-repair)
    *   [![Image 32: 电商应用](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico16.png)电商应用 34篇](https://www.comfyorg.cn/workflow/ai-commerce)
    *   [![Image 33: Qwen-image](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico17.png)Qwen-image 29篇](https://www.comfyorg.cn/workflow/qwen-image)
    *   [![Image 34: 角色设计](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico18.png)角色设计 18篇](https://www.comfyorg.cn/workflow/ai-character)
    *   [![Image 35: 海报设计](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico19.png)海报设计 26篇](https://www.comfyorg.cn/workflow/ai-poster)
    *   [![Image 36: 风格转换](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico20.png)风格转换 17篇](https://www.comfyorg.cn/workflow/ai-stylistic)
    *   [![Image 37: ControlNet](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico21.png)Flux工作流 38篇](https://www.comfyorg.cn/workflow/ai-flux)
    *   [![Image 38: 音视频](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico22.png)音视频 60篇](https://www.comfyorg.cn/workflow/audio-video)
    *   [![Image 39: 人像摄影](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico23.png)人像摄影 29篇](https://www.comfyorg.cn/workflow/ai-photography)
    *   [![Image 40: 实用工具](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico24.png)实用工具 41篇](https://www.comfyorg.cn/workflow/utilities)
    *   [![Image 41: 高级工作流（商用）](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico25.png)高级工作流（商用） 11篇](https://www.comfyorg.cn/workflow/advanced-workflow)

*   [插件](https://www.comfyorg.cn/chajian)
    *   [![Image 42: 基础插件](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico30.png)基础插件 40篇](https://www.comfyorg.cn/chajian/basicplugins)
    *   [![Image 43: 提示词插件](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico31.png)提示词插件 11篇](https://www.comfyorg.cn/chajian/promptplugin)
    *   [![Image 44: ControlNet](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico21.png)ControlNet 11篇](https://www.comfyorg.cn/chajian/controlnetplug)
    *   [![Image 45: 图片插件](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico33.png)图片插件 35篇](https://www.comfyorg.cn/chajian/imgplug)
    *   [![Image 46: 视频插件](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico34.png)视频插件 42篇](https://www.comfyorg.cn/chajian/videoplug)
    *   [![Image 47: Flux插件](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico32.png)Flux插件 18篇](https://www.comfyorg.cn/chajian/fluxplugin)
    *   [![Image 48: 3D插件](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico35.png)3D插件 2篇](https://www.comfyorg.cn/chajian/3dplug)
    *   [![Image 49: 其他插件](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico36.png)其他插件 32篇](https://www.comfyorg.cn/chajian/otherplugins)

*   [自学课程](https://www.comfyorg.cn/tutorial)
    *   [![Image 50: 基础教程](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico26.png)基础教程 27篇](https://www.comfyorg.cn/tutorial/basic)
    *   [![Image 51: 进阶教程](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico27.png)进阶教程 27篇](https://www.comfyorg.cn/tutorial/advanced)
    *   [![Image 52: 高级教程](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico28.png)高级教程 8篇](https://www.comfyorg.cn/tutorial/gaoji)
    *   [![Image 53: 其他](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico29.png)其他 9篇](https://www.comfyorg.cn/tutorial/yqt)

*   [视频教程](https://www.comfyorg.cn/videojc)
*   [更多](https://www.comfyorg.cn/3248.html#)
    *   [![Image 54: 模型排行榜](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico15.png)站长运维 6篇](https://www.comfyorg.cn/kjqy/zzyw)
    *   [![Image 55: 模型排行榜](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico15.png)模型排行榜](https://www.comfyorg.cn/document/2371.html)
    *   [![Image 56: 疑难解答](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/ico41.png)疑难解答](https://www.comfyorg.cn/ask)

[投稿](javascript:void(0))

# 小白泪目！这个插件让ComfyUI界面全中文化，从此告别语言障碍！（纯干货，建议收藏）

*   [基础插件](https://www.comfyorg.cn/chajian/basicplugins)[基础教程](https://www.comfyorg.cn/tutorial/basic) 
*   3 个月前

前往下载

[](https://www.comfyorg.cn/users/1)

![Image 57](https://www.comfyorg.cn/wp-content/uploads/thumb/2025/06/fill_w120_h120_g0_mark_20250612030820830302.png)

**ComfyUI教程**免费资源

![Image 58](https://www.comfyorg.cn/wp-content/plugins/wp-opt/static/img/bot.svg)

AI摘要

 此内容由AI根据文章内容自动生成，并已由人工审核 

[AI助手](https://aigc.oagi.com.cn/)

DD-translate插件是最强ComfyUI汉化神器，专为解决官方汉化不全问题而设计。该插件由国内开

[看点别的 ![Image 59](https://www.comfyorg.cn/wp-content/plugins/wp-opt/static/img/next.svg)](https://www.comfyorg.cn/973.html)

刚接触ComfyUI的你，是不是经常面对这样的场景：

“这个新出的节点是干啥的？”

“官方汉化怎么这么多没翻译的？”

“右键菜单全是英文，点错了怎么办？”

别慌！今天我要分享一个最强汉化神器——DD-translate[插件](https://www.comfyorg.cn/tag/%e6%8f%92%e4%bb%b6 "View all posts in 插件")，让你彻底解决ComfyUI的语言障碍，学习效率翻倍！

![Image 60: 小白泪目！这个插件让ComfyUI界面全中文化，从此告别语言障碍！（纯干货，建议收藏）](https://www.comfyorg.cn/wp-content/uploads/2026/03/20260324032941229190.jpg)

### 为什么你需要DD-translate插件？

1. 官方汉化的局限性与旧版插件的终结

虽然ComfyUI官方已经支持中文，但官方汉化的速度明显跟不上插件的开发速度。很多新出的插件和节点没有及时汉化，给学习带来困难。

![Image 61: 3步出图！最新图片编辑模型BooGu：Boogu-Image-0.1生图模型硬刚Qwen](https://www.comfyorg.cn/wp-content/themes/b2/Assets/fontend/images/default-img.jpg)

 之前流行的“AIGODLIKE-ComfyUI-Translation”插件在2025年3月已经停止了更新维护，原因是ComfyUI官方自己推出了汉化功能。但官方汉化覆盖不全的问题依然存在。

**2. DD-translate的诞生**

ComfyUI-DD-Translation是一个专门为ComfyUI设计的多语言翻译插件，由国内开发者Dontdrunk维护。它实现了对常驻菜单栏、搜索栏、右键上下文菜单、节点等的全面翻译。

![Image 62: 3步出图！最新图片编辑模型BooGu：Boogu-Image-0.1生图模型硬刚Qwen](https://www.comfyorg.cn/wp-content/themes/b2/Assets/fontend/images/default-img.jpg)

 看看作者自己的说法：

![Image 63: 3步出图！最新图片编辑模型BooGu：Boogu-Image-0.1生图模型硬刚Qwen](https://www.comfyorg.cn/wp-content/themes/b2/Assets/fontend/images/default-img.jpg)

**安装前的重要提醒！**

⚠️ 重要警告：DD-translate插件与旧版的“AIGODLIKE-ComfyUI-Translation”并不兼容。所以在安装DD-translate之前，一定要先卸载旧版的“AIGODLIKE-ComfyUI-Translation”！卸载步骤如下：

1. 进入ComfyUI安装目录下的custom_nodes文件夹

 2.找到并删除AIGODLIKE-ComfyUI-Translation文件夹

 3. 重启ComfyUI

**1.手把手教你实现中文自由！**

*   通过Comfyui管理器直接搜索“DD-”（或者全称）

![Image 64: 3步出图！最新图片编辑模型BooGu：Boogu-Image-0.1生图模型硬刚Qwen](https://www.comfyorg.cn/wp-content/themes/b2/Assets/fontend/images/default-img.jpg)下拉菜单中找到对应插件，然后点击安装即可（我已经安装了，所以这里无“安装”选项）。

![Image 65: 3步出图！最新图片编辑模型BooGu：Boogu-Image-0.1生图模型硬刚Qwen](https://www.comfyorg.cn/wp-content/themes/b2/Assets/fontend/images/default-img.jpg)

安装完成后重启Comfyui即可。

### 02直接从网上下载安装

打开插件下载地址：[https://github.com/Dontdrunk/ComfyUI-DD-Translation](https://www.comfyorg.cn/url?url=aHR0cHM6Ly9naXRodWIuY29tL0RvbnRkcnVuay9Db21meVVJLURELVRyYW5zbGF0aW9u)

下载压缩包到本地

![Image 66: 3步出图！最新图片编辑模型BooGu：Boogu-Image-0.1生图模型硬刚Qwen](https://www.comfyorg.cn/wp-content/themes/b2/Assets/fontend/images/default-img.jpg)

解压压缩包，并将整个文件夹放入 ComfyUI 的 custom_nodes 目录下

![Image 67: 3步出图！最新图片编辑模型BooGu：Boogu-Image-0.1生图模型硬刚Qwen](https://www.comfyorg.cn/wp-content/themes/b2/Assets/fontend/images/default-img.jpg)

安装完成后重启Comfyui即可。

如果对于插件安装有疑问可以查询以往文章：[https://www.comfyorg.cn/2885.html](https://www.comfyorg.cn/2885.html)

温馨提示：本站提供的一切软件、教程和内容信息都来自网络收集整理，仅限用于学习和研究目的；不得将上述内容用于商业或者非法用途，否则，一切后果请用户自负，版权争议与本站无关。在未征得本站同意时，禁止复制、盗用、采集、发布本站内容到任何网站、书籍等各类媒体平台。如若本站内容侵犯了原著者的合法权益，可联系我们进行处理。

给TA打赏

共人

**海报分享****收藏**

[插件](https://www.comfyorg.cn/tag/%e6%8f%92%e4%bb%b6)

 1 条回复 **A**_文章作者_**M**_管理员_

您必须登录或注册以后才能发表评论

登录

![Image 68](https://www.comfyorg.cn/wp-content/themes/b2/Assets/fontend/images/default-avatar.png)

欢迎您，新朋友，感谢参与互动！

确认修改

细 中 粗

😁😊😎😤😥😂😍😏😙😟😖😜😱😲😭😚💀👻👍💪👊

取消回复 提交

1.   ![Image 69: 3步出图！最新图片编辑模型BooGu：Boogu-Image-0.1生图模型硬刚Qwen](https://www.comfyorg.cn/wp-content/themes/b2/Assets/fontend/images/default-img.jpg)[www](https://www.comfyorg.cn/users/4528)**学前班**_lv0_  1 个月前  汉化插件链接没有了  置顶 回复       

1/1 页 前往 

❮❯

## 关于作者 关注 私信

![Image 70](https://www.comfyorg.cn/wp-content/uploads/thumb/2025/06/fill_w192_h192_g0_mark_20250612030820830302.png)

[](https://www.comfyorg.cn/users/1)
ComfyUI教程

**博导**_lv7_**永久会员**

文章

291

评论

106

关注

0

粉丝

198

[[文章] 3步出图！最新图片编辑模型BooGu：Boogu-Image-0.1生图模型硬刚Qwen](https://www.comfyorg.cn/3529.html)

[[文章] Bernini：全能Wan视频编辑与生成模型，AI视频编辑先理解再动手](https://www.comfyorg.cn/3521.html)

[[文章] Krea2 Turbo模型：多风格生成工作流，人像效果足以撼动Z-Image人像王座的最新模型](https://www.comfyorg.cn/3502.html)

[[文章] 清华团队开源SCAIL-2： 动作转移、分段队列换装、人物替换多角色+动物全支持](https://www.comfyorg.cn/3497.html)

[Ta的全部动态](https://www.comfyorg.cn/tastream/1)

*   [](https://www.comfyorg.cn/3248.html#)[](https://www.comfyorg.cn/3248.html#)   
*   [](https://www.comfyorg.cn/3248.html#)[](https://www.comfyorg.cn/3248.html#)   
*   [](https://www.comfyorg.cn/3248.html#)[](https://www.comfyorg.cn/3248.html#)   
*   [](https://www.comfyorg.cn/3248.html#)[](https://www.comfyorg.cn/3248.html#)   
*   [](https://www.comfyorg.cn/3248.html#)[](https://www.comfyorg.cn/3248.html#)   
*   [](https://www.comfyorg.cn/3248.html#)[](https://www.comfyorg.cn/3248.html#)   

[签到排行](https://www.comfyorg.cn/mission)

## 猜你喜欢

*   TOP1 ![Image 71: 清华团队开源SCAIL-2： 动作转移、分段队列换装、人物替换多角色+动物全支持](https://www.comfyorg.cn/wp-content/uploads/thumb/2026/06/fill_w100_h62_g0_mark_20260621142134698333.jpg) ## 清华团队开源SCAIL-2： 动作转移、分段队列换装、人物替换多角色+动物全支持

3 周前  [](https://www.comfyorg.cn/3497.html)
*   TOP2 ![Image 72: Krea2 Turbo模型：多风格生成工作流，人像效果足以撼动Z-Image人像王座的最新模型](https://www.comfyorg.cn/wp-content/uploads/thumb/2026/06/fill_w100_h62_g0_mark_20260629140138899269.png) ## Krea2 Turbo模型：多风格生成工作流，人像效果足以撼动Z-Image人像王座的最新模型

2 周前  [](https://www.comfyorg.cn/3502.html)
*   TOP3 ![Image 73: Bernini：全能Wan视频编辑与生成模型，AI视频编辑先理解再动手](https://www.comfyorg.cn/wp-content/uploads/thumb/2026/07/fill_w100_h62_g0_mark_20260705052219113732.jpg) ## Bernini：全能Wan视频编辑与生成模型，AI视频编辑先理解再动手

1 周前  [](https://www.comfyorg.cn/3521.html)
*   ![Image 74: 3步出图！最新图片编辑模型BooGu：Boogu-Image-0.1生图模型硬刚Qwen](https://www.comfyorg.cn/wp-content/themes/b2/Assets/fontend/images/default-img.jpg) ## 3步出图！最新图片编辑模型BooGu：Boogu-Image-0.1生图模型硬刚Qwen

3 天前  [](https://www.comfyorg.cn/3529.html)

×

![Image 75](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/logo.png)

使用邀请码，您将获得一份特殊的礼物！

请输入邀请码

[获取邀请码](https://www.comfyorg.cn/3248.html#)

**跳过**提交

**登录**

**可爱的昵称** **登录邮箱**
用作登录：字母或数字的组合，最少6位字符

用作登录

 **验证码****发送验证码** **密码** **重复新密码**
最少6位字符

 

快速登录

[忘记密码？](javascript:void(0))新用户？[注册](javascript:void(0))

社交登录:

## 请输入验证码

请输入图片中的验证码

点击发送按钮获取验证码

[取消](javascript:void(0))发送

![Image 76](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/logo.png)

×

搜索一下可能来得更快

搜索

![Image 77](https://www.comfyorg.cn/3248.html)

×

取消 发送

×

![Image 78](https://www.comfyorg.cn/3248.html)

￥undefined

请打开手机使用 微信 扫码支付

「」

×

## ....支付确认中....

「」

×

支付金额

_￥_

请输入金额

 undefined 

×

 积分支付 

您当前的积分为 0

 您当前的积分不足，请 [购买积分](https://www.comfyorg.cn/gold/credit)

支付

检测到您未绑定微信账户，请先绑定微信

[立刻绑定](https://www.comfyorg.cn/3248.html)

[确定](javascript:void(0))

![Image 79](https://www.comfyorg.cn/wp-content/themes/b2/Assets/images/logo.png)

×

使用邀请码，您将获得一份特殊的礼物！

请输入邀请码

[获取邀请码](https://www.comfyorg.cn/3248.html#)

**跳过**提交

打开微信扫一扫

扫码并「关注我们的公众号」安全快捷登录

×

![Image 80](https://www.comfyorg.cn/3248.html)

为了确保您的账户安全

请您设置一个**登录用户名**和密码

**登录用户名**
请填写您的的登录用户名

 **验证码****发送验证码** **密码**
最少6位字符

 

提交

×

分享到：

微博 QQ好友 QQ空间

下载海报：

海报创建中

个人中心

购物车

优惠劵

今日签到

私信列表

搜索

客服

*   ![Image 81](blob:http://localhost/af8ea51cfc79994dbe188c2d6c5e232a)
扫码打开当前页

返回顶部

Copyright © 2026[ComfyUI资源网](https://www.comfyorg.cn/)

 本站已稳定运行：603 天 18 时 35 分 56 秒

 查询 85 次，耗时 0.1022 秒 

[**首页**](https://www.comfyorg.cn/)[**专题**](https://www.comfyorg.cn/collection)[**认证**](https://www.comfyorg.cn/verify)

[**搜索**](javascript:void(0))[**菜单**](javascript:void(0))[**我的**](javascript:void(0))

发布文章

创建圈子

发表话题

提交工单
