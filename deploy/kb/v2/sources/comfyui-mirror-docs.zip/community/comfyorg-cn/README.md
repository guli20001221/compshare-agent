# comfyorg.cn 中文 ComfyUI 教程补充

这些文章是对官方文档的中文实操补充，不替代官方来源。

- `core/`：工作流、界面、插件、模型安装和常用基础操作。
- `compatibility-reference/`：Windows 环境、WebUI 共享模型、Git、虚拟内存和中文界面等兼容性参考。

已排除 Nano Banana 推广、白嫖网站、模型排行榜和时效性较强的商业推荐内容。
