# 优云智算模型套餐FAQ

# 新版模型套餐FAQ

### 套餐包规格及扣除模式

Coding Plan套餐包采用按量扣费形式，不同套餐包对应不同的5小时、周度、月度用量

![image\.png](图片和附件/image%201.png)

### 套餐包已支持模型及计次规则

- 支持套餐：订阅套餐包含以下模型的调用权限，模型列表及调用次数倍率会根据官方 API 的更新而动态调整。

- 套餐用尽：套餐到期或额度耗尽后停止服务，如需继续使用，可升级套餐或切换至按量计费（按量需更换API Key 及 Base URL）。

- 调用次数：

    - 调用次数指一次接口调用请求。不同工具在处理任务的时候会调用多次接口来完成你的一整个任务，因此会产生一次输入多次调用的情况。

    - 不同套餐包对应的调用并发不同（Lite\-3并发、Pro\-5并发），如果工具并发调用超过上限，会有并发限制。

### BaseURL及API Key

新套餐包采用独立的 BaseURL 及 API Key 

- BaseURL（兼容OpenAI与Anthropic）：https://cp\.compshare\.cn

    - openclaw/hermes/opencode/cursor/copilot等配置：https://cp\.compshare\.cn/v1

    - claudecode配置：https://cp\.compshare\.cn

    - trea配置：https://cp\.compshare\.cn/v1/chat/completions

- API Key：套餐管理 \- [获取API Key](https://console.compshare.cn/light-gpu/model-manage) 

注意：如遇401报错，一般是配置不对，请检查baseurl和apikey

![image\.png](图片和附件/image%208.png)

### 各客户端配置指南

#### Cursor

![image\.png](图片和附件/image%206.png)

#### Trae

![企业微信截图\_4ac12011\-09e7\-4fa6\-a304\-b75d6f7246ad\.png](图片和附件/企业微信截图_4ac12011-09e7-4fa6-a304-b75d6f7246ad.png)

![usecase5\.png](图片和附件/usecase5.png)

#### Claude Code

通过CC Switch配置，注意请求地址为：https://cp\.compshare\.cn

![image\.png](图片和附件/image%2010.png)

直接修改setting\.json文件

```JSON
{
  "env": {
    "ANTHROPIC_BASE_URL": "https://cp.compshare.cn",
    "ANTHROPIC_AUTH_TOKEN": "你的套餐API key",
    "ANTHROPIC_MODEL": "deepseek-v4-pro",
    "ANTHROPIC_DEFAULT_HAIKU_MODEL": "deepseek-v4-pro",
    "ANTHROPIC_DEFAULT_SONNET_MODEL": "deepseek-v4-pro",
    "CLAUDE_CODE_DISABLE_EXPERIMENTAL_BETAS": "1",
    "ANTHROPIC_DEFAULT_OPUS_MODEL": "deepseek-v4-pro",
    "ANTHROPIC_REASONING_MODEL": "deepseek-v4-pro"
  },
  "autoUpdatesChannel": "latest"
}
```

#### OpenClaw

![image\.png](图片和附件/image%209.png)

#### Hermes

输入指令进入hermes模型配置，选择custom endpoint，然后按图示配置

```Plain Text
hermes model
```

![image\.png](图片和附件/image%205.png)

#### OpenCode

打开opencode\.json文件，根据需求模型修改配置，并覆盖粘贴保存

```Bash
{
  "$schema": "https://opencode.ai/config.json",
  "provider": {
    "compshare": {
      "npm": "@ai-sdk/openai-compatible",
      "name": "compshare",
      "options": {
        "baseURL": "https://cp.compshare.cn/v1",
        "apiKey": "your-api-key",
      },
      "models": {
        "glm-5.1": {
          "name": "glm-5.1",
        }
      }
    }
  }
}
```



# ~~旧版模型套餐（已下线）~~

### 目前套餐内支持哪些模型

目前套餐内支持模型如下，请求模型名字即可，更多模型陆续支持中

4\.15更新：codex官方已下架模型gpt\-5\.2\-codex、gpt\-5\.1\-codex\-mini、gpt\-5\.1\-codex\-max、gpt\-5\.1\-codex、gpt\-5\.1、gpt\-5，套餐已不支持，请悉知；

```Plain Text
MiniMax-M2.1
MiniMax-M2.5
moonshotai/kimi-k2.5
zai-org/glm-5
gpt-5.2-codex
gpt-5.3-codex
gpt-5.4
claude-opus-4-6
claude-sonnet-4-6
claude-haiku-4-5-20251001
claude-opus-4-5-20251101
claude-sonnet-4-5-20250929
deepseek-ai/DeepSeek-V3.2
```

### 积分和token的换算关系

积分额度 = 输入Token x 输入倍率 ＋ 缓存创建Token x 缓存创建倍率 ＋ 缓存命中倍率 x 缓存命中Token \+ 输出倍率 x 输出Token

claude等部分模型倍率较高，在OpenClaw等Agent工具中请谨慎使用

套餐支持的模型ID及倍率

### 多个包的抵扣顺序

- 每次 API 调用消耗积分时，扣除顺序为：**包月套餐包 \>  按量套餐包（按量包/积分包）**

- 如果你同时购买了多个按量包：按**最先到期**的按量包优先扣除

- 目前包月有三种档位：

    - 如果购买了多个包月的套餐包，优先扣价格低的包月套餐

    - 每多买 1 个同套餐的包月，**有效期叠加 30 天**（相当于续期）

    - 包月为**每日固定上限的积分额度**，并在**每天 0 点刷新**当日额度

### 如果需要的模型不在套餐内怎么办

请求不在套餐内的模型，会正常按照使用量扣费，不走套餐逻辑，具体见按量计费说明https://www\.compshare\.cn/docs/modelverse/price

全部模型列表：[模型lD列表](https://compshare.feishu.cn/wiki/HmNdwaFtyirdXkkM6XFcNsxlnMd)

配置时请仔细检查调用模型名称，以防调用套餐外模型产生大额扣费情况

（后续会区分套餐和按量的API请求，做到两种计费模式的隔离）

### 目前能在哪些工具中使用

支持Claude Code、OpenCode、OpenClaw、Cline、Kilo Code、Codex CLI 等主流编程工具（TRAE暂不支持），同时支持CherryStudio等Chatbot客户端，及API调用场景

### OpenClaw、CC中积分消耗较快

OpenClaw和CC等客户端中会嵌套较多的工具或agent，token用量相对较多，小套餐请谨慎使用

### OpenClaw、ClaudeCode及CodeX接入指南

> OpenClaw：https://www\.compshare\.cn/docs/modelverse/best\_practice/openclaw
> 
> Claude Code：https://www\.compshare\.cn/docs/modelverse/best\_practice/claudecode
> 
> OpenCode：https://www\.compshare\.cn/docs/modelverse/best\_practice/opencode
> 
> CodeX：https://www\.compshare\.cn/docs/modelverse/best\_practice/codex
> 
> 

### GPT 在部分工具中无法使用

GPT请求需要使用responses协议，协议类型需要在工具中修改为openai\-responses，部分工具调用示例如下

> CherryStudio：添加供应商时选择OpenAI\-Response，API地址填写https://api\.modelverse\.cn/v1 \(确保拼接后的地址为https://api\.modelverse\.cn/v1/responses\)，添加密钥即可
> 
> Kilo：选择OpenAI Compatible（Responses）
> 
> 

![image\.png](图片和附件/image%204.png)

![image\.png](图片和附件/image.png)

![image\.png](图片和附件/image%207.png)

> OpenClaw：openclaw启动后，在管理服务器中新开终端执行一下命令（Key需要更换为自己的，如使用其他非gpt模型，则将openai\-responses更换为openai\-completions）
> 
> 

```SQL
openclaw config set 'compshare' --json '{
  "baseUrl": "https://api.modelverse.cn/v1",
  "apiKey": "xxxxx",
  "api": "openai-responses",
  "models": [
    { "id": "gpt-5.2", "name": "gpt5.2" }
  ]
}'
```

> 其他js示例
> 
> 

```JSON
{
  "provider": "compshare",
  "base_url": "https://api.modelverse.cn/v1",
  "api": "openai-responses",
  "api_key": "your-api-key-here",
  "model": {
    "id": "gpt-5.2",
    "name": "GPT-5.2"
  }
}
```

### Claude在部分工具中无法使用

Claude请求需要选择Anthropic协议，部分工具调用示例如下

> CherryStudio：添加供应商时选择Anthropic，API地址填写https://api\.modelverse\.cn/，添加密钥即可（注意请求地址有变化，确保拼接后的请求地址为https://api\.modelverse\.cn/v1/messages）
> 
> Kilo：选择Anthropic，URL地址填写https://api\.modelverse\.cn/
> 
> ![image\.png](图片和附件/image%203.png)
> 
> ![image\.png](图片和附件/image%202.png)
> 
> ![image\.png](图片和附件/image%2011.png)
> 
> 

> OpenClaw：openclaw启动后，在管理服务器中新开终端执行一下命令（Key需要更换为自己的）
> 
> 

```SQL
openclaw config set 'compshare' --json '{
  "baseUrl": "https://api.modelverse.cn",
  "apiKey": "xxxxx",
  "api": "anthropic-messages",
  "models": [
    { "id": "claude-opus-4-5-20251101", "name": "claude4.5" }
  ]
}'
```

### 在OpenClaw中切换模型不生效

需要更换默认模型，或修改\.openclaw/openclaw\.json中的默认模型

### 如有其他问题，请在下方问卷中填写

[https://f.howxm.com/xs/u/Z2GO3UBD1NF5]()





